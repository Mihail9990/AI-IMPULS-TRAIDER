"""Deterministic, tick-driven paper trading engine. Contains ZERO broker trade calls.

All input timestamps are Unix milliseconds UTC; candles use BID; executions use ASK
for buys and BID for sells, exits in the opposite quote. Historical and live modes
both drive this exact same engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from math import ceil, floor, isfinite
from typing import Any, Optional


@dataclass(frozen=True)
class Settings:
    trigger_distance: float = 1.0
    tp_distance: float = 0.25
    sl_distance: float = 3.0
    tick_size: float = 0.01
    volume_lots: float = 0.10
    tick_value_per_lot: float = 0.0  # currency value of 1 tick for ONE lot; 0 = unknown
    commission_per_lot_roundtrip: float = 0.0
    # Opt-in: old saved projects stay in the original SL/TP mode after upgrade.
    recovery_enabled: bool = False
    # classic = existing RECOVERY v1.3.4; extreme = independent V2 algorithm.
    recovery_variant: str = 'classic'  # classic V1 | extreme V2 | fixed_flip V3
    # V2 independent price distances, each editable without changing classic.
    recovery_v2_initial_lots: float = 0.03
    recovery_v2_work_lots: float = 0.03
    recovery_v2_trigger_distance: float = 1.0
    recovery_v2_initial_tp_distance: float = 0.25
    recovery_v2_initial_sl_distance: float = 1.0
    recovery_v2_support_sl_distance: float = 1.0
    recovery_v2_trail_step: float = 0.10
    recovery_v2_reentry_offset: float = 0.50
    # Zero = preserve the original opposite entry exactly, no range cap.
    recovery_v2_opposite_max_range: float = 0.0
    # V3: TWO FIXED nominal STOP anchors (BUY / SELL), never modified by gaps.
    recovery_v3_initial_lots: float = 0.03
    recovery_v3_work_lots: float = 0.03
    recovery_v3_trigger_distance: float = 1.0
    recovery_v3_initial_tp_distance: float = 0.25
    recovery_v3_stop_gap: float = 1.50  # fixed SL distance AFTER recovery starts
    recovery_v3_initial_sl_distance: float = 4.0  # separate initial TP .25 position SL
    recovery_v3_partial_lots: float = 0.01  # one TP tranche; automatically divided
    recovery_v3_range_mode: str = 'fixed'  # fixed | alternating | once
    recovery_v3_expansion: float = 1.0  # outward extra beyond nominal SL
    volume_step_lots: float = 0.01  # populated from MT5 symbol specification
    volume_min_lots: float = 0.01

    recovery_core_lots: float = 0.01   # legacy v1.2, initial size matched to volume_lots
    recovery_reentry_lots: float = 0.12
    recovery_hedge_lots: float = 0.13  # legacy v1.2, unused in v1.3
    recovery_partial_stop_distance: float = 1.0  # LEGACY v1.2 (ignored by v1.3)
    recovery_trail_activation: float = 0.0  # legacy; 0.50 activation removed in v1.3.4
    recovery_trail_start_offset: float = 1.0  # support SL active immediately, 1 point behind entry
    recovery_trail_step: float = 0.10
    recovery_partial_lots: float = 0.03
    # Maximum gap between opposite BUY/SELL STOP levels in stepped RECOVERY.
    recovery_opposite_max_range: float = 3.0
    recovery_take_levels: tuple[float, float, float] = (1.0, 2.0, 3.0)

    def __post_init__(self):
        for name in ('trigger_distance', 'tp_distance', 'sl_distance', 'tick_size', 'volume_lots'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        for name in ('tick_value_per_lot', 'commission_per_lot_roundtrip'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n < 0:
                raise ValueError(f'{name} must be finite and >= 0')
        if not isinstance(self.recovery_enabled, bool):
            raise ValueError('recovery_enabled must be boolean')
        if self.recovery_variant not in ('classic','extreme','fixed_flip'):
            raise ValueError('Unknown RECOVERY variant')
        for name in ('recovery_v2_initial_lots','recovery_v2_work_lots',
                     'recovery_v2_trigger_distance','recovery_v2_initial_tp_distance',
                     'recovery_v2_initial_sl_distance','recovery_v2_support_sl_distance',
                     'recovery_v2_trail_step','recovery_v2_reentry_offset'):
            value=getattr(self,name)
            if not isinstance(value,(int,float)) or not isfinite(value) or value<=0:
                raise ValueError(f'{name} must be finite and positive')
        for name in ('recovery_v3_initial_lots','recovery_v3_work_lots',
                     'recovery_v3_trigger_distance','recovery_v3_initial_tp_distance',
                     'recovery_v3_stop_gap','recovery_v3_initial_sl_distance',
                     'recovery_v3_partial_lots','recovery_v3_expansion',
                     'volume_step_lots','volume_min_lots'):
            n=getattr(self,name)
            if not isinstance(n,(int,float)) or not isfinite(n) or n<=0:
                raise ValueError(f'{name} must be finite and positive')
        if self.recovery_v3_range_mode not in ('fixed','alternating','once'):
            raise ValueError('V3 range mode must be fixed, alternating or once')
        if self.recovery_enabled and self.recovery_variant=='fixed_flip':
            for v_name in ('recovery_v3_initial_lots','recovery_v3_work_lots','recovery_v3_partial_lots'):
                v=getattr(self,v_name)
                step=self.volume_step_lots
                if v<self.volume_min_lots-1e-8 or abs(v/step-round(v/step))>1e-7:
                    raise ValueError(f'V3 {v_name} must respect MT5 minimum/step of {self.volume_min_lots}/{step}')
            if self.recovery_v3_partial_lots>self.recovery_v3_work_lots+1e-8:
                raise ValueError('V3 TP part cannot exceed recovery position volume')
        if not isinstance(self.recovery_v2_opposite_max_range,(int,float)) or not isfinite(self.recovery_v2_opposite_max_range) or self.recovery_v2_opposite_max_range<0:
            raise ValueError('V2 maximum OCO range must be >= 0')

        # Kept for existing saved v1.3.x snapshots / API clients. The old +0.50
        # activation parameter is accepted but no longer used in calculations.
        if not isinstance(self.recovery_trail_activation,(int,float)) or not isfinite(self.recovery_trail_activation):
            raise ValueError('recovery_trail_activation must be finite')
        if self.recovery_trail_activation != 0.0:
            object.__setattr__(self,'recovery_trail_activation',0.0)
        for name in ('recovery_core_lots','recovery_reentry_lots',
                     'recovery_hedge_lots','recovery_partial_stop_distance',
                     'recovery_trail_start_offset',
                     'recovery_trail_step','recovery_partial_lots',
                     'recovery_opposite_max_range'):
            n = getattr(self,name)
            if not isinstance(n,(int,float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        if self.recovery_enabled and self.recovery_variant=='extreme':
            if abs(self.volume_lots-self.recovery_v2_initial_lots)>1e-8:
                raise ValueError('RECOVERY V2: initial lots and standard volume_lots must match')
            if self.commission_per_lot_roundtrip and not self.tick_value_per_lot:
                raise ValueError('V2 commission requires MT5 tick value')
        if self.recovery_enabled and self.recovery_variant=='fixed_flip':
            if abs(self.volume_lots-self.recovery_v3_initial_lots)>1e-8:
                raise ValueError('RECOVERY V3: initial lots and standard volume_lots must match')
            if self.commission_per_lot_roundtrip and not self.tick_value_per_lot:
                raise ValueError('RECOVERY V3 with commission requires MT5 tick value')
        if self.recovery_enabled and self.recovery_variant=='classic':
            if abs(self.volume_lots-self.recovery_core_lots)>1e-8:
                raise ValueError('RECOVERY: initial volume_lots must equal recovery_core_lots')
            if not (self.recovery_reentry_lots > 3*self.recovery_partial_lots+1e-8):
                raise ValueError('RECOVERY: volume must leave a positive runner after 3 partial TP tranches')
            if len(self.recovery_take_levels)!=3 or any(not isfinite(x) or x<=0 for x in self.recovery_take_levels):
                raise ValueError('RECOVERY: need 3 positive partial TP distances')
            if list(self.recovery_take_levels)!=sorted(set(self.recovery_take_levels)):
                raise ValueError('RECOVERY: partial TP levels must be increasing')
            if self.commission_per_lot_roundtrip and not self.tick_value_per_lot:
                raise ValueError('RECOVERY with commission requires positive tick_value_per_lot')


@dataclass(frozen=True)
class Tick:
    t_ms: int
    bid: float
    ask: float

    def __post_init__(self):
        if not isinstance(self.t_ms, int) or self.t_ms < 0:
            raise ValueError('Invalid timestamp')
        if not all(isfinite(x) and x > 0 for x in (self.bid, self.ask)) or self.ask < self.bid:
            raise ValueError('Invalid Bid/Ask quote')


@dataclass
class Candle:
    time: int  # minute start in UNIX seconds UTC
    open: float
    high: float
    low: float
    close: float
    ticks: int = 1

    @property
    def color(self) -> str:
        return 'BUY' if self.close > self.open else ('SELL' if self.close < self.open else 'DOJI')

    def on_tick(self, bid: float):
        self.high = max(self.high, bid)
        self.low = min(self.low, bid)
        self.close = bid
        self.ticks += 1


@dataclass
class Pending:
    side: str
    level: float
    created_ms: int
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str
    lots: Optional[float] = None  # None means configured default; old snapshots still load


@dataclass
class Position:
    side: str
    entry: float
    tp: float
    sl: float
    opened_ms: int
    trigger_level: float
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str
    entry_spread: float
    mfe: float = 0.0
    mae: float = 0.0
    lots: Optional[float] = None  # optional manual size on strategy-owned position


@dataclass
class RecoveryLeg:
    side: str
    entry: float
    lots: float
    opened_ms: int
    role: str
    stop: float
    tp: Optional[float] = None  # FIXED-TP first RECOVERY phase only
    peak_favorable: float = 0.0
    trail_step_index: int = -1  # -1 fixed SL; >=0 support SL active immediately in stepped mode
    next_take_index: int = 0
    # Best quote capable of triggering a fresh STOP on this side since this
    # actual fill: BUY uses ASK high, SELL uses BID low.  Retained in snapshots.
    best_trigger_quote: Optional[float] = None
    v3_tp_targets: list[dict] = field(default_factory=list)
    v3_nominal_entry: Optional[float] = None


@dataclass
class RecoveryState:
    started_ms: int
    origin: Position  # original position is already CLOSED at initial SL
    original_sl_exit: float
    buy_anchor: float
    sell_anchor: float
    active: Optional[RecoveryLeg]
    pending_stops: list[dict] = field(default_factory=list)
    # Closed initial loss and later realized recovery losses/profit.
    realized_weighted_points: float = 0.0
    realized_commission_money: float = 0.0
    partial_tps: int = 0
    fixed_tps: int = 0
    stepped_mode: bool = False  # Activate only after a RECOVERY 0.12 SL
    recovery_sls: int = 0
    reentries: int = 0
    max_loss_points: float = 0.0
    actions: list[dict] = field(default_factory=list)
    truncated_actions: int = 0
    # Which side last established the priority same-side re-entry anchor.
    anchor_priority_side: str = "SELL"
    # V2 records the first BUY and SELL entry levels forever within its cycle.
    variant: str = 'classic'
    original_buy_anchor: Optional[float] = None
    original_sell_anchor: Optional[float] = None
    # V3 flip index counts RECOVERY-to-RECOVERY switches (not initial SL).
    v3_flip_count: int = 0
    v3_last_nominal: Optional[float] = None
    v3_next_nominal: Optional[float] = None


@dataclass
class ManualPosition:
    id: int
    side: str
    entry: float
    lots: float
    opened_ms: int
    entry_spread: float


@dataclass
class ManualStop:
    id: int
    side: str
    level: float
    lots: float
    created_ms: int
    armed: bool


class PaperEngine:
    def __init__(self, settings: Settings = Settings()):
        self.settings = settings
        self.mode = 'stopped'  # stopped | running | stopping
        self.arm_minute: Optional[int] = None
        self.candle: Optional[Candle] = None
        self.candles: list[dict] = []
        self.pending: Optional[Pending] = None
        self.position: Optional[Position] = None
        self.recovery: Optional[RecoveryState] = None
        # Separate, explicitly requested PAPER manual positions/orders.
        # Never transmitted to MT5; they do not alter automatic RECOVERY debt.
        self.manual_positions: list[ManualPosition] = []
        self.manual_stops: list[ManualStop] = []
        self.manual_seq = 0
        self.recovery_activations = 0
        self.recovery_completed = 0
        self.recovery_partial_stops = 0  # retained in JSON for compatibility: counts RECOVERY SLs
        self.recovery_partial_tps = 0
        self.recovery_fixed_tps = 0
        self.recovery_reentries = 0
        self.recovery_sls = 0
        self.recovery_aborted = 0
        self.realized_cycle_points = 0.0
        self.max_active_recovery_loss_points = 0.0
        self.equity_peak_points = 0.0
        self.max_equity_drawdown_points = 0.0
        self.min_equity_points = 0.0
        self.latest: Optional[Tick] = None
        self.last_tick_signature: Optional[tuple] = None
        self.trade_seq = 0
        self.order_seq = 0
        self.trades: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.new_trades: list[dict[str, Any]] = []
        self.new_events: list[dict[str, Any]] = []
        self.canceled_orders = 0
        self.placed_orders = 0
        self.triggered_orders = 0
        self.skipped_invalid = 0
        self.tick_count = 0
        self.first_tick_ms: Optional[int] = None
        self.max_tick_gap_ms = 0

    def _level(self, p: float, higher: bool) -> float:
        """Snap protective/entry target outward to the symbol's tick grid."""
        tick = self.settings.tick_size
        scale = p / tick
        snapped = (ceil(scale - 1e-8) if higher else floor(scale + 1e-8)) * tick
        return round(snapped, 10)

    def _event(self, t_ms: int, typ: str, **extra):
        row = dict(t_ms=t_ms, type=typ, **extra)
        self.events.append(row)
        self.new_events.append(row)
        if len(self.events) > 250:
            self.events = self.events[-250:]

    def start(self) -> None:
        if self.mode != 'stopped':
            raise ValueError('Session is already running')
        self.mode = 'running'
        self.arm_minute = self.candle.time if self.candle else None
        self.pending = None
        self.position = None
        self.recovery = None
        self._event(self.latest.t_ms if self.latest else 0, 'start')

    def request_stop(self) -> None:
        """Finish the existing cycle (including waiting for a pending trigger)."""
        if self.mode == 'running':
            if self.pending is None and self.position is None and self.recovery is None:
                self.mode = 'stopped'
            else:
                self.mode = 'stopping'
            self._event(self.latest.t_ms if self.latest else 0, 'stop_requested')

    def force_stop(self) -> None:
        """Abandon virtual pending/position (not an SL/TP)."""
        if self.pending:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_cancel', side=self.pending.side, price=self.pending.level)
        if self.recovery and self.latest:
            # Aborted simulated baskets must be accounted as losses, not erased.
            self._end_recovery(self.latest, 'ABORTED')
            self.recovery_aborted += 1
        elif self.position:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_abandon', side=self.position.side, price=self.position.entry)
        self.mode = 'stopped'
        self.pending = None
        self.position = None
        self.recovery = None
        self._event(self.latest.t_ms if self.latest else 0, 'forced_stop')

    def _create_pending(self, bar: Candle, t_ms: int):
        side = bar.color
        if side == 'DOJI':
            return
        variant=self.settings.recovery_variant if self.settings.recovery_enabled else 'classic'
        delta = (self.settings.recovery_v2_trigger_distance if variant=='extreme' else
                 self.settings.recovery_v3_trigger_distance if variant=='fixed_flip' else
                 self.settings.trigger_distance)
        level = self._level(bar.close + delta if side == 'BUY' else bar.close - delta, side == 'BUY')
        if self.pending and self.pending.side == side:
            return
        if self.pending:
            self.canceled_orders += 1
            self._event(t_ms, 'cancel', side=self.pending.side, price=self.pending.level,
                        reason='opposite_closed_candle')
        self.pending = Pending(side, level, t_ms, bar.time, abs(bar.close-bar.open),
                               bar.high-bar.low, side)
        self.placed_orders += 1
        self.order_seq += 1
        self._event(t_ms, 'place', side=side, price=level, signal_time=bar.time)

    def _finish_bar(self, bar: Candle, t_ms: int):
        self.candles.append(asdict(bar))
        if len(self.candles) > 750:
            self.candles = self.candles[-750:]
        if self.mode in ('running', 'stopping') and self.position is None and self.recovery is None:
            if self.arm_minute is not None and bar.time < self.arm_minute:
                return
            self._create_pending(bar, t_ms)

    def _fill(self, tick: Tick):
        p = self.pending
        if p is None:
            return
        variant=self.settings.recovery_variant if self.settings.recovery_enabled else 'classic'
        tp_distance=(self.settings.recovery_v2_initial_tp_distance if variant=='extreme' else
                     self.settings.recovery_v3_initial_tp_distance if variant=='fixed_flip' else
                     self.settings.tp_distance)
        sl_distance=(self.settings.recovery_v2_initial_sl_distance if variant=='extreme' else
                     self.settings.recovery_v3_initial_sl_distance if variant=='fixed_flip' else
                     self.settings.sl_distance)
        if p.side == 'BUY':
            if tick.ask < p.level:
                return
            fill = max(p.level, tick.ask)  # adverse gap/trigger slippage
            tp = self._level(fill + tp_distance, True)
            sl = self._level(fill - sl_distance, False)
        else:
            if tick.bid > p.level:
                return
            fill = min(p.level, tick.bid)
            tp = self._level(fill - tp_distance, False)
            sl = self._level(fill + sl_distance, True)
        self.position = Position(p.side, fill, tp, sl, tick.t_ms, p.level, p.signal_time,
                                 p.signal_body, p.signal_range, p.signal_color,
                                 tick.ask - tick.bid, lots=p.lots or self.settings.volume_lots)
        self.pending = None
        self.triggered_orders += 1
        self._event(tick.t_ms, 'fill', side=p.side, price=fill, trigger_level=p.level,
                    tp=tp, sl=sl, spread=tick.ask-tick.bid)

    def _position_lots(self, pos: Position) -> float:
        return pos.lots if pos.lots is not None else self.settings.volume_lots

    def _position_tick(self, tick: Tick):
        pos = self.position
        if pos is None:
            return
        if self.recovery is not None:
            self._recovery_tick(tick)
            return
        if self.settings.recovery_enabled:
            self._pre_recovery_tick(tick)
            return
        # Mark to market on the quote that actually CLOSES the position.
        exit_quote = tick.bid if pos.side == 'BUY' else tick.ask
        move = exit_quote - pos.entry if pos.side == 'BUY' else pos.entry - exit_quote
        pos.mfe = max(pos.mfe, move)
        pos.mae = max(pos.mae, -move)
        if pos.side == 'BUY':
            result = 'SL' if tick.bid <= pos.sl else ('TP' if tick.bid >= pos.tp else None)
            exit_price = min(pos.sl, tick.bid) if result == 'SL' else pos.tp
        else:
            result = 'SL' if tick.ask >= pos.sl else ('TP' if tick.ask <= pos.tp else None)
            exit_price = max(pos.sl, tick.ask) if result == 'SL' else pos.tp
        if result is None:
            return
        raw_move = exit_price - pos.entry if pos.side == 'BUY' else pos.entry - exit_price
        lots = self._position_lots(pos)
        points = raw_move * lots / self.settings.volume_lots
        gap_to_tp = max(0.0, abs(pos.tp-pos.entry)-pos.mfe)
        money = None
        if self.settings.tick_value_per_lot > 0:
            money = (raw_move/self.settings.tick_size*self.settings.tick_value_per_lot
                     - self.settings.commission_per_lot_roundtrip) * lots
        self.trade_seq += 1
        trade = dict(
            id=self.trade_seq, side=pos.side, result=result, opened_ms=pos.opened_ms,
            closed_ms=tick.t_ms, entry=pos.entry, exit=round(exit_price, 10),
            tp=pos.tp, sl=pos.sl, trigger_level=pos.trigger_level,
            pnl_points=round(points, 10), pnl_money_est=round(money, 5) if money is not None else None,
            mfe_points=round(pos.mfe, 10), mae_points=round(pos.mae, 10),
            gap_to_tp=round(gap_to_tp, 10), duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
            signal_time=pos.signal_time, signal_body=round(pos.signal_body, 6),
            signal_range=round(pos.signal_range, 6), signal_color=pos.signal_color,
            spread_at_entry=round(pos.entry_spread, 10),lots=lots,
            entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000, timezone.utc).hour,
        )
        self.trades.append(trade)
        self.new_trades.append(trade)
        self.realized_cycle_points += trade['pnl_points']
        self._event(tick.t_ms, result.lower(), side=pos.side, price=exit_price, trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'], gap_to_tp=trade['gap_to_tp'])
        self.position = None
        self._next_cycle_after_close(tick)

    def _manual_quantity(self,lots:float):
        if not isinstance(lots,(int,float)) or not isfinite(lots) or lots<=0 or lots>100:
            raise ValueError('Invalid virtual lot size')
        # XAUUSD.s standard minimum volume/step; the service also validates
        # against the actual MT5 symbol metadata, without placing any orders.
        if abs(round(lots*100)-lots*100)>1e-7:
            raise ValueError('Lot size must be multiple of 0.01')

    def strategy_manual_open(self, side: str, lots: float,
                             order_type: str = 'MARKET',
                             level: Optional[float] = None):
        """Manually intervene in the ACTIVE paper strategy, not a second portfolio.

        On initial phase a MARKET fill is handled by ordinary TP/SL/RECOVERY.
        In the RECOVERY phase manual MARKET fills inherit first fixed TP or
        stepped trailing support/partials. OCO STOP anchors stay managed by
        the same tick engine. No broker order API is reachable here.
        """
        self._manual_quantity(lots)
        if side not in ('BUY', 'SELL') or order_type not in ('MARKET','STOP'):
            raise ValueError('Invalid direction or virtual order type')
        tick=self.latest
        if tick is None:raise ValueError('Нет котировки Bid/Ask')
        if self.mode=='stopping':
            raise ValueError('Цикл завершается. Дождись завершения или запусти новый.')
        if self.position or (self.recovery and self.recovery.active):
            raise ValueError('Сначала закрой текущую виртуальную позицию; нельзя открыть вторую в том же цикле.')
        snapped=None
        if order_type=='STOP':
            if not isinstance(level,(float,int)) or not isfinite(level) or level<=0:
                raise ValueError('Нужна корректная цена STOP')
            snapped=self._level(level,side=='BUY')
            if (side=='BUY' and snapped<=tick.ask or side=='SELL' and snapped>=tick.bid):
                raise ValueError('BUY STOP должен быть выше Ask; SELL STOP ниже Bid')
        # Avoid modifications before validating role and size.
        r=self.recovery
        if r:
            first_v2=(r.variant=='extreme' and not r.reentries and not r.recovery_sls
                      and not r.active and len(r.pending_stops)==1)
            if first_v2 and side!=('SELL' if r.origin.side=='BUY' else 'BUY'):
                raise ValueError('Первая RECOVERY V2 должна быть противоположна исходной позиции')
            if r.variant=='classic' and not r.stepped_mode and side!=('SELL' if r.origin.side=='BUY' else 'BUY'):
                raise ValueError('Первый RECOVERY: разрешено только противоположное исходной позиции направление')
            if r.variant=='classic' and r.stepped_mode and lots<=3*self.settings.recovery_partial_lots+1e-8:
                raise ValueError('Для ступенчатого RECOVERY лот должен оставлять объём после трёх частичных TP')
        if self.mode=='stopped':
            self.start()  # initial manual entry also starts the standard strategy lifecycle
        if r is None:
            # Entire standard pending STOP, if present, is replaced. A later
            # opposite closed candle can still cancel the manually set STOP.
            if self.pending:
                self.canceled_orders+=1
                self._event(tick.t_ms,'manual_cancel_prior_stop',side=self.pending.side,
                            price=self.pending.level)
                self.pending=None
            if order_type=='STOP':
                self.pending=Pending(side,snapped,tick.t_ms,
                                     self.candle.time if self.candle else 0,
                                     0.0,0.0,'MANUAL',lots=round(lots,8))
                self.placed_orders+=1;self.order_seq+=1
                self._event(tick.t_ms,'manual_strategy_stop',side=side,price=snapped,lots=lots)
                return
            entry=tick.ask if side=='BUY' else tick.bid
            variant=self.settings.recovery_variant if self.settings.recovery_enabled else 'classic'
            d_tp=(self.settings.recovery_v2_initial_tp_distance if variant=='extreme' else
                  self.settings.recovery_v3_initial_tp_distance if variant=='fixed_flip' else self.settings.tp_distance)
            d_sl=(self.settings.recovery_v2_initial_sl_distance if variant=='extreme' else
                  self.settings.recovery_v3_initial_sl_distance if variant=='fixed_flip' else self.settings.sl_distance)
            tp=self._level(entry+d_tp if side=='BUY' else entry-d_tp,side=='BUY')
            sl=self._level(entry-d_sl if side=='BUY' else entry+d_sl,side=='SELL')
            self.position=Position(side,entry,tp,sl,tick.t_ms,entry,
                                   self.candle.time if self.candle else 0,
                                   0.0,0.0,'MANUAL',tick.ask-tick.bid,
                                   lots=round(lots,8))
            self._event(tick.t_ms,'manual_strategy_market',side=side,price=entry,
                        lots=lots,tp=tp,sl=sl,phase='initial')
            return
        if r.variant=='fixed_flip':
            if order_type=='STOP':
                self.move_trigger('recovery',snapped,side)
                r.pending_stops=[dict(side=side,level=snapped,lots=round(lots,8),
                    armed=(tick.ask<snapped if side=='BUY' else tick.bid>snapped),created_ms=tick.t_ms)]
                self._recovery_ledger(tick,'v3_manual_stop',side=side,price=snapped,lots=lots)
                return
            entry=tick.ask if side=='BUY' else tick.bid
            self._open_recovery_leg(tick,side,entry,initial=False,lots=lots)
            self._recovery_ledger(tick,'v3_manual_market',side=side,price=entry,lots=lots)
            return
        if not r.stepped_mode or (r.variant=='extreme' and not r.reentries and not r.recovery_sls
                                  and not r.active and len(r.pending_stops)==1):
            if order_type=='STOP':
                r.pending_stops=[dict(side=side,level=snapped,lots=round(lots,8),armed=True,
                                      created_ms=tick.t_ms)]
                self._recovery_ledger(tick,'manual_recovery_first_stop',side=side,
                                      price=snapped,lots=lots)
                return
            entry=tick.ask if side=='BUY' else tick.bid
            self._open_recovery_leg(tick,side,entry,initial=True,lots=lots)
            self._recovery_ledger(tick,'manual_recovery_market',side=side,price=entry,
                                  lots=lots,phase='fixed_tp')
            return
        # Stepped RECOVERY: new fill/STOP remains inside the OCO mechanism.
        if order_type=='STOP':
            self.move_trigger('recovery',snapped,side)
            for stop in r.pending_stops:
                if stop['side']==side:
                    stop['lots']=round(lots,8)
                    stop['created_ms']=tick.t_ms
            self._recovery_ledger(tick,'manual_recovery_stop',side=side,price=snapped,lots=lots)
            return
        entry=tick.ask if side=='BUY' else tick.bid
        if r.variant=='extreme':
            self._open_recovery_leg(tick,side,entry,initial=False,lots=lots)
            self._recovery_ledger(tick,'manual_recovery_market',side=side,
                                  price=entry,lots=lots,phase='extreme')
            return
        if side=='BUY':r.buy_anchor=self._level(entry,True)
        else:r.sell_anchor=self._level(entry,False)
        # Market execution changes the relevant reference anchor; the
        # opposite OCO level must remain on the other side and within range.
        tick_size=self.settings.tick_size
        if r.buy_anchor<=r.sell_anchor:
            if side=='BUY':r.sell_anchor=self._level(r.buy_anchor-tick_size,False)
            else:r.buy_anchor=self._level(r.sell_anchor+tick_size,True)
        self._enforce_recovery_opposite_range(tick,side)
        self._open_recovery_leg(tick,side,entry,initial=False,lots=lots)
        self._recovery_ledger(tick,'manual_recovery_market',side=side,
                              price=entry,lots=lots,phase='stepped')

    def manual_open(self,side:str,lots:float,order_type:str='MARKET',level:Optional[float]=None):
        """Open a SEPARATE virtual position or STOP, never through a broker.

        Manual positions are independent of the automatic RECOVERY debt: this
        prevents user clicks from corrupting the deterministic strategy engine.
        """
        if side not in ('BUY','SELL') or order_type not in ('MARKET','STOP'):
            raise ValueError('Choose BUY/SELL and MARKET/STOP')
        self._manual_quantity(lots)
        tick=self.latest
        if tick is None:raise ValueError('No current quote for virtual execution')
        if len(self.manual_positions)+len(self.manual_stops)>=30:
            raise ValueError('Maximum 30 parallel manual virtual orders and positions')
        self.manual_seq+=1
        number=self.manual_seq
        if order_type=='MARKET':
            entry=tick.ask if side=='BUY' else tick.bid
            self.manual_positions.append(ManualPosition(number,side,entry,round(lots,8),
                                                         tick.t_ms,tick.ask-tick.bid))
            self._event(tick.t_ms,'manual_open',side=side,price=entry,lots=lots,manual_id=number)
        else:
            if not isinstance(level,(int,float)) or not isfinite(level) or level<=0:
                raise ValueError('Select the chart STOP price')
            entry=self._level(level,side=='BUY')
            if (side=='BUY' and entry<=tick.ask or side=='SELL' and entry>=tick.bid):
                raise ValueError('BUY STOP must be ABOVE Ask; SELL STOP BELOW Bid')
            self.manual_stops.append(ManualStop(number,side,entry,round(lots,8),tick.t_ms,True))
            self._event(tick.t_ms,'manual_stop_placed',side=side,price=entry,lots=lots,manual_id=number)
        return number

    def _manual_fill_orders(self,tick:Tick):
        for order in self.manual_stops[:]:
            if tick.t_ms<=order.created_ms:continue  # Never fill on the creating tick
            if (order.side=='BUY' and tick.ask>=order.level or
                    order.side=='SELL' and tick.bid<=order.level):
                entry=max(order.level,tick.ask) if order.side=='BUY' else min(order.level,tick.bid)
                self.manual_stops.remove(order)
                self.manual_positions.append(ManualPosition(order.id,order.side,entry,
                                               order.lots,tick.t_ms,tick.ask-tick.bid))
                self._event(tick.t_ms,'manual_stop_filled',side=order.side,price=entry,
                            lots=order.lots,manual_id=order.id)

    def manual_cancel_stop(self,number:int):
        order=next((x for x in self.manual_stops if x.id==number),None)
        if not order:raise ValueError('Manual virtual STOP not found')
        self.manual_stops.remove(order)
        self._event(self.latest.t_ms if self.latest else 0,'manual_stop_cancelled',
                    side=order.side,price=order.level,manual_id=number)

    def manual_move_stop(self,number:int,price:float):
        order=next((x for x in self.manual_stops if x.id==number),None)
        if not order:raise ValueError('Manual virtual STOP not found')
        tick=self.latest
        if not tick or not isfinite(price) or price<=0:raise ValueError('Invalid quote/price')
        new=self._level(price,order.side=='BUY')
        if (order.side=='BUY' and new<=tick.ask or order.side=='SELL' and new>=tick.bid):
            raise ValueError('BUY STOP must be above Ask; SELL STOP below Bid')
        old=order.level
        order.level=new
        order.created_ms=tick.t_ms
        self._event(tick.t_ms,'manual_move_trigger',side=order.side,price=new,
                    previous_price=old,manual_id=number,kind='manual_stop')

    def manual_close(self,kind:str,lots:float,number:Optional[int]=None):
        """Explicit partially/full closing at the last executable Bid/Ask.
        No MT5 trade() or MetaTrader5.order_send() is ever called.
        """
        tick=self.latest
        if tick is None:raise ValueError('No executable paper quote')
        self._manual_quantity(lots)
        if kind=='manual':
            pos=next((x for x in self.manual_positions if x.id==number),None)
            if pos is None:raise ValueError('Manual position not found')
            if lots>pos.lots+1e-8:raise ValueError('Close volume exceeds open volume')
            self._close_manual_lots(tick,pos,min(lots,pos.lots))
            return
        if kind=='auto':
            pos=self.position
            if pos is None or self.recovery:raise ValueError('No initial automatic position')
            current_lots=self._position_lots(pos)
            if lots>current_lots+1e-8:
                raise ValueError('Нельзя закрыть больше открытого объёма')
            quote=self._close_quote(pos.side,tick)
            weighted=(quote-pos.entry if pos.side=='BUY' else pos.entry-quote)*lots
            points=weighted/self.settings.volume_lots
            cash=(weighted/self.settings.tick_size*self.settings.tick_value_per_lot-
                  lots*self.settings.commission_per_lot_roundtrip) if self.settings.tick_value_per_lot>0 else None
            self.trade_seq+=1
            trade=dict(id=self.trade_seq,side=pos.side,result='MANUAL_CLOSE',
                       opened_ms=pos.opened_ms,closed_ms=tick.t_ms,
                       entry=pos.entry,exit=quote,tp=pos.tp,sl=pos.sl,
                       trigger_level=pos.trigger_level,pnl_points=round(points,8),
                       pnl_money_est=round(cash,5) if cash is not None else None,
                       mfe_points=pos.mfe,mae_points=pos.mae,gap_to_tp=max(0.,abs(pos.tp-pos.entry)-pos.mfe),
                       signal_time=pos.signal_time,signal_body=pos.signal_body,
                       signal_range=pos.signal_range,signal_color=pos.signal_color,
                       spread_at_entry=pos.entry_spread,entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000,timezone.utc).hour,
                       lots=lots,manual=True)
            self.trades.append(trade);self.new_trades.append(trade)
            self.realized_cycle_points+=points
            self._event(tick.t_ms,'manual_close',side=pos.side,price=quote,lots=lots,
                        remaining_lots=round(current_lots-lots,8),kind='auto')
            remaining=round(current_lots-lots,8)
            if remaining<=1e-8:
                self.position=None
                self._next_cycle_after_close(tick)
            else:
                pos.lots=remaining
            return
        if kind=='recovery':
            r=self.recovery
            if not r or not r.active:raise ValueError('No active RECOVERY position')
            if lots>r.active.lots+1e-8:raise ValueError('Close volume exceeds active RECOVERY lot')
            closing_leg=r.active
            self._recovery_close_lots(tick,min(lots,r.active.lots),'manual_recovery_close')
            if r.variant=='fixed_flip' and r.active is not None:
                # Recompute the ENTIRE remaining ladder after manual liquidation.
                self._v3_grid_rebuild(tick)
            elif r.variant=='extreme' and r.active is not None:
                r.active.tp=self._recovery_v2_target_price(r.active.side,r.active.entry,r.active.lots)
            if r.active is None and r.variant=='fixed_flip':
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                else:
                    other='SELL' if closing_leg.side=='BUY' else 'BUY'
                    self._recovery_v3_arm_opposite(tick,other)
                return
            if r.active is None and r.variant=='extreme':
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                else:
                    self._recovery_v2_after_stop(tick,closing_leg)
                return
            if r.active is None:
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                elif r.stepped_mode:
                    self._recovery_reset_triggers(tick)
                else:
                    # A manual full close is NOT the first RECOVERY TP or SL.
                    # Remain in fixed TP/SL phase; let the user re-enter at
                    # market or drag the rearmed first STOP. The debt stays in
                    # the same basket instead of silently ending the cycle.
                    side=('SELL' if r.origin.side=='BUY' else 'BUY')
                    level=(r.sell_anchor if side=='SELL' else r.buy_anchor)
                    valid_side=(tick.bid>level if side=='SELL' else tick.ask<level)
                    r.pending_stops=[dict(side=side,level=level,
                        lots=self.settings.recovery_reentry_lots,armed=valid_side)]
                    self._recovery_ledger(tick,'manual_recovery_first_rearmed',
                                          side=side,price=level,armed=valid_side)
            return
        raise ValueError('Unknown virtual position kind')

    def _close_manual_lots(self,tick:Tick,pos:ManualPosition,lots:float):
        quote=self._close_quote(pos.side,tick)
        weighted=(quote-pos.entry if pos.side=='BUY' else pos.entry-quote)*lots
        points=weighted/self.settings.volume_lots
        cash=(weighted/self.settings.tick_size*self.settings.tick_value_per_lot-
              lots*self.settings.commission_per_lot_roundtrip) if self.settings.tick_value_per_lot>0 else None
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=pos.side,result='MANUAL_CLOSE',
                   opened_ms=pos.opened_ms,closed_ms=tick.t_ms,entry=pos.entry,exit=quote,
                   tp=None,sl=None,trigger_level=pos.entry,
                   pnl_points=round(points,8),pnl_weighted_points_lots=round(weighted,8),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=0.,mae_points=0.,gap_to_tp=0.,signal_time=0,
                   signal_body=0.,signal_range=0.,signal_color='MANUAL',
                   spread_at_entry=pos.entry_spread,
                   entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000,timezone.utc).hour,
                   lots=lots,manual=True,manual_id=pos.id)
        self.trades.append(trade);self.new_trades.append(trade)
        self.realized_cycle_points+=points
        pos.lots=round(pos.lots-lots,8)
        if pos.lots<=1e-8:self.manual_positions.remove(pos)
        self._event(tick.t_ms,'manual_close',side=pos.side,price=quote,lots=lots,
                    manual_id=pos.id,pnl_equiv_points=round(points,8))

    def _next_cycle_after_close(self, tick: Tick):
        if self.mode == 'stopping':
            self.mode = 'stopped'
            self.arm_minute = None
        else:
            # First complete candle ending AFTER the current tick can arm a new STOP.
            self.arm_minute = (tick.t_ms // 60000) * 60

    def _close_quote(self, side: str, tick: Tick) -> float:
        return tick.bid if side == 'BUY' else tick.ask

    def _weighted_move(self, leg: RecoveryLeg, price: float) -> float:
        return (price-leg.entry if leg.side == 'BUY' else leg.entry-price)*leg.lots

    def _recovery_ledger(self, tick: Tick, typ: str, **kwargs):
        r=self.recovery
        if r is None:return
        action=dict(t_ms=tick.t_ms,type=typ,**kwargs)
        if len(r.actions)<500:r.actions.append(action)
        else:r.truncated_actions+=1
        self._event(tick.t_ms,typ,**kwargs)

    def _recovery_net(self, tick: Tick) -> tuple[float, Optional[float]]:
        r=self.recovery
        if not r:return 0.0,None
        live=(self._weighted_move(r.active,self._close_quote(r.active.side,tick))
              if r.active else 0.0)
        weighted=r.realized_weighted_points+live
        cash=None
        if self.settings.tick_value_per_lot>0:
            fees=r.realized_commission_money + (
                r.active.lots*self.settings.commission_per_lot_roundtrip if r.active else 0.0)
            cash=weighted/self.settings.tick_size*self.settings.tick_value_per_lot-fees
        return weighted,cash

    def _recovery_target_met(self,tick:Tick)->bool:
        weighted,cash=self._recovery_net(tick)
        return cash>=-1e-8 if cash is not None else weighted>=-1e-9

    def _recovery_v2_target_price(self,side:str,entry:float,lots:float)->float:
        """Exit price necessary to compensate ONLY realized cycle losses/fees.

        All P/L in weighted price*lots, including spread from executable quotes.
        The initial +0.25 target does NOT get added to V2 recovery debt.
        """
        r=self.recovery
        owed=-r.realized_weighted_points
        if self.settings.tick_value_per_lot>0:
            fee=(r.realized_commission_money + lots*self.settings.commission_per_lot_roundtrip)
            owed+=fee*self.settings.tick_size/self.settings.tick_value_per_lot
        distance=max(0.,owed/max(lots,1e-8))
        return self._level(entry+distance if side=='BUY' else entry-distance,side=='BUY')

    def _v3_chunks(self, lots: float) -> list[float]:
        """Volume partition, rounded to actual MT5 lot step and minimum.

        Never fabricate sub-minimum partial closes; any remaining tail smaller
        than broker min is merged with the preceding tranche.
        """
        step=self.settings.volume_step_lots
        count=round(lots/step)
        if abs(count*step-lots)>1e-7 or count<1:
            raise ValueError('V3 volume is not aligned to MT5 volume_step')
        size_steps=round(self.settings.recovery_v3_partial_lots/step)
        min_steps=ceil(self.settings.volume_min_lots/step-1e-8)
        if not size_steps or size_steps<min_steps:
            raise ValueError('V3 part volume below MT5 minimum lot size')
        chunks=[]
        while count>0:
            if count<=size_steps or count-size_steps<min_steps:
                chunks.append(round(count*step,8));count=0
            else:
                chunks.append(round(size_steps*step,8));count-=size_steps
        return chunks

    def _v3_grid_rebuild(self,tick:Tick):
        """Compute all remaining partial TP levels from ACTUAL realized P/L.

        With N equal tranches, required step = deficit / SUM(i*lot_i), NOT
        deficit/whole_volume/N. Future fees and the current liquidation Bid/Ask
        are included once; after any fill the outstanding ladder is rebuilt.
        """
        r=self.recovery
        if not r or r.variant!='fixed_flip' or not r.active:return
        leg=r.active
        quote=self._close_quote(leg.side,tick)
        sizes=self._v3_chunks(leg.lots)
        factor=sum((i+1)*v for i,v in enumerate(sizes))
        current_weighted=(r.realized_weighted_points+
                          self._weighted_move(leg,quote))
        debt=-current_weighted
        if self.settings.tick_value_per_lot>0:
            fees=r.realized_commission_money + leg.lots*self.settings.commission_per_lot_roundtrip
            debt += fees*self.settings.tick_size/self.settings.tick_value_per_lot
        # Never mark a profitable basket as "in debt" due to rounding.
        raw_step=max(0.0,debt)/factor if factor>0 else 0.0
        step=max(self.settings.tick_size,
                 self._level(raw_step,True))
        targets=[]
        for i,volume in enumerate(sizes,1):
            price=self._level(quote+(step*i if leg.side=='BUY' else -step*i),leg.side=='BUY')
            targets.append(dict(price=price,lots=volume,index=i))
        leg.v3_tp_targets=targets
        leg.tp=targets[0]['price'] if targets else None
        self._recovery_ledger(tick,'v3_grid_recalculated',side=leg.side,
                              remaining_lots=leg.lots,base_quote=quote,
                              parts=len(targets),step=step,
                              first_tp=leg.tp,last_tp=targets[-1]['price'] if targets else None,
                              debt_weighted=max(debt,0.0))

    def _v3_mode_offset(self, next_flip:int) -> float:
        """Switch #1-2 narrow, #3-4 wide in A; B widens from #2 once."""
        mode=self.settings.recovery_v3_range_mode
        extra=self.settings.recovery_v3_expansion
        if mode=='alternating':
            return extra if (next_flip-1)//2%2==1 else 0.0
        if mode=='once':
            return extra if next_flip>=2 else 0.0
        return 0.0

    def _v3_plan_next(self, tick:Tick, side:str, nominal:float, next_flip:int):
        """Derive opposite nominal STOP from NOMINAL entry, not execution.

        The real SL is a separate broker-style level based on the actual fill.
        This allows a flat interval between the SL and the next trigger.
        """
        r=self.recovery
        if not r or r.variant!='fixed_flip':return
        opposite='SELL' if side=='BUY' else 'BUY'
        distance=self.settings.recovery_v3_stop_gap+self._v3_mode_offset(next_flip)
        level=self._level(nominal-distance if side=='BUY' else nominal+distance,
                          opposite=='BUY')
        r.v3_last_nominal=nominal
        r.v3_next_nominal=level
        if opposite=='BUY':r.buy_anchor=level
        else:r.sell_anchor=level
        r.pending_stops=[dict(side=opposite,level=level,
                              lots=self.settings.recovery_v3_work_lots,
                              armed=True,created_ms=tick.t_ms)]
        self._recovery_ledger(tick,'v3_next_stop_planned',side=opposite,
                              level=level,from_nominal=nominal,
                              flip_index=next_flip,offset=distance-self.settings.recovery_v3_stop_gap,
                              range_mode=self.settings.recovery_v3_range_mode)

    def _recovery_v3_arm_opposite(self,tick:Tick,side:str):
        """Re-arm only the saved nominal STOP, without moving the anchor."""
        r=self.recovery
        if not r or r.variant!='fixed_flip':return
        level=r.v3_next_nominal
        if level is None:level=r.buy_anchor if side=='BUY' else r.sell_anchor
        # After manual close, wait for a new crossing from the correct side.
        armed=(tick.ask<level-1e-9 if side=='BUY' else tick.bid>level+1e-9)
        r.pending_stops=[dict(side=side,level=level,
                              lots=self.settings.recovery_v3_work_lots,
                              armed=armed,created_ms=tick.t_ms)]
        self._recovery_ledger(tick,'v3_anchor_stop_armed',side=side,price=level,armed=armed)

    def _v3_try_fill_pending(self,tick:Tick, *,allow_same_tick:bool=False):
        r=self.recovery
        if not r or r.active or not r.pending_stops:return
        p=r.pending_stops[0]
        if not p.get('armed'):
            if (p['side']=='BUY' and tick.ask<p['level']-1e-9 or
                    p['side']=='SELL' and tick.bid>p['level']+1e-9):
                p['armed']=True
            return
        hit=(tick.ask>=p['level'] if p['side']=='BUY' else tick.bid<=p['level'])
        if not hit:return
        # If both nominal sides are inside the same spread, tick ordering is
        # unknown: don't fabricate a cascade of fills on one quote.
        if tick.bid<=r.sell_anchor and tick.ask>=r.buy_anchor:
            self._recovery_ledger(tick,'v3_spread_overlap',bid=tick.bid,ask=tick.ask)
            return
        entry=max(p['level'],tick.ask) if p['side']=='BUY' else min(p['level'],tick.bid)
        next_nominal=p['level']
        self._open_recovery_leg(tick,p['side'],entry,initial=r.reentries==0,
                                lots=p.get('lots',self.settings.recovery_v3_work_lots),
                                v3_nominal=next_nominal)

    def _recovery_tick_v3(self,tick:Tick):
        """V3: single actual-fill SL, adaptive partial TP, anchored STOPs."""
        r=self.recovery
        weighted,_=self._recovery_net(tick)
        r.max_loss_points=max(r.max_loss_points,-weighted/self.settings.volume_lots)
        self.max_active_recovery_loss_points=max(self.max_active_recovery_loss_points,r.max_loss_points)
        leg=r.active
        if leg:
            # Close remaining lots as soon as REALIZED + FLOATING recover debt.
            if self._recovery_target_met(tick):
                self._end_recovery(tick,'RECOVERED')
                return
            quote=self._close_quote(leg.side,tick)
            sl_hit=quote<=leg.stop+1e-9 if leg.side=='BUY' else quote>=leg.stop-1e-9
            if sl_hit:
                side=leg.side
                nominal=(leg.v3_nominal_entry if leg.v3_nominal_entry is not None else
                         r.buy_anchor if side=='BUY' else r.sell_anchor)
                self._recovery_close_lots(tick,leg.lots,'v3_fixed_sl')
                r.recovery_sls+=1;self.recovery_sls+=1;self.recovery_partial_stops+=1
                r.v3_flip_count+=1
                # The next nominal STOP was pre-planned on leg entry. Manual
                # dragging may have changed it and SL must NOT overwrite it.
                self._recovery_ledger(tick,'v3_sl_wait_stop',side=r.pending_stops[0]['side'],
                                      price=r.pending_stops[0]['level'],flip_index=r.v3_flip_count)
                # Pre-planned STOP can execute at the same SL tick IF the actual
                # Bid/Ask has crossed it. A farther level waits until crossed.
                self._v3_try_fill_pending(tick,allow_same_tick=True)
                return
            if not leg.v3_tp_targets:
                self._v3_grid_rebuild(tick)
            first=leg.v3_tp_targets[0] if leg.v3_tp_targets else None
            if first and (quote>=first['price']-1e-9 if leg.side=='BUY'
                          else quote<=first['price']+1e-9):
                # Use the first executable observed Bid/Ask; can overshoot the
                # target. New targets reflect ACTUAL proceeds, not a fiction.
                self._recovery_close_lots(tick,first['lots'],'v3_partial_tp')
                r.partial_tps+=1;self.recovery_partial_tps+=1
                if r.active is None:
                    if self._recovery_target_met(tick):
                        self._end_recovery(tick,'RECOVERED')
                    else:
                        self._recovery_v3_arm_opposite(tick,'SELL' if leg.side=='BUY' else 'BUY')
                elif self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                else:
                    self._v3_grid_rebuild(tick)
            return
        self._v3_try_fill_pending(tick)

    def _recovery_v2_after_stop(self,tick:Tick,leg:RecoveryLeg):
        """After support SL: same side beyond its observed extreme by offset;
        opposite side at ORIGINAL opposite-side entry. The OCO pair is created
        only AFTER a recovery position has been stopped (never in advance).
        """
        r=self.recovery
        offset=self.settings.recovery_v2_reentry_offset
        extreme=leg.best_trigger_quote if leg.best_trigger_quote is not None else leg.entry
        if leg.side=='BUY':
            r.buy_anchor=self._level(extreme+offset,True)
            r.sell_anchor=r.original_sell_anchor
        else:
            r.sell_anchor=self._level(extreme-offset,False)
            r.buy_anchor=r.original_buy_anchor
        r.anchor_priority_side=leg.side
        self._recovery_ledger(tick,'v2_extreme_reentry',side=leg.side,
                              best=extreme,offset=offset,buy_anchor=r.buy_anchor,
                              sell_anchor=r.sell_anchor)
        self._recovery_reset_triggers(tick,priority_side=leg.side)

    def _recovery_tick_v2(self,tick:Tick):
        r=self.recovery
        weighted,cash=self._recovery_net(tick)
        r.max_loss_points=max(r.max_loss_points,-weighted/self.settings.volume_lots)
        self.max_active_recovery_loss_points=max(self.max_active_recovery_loss_points,r.max_loss_points)
        leg=r.active
        if leg:
            # The liquidation quote is Bid for BUY and Ask for SELL.
            if self._recovery_target_met(tick):
                self._end_recovery(tick,'RECOVERED')
                return
            quote=self._close_quote(leg.side,tick)
            stop_hit=quote<=leg.stop if leg.side=='BUY' else quote>=leg.stop
            if stop_hit:
                # Slippage through support SL is included; the losing tick is
                # deliberately excluded from favorable extreme calculation.
                self._recovery_close_lots(tick,leg.lots,'v2_support_sl')
                r.recovery_sls+=1;self.recovery_sls+=1;self.recovery_partial_stops+=1
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                else:
                    self._recovery_v2_after_stop(tick,leg)
                return
            self._recovery_observe_extreme(leg,tick)
            favourable=quote-leg.entry if leg.side=='BUY' else leg.entry-quote
            leg.peak_favorable=max(leg.peak_favorable,favourable)
            step=self.settings.recovery_v2_trail_step
            index=max(0,floor((leg.peak_favorable+1e-8)/step))
            if index>leg.trail_step_index:
                offset=self.settings.recovery_v2_support_sl_distance
                new=self._level(leg.entry-offset+index*step if leg.side=='BUY'
                                else leg.entry+offset-index*step,leg.side=='SELL')
                leg.stop=max(leg.stop,new) if leg.side=='BUY' else min(leg.stop,new)
                leg.trail_step_index=index
                self._recovery_ledger(tick,'v2_support_trail',side=leg.side,
                                      price=leg.stop,peak=leg.peak_favorable,index=index)
            return
        # Only the opposite STOP exists right after original SL. After each
        # support SL, TWO OCO orders are created; first fill cancels the other.
        hits=[]
        for p in r.pending_stops:
            if not p.get('armed'):
                if p['side']=='BUY' and tick.ask < p['level']-1e-9:p['armed']=True
                elif p['side']=='SELL' and tick.bid > p['level']+1e-9:p['armed']=True
            elif (p['side']=='BUY' and tick.ask>=p['level'] or
                  p['side']=='SELL' and tick.bid<=p['level']):
                hits.append(p)
        if len(hits)>1:
            self._recovery_ledger(tick,'v2_ambiguous_spread',bid=tick.bid,ask=tick.ask)
            return
        if len(hits)==1:
            p=hits[0]
            entry=max(p['level'],tick.ask) if p['side']=='BUY' else min(p['level'],tick.bid)
            self._open_recovery_leg(tick,p['side'],entry,
                                    initial=r.reentries==0 and r.recovery_sls==0,
                                    lots=p.get('lots',self.settings.recovery_v2_work_lots))

    def _open_recovery_leg(self, tick: Tick, side: str, entry: float,
                           initial: bool, lots: Optional[float] = None,
                           v3_nominal: Optional[float] = None):
        r=self.recovery
        if r is None:return
        if r.variant=='fixed_flip':
            size=lots or self.settings.recovery_v3_work_lots
            nominal=v3_nominal
            if nominal is None:
                nominal=(r.buy_anchor if side=='BUY' else r.sell_anchor)
            # Real SL is ALWAYS 1.50 from actual execution, NOT the saved STOP.
            gap=self.settings.recovery_v3_stop_gap
            stop=self._level(entry-gap if side=='BUY' else entry+gap,side=='SELL')
            r.active=RecoveryLeg(side,entry,size,tick.t_ms,'fixed_flip',stop,
                                 tp=None,trail_step_index=-1,v3_nominal_entry=nominal)
            r.pending_stops=[]
            if not initial:r.reentries+=1;self.recovery_reentries+=1
            self._v3_grid_rebuild(tick)
            # A single opposite STOP is pre-planned but NOT executable while
            # this leg is active. It becomes executable only once SL closes it.
            self._v3_plan_next(tick,side,nominal,r.v3_flip_count+1)
            self._recovery_ledger(tick,'v3_fixed_fill',side=side,nominal=nominal,
                                  execution=entry,lots=size,sl=stop,
                                  next_partial_tp=r.active.tp,initial=initial)
            return
        if r.variant=='extreme':
            size=lots or self.settings.recovery_v2_work_lots
            # The remembered opposite STOP must use the actual first entry,
            # which may differ from the SL trigger due to gaps/slippage.
            if initial:
                if side=='BUY':
                    r.original_buy_anchor=entry
                    r.buy_anchor=entry
                else:
                    r.original_sell_anchor=entry
                    r.sell_anchor=entry
            stop=self._level(entry-self.settings.recovery_v2_support_sl_distance if side=='BUY'
                             else entry+self.settings.recovery_v2_support_sl_distance,side=='SELL')
            target=self._recovery_v2_target_price(side,entry,size)
            r.active=RecoveryLeg(side,entry,size,tick.t_ms,'extreme',stop,tp=target,
                                 trail_step_index=0,best_trigger_quote=entry)
            r.pending_stops=[]
            if not initial:
                r.reentries+=1;self.recovery_reentries+=1
            self._recovery_ledger(tick,'v2_recovery_fill',side=side,price=entry,
                                  lots=size,sl=stop,required_tp=target,initial=initial)
            return
        # The first 0.12 recovery leg MUST retain its fixed SL3/TP0.25.
        # Only AFTER that first 0.12 SL, the stepped leg starts with its support
        # SL already 1.00 price point behind entry, no +0.50 activation wait.
        fixed_tp = not r.stepped_mode
        stop_distance=(self.settings.sl_distance if fixed_tp else
                       self.settings.recovery_trail_start_offset)
        stop=self._level(entry-stop_distance if side=='BUY' else entry+stop_distance,
                         side=='SELL')
        take=(self._level(entry+self.settings.tp_distance if side=='BUY' else
                          entry-self.settings.tp_distance,side=='BUY') if fixed_tp else None)
        r.active=RecoveryLeg(side,entry,lots or self.settings.recovery_reentry_lots,tick.t_ms,
                             'fixed_tp' if fixed_tp else 'stepped',stop,tp=take,
                             trail_step_index=-1 if fixed_tp else 0,
                             best_trigger_quote=entry)
        r.pending_stops=[]  # OCO: other virtual trigger canceled upon fill.
        if not initial:
            r.reentries+=1;self.recovery_reentries+=1
        self._recovery_ledger(tick,'recovery_first_fill' if initial else 'recovery_reentry',
                              side=side,price=entry,lots=r.active.lots,sl=stop,
                              tp=take,phase='fixed_tp' if fixed_tp else 'stepped')

    def _start_recovery(self,tick:Tick):
        """First real (virtual) initial SL; next RECOVERY order is a PENDING STOP.

        Same-tick fill is disallowed. Stop orders placed after a price has already
        crossed their level may not be valid at a real broker. This is paper
        modeling, with the fill performed on a future tick only.
        """
        pos=self.position
        if pos is None or self.recovery:return
        side=pos.side
        crossed=tick.bid<=pos.sl if side=='BUY' else tick.ask>=pos.sl
        if not crossed:return
        exit_price=min(pos.sl,tick.bid) if side=='BUY' else max(pos.sl,tick.ask)
        weighted=(exit_price-pos.entry if side=='BUY' else pos.entry-exit_price)*self._position_lots(pos)
        r=RecoveryState(started_ms=tick.t_ms,origin=pos,original_sl_exit=exit_price,
                        buy_anchor=pos.entry if side=='BUY' else exit_price,
                        sell_anchor=pos.entry if side=='SELL' else exit_price,
                        active=None,realized_weighted_points=weighted,
                        realized_commission_money=(self._position_lots(pos)*
                            self.settings.commission_per_lot_roundtrip))
        if self.settings.recovery_variant=='fixed_flip':
            r.variant='fixed_flip'
            nominal=pos.trigger_level  # original planned STOP, unaffected by slippage
            initial_gap=self.settings.recovery_v3_initial_sl_distance
            if side=='BUY':
                r.buy_anchor=nominal
                r.sell_anchor=self._level(nominal-initial_gap,False)
            else:
                r.sell_anchor=nominal
                r.buy_anchor=self._level(nominal+initial_gap,True)
            r.original_buy_anchor=r.buy_anchor
            r.original_sell_anchor=r.sell_anchor
            r.v3_flip_count=0
            r.v3_last_nominal=nominal
            r.v3_next_nominal=r.sell_anchor if side=='BUY' else r.buy_anchor
            r.stepped_mode=False
        if self.settings.recovery_variant=='extreme':
            r.variant='extreme'
            r.stepped_mode=True
            r.original_buy_anchor=(pos.entry if side=='BUY' else exit_price)
            r.original_sell_anchor=(pos.entry if side=='SELL' else exit_price)
            r.buy_anchor=r.original_buy_anchor
            r.sell_anchor=r.original_sell_anchor
        self.recovery=r
        self.position=None  # initial SL truly closes position, unlike v1.2 hedge
        recovery_side='SELL' if side=='BUY' else 'BUY'
        r.pending_stops=[dict(side=recovery_side,level=exit_price,
                              lots=(self.settings.recovery_v2_work_lots if r.variant=='extreme'
                                    else self.settings.recovery_reentry_lots),armed=True)]
        self.recovery_activations+=1
        if r.variant=='fixed_flip':
            stop_nominal=r.v3_next_nominal
            r.pending_stops=[dict(side=recovery_side,level=stop_nominal,
                                  lots=self.settings.recovery_v3_work_lots,
                                  armed=True,created_ms=tick.t_ms)]
            self._recovery_ledger(tick,'v3_recovery_start',side=side,
                                  sl_execution=exit_price,stop_nominal=stop_nominal,
                                  initial_sl_weighted=weighted)
            self._v3_try_fill_pending(tick,allow_same_tick=True)
            return
        self._recovery_ledger(tick,'recovery_start',side=side,price=exit_price,
                              initial_sl_weighted=weighted,pending_side=recovery_side,
                              recovery_trigger=exit_price)

    def _pre_recovery_tick(self,tick:Tick):
        pos=self.position
        if pos is None:return
        quote=self._close_quote(pos.side,tick)
        move=(quote-pos.entry if pos.side=='BUY' else pos.entry-quote)
        pos.mfe=max(pos.mfe,move)
        pos.mae=max(pos.mae,-move)
        # Both TP and SL use liquidation quote (BUY Bid, SELL Ask).
        if (pos.side=='BUY' and tick.bid>=pos.tp or
                pos.side=='SELL' and tick.ask<=pos.tp):
            self._close_initial_tp(tick)
        else:
            self._start_recovery(tick)

    def _close_initial_tp(self,tick:Tick):
        pos=self.position
        if not pos:return
        close=pos.tp
        raw_move=(close-pos.entry if pos.side=='BUY' else pos.entry-close)
        lots=self._position_lots(pos)
        points=raw_move*lots/self.settings.volume_lots
        cash=None
        if self.settings.tick_value_per_lot>0:
            cash=(raw_move/self.settings.tick_size*self.settings.tick_value_per_lot-
                  self.settings.commission_per_lot_roundtrip)*lots
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=pos.side,result='TP',opened_ms=pos.opened_ms,
                   closed_ms=tick.t_ms,entry=pos.entry,exit=close,tp=pos.tp,sl=pos.sl,
                   trigger_level=pos.trigger_level,pnl_points=round(points,10),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=round(pos.mfe,10),mae_points=round(pos.mae,10),
                   gap_to_tp=0.0,duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
                   signal_time=pos.signal_time,signal_body=round(pos.signal_body,6),
                   signal_range=round(pos.signal_range,6),signal_color=pos.signal_color,
                   spread_at_entry=round(pos.entry_spread,10),lots=lots,
                   entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000,timezone.utc).hour,
                   recovery_used=False,recovery_actions=[],recovery_partial_stops=0,
                   recovery_partial_tps=0,recovery_reentries=0)
        self.trades.append(trade);self.new_trades.append(trade)
        self.realized_cycle_points+=trade['pnl_points']
        self._event(tick.t_ms,'tp',side=pos.side,price=close,trade_id=self.trade_seq)
        self.position=None
        self._next_cycle_after_close(tick)

    def _recovery_close_lots(self,tick:Tick,lots:float,typ:str,execution_price:Optional[float]=None):
        r=self.recovery
        if not r or not r.active:return
        active=r.active
        lots=min(lots,active.lots)
        quote=(self._close_quote(active.side,tick) if execution_price is None else execution_price)
        weighted=(quote-active.entry if active.side=='BUY' else active.entry-quote)*lots
        r.realized_weighted_points+=weighted
        r.realized_commission_money+=lots*self.settings.commission_per_lot_roundtrip
        active.lots=round(active.lots-lots,8)
        self._recovery_ledger(tick,typ,side=active.side,price=quote,lots=lots,
                              weighted=round(weighted,8),remaining_lots=active.lots)
        if active.lots<=1e-8:r.active=None

    def _recovery_trail_update(self,tick:Tick):
        r=self.recovery
        if not r or not r.active:return
        p=r.active
        q=self._close_quote(p.side,tick)
        favourable=q-p.entry if p.side=='BUY' else p.entry-q
        p.peak_favorable=max(p.peak_favorable,favourable)
        # Immediate step-based trailing. A new stepped leg already has its
        # first support SL at entry +/- offset, and moves by exactly step
        # per completed +0.10 favorable movement. No +0.50 gate.
        i=max(0,floor((p.peak_favorable+1e-8)/self.settings.recovery_trail_step))
        if i<=p.trail_step_index:return
        offset=self.settings.recovery_trail_start_offset
        raw=(p.entry-offset+i*self.settings.recovery_trail_step if p.side=='BUY' else
             p.entry+offset-i*self.settings.recovery_trail_step)
        new_stop=self._level(raw,p.side=='SELL')
        p.stop=max(p.stop,new_stop) if p.side=='BUY' else min(p.stop,new_stop)
        p.trail_step_index=i
        self._recovery_ledger(tick,'recovery_trail',side=p.side,price=p.stop,
                              step=i,peak_favorable=round(p.peak_favorable,7))

    def _recovery_observe_extreme(self, leg: RecoveryLeg, tick: Tick):
        """Record actual trigger-side tick high/low, never candle High/Low.

        On BUY STOPs fills occur on Ask; on SELL STOPs they occur on Bid.
        Do not count the adverse SL tick as a new favorable extreme: a sudden
        spread expansion could otherwise fabricate a reentry price.
        """
        quote=tick.ask if leg.side=='BUY' else tick.bid
        if leg.best_trigger_quote is None:
            leg.best_trigger_quote=leg.entry
        if leg.side=='BUY':
            leg.best_trigger_quote=max(leg.best_trigger_quote,quote)
        else:
            leg.best_trigger_quote=min(leg.best_trigger_quote,quote)

    def _recovery_advance_reentry(self, tick: Tick, leg: RecoveryLeg, trailing_stop: bool):
        """Update the SAME-side STOP only, preserving the opposite OCO anchor.

        Initial/opposite-side SL: at least one full price point beyond the
        previous *actual* entry, or farther at the best observed quote.
        Trailing/support SL: set the next same-side STOP at least 1 FULL PRICE
        POINT *BEYOND the most favorable actual trigger-side quote seen*:
        BUY: highest Ask + 1.00; SELL: lowest Bid - 1.00.
        In either case, never pull an old same-side anchor backwards.
        """
        r=self.recovery
        if r is None:return
        best=leg.best_trigger_quote if leg.best_trigger_quote is not None else leg.entry
        distance=1.0  # XAUUSD.s PRICE units, NOT tick-size units
        if trailing_stop:
            candidate=best+distance if leg.side=='BUY' else best-distance
            reason='support_trailing_sl'
        else:
            min_next=leg.entry+distance if leg.side=='BUY' else leg.entry-distance
            candidate=max(min_next,best) if leg.side=='BUY' else min(min_next,best)
            reason='opposite_side_sl'
        candidate=self._level(candidate,leg.side=='BUY')
        if leg.side=='BUY':
            r.buy_anchor=max(r.buy_anchor,candidate)
            level=r.buy_anchor
        else:
            r.sell_anchor=min(r.sell_anchor,candidate)
            level=r.sell_anchor
        r.anchor_priority_side=leg.side
        self._recovery_ledger(tick,'recovery_reentry_anchor',side=leg.side,
                              price=level,previous_entry=leg.entry,
                              best_seen=round(best,10),reason=reason,
                              opposite_level=(r.sell_anchor if leg.side=='BUY' else r.buy_anchor))

    def _enforce_recovery_opposite_range(self,tick:Tick, priority_side:Optional[str]=None):
        """Clamp the OPPOSITE anchor, never the recently established same-side
        extreme. The configurable gap is in XAUUSD.s price units, not ticks.

        A capped STOP can be temporarily unarmed if the live quote is already on
        its invalid side. Never turn that into a synthetic market fill.
        """
        r=self.recovery
        if r is None or not r.stepped_mode:return
        priority=priority_side or r.anchor_priority_side
        if priority not in ('BUY','SELL'):raise ValueError('Invalid recovery anchor side')
        r.anchor_priority_side=priority
        span=r.buy_anchor-r.sell_anchor
        limit=(self.settings.recovery_v2_opposite_max_range if r.variant=='extreme'
               else self.settings.recovery_opposite_max_range)
        if limit==0 or span<=limit+1e-8:return
        if priority=='BUY':
            r.sell_anchor=self._level(r.buy_anchor-limit,False)
        else:
            r.buy_anchor=self._level(r.sell_anchor+limit,True)
        # Tick grid may round outward one tick. Move the *opposite* level back
        # inward if needed, preserving the priority-side price.
        if r.buy_anchor-r.sell_anchor>limit+1e-8:
            if priority=='BUY':
                r.sell_anchor=self._level(r.buy_anchor-limit,True)
            else:
                r.buy_anchor=self._level(r.sell_anchor+limit,False)
        self._recovery_ledger(tick,'recovery_opposite_capped',priority_side=priority,
                              buy_level=r.buy_anchor,sell_level=r.sell_anchor,
                              max_range=limit)

    def move_trigger(self,kind:str,price:float,side:Optional[str]=None):
        """Authenticated user-confirmed PAPER trigger adjustment only.

        The chart never changes limits by itself: this method is invoked only
        after a price confirmation dialog, under AnalyzerService.engine_lock.
        """
        tick=self.latest
        if not tick:raise ValueError('No current market quote')
        if not isinstance(price,(int,float)) or not isfinite(price) or price<=0:
            raise ValueError('Invalid new trigger price')
        if kind=='standard':
            if not self.pending or self.position or self.recovery:
                raise ValueError('No standard pending trigger to move')
            name=self.pending.side
            snapped=self._level(price,name=='BUY')
            if (name=='BUY' and snapped<=tick.ask or name=='SELL' and snapped>=tick.bid):
                raise ValueError('BUY STOP must be above Ask; SELL STOP below Bid')
            old=self.pending.level
            self.pending.level=snapped
            self._event(tick.t_ms,'manual_move_trigger',side=name,price=snapped,
                        previous_price=old,kind='standard')
            return
        if kind=='recovery_first':
            r=self.recovery
            if not r or r.active or len(r.pending_stops)!=1 or (r.stepped_mode and r.variant!='extreme') or (r.variant=='extreme' and (r.reentries or r.recovery_sls)):
                raise ValueError('Нет ожидающего первого RECOVERY STOP')
            p=r.pending_stops[0]
            if side!=p['side']:
                raise ValueError('Первый RECOVERY STOP должен оставаться в противоположном направлении')
            snapped=self._level(price,side=='BUY')
            if (side=='BUY' and snapped<=tick.ask or side=='SELL' and snapped>=tick.bid):
                raise ValueError('BUY STOP должен быть выше Ask, SELL STOP ниже Bid')
            prior=p['level']
            p['level']=snapped;p['armed']=True;p['created_ms']=tick.t_ms
            self._recovery_ledger(tick,'manual_move_trigger',side=side,kind='recovery_first',
                                  price=snapped,previous_price=prior)
            return
        if kind=='recovery':
            r=self.recovery
            if r and r.variant=='fixed_flip':
                if side not in ('BUY','SELL'):
                    raise ValueError('Выбери сторону триггера RECOVERY V3')
                snapped=self._level(price,side=='BUY')
                # Explicit user override changes ONLY the selected virtual STOP.
                # It does NOT move actual-fill SL or silently move the other anchor.
                if r.active:
                    if side==r.active.side:
                        raise ValueError('Можно перемещать только встречный STOP')
                    r.v3_next_nominal=snapped
                    r.pending_stops=[dict(side=side,level=snapped,
                        lots=self.settings.recovery_v3_work_lots,armed=True)]
                else:
                    if (side=='BUY' and snapped<=tick.ask or
                            side=='SELL' and snapped>=tick.bid):
                        raise ValueError('Для BUY STOP уровень выше Ask, для SELL STOP ниже Bid')
                    r.v3_next_nominal=snapped
                    r.pending_stops=[dict(side=side,level=snapped,
                        lots=self.settings.recovery_v3_work_lots,armed=True)]
                if side=='BUY':r.buy_anchor=snapped
                else:r.sell_anchor=snapped
                self._recovery_ledger(tick,'v3_manual_reanchor',side=side,
                    buy_anchor=r.buy_anchor,sell_anchor=r.sell_anchor)
                return
            if not r or not r.stepped_mode or side not in ('BUY','SELL'):
                raise ValueError('Recovery drag is available only in stepped RECOVERY')
            snapped=self._level(price,side=='BUY')
            # Active triggers must remain valid STOPs at confirmation time.
            # While a leg is open these are PLANNED re-entry anchors only.
            if not r.active:
                if (side=='BUY' and snapped<=tick.ask or side=='SELL' and snapped>=tick.bid):
                    raise ValueError('BUY STOP must be above Ask; SELL STOP below Bid')
            # If the dragged side crosses the previous opposite anchor, the
            # opposite (secondary) anchor follows it by at least one tick.
            # An unarmed STOP cannot fill until price returns to its valid side.
            if side=='BUY':
                r.buy_anchor=snapped
                if r.sell_anchor>=snapped:
                    r.sell_anchor=self._level(snapped-self.settings.tick_size,False)
            else:
                r.sell_anchor=snapped
                if r.buy_anchor<=snapped:
                    r.buy_anchor=self._level(snapped+self.settings.tick_size,True)
            self._enforce_recovery_opposite_range(tick,side)
            if not r.active:self._recovery_reset_triggers(tick,priority_side=side)
            self._recovery_ledger(tick,'manual_move_trigger',side=side,
                                  price=snapped,kind='recovery',max_range=self.settings.recovery_opposite_max_range)
            return
        raise ValueError('Unknown trigger kind')

    def update_opposite_range(self,max_range:float):
        """Hot-update ONLY the cap while a cycle is active; changes future and
        existing virtual OCO levels without touching filled positions or SLs."""
        is_v2=(self.recovery and self.recovery.variant=='extreme') or (
            self.settings.recovery_enabled and self.settings.recovery_variant=='extreme')
        if self.recovery and self.recovery.variant=='fixed_flip':
            raise ValueError('V3 uses a fixed SL gap; edit the V3 gap between cycles')
        minimum=0 if is_v2 else .01
        if not isinstance(max_range,(int,float)) or not isfinite(max_range) or not minimum<=max_range<=100:
            raise ValueError(f'Maximum opposite range must be within {minimum}–100')
        from dataclasses import replace
        if is_v2:
            self.settings=replace(self.settings,recovery_v2_opposite_max_range=float(max_range))
        else:
            self.settings=replace(self.settings,recovery_opposite_max_range=float(max_range))
        r=self.recovery
        if r and r.stepped_mode and self.latest:
            self._enforce_recovery_opposite_range(self.latest)
            if not r.active:self._recovery_reset_triggers(self.latest)
        self._event(self.latest.t_ms if self.latest else 0,'recovery_range_changed',max_range=max_range)

    def _recovery_reset_triggers(self,tick:Tick,priority_side:Optional[str]=None):
        r=self.recovery
        if not r:return
        self._enforce_recovery_opposite_range(tick,priority_side)
        # Both STOP directions, anchored at the observed BEST price reached on
        # that side and at the opposite side's prior entry/extreme.
        # Mark armed only after price trades on the valid side of trigger.
        size=(self.settings.recovery_v2_work_lots if r.variant=='extreme'
              else self.settings.recovery_reentry_lots)
        r.pending_stops=[dict(side='BUY',level=r.buy_anchor,lots=size,
                              armed=tick.ask < r.buy_anchor-1e-9),
                         dict(side='SELL',level=r.sell_anchor,lots=size,
                              armed=tick.bid > r.sell_anchor+1e-9)]
        self._recovery_ledger(tick,'recovery_oco_placed',buy_level=r.buy_anchor,
                              sell_level=r.sell_anchor,actual_range=round(r.buy_anchor-r.sell_anchor,10),
                              range_limit=(self.settings.recovery_v2_opposite_max_range
                                           if r.variant=='extreme' else self.settings.recovery_opposite_max_range))

    def _recovery_tick(self,tick:Tick):
        r=self.recovery
        if r is None:return
        if r.variant=='fixed_flip':
            self._recovery_tick_v3(tick)
            return
        if r.variant=='extreme':
            self._recovery_tick_v2(tick)
            return
        weighted,cash=self._recovery_net(tick)
        r.max_loss_points=max(r.max_loss_points,-weighted/self.settings.volume_lots)
        self.max_active_recovery_loss_points=max(self.max_active_recovery_loss_points,r.max_loss_points)
        active=r.active
        if active and active.role=='fixed_tp':
            quote=self._close_quote(active.side,tick)
            sl_hit=(quote<=active.stop if active.side=='BUY' else quote>=active.stop)
            tp_hit=(quote>=active.tp if active.side=='BUY' else quote<=active.tp)
            # Fixed TP has priority on its own favorable tick; no first-phase trailing.
            if sl_hit:
                self._recovery_advance_reentry(tick,active,trailing_stop=False)
                self._recovery_close_lots(tick,active.lots,'recovery_sl')
                r.recovery_sls+=1;self.recovery_sls+=1
                self.recovery_partial_stops+=1
                r.stepped_mode=True
                self._recovery_ledger(tick,'recovery_stepped_activated',after='first_recovery_sl')
                self._recovery_reset_triggers(tick)
                return
            if tp_hit:
                # A take-profit limit is modeled at its TP price, while stop
                # gaps always use the adverse executable quote.
                self._recovery_close_lots(tick,active.lots,'recovery_fixed_tp',
                                          execution_price=active.tp)
                r.fixed_tps+=1;self.recovery_fixed_tps+=1
                # Fixed TP ends the ENTIRE cycle, regardless of whether it
                # reimbursed the initial SL. The remaining deficit is realized
                # in the cumulative global P/L, not carried to new RECOVERY.
                self._end_recovery(tick,'RECOVERY_TP')
                return
            # The first 0.12 leg stays on fixed TP / SL exclusively; no
            # stepped trailing or net-P/L early liquidation before TP or SL.
            self._recovery_observe_extreme(active,tick)
            return
        if self._recovery_target_met(tick):
            self._end_recovery(tick,'RECOVERED')
            return
        if active:
            quote=self._close_quote(active.side,tick)
            stop_hit=(quote<=active.stop if active.side=='BUY' else quote>=active.stop)
            if stop_hit:
                # An activated trailing stop is a SUPPORT stop.  A stop that
                # never trailed is an opposite-side SL3 (minimum +1/-1 rule).
                # Any adverse gap uses the current liquidation quote for P/L.
                self._recovery_advance_reentry(tick,active,
                    trailing_stop=active.trail_step_index>=0)
                self._recovery_close_lots(tick,active.lots,'recovery_sl')
                r.recovery_sls+=1;self.recovery_sls+=1
                self.recovery_partial_stops+=1  # deprecated field for older UI clients
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                else:
                    self._recovery_reset_triggers(tick)
                return
            self._recovery_observe_extreme(active,tick)
            self._recovery_trail_update(tick)
            if not r.active:return
            for i,level in enumerate(self.settings.recovery_take_levels):
                p=r.active
                if p is None or i<p.next_take_index:continue
                profit=self._close_quote(p.side,tick)-p.entry if p.side=='BUY' else p.entry-self._close_quote(p.side,tick)
                if profit+1e-8<level:break
                # Guard each take index; if gaps jump 1→3 all three close at the
                # next executable quote (not at invented intermediate prints).
                p.next_take_index=i+1
                self._recovery_close_lots(tick,self.settings.recovery_partial_lots,'recovery_partial_tp')
                r.partial_tps+=1;self.recovery_partial_tps+=1
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                    return
            return
        if not r.pending_stops:
            self._recovery_reset_triggers(tick)
            return
        hits=[]
        for p in r.pending_stops:
            # STOP level must be armed from its valid side. Initial recovery
            # trigger is pre-armed at SL for transition, but only fills NEXT tick.
            if not p.get('armed'):
                if p['side']=='BUY' and tick.ask < p['level']-1e-9:
                    p['armed']=True
                elif p['side']=='SELL' and tick.bid > p['level']+1e-9:
                    p['armed']=True
            elif ((p['side']=='BUY' and tick.ask>=p['level']) or
                  (p['side']=='SELL' and tick.bid<=p['level'])):
                hits.append(p)
        if len(hits)>1:
            self._recovery_ledger(tick,'recovery_ambiguous_spread',bid=tick.bid,ask=tick.ask)
            return
        if len(hits)==1:
            p=hits[0]
            entry=(max(p['level'],tick.ask) if p['side']=='BUY' else
                   min(p['level'],tick.bid))
            self._open_recovery_leg(tick,p['side'],entry,
                initial=r.reentries==0 and r.fixed_tps==0 and r.recovery_sls==0,
                lots=p.get('lots',self.settings.recovery_reentry_lots))

    def _end_recovery(self,tick:Tick,result:str,execution_price:Optional[float]=None):
        r=self.recovery
        if r is None:return
        weighted,cash=self._recovery_net(tick)
        origin=r.origin
        if r.active:
            # For a fixed V3 TP, credit the target LIMIT price, not a larger
            # hypothetical windfall after a gap. Other modes remain untouched.
            self._recovery_close_lots(tick,r.active.lots,'recovery_flatten',execution_price)
            if execution_price is not None:
                weighted=r.realized_weighted_points
                cash=(weighted/self.settings.tick_size*self.settings.tick_value_per_lot-
                      r.realized_commission_money) if self.settings.tick_value_per_lot>0 else None
        points=weighted/self.settings.volume_lots
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=origin.side,result=result,opened_ms=origin.opened_ms,
                   closed_ms=tick.t_ms,entry=origin.entry,exit=r.original_sl_exit,
                   tp=origin.tp,sl=origin.sl,trigger_level=origin.trigger_level,
                   pnl_points=round(points,10),pnl_weighted_points_lots=round(weighted,10),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=round(origin.mfe,10),mae_points=round(origin.mae,10),
                   gap_to_tp=round(max(0.,abs(origin.tp-origin.entry)-origin.mfe),10),
                   duration_seconds=round((tick.t_ms-origin.opened_ms)/1000,3),
                   signal_time=origin.signal_time,signal_body=round(origin.signal_body,6),
                   signal_range=round(origin.signal_range,6),signal_color=origin.signal_color,
                   spread_at_entry=round(origin.entry_spread,10),
                   entry_utc_hour=datetime.fromtimestamp(origin.opened_ms/1000,timezone.utc).hour,
                   recovery_used=True,recovery_actions=r.actions[:],
                   recovery_actions_truncated=r.truncated_actions,
                   recovery_partial_stops=r.recovery_sls,recovery_partial_tps=r.partial_tps,
                   recovery_fixed_tps=r.fixed_tps,
                   recovery_reentries=r.reentries,recovery_max_loss_points=round(r.max_loss_points,7),
                   unrecovered_loss_points=round(min(0.,points),10),
                   unrecovered_loss_money_est=round(min(0.,cash),5) if cash is not None else None,
                   buy_anchor=r.buy_anchor,sell_anchor=r.sell_anchor,
                   recovery_variant=r.variant)
        self.trades.append(trade);self.new_trades.append(trade)
        self.realized_cycle_points+=trade['pnl_points']
        if result=='RECOVERED':self.recovery_completed+=1
        event_type=('recovery_complete' if result=='RECOVERED' else
                    'recovery_fixed_cycle_complete' if result=='RECOVERY_TP' else
                    'recovery_manual_exit' if result=='MANUAL_RECOVERY' else 'recovery_aborted')
        self._event(tick.t_ms,event_type,trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'],pnl_money_est=trade['pnl_money_est'],
                    unrecovered_loss_points=trade['unrecovered_loss_points'])
        self.position=None;self.recovery=None
        self._next_cycle_after_close(tick)

    def _equity_points(self, tick: Optional[Tick] = None) -> float:
        closed=self.realized_cycle_points
        now=tick or self.latest
        if now is None:return closed
        manual=sum(self._weighted_move(p,self._close_quote(p.side,now))
                   for p in self.manual_positions)/self.settings.volume_lots
        if self.recovery:
            raw,_=self._recovery_net(now)
            return closed+raw/self.settings.volume_lots+manual
        if self.position:
            pos=self.position
            quote=self._close_quote(pos.side,now)
            move=quote-pos.entry if pos.side=='BUY' else pos.entry-quote
            return closed+move*self._position_lots(pos)/self.settings.volume_lots+manual
        return closed+manual

    def _track_equity(self):
        if self.latest is None:return
        equity=self._equity_points(self.latest)
        self.equity_peak_points=max(self.equity_peak_points,equity)
        self.min_equity_points=min(self.min_equity_points,equity)
        self.max_equity_drawdown_points=max(self.max_equity_drawdown_points,
                                            self.equity_peak_points-equity)

    def on_tick(self, tick: Tick):
        if self.last_tick_signature == (tick.t_ms,tick.bid,tick.ask):
            return
        if self.latest and tick.t_ms < self.latest.t_ms:
            self.skipped_invalid += 1
            return
        if self.latest:
            self.max_tick_gap_ms = max(self.max_tick_gap_ms, tick.t_ms-self.latest.t_ms)
        else:
            self.first_tick_ms = tick.t_ms
        self.last_tick_signature = (tick.t_ms,tick.bid,tick.ask)
        self.latest = tick
        self.tick_count += 1
        self._manual_fill_orders(tick)
        minute = (tick.t_ms // 60000) * 60
        if self.candle is None:
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            if self.mode == 'running' and self.arm_minute is None:
                self.arm_minute = minute
        elif minute != self.candle.time:
            # The old STOP still exists at the *first tick* of a new minute.
            # Broker may execute it before our simulated cancel/replace request.
            if self.mode in ('running', 'stopping') and self.pending is not None and self.position is None and self.recovery is None:
                self._fill(tick)
                filled_on_boundary = self.position is not None
            else:
                filled_on_boundary = False
            old = self.candle
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            self._finish_bar(old,tick.t_ms)
            if filled_on_boundary:
                self._position_tick(tick)
                self._track_equity()
                return
        else:
            self.candle.on_tick(tick.bid)
        if self.mode in ('running', 'stopping'):
            if self.recovery:
                self._recovery_tick(tick)
            elif self.position:
                self._position_tick(tick)
            elif self.pending:
                self._fill(tick)
                # No same-tick exit for freshly filled position.
        self._track_equity()

    def summary(self) -> dict:
        trades=self.trades
        tp=sum(t['result']=='TP' for t in trades)
        sl=sum(t['result']=='SL' for t in trades)
        recovered=sum(t['result']=='RECOVERED' for t in trades)
        recovery_tp_cycles=sum(t['result']=='RECOVERY_TP' for t in trades)
        recovery_tp_loss_cycles=sum(t['result']=='RECOVERY_TP' and
                                    (t.get('pnl_money_est') if t.get('pnl_money_est') is not None
                                     else t['pnl_points']) < -1e-8 for t in trades)
        aborted=sum(t['result']=='ABORTED' for t in trades)
        gross_win=sum(max(0,t['pnl_points']) for t in trades)
        gross_loss=-sum(min(0,t['pnl_points']) for t in trades)
        balance=peak=max_dd=0.0
        for t in trades:
            balance+=t['pnl_points']
            peak=max(peak,balance)
            max_dd=max(max_dd,peak-balance)
        near={f'{v:.2f}':sum(t['result']=='SL' and t['gap_to_tp']<=v+1e-9 for t in trades)
              for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        near_recovery={f'{v:.2f}':sum(t.get('recovery_used',False) and
                          t.get('gap_to_tp',float('inf'))<=v+1e-9 for t in trades)
                       for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        weighted=None;active_money=None;open_recovery=None
        if self.recovery and self.latest:
            rec=self.recovery
            weighted,active_money=self._recovery_net(self.latest)
            open_recovery=dict(started_ms=rec.started_ms,buy_anchor=rec.buy_anchor,
                sell_anchor=rec.sell_anchor,partial_stops=rec.recovery_sls,
                partial_tps=rec.partial_tps,fixed_tps=rec.fixed_tps,
                stepped_mode=rec.stepped_mode,reentries=rec.reentries,
                realized_weighted_points=round(rec.realized_weighted_points,7),
                unrealized_and_realized_points_equivalent=round(weighted/self.settings.volume_lots,5),
                net_money_est=round(active_money,4) if active_money is not None else None)
        equity=self._equity_points()
        cash_closed=(round(sum(t['pnl_money_est'] for t in trades),4)
                     if all(t['pnl_money_est'] is not None for t in trades) else None)
        active_cost_est=None
        if self.position and not self.recovery and self.latest and self.settings.tick_value_per_lot>0:
            pos=self.position
            quote=self._close_quote(pos.side,self.latest)
            points=quote-pos.entry if pos.side=='BUY' else pos.entry-quote
            active_cost_est=(points/self.settings.tick_size*self.settings.tick_value_per_lot-
                             self.settings.commission_per_lot_roundtrip)*self._position_lots(pos)
        manual_active_cash=0.0
        if self.latest and self.settings.tick_value_per_lot>0:
            for item in self.manual_positions:
                quote=self._close_quote(item.side,self.latest)
                move=(quote-item.entry if item.side=='BUY' else item.entry-quote)
                manual_active_cash+=(move/self.settings.tick_size*self.settings.tick_value_per_lot-
                                     self.settings.commission_per_lot_roundtrip)*item.lots
        if cash_closed is not None:
            if self.recovery and active_money is not None:
                net_cash=cash_closed+active_money+manual_active_cash
            elif active_cost_est is not None:
                net_cash=cash_closed+active_cost_est+manual_active_cash
            else:
                net_cash=cash_closed+manual_active_cash
        else:
            net_cash=None
        positive_cycles=sum((t.get('pnl_money_est') if t.get('pnl_money_est') is not None
                                  else t['pnl_points'])>1e-8 for t in trades)
        return dict(trades=len(trades),tp=tp,sl=sl,recovered=recovered,aborted=aborted,
            recovery_tp_cycles=recovery_tp_cycles,recovery_tp_loss_cycles=recovery_tp_loss_cycles,
            win_rate=round(100*positive_cycles/len(trades),2) if trades else 0,
            pnl_points=round(balance,5),max_drawdown_points=round(max_dd,5),
            equity_points=round(equity,5),
            max_equity_drawdown_points=round(self.max_equity_drawdown_points,5),
            min_equity_points=round(self.min_equity_points,5),
            profit_factor=round(gross_win/gross_loss,3) if gross_loss else None,
            pnl_money_est=cash_closed,net_equity_money_est=round(net_cash,4) if net_cash is not None else None,
            near_tp_then_sl=near,near_tp_then_recovery=near_recovery,
            recovery_activations=self.recovery_activations,
            recovery_completed=self.recovery_completed,
            recovery_partial_stops=self.recovery_partial_stops,
            recovery_partial_tps=self.recovery_partial_tps,
            recovery_fixed_tps=self.recovery_fixed_tps,recovery_sls=self.recovery_sls,
            recovery_reentries=self.recovery_reentries,
            recovery_aborted=self.recovery_aborted,
            max_active_recovery_loss_points=round(self.max_active_recovery_loss_points,5),
            open_recovery=open_recovery,unresolved_recovery=1 if self.recovery else 0,
            unfinished_cycle=1 if self.position is not None else 0,
            manual_open_positions=len(self.manual_positions),
            manual_pending_stops=len(self.manual_stops),
            manual_closed_trades=sum(bool(t.get('manual')) for t in trades),
            placed=self.placed_orders,canceled=self.canceled_orders,triggered=self.triggered_orders,
            tick_count=self.tick_count,max_tick_gap_seconds=round(self.max_tick_gap_ms/1000,3))

    def public_state(self) -> dict:
        rec=self.recovery
        recovery_info=None
        if rec is not None:
            weighted,cash=self._recovery_net(self.latest) if self.latest else (0.,None)
            recovery_info=dict(started_ms=rec.started_ms,buy_anchor=rec.buy_anchor,
                sell_anchor=rec.sell_anchor,initial_sl_exit=rec.original_sl_exit,
                active=asdict(rec.active) if rec.active else None,
                pending_stops=rec.pending_stops[:],
                realized_weighted_points=round(rec.realized_weighted_points,7),
                equity_points_equivalent=round(weighted/self.settings.volume_lots,6),
                equity_money_est=round(cash,5) if cash is not None else None,
                partial_stops=rec.recovery_sls,partial_tps=rec.partial_tps,
                fixed_tps=rec.fixed_tps,stepped_mode=rec.stepped_mode,
                variant=rec.variant,
                original_buy_anchor=rec.original_buy_anchor,
                original_sell_anchor=rec.original_sell_anchor,
                reentries=rec.reentries,
                v3_flip_count=rec.v3_flip_count,
                v3_tp_targets=(rec.active.v3_tp_targets[:] if rec.active else []),
                opposite_max_range=(self.settings.recovery_v3_stop_gap if rec.variant=='fixed_flip'
                                    else self.settings.recovery_v2_opposite_max_range if rec.variant=='extreme'
                                    else self.settings.recovery_opposite_max_range),
                actual_anchor_range=round(rec.buy_anchor-rec.sell_anchor,10))
        return dict(mode=self.mode,settings=asdict(self.settings),
                    tick=asdict(self.latest) if self.latest else None,
                    candle=asdict(self.candle) if self.candle else None,
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    recovery=recovery_info,
                    manual_positions=[asdict(x) for x in self.manual_positions],
                    manual_stops=[asdict(x) for x in self.manual_stops],
                    summary=self.summary(),events=self.events[-30:],trades=self.trades[-35:])

    def chart_candles(self, max_rows=450) -> list[dict]:
        data = self.candles[-max_rows:]
        if self.candle:
            data = data + [asdict(self.candle)]
        return data

    def to_snapshot(self) -> dict:
        # No transient output buffers, they are already stored separately.
        return dict(support_sl_rules_version=134,settings=asdict(self.settings),mode=self.mode,arm_minute=self.arm_minute,
                    candle=asdict(self.candle) if self.candle else None,candles=self.candles[-750:],
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    recovery=asdict(self.recovery) if self.recovery else None,
                    manual_positions=[asdict(p) for p in self.manual_positions],
                    manual_stops=[asdict(p) for p in self.manual_stops],manual_seq=self.manual_seq,
                    latest=asdict(self.latest) if self.latest else None,
                    trade_seq=self.trade_seq,order_seq=self.order_seq,
                    trades=self.trades,events=self.events[-250:],canceled_orders=self.canceled_orders,
                    placed_orders=self.placed_orders, triggered_orders=self.triggered_orders,
                    tick_count=self.tick_count,skipped_invalid=self.skipped_invalid,
                    first_tick_ms=self.first_tick_ms,max_tick_gap_ms=self.max_tick_gap_ms,
                    realized_cycle_points=self.realized_cycle_points,
                    recovery_activations=self.recovery_activations,
                    recovery_completed=self.recovery_completed,
                    recovery_partial_stops=self.recovery_partial_stops,
                    recovery_partial_tps=self.recovery_partial_tps,recovery_sls=self.recovery_sls,
                    recovery_reentries=self.recovery_reentries,
                    recovery_fixed_tps=self.recovery_fixed_tps,
                    recovery_aborted=self.recovery_aborted,
                    max_active_recovery_loss_points=self.max_active_recovery_loss_points,
                    equity_peak_points=self.equity_peak_points,
                    max_equity_drawdown_points=self.max_equity_drawdown_points,
                    min_equity_points=self.min_equity_points)

    @classmethod
    def from_snapshot(cls, data: dict) -> 'PaperEngine':
        settings_data=dict(data['settings'])
        if data.get('support_sl_rules_version') not in (134,180):
            # One-time in-memory conversion of old saved v1.3.1-1.3.3 settings.
            # All other user settings, history, tick cache and password survive.
            settings_data['recovery_trail_activation']=0.0
            settings_data['recovery_trail_start_offset']=1.0
        e = cls(Settings(**settings_data))
        for attr, typ in [('candle',Candle),('pending',Pending),('position',Position),('latest',Tick)]:
            if data.get(attr):
                setattr(e,attr,typ(**data[attr]))
        rec=data.get('recovery')
        if rec:
            # Migration safeguard: v1.2 hedge baskets cannot be resumed using
            # v1.3 stop-based accounting. Stop rather than reinterpret them.
            if 'origin' not in rec:
                raise ValueError('Old RECOVERY state requires reset before v1.3')
            e.recovery=RecoveryState(started_ms=rec['started_ms'],
                origin=Position(**rec['origin']),
                original_sl_exit=rec['original_sl_exit'],
                buy_anchor=rec['buy_anchor'],sell_anchor=rec['sell_anchor'],
                active=RecoveryLeg(**rec['active']) if rec.get('active') else None,
                pending_stops=rec.get('pending_stops',[]),
                realized_weighted_points=rec.get('realized_weighted_points',0.),
                realized_commission_money=rec.get('realized_commission_money',0.),
                partial_tps=rec.get('partial_tps',0),
                fixed_tps=rec.get('fixed_tps',0),
                # Old v1.3 active state must not silently be treated as first TP.
                stepped_mode=rec.get('stepped_mode',True),
                recovery_sls=rec.get('recovery_sls',0),
                reentries=rec.get('reentries',0),
                max_loss_points=rec.get('max_loss_points',0.),
                actions=rec.get('actions',[]),
                truncated_actions=rec.get('truncated_actions',0),
                anchor_priority_side=rec.get('anchor_priority_side','SELL'),
                variant=rec.get('variant','classic'),
                original_buy_anchor=rec.get('original_buy_anchor'),
                original_sell_anchor=rec.get('original_sell_anchor'),
                v3_flip_count=rec.get('v3_flip_count',0),
                v3_last_nominal=rec.get('v3_last_nominal'),
                v3_next_nominal=rec.get('v3_next_nominal'))
        for attr in ('mode','arm_minute','trade_seq','order_seq','canceled_orders','placed_orders',
                     'triggered_orders','skipped_invalid','tick_count','first_tick_ms','max_tick_gap_ms',
                     'recovery_activations','recovery_completed','recovery_partial_stops',
                     'recovery_reentries','recovery_partial_tps','recovery_fixed_tps','recovery_sls',
                     'recovery_aborted','max_active_recovery_loss_points',
                     'equity_peak_points','max_equity_drawdown_points','min_equity_points',
                     'realized_cycle_points'):
            if attr in data:
                setattr(e,attr,data[attr])
        e.candles = data.get('candles',[])
        e.trades = data.get('trades',[])
        if 'realized_cycle_points' not in data:
            e.realized_cycle_points=sum(t['pnl_points'] for t in e.trades)
        e.events = data.get('events',[])
        e.manual_positions=[ManualPosition(**p) for p in data.get('manual_positions',[])]
        e.manual_stops=[ManualStop(**p) for p in data.get('manual_stops',[])]
        e.manual_seq=data.get('manual_seq',0)
        e.last_tick_signature = (e.latest.t_ms,e.latest.bid,e.latest.ask) if e.latest else None
        return e

'use strict';
// No third-party chart library, account keys, exchange permissions or trading APIs.
const $ = (id) => document.getElementById(id);
const app = {tab:'live', status:null, marketCandles:[], replay:null, replayTimer:null,
  currentRun:null, selectedVariant:null, variants:[], settingsTouched:false, firstStatus:true,
  visibleBars:76, rightOffset:0, pointerMap:new Map(), drag:null, hover:null, mouseX:0, rendering:false,
  chartGeometry:null,virtualAction:null,previewLevel:null,gesture:null};
const currency=(n,d=2)=>Number.isFinite(Number(n))?Number(n).toFixed(d):'—';
const sign=(n)=>Number(n)>0?'+':'';
const htmlesc=(str)=>String(str).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const ts=(ms,full=false)=>ms?new Date(ms).toLocaleString('ru-RU', full?{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}:{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';
const safe=(x)=>htmlesc(x??'—');
let toastTimer;
function toast(message){const el=$('toast');el.textContent=message;el.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),6500);}
async function api(path,options={}){
  const opts={credentials:'same-origin',...options,headers:{...(options.body?{'Content-Type':'application/json'}:{}),...options.headers}};
  const res=await fetch(path,opts);let data;
  try {data=await res.json();}catch {data=null;}
  if(!res.ok)throw Error(typeof data?.detail==='string'?data.detail:`HTTP ${res.status}`);
  return data;
}
function bodyForm(form){return Object.fromEntries(new FormData(form));}
function toggleTab(tab){
  app.tab=tab;
  document.querySelectorAll('[data-tab]').forEach(e=>e.classList.toggle('active',e.dataset.tab===tab));
  document.querySelectorAll('.page').forEach(e=>e.classList.toggle('active',e.id===`tab-${tab}`));
  $('activeBreadcrumb').textContent={live:'Онлайн',backtest:'Массовые тесты',insights:'Закономерности',history:'История'}[tab]||tab;
  if(tab==='history')refreshJobs();
  if(tab==='backtest')refreshVariants();
  if(tab==='insights')refreshRegimes();
  if(tab==='live')requestAnimationFrame(drawChart);
  window.scrollTo({top:0,behavior:'instant'});
}
function floatField(form,name){const v=Number(form.elements[name].value);if(!Number.isFinite(v))throw Error(`Неверное значение: ${name}`);return v;}
function setSettings(settings){
  if(app.settingsTouched)return;
  const form=$('settingsForm');
  for(const key of ['trigger_distance','tp_distance','sl_distance','volume_lots',
     'recovery_reentry_lots','recovery_trail_start_offset','recovery_trail_step','recovery_partial_lots','commission_per_lot_roundtrip','recovery_opposite_max_range',
     'recovery_v2_initial_lots','recovery_v2_work_lots','recovery_v2_trigger_distance',
     'recovery_v2_initial_tp_distance','recovery_v2_initial_sl_distance',
     'recovery_v2_support_sl_distance','recovery_v2_trail_step',
     'recovery_v2_reentry_offset','recovery_v2_opposite_max_range',
     'recovery_v3_initial_lots','recovery_v3_work_lots','recovery_v3_trigger_distance',
     'recovery_v3_initial_tp_distance','recovery_v3_stop_gap','recovery_v3_initial_sl_distance',
     'recovery_v3_partial_lots','recovery_v3_expansion']){
    if(settings[key]!==undefined && form.elements[key])form.elements[key].value=settings[key];
  }
  form.elements.recovery_enabled.checked=!!settings.recovery_enabled;
  form.elements.recovery_variant.value=settings.recovery_variant||'classic';
  if(form.elements.recovery_v3_range_mode)form.elements.recovery_v3_range_mode.value=settings.recovery_v3_range_mode||'fixed';
  showRecoveryFields();
}
function showRecoveryFields(){
  const f=$('settingsForm').elements;
  const active=f.recovery_enabled.checked,variant=f.recovery_variant.value;
  const extreme=active&&variant==='extreme',fixed=active&&variant==='fixed_flip';
  document.querySelectorAll('[data-recovery-mode]').forEach(el=>{
    const chosen=el.dataset.recoveryMode===variant;
    el.classList.toggle('active',chosen);el.setAttribute('aria-pressed',String(chosen));
  });
  document.querySelector('.recovery-classic-settings').classList.toggle('hidden',!active||variant!=='classic');
  document.querySelector('.recovery-v2-settings').classList.toggle('hidden',!extreme);
  document.querySelector('.recovery-v3-settings').classList.toggle('hidden',!fixed);
  document.querySelector('.classic-basic-settings').classList.toggle('hidden',extreme||fixed);
  const b=$('backtestForm')?.elements;
  if(b){
    const btV2=b.recovery_enabled.checked&&b.recovery_variant.value==='extreme';
    const btV3=b.recovery_enabled.checked&&b.recovery_variant.value==='fixed_flip';
    document.querySelectorAll('.backtest-v2-fields').forEach(node=>node.classList.toggle('hidden',!btV2));
    document.querySelectorAll('.backtest-v3-fields').forEach(node=>node.classList.toggle('hidden',!btV3));
    document.querySelector('.backtest-classic-support').classList.toggle('hidden',btV2||btV3);
    $('backtestInitialSlTitle').textContent=btV2?'SL только первого входа с TP 0.25':btV3?'Единый SL / расстояние фиксированных BUY–SELL':'SL / запуск RECOVERY';
  }
}
function presentStatus(s){
  app.status=s;
  if(app.firstStatus){setSettings(s.settings);app.firstStatus=false;}
  const isDemo=s.source==='demo';
  // Compact, accurate source indication: never present training quotes as MT5.
  $('sourceName').textContent=isDemo?'Учебный поток':s.symbol;
  $('sourcePill').textContent=isDemo?'ТРЕНАЖЁР':'MT5 CFD';
  $('sourcePill').style.color=isDemo?'#f0c878':'';
  $('connectionBanner').classList.toggle('hidden',s.connection==='connected'&&!s.data_quality_warning&&!s.recovery_volume_warning);
  $('connectionError').textContent=[s.error,s.data_quality_warning,s.recovery_volume_warning].filter(Boolean).join(' · ')||'Ожидание данных котировок';
  const conn=$('sidebarConnection');conn.className='connection '+s.connection;conn.innerHTML=`<i class="status-led"></i> ${s.connection==='connected'?'Котировки доступны':s.connection==='catching_up'?'Синхронизация истории':'Соединение отсутствует'}`;
  const mode=s.mode;
  const badge=$('liveModeBadge');badge.textContent={stopped:'Остановлен',running:'● Анализ активен',stopping:'Завершаем цикл'}[mode]||mode;
  badge.className='tag '+(mode==='running'?'active':mode==='stopping'?'stopping':'neutral');
  $('btnStart').disabled=mode!=='stopped'; $('btnStop').disabled=mode==='stopped';
  $('bidPrice').textContent=currency(s.tick?.bid); $('askPrice').textContent=currency(s.tick?.ask);
  // Display ONLY the live broker Bid, never a hard-coded preview price.
  const lastBid=app.displayedBid, bid=Number(s.tick?.bid);
  const quote=$('lastPrice');
  if(Number.isFinite(bid)){
    quote.textContent=currency(bid);
    if(Number.isFinite(lastBid) && bid!==lastBid){
      quote.classList.toggle('rising',bid>lastBid);
      quote.classList.toggle('falling',bid<lastBid);
    }
    app.displayedBid=bid;
  }else{quote.textContent='—';}
  $('quoteMovement').textContent=isDemo?'Bid · учебный поток':'Bid · котировка XAUUSD.s';
  const stage=s.recovery?.variant==='fixed_flip'?'RECOVERY V3 · фиксированный SL':s.recovery?.variant==='extreme'?'RECOVERY V2 · экстремумы':s.recovery?.stepped_mode?'Ступенчатый RECOVERY':s.recovery?'Первый RECOVERY 0.12':
    s.position?'Позиция открыта':s.pending?'Ожидание триггера':s.mode==='running'?'Ожидаем закрытую M1':'Анализ остановлен';
  $('runHeadline').textContent=stage;
  $('runHint').textContent=s.mode==='running'?'Виртуальное исполнение Bid / Ask':
    s.mode==='stopping'?'Завершается активный цикл':'Нажми «Запустить», чтобы продолжить';
  document.querySelector('.run-state').classList.toggle('running',s.mode==='running');
  $('positionQuick').textContent=s.recovery?.active?`${s.recovery.active.side} ${currency(s.recovery.active.lots)} л.`:
    s.position?`${s.position.side} ${currency(s.position.lots??s.settings.volume_lots)} л.`:'Нет';
  $('triggerQuick').textContent=s.recovery?.pending_stops?.length?`${s.recovery.pending_stops.length} STOP`:
    s.pending?`${s.pending.side} STOP`:'Нет';
  const active=s.recovery?.active;
  $('tpSlQuick').textContent=active?
    `${active.tp!=null?currency(active.tp):'—'} / ${currency(active.stop)}`:
    s.position?`${currency(s.position.tp)} / ${currency(s.position.sl)}`:'— / —';
  $('cycleQuick').textContent=s.recovery?'RECOVERY':s.position||s.pending?'Обычный':'—';
  $('recoveryQuick').textContent=s.recovery?(s.recovery.variant==='fixed_flip'?'V3 · фикс. SL':s.recovery.variant==='extreme'?'V2 · экстремумы':s.recovery.stepped_mode?'Ступенчатый V1':'Первый 0.12 V1'):'Не активен';
  const pnl=s.summary?.net_equity_money_est;
  const equiv=s.summary?.equity_points??s.summary?.pnl_points;
  $('pnlQuick').textContent=pnl!=null?`${sign(pnl)}${currency(pnl)}`:
    Number.isFinite(Number(equiv))?`${sign(equiv)}${currency(equiv)} п.`:'—';
  $('pnlQuick').className=Number(pnl??equiv)<0?'negative':Number(pnl??equiv)>0?'positive':'';
  $('spreadPrice').textContent=s.tick?currency(s.tick.ask-s.tick.bid):'—';
  const offset=s.details?.clock_offset_hours;
  const offsetLabel=Number.isFinite(offset)?` · MT5 ${offset>=0?'+':''}${offset}ч → UTC`:'';
  $('chartCaption').textContent=`Bid-свечи · M1 · UTC${isDemo?' · учебный поток':offsetLabel}`;
  const sum=s.summary;
  updateManualPositions(s);
  $('tpCount').textContent=sum.tp; $('recoveredCount').textContent=sum.recovered??0;
  $('tradeCount').textContent=sum.trades;
  $('winRate').textContent=currency(sum.win_rate,1)+'%';
  const equity=sum.equity_points??sum.pnl_points;
  $('netPoints').textContent=sign(equity)+currency(equity);
  $('netPoints').className=equity>0?'positive':equity<0?'negative':'';
  $('maxDrawdown').textContent=currency(sum.max_equity_drawdown_points??sum.max_drawdown_points);
  const globalMoney=sum.net_equity_money_est;
  $('netMoney').textContent=globalMoney==null?
    'Общий P/L в валюте счёта: стоимость тика MT5 пока неизвестна; смотри эквивалентные пункты.':
    `Общий P/L (включая некомпенсированные убытки после TP 0.25): ${sign(globalMoney)}${currency(globalMoney)} в валюте счёта`;
  $('netMoney').className='net-money-summary '+(globalMoney<0?'negative':globalMoney>0?'positive':'');
  const ongoing=sum.open_recovery;
  $('recoveryPulse').textContent=ongoing?
    `RECOVERY активен · Текущий P/L: ${sign(ongoing.unrealized_and_realized_points_equivalent)}${currency(ongoing.unrealized_and_realized_points_equivalent)} экв. п. · `+
    `Первых TP: ${ongoing.fixed_tps??0} · Частичных TP: ${ongoing.partial_tps} · Перевходов: ${ongoing.reentries}`:
    `RECOVERY возмещено полностью: ${sum.recovered??0} · Закрыто первым TP 0.25: ${sum.recovery_tp_cycles??0} · `+
    `С остаточным убытком: ${sum.recovery_tp_loss_cycles??0} · Частичных TP: ${sum.recovery_partial_tps??0} · `+
    `Незавершённых: ${sum.unresolved_recovery??0}`;
  $('nearTPStats').innerHTML=Object.entries(sum.near_tp_then_sl).map(([v,n])=>
    `<div class="near-item">≤ ${safe(v)}<strong>${n} SL</strong></div>`).join('')+
    Object.entries(sum.near_tp_then_recovery||{}).map(([v,n])=>
    `<div class="near-item">≤ ${safe(v)}<strong>${n} REC</strong></div>`).join('');
  updateCycle(s);
  updateEvents(s.events||[]);
  updateLiveTrades(s.trades||[]);
  if(!app.replay && s.tick){
    updateCurrentBidCandle(s.tick);
  }
  requestDraw();
}
function updateCycle(s){
  const p=s.position, pend=s.pending, r=s.recovery, has=p||pend||r;
  $('cycleDot').classList.toggle('active',!!has);
  $('cycleStatus').textContent=r?
    (r.variant==='fixed_flip'?'RECOVERY V3: единый SL · адаптивные частичные TP · три диапазона':r.variant==='extreme'?'RECOVERY V2: возмещение убытка · защита + экстремумы':r.stepped_mode?'RECOVERY V1: ступенчатый TP после SL 0.12':'RECOVERY V1: первый 0.12 · TP 0.25 / SL 3'):
    p?'Позиция открыта':pend?'Триггер ожидает исполнения':
    s.mode==='running'?'Ожидание закрытой свечи':'Нет активного цикла';
  if(!has){$('currentCycle').innerHTML=`<div class="state-placeholder">${s.mode==='running'?'После закрытия M1 будет установлен новый виртуальный STOP.':'Запусти симуляцию для отслеживания триггеров.'}</div>`;return;}
  let rows=[],side=p?.side??pend?.side??'BUY',status=p?'ОТКРЫТО':'PENDING';
  if(r){
    status='RECOVERY';
    side=r.active?.side??r.pending_stops?.[0]?.side??side;
    rows=[['Первоначальная позиция','Закрыта по SL '+currency(r.initial_sl_exit)],
      ['Верхний BUY STOP / фиксированный уровень',currency(r.buy_anchor)],
      ['Нижний SELL STOP / фиксированный уровень',currency(r.sell_anchor)],
      ['Рабочая позиция',r.active?`${r.active.side} ${currency(r.active.entry)} · ${currency(r.active.lots)} лота`:'Ожидает STOP'],
      ['Фаза RECOVERY',r.variant==='fixed_flip'?'V3: SL от исполнения, TP частями для возмещения убытков':r.variant==='extreme'?'V2: расчёт TP по накопленному убытку':r.stepped_mode?'Ступенчатая V1 (после SL 0.12)':'Первоначальная · фиксированный TP 0.25'],
      ['Текущий целевой TP',r.active?.tp==null?'—':currency(r.active.tp)],
      ...(r.variant==='fixed_flip'?[
        ['TP частей (оставшиеся)',r.active?.v3_tp_targets?.length||0],
        ['Последняя цель TP',r.active?.v3_tp_targets?.length?currency(r.active.v3_tp_targets.at(-1).price):'—'],
        ['Переключения V3',r.v3_flip_count??0]
      ]:[]),
      ['SL текущей RECOVERY-позиции',r.active?currency(r.active.stop):'—'],
      ['Экстремум для перевхода (BUY Ask / SELL Bid)',r.active?.best_trigger_quote==null?'—':currency(r.active.best_trigger_quote)],
      ['Встречные триггеры',r.pending_stops?.map(x=>x.side+' '+currency(x.level)).join(' / ')||'Нет'],
      ['Накопленный результат, пункт×лот',currency(r.realized_weighted_points,5)],
      ['Общий P/L, экв. пункты',`${sign(r.equity_points_equivalent)}${currency(r.equity_points_equivalent)}`],
      ['Общий P/L, расчёт',r.equity_money_est===null?'Стоимость тика неизвестна':`${sign(r.equity_money_est)}${currency(r.equity_money_est)} (валюта счёта)`],
      ['Частичные TP / SL / перевходы',`${r.partial_tps} / ${r.partial_stops} / ${r.reentries}`]];
  }else if(p){
    rows=[['Цена входа',currency(p.entry)],['Take Profit',currency(p.tp)],
      ['Stop Loss',currency(p.sl)],
      ['Спред при входе',currency(p.entry_spread)],['MFE / MAE',`${currency(p.mfe)} / ${currency(p.mae)}`]];
  }else{
    rows=[['Триггер STOP',currency(pend.level)],
      ['Закрытая свеча',new Date(pend.signal_time*1000).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})],
      ['TP (ориентир)',currency(side==='BUY'?pend.level+
        (s.settings.recovery_enabled&&s.settings.recovery_variant==='fixed_flip'?s.settings.recovery_v3_initial_tp_distance:s.settings.tp_distance):
         pend.level-(s.settings.recovery_enabled&&s.settings.recovery_variant==='fixed_flip'?s.settings.recovery_v3_initial_tp_distance:s.settings.tp_distance))],
      ['SL (ориентир)',currency(side==='BUY'?pend.level-
        (s.settings.recovery_enabled&&s.settings.recovery_variant==='fixed_flip'?s.settings.recovery_v3_initial_sl_distance:s.settings.sl_distance):
         pend.level+(s.settings.recovery_enabled&&s.settings.recovery_variant==='fixed_flip'?s.settings.recovery_v3_initial_sl_distance:s.settings.sl_distance))]];
  }
  $('currentCycle').innerHTML=`<div class="cycle-type"><span class="type ${side.toLowerCase()}">${r?'RECOVERY':side+' '+(p?'POSITION':'STOP')}</span><span>${status}</span></div>`+
    rows.map(([name,value])=>`<div class="price-row"><span>${safe(name)}</span><b>${safe(value)}</b></div>`).join('');
}
const eventText={v3_spread_overlap:'V3: спред перекрыл оба уровня; ждём повторного подтверждения STOP',v3_recovery_start:'V3: SL первой позиции, активирован встречный STOP',v3_fixed_fill:'V3: вход по фиксированному уровню',v3_fixed_sl:'V3: фиксированный SL',v3_flip:'V3: переход к противоположному фиксированному STOP',v3_manual_reanchor:'V3: ручной перенос встречного STOP',v3_grid_recalculated:'V3: пересчёт частичных TP',v3_partial_tp:'V3: закрыта часть позиции по TP',v3_sl_wait_stop:'V3: SL исполнен, ожидаем следующий STOP',v3_next_stop_planned:'V3: намечен противоположный STOP',v3_anchor_stop_armed:'V3: ожидание следующего STOP',v3_manual_market:'V3: ручной вход',start:'Запуск анализа',stop_requested:'Остановка после цикла',forced_stop:'Принудительная остановка',forced_cancel:'Отмена триггера',forced_abandon:'Отказ от виртуальной позиции',place:'Выставлен STOP',cancel:'Триггер переставлен',fill:'Триггер исполнен',tp:'Take Profit',sl:'Stop Loss',recovery_start:'Начальный SL → RECOVERY',recovery_first_fill:'Первый RECOVERY 0.12 · TP 0.25',recovery_fixed_tp:'TP первого RECOVERY 0.12',recovery_stepped_activated:'SL 0.12 → ступенчатый RECOVERY',recovery_trail:'Подтянут SL',recovery_partial_tp:'Закрыто 0.03 по прибыли',recovery_sl:'SL RECOVERY',recovery_reentry_anchor:'Новая точка входа после SL',recovery_oco_placed:'Два встречных STOP',recovery_reentry:'Повторный вход 0.12',recovery_flatten:'Остаток закрыт при восстановлении',recovery_complete:'RECOVERY: убыток возмещён',recovery_fixed_cycle_complete:'TP 0.25: цикл окончен, остаток учтён в общем P/L',recovery_aborted:'RECOVERY: прерван',recovery_ambiguous_spread:'Оба STOP пересечены спредом — пропуск'};
function updateEvents(events){
  if(!events.length)return;
  $('eventFeed').innerHTML=events.slice(-14).reverse().map(e=>`<div class="event"><i class="event-led ${(e.side||'').toLowerCase()}"></i><div><strong>${safe(eventText[e.type]||e.type)} ${e.side||''} ${e.price!==undefined?currency(e.price):''}</strong><small>${e.reason==='opposite_closed_candle'?'Смена цвета M1':e.pnl_points!==undefined?`Результат ${sign(e.pnl_points)}${currency(e.pnl_points)} пункта`:''} <span class="event-time">${ts(e.t_ms)}</span></small></div></div>`).join('');
}
function updateLiveTrades(trades){
  const body=$('liveTradesBody');
  if(!trades.length){body.innerHTML='<tr><td colspan="7" class="empty-table">Пока нет сделок</td></tr>';return;}
  body.innerHTML=trades.slice().reverse().slice(0,20).map(t=>`<tr><td>${ts(t.opened_ms)}</td><td><span class="type ${t.side.toLowerCase()}">${t.side}</span></td><td>${currency(t.entry)}</td><td>${currency(t.exit)}</td><td><span class="result-pill ${t.result.toLowerCase()}">${t.result}</span></td><td class="${t.pnl_points>=0?'positive':'negative'}">${sign(t.pnl_points)}${currency(t.pnl_points)}</td><td>${t.recovery_used?`${t.recovery_partial_tps||0} TP / ${t.recovery_reentries||0} входов`:t.result==='SL'?currency(t.gap_to_tp):'—'}</td></tr>`).join('');
}
// All price levels are deliberately solid, including current Bid/Ask.
function levels(){
  if(app.replay){
    const tr=app.replay.trade,tick=app.replay.ticks[app.replay.index];
    if(!tick)return [];
    const out=[{price:tick.bid,label:'BID',color:'#6ba9f5'},
               {price:tick.ask,label:'ASK',color:'#c7a0e9'}];
    if(tick.t_ms<tr.opened_ms){out.push({price:tr.trigger_level,label:'STOP',color:'#e8b756'});}
    else if(tick.t_ms<=tr.closed_ms){
      if(tr.recovery_used){
        const actions=(tr.recovery_actions||[]).filter(a=>a.t_ms<=tick.t_ms);
        const start=actions.find(a=>a.type==='recovery_start');
        if(!start){out.push({price:tr.entry,label:'ENTRY',color:'#e8b756'});}
        else{
          out.push({price:tr.buy_anchor,label:'BUY MAX',color:'#27b98b'},
            {price:tr.sell_anchor,label:'SELL MIN',color:'#ed7182'});
          const latest=actions.slice().reverse().find(a=>['recovery_trail','recovery_first_fill','recovery_reentry','recovery_sl','recovery_oco_placed'].includes(a.type));
          if(latest?.type==='recovery_trail'||latest?.sl!==undefined){
            out.push({price:latest.price??latest.sl,label:'REC SL',color:'#f18491'});
          }
        }
      }else{
        out.push({price:tr.entry,label:'ENTRY',color:'#e8b756'});
        if(tr.tp!=null)out.push({price:tr.tp,label:'TP',color:'#26c995'});
        if(tr.sl!=null)out.push({price:tr.sl,label:'SL',color:'#ed7182'});
      }
    }
    return out;
  }
  if(app.rightOffset>0.5)return [];
  const s=app.status;if(!s)return [];
  const o=[];
  if(s.recovery){
    const r=s.recovery;
    o.push({price:r.buy_anchor,label:r.variant==='fixed_flip'?'BUY · УРОВЕНЬ':r.stepped_mode?'BUY STOP ↕':'BUY MAX',color:'#27b98b'},
      {price:r.sell_anchor,label:r.variant==='fixed_flip'?'SELL · УРОВЕНЬ':r.stepped_mode?'SELL STOP ↕':'SELL MIN',color:'#ed7182'});
    if(r.active){o.push({price:r.active.entry,label:`${r.active.side} ${currency(r.active.lots)}`,color:'#e8b756'});
      o.push({price:r.active.stop,label:r.variant==='fixed_flip'?'FIXED SL':r.active.tp==null?'TRAIL / SL':'SL REC',color:'#f18491'});
      if(r.active.tp!=null)o.push({price:r.active.tp,label:r.variant==='fixed_flip'?'СЛЕД. TP':'TP',color:'#26c995'});
      if(r.variant==='fixed_flip'&&Array.isArray(r.active.v3_tp_targets))for(const [i,tp] of r.active.v3_tp_targets.entries()){
        if(i>0&&i<3)o.push({price:tp.price,label:`TP ${i+1} · ${currency(tp.lots)} л`,color:'#208c77'});
      }
    }else{
      for(const st of r.pending_stops)o.push({price:st.level,label:`${st.side} STOP ${currency(st.lots)}`,color:st.side==='BUY'?'#2bc996':'#ed7182'});
    }
  }else if(s.pending){
    const p=s.pending,buy=p.side==='BUY';
    const v=s.settings.recovery_enabled?s.settings.recovery_variant:'classic';
    const tp=v==='fixed_flip'?s.settings.recovery_v3_initial_tp_distance:v==='extreme'?s.settings.recovery_v2_initial_tp_distance:s.settings.tp_distance;
    const sl=v==='fixed_flip'?s.settings.recovery_v3_initial_sl_distance:v==='extreme'?s.settings.recovery_v2_initial_sl_distance:s.settings.sl_distance;
    o.push({price:p.level,label:p.side+' STOP',color:'#e8b756'},
      {price:p.level+(buy?1:-1)*tp,label:'TP*',color:'#27b98b'},
      {price:p.level+(buy?-1:1)*sl,label:'SL*',color:'#dc6f7d'});
  }else if(s.position){
    const p=s.position;
    o.push({price:p.entry,label:'ENTRY',color:'#e8b756'},
      {price:p.tp,label:'TP',color:'#26c995'},
      {price:p.sl,label:'SL',color:'#ed7182'});
  }
  for(const p of(s.manual_stops||[]))o.push({price:p.level,label:`РУЧ STOP #${p.id}`,color:'#e5b95a'});
  for(const p of(s.manual_positions||[]))o.push({price:p.entry,label:`РУЧ ENTRY #${p.id}`,color:'#d6e9f7'});
  if(s.tick)o.push({price:s.tick.bid,label:'BID',color:'#6ba9f5'},
    {price:s.tick.ask,label:'ASK',color:'#c7a0e9'});
  return o;
}
function updateCurrentBidCandle(tick){
  if(!tick||!Number.isFinite(+tick.bid)||!Number.isFinite(+tick.t_ms))return;
  if(Math.abs(Date.now()-tick.t_ms)>90_000)return; // Do not draw stale snapshots as fresh M1.
  const minute=Math.floor(tick.t_ms/60000)*60;
  const cs=app.marketCandles;
  if(!cs.length)return;
  const last=cs[cs.length-1];
  if(last.time===minute){
    last.close=tick.bid;last.high=Math.max(last.high,tick.bid);last.low=Math.min(last.low,tick.bid);
  }else if(last.time<minute){
    cs.push({time:minute,open:tick.bid,high:tick.bid,low:tick.bid,close:tick.bid});
    if(cs.length>520)cs.splice(0,cs.length-520);
  }
}
function chartQualityMessage(candles){
  if(app.replay||!candles.length)return '';
  const latest=candles[candles.length-1],tick=app.status?.tick;
  if(!tick)return '';
  if(!Number.isFinite(tick.t_ms)||!Number.isFinite(tick.bid))return '';
  const now=Date.now(),quoteAge=Math.max(0,Math.round((now-tick.t_ms)/1000));
  if(quoteAge>90)return `Нет свежих тиков MT5 (${quoteAge} сек.). Показывается последняя доступная цена.`;
  const latestMinute=Math.floor(tick.t_ms/60000)*60;
  if(latest.time>latestMinute+60)return 'Время свечей опережает тики MT5. Требуется проверка часов источника.';
  if(latestMinute-latest.time>120)return `Свечи отстают от котировки на ${Math.round((latestMinute-latest.time)/60)} мин. Проверь источник.`;
  if(latest.time===latestMinute && Math.abs(latest.close-tick.bid)>0.15){
    return 'Последняя свеча и Bid расходятся. История обновляется, проверь подключение MT5.';
  }
  return '';
}
function updateManualPositions(s){
  // This is the MANAGED strategy portfolio: manual actions are not disconnected
  // trades. Upon confirmation, ordinary TP/SL and RECOVERY resume automatically.
  const p=s.position,r=s.recovery,pending=s.pending;
  const rows=[];
  if(p){
    const lots=p.lots??s.settings.volume_lots;
    rows.push(`<div class="manual-order-row"><span><b>${safe(p.side)}</b> ${currency(lots)} л · ENTRY ${currency(p.entry)} · TP ${currency(p.tp)} / SL ${currency(p.sl)}</span><button type="button" class="btn small" data-close-auto="1">Закрыть</button></div>`);
  }
  if(r?.active){
    rows.push(`<div class="manual-order-row"><span><b>${safe(r.active.side)} RECOVERY</b> ${currency(r.active.lots)} л · ENTRY ${currency(r.active.entry)} · SL ${currency(r.active.stop)}</span><button type="button" class="btn small" data-close-rec="1">Закрыть</button></div>`);
  }
  if(pending){
    rows.push(`<div class="manual-order-row"><span><b>${safe(pending.side)} STOP</b> ${currency(pending.lots??s.settings.volume_lots)} л · ${currency(pending.level)}</span><button type="button" class="btn small" data-move-auto="1">Изменить</button></div>`);
  }
  if(r?.pending_stops?.length){
    for(const st of r.pending_stops){
      rows.push(`<div class="manual-order-row"><span><b>${safe(st.side)} REC STOP</b> ${currency(st.lots)} л · ${currency(st.level)}</span><button type="button" class="btn small" data-move-rec="${safe(st.side)}">Изменить</button></div>`);
    }
  }
  $('manualCount').textContent=String(rows.length);
  $('manualPositions').innerHTML=rows.join('')||'<div class="state-placeholder">Нет активных позиций. Коснись графика для ручного входа в текущий цикл.</div>';
}

function editableLevels(){
  if(app.replay||app.rightOffset>.5)return [];
  const s=app.status;if(!s)return [];
  const out=[];
  if(s.pending)out.push({price:s.pending.level,kind:'move',triggerKind:'standard',side:s.pending.side,label:s.pending.side+' STOP'});
  if(s.position)out.push({price:s.position.entry,kind:'close',closeKind:'auto',side:s.position.side,
                          lots:s.position.lots??s.settings.volume_lots,label:'ENTRY'});
  if(s.recovery){
    const r=s.recovery;
    if(r.stepped_mode||r.variant==='fixed_flip'){
      for(const side of ['BUY','SELL'])out.push({price:side==='BUY'?r.buy_anchor:r.sell_anchor,
        kind:'move',triggerKind:'recovery',side,label:side+' REC STOP'});
    }else if(r.pending_stops?.length){
      for(const st of r.pending_stops)out.push({price:st.level,kind:'move',triggerKind:'recovery_first',
        side:st.side,label:st.side+' FIRST REC STOP'});
    }
    if(r.active)out.push({price:r.active.entry,kind:'close',closeKind:'recovery',side:r.active.side,
      lots:r.active.lots,label:'REC ENTRY'});
  }
  for(const p of (s.manual_stops||[]))out.push({price:p.level,kind:'move',triggerKind:'manual_stop',
    side:p.side,manualId:p.id,label:`${p.side} РУЧ STOP #${p.id}`});
  for(const p of (s.manual_positions||[]))out.push({price:p.entry,kind:'close',closeKind:'manual',
    side:p.side,manualId:p.id,lots:p.lots,label:`РУЧ ENTRY #${p.id}`});
  return out;
}
function selectedLine(screenY){
  const geometry=app.chartGeometry;
  if(!geometry||screenY<geometry.top||screenY>geometry.bottom)return null;
  const candidates=editableLevels().map(level=>({...level,
    delta:Math.abs(geometry.priceToY(level.price)-screenY)})).sort((a,b)=>a.delta-b.delta);
  return candidates[0]?.delta<=(window.matchMedia('(pointer:coarse)').matches?16:10)?candidates[0]:null;
}
function chartPriceFromClient(clientY){
  const geo=app.chartGeometry,rect=$('priceCanvas').getBoundingClientRect();
  if(!geo)return null;
  const price=geo.yToPrice(Math.max(geo.top,Math.min(geo.bottom,clientY-rect.top)));
  const tick=Math.max(.0000001,Number(app.status?.settings?.tick_size)||.01);
  return Math.max(tick,Math.round(price/tick)*tick);
}
function openVirtualDialog(action){
  if(app.replay){toast('Заверши воспроизведение, чтобы управлять виртуальными ордерами.');return;}
  const dlg=$('virtualActionDialog');app.virtualAction=action;
  $('virtualOpenFields').classList.toggle('hidden',action.mode!=='open');
  $('virtualPriceRow').classList.toggle('hidden',action.mode==='close');
  $('virtualLotsRow').classList.toggle('hidden',action.mode==='move'||action.mode==='cancel');
  $('virtualDeleteStop').classList.toggle('hidden',!(action.mode==='move'&&action.triggerKind==='manual_stop'));
  $('virtualSide').value=action.side||'BUY';
  $('virtualOrderType').value=action.orderType||'MARKET';
  $('virtualPrice').value=currency(action.price??app.status?.tick?.bid,2);
  const stage=app.status?.recovery;
  const initialLots=stage ? app.status?.settings?.recovery_reentry_lots : app.status?.settings?.volume_lots;
  $('virtualLots').value=currency(action.lots??initialLots??.01);
  const heading={open:'Открыть виртуальную позицию',close:'Закрыть виртуальную позицию',move:'Переместить виртуальный STOP'};
  $('virtualActionTitle').textContent=heading[action.mode]||'Виртуальное действие';
  $('virtualActionDescription').textContent=action.mode==='open'?
    'Вход меняет текущий виртуальный цикл. После MARKET или STOP анализатор автоматически сопровождает позицию по TP/SL и правилам RECOVERY. Если позиция уже открыта, сначала закрой её.':
    action.mode==='close'?`Закрытие ${action.side} по текущей котировке. Максимальный объём: ${currency(action.lots)} лота. `+
      (action.closeKind==='recovery'?'Частичное закрытие влияет на текущий долг RECOVERY.':''):
      'После перетаскивания подтвердите новую цену STOP. Встречный STOP остаётся, OCO сохраняется.';
  if(action.mode==='move')$('virtualLotsRow').classList.add('hidden');
  $('virtualConfirm').disabled=false;
  updateVirtualDialogDetails();
  dlg.showModal();
  (action.mode==='move'||(action.mode==='open'&&action.orderType==='STOP')?$('virtualPrice'):$('virtualLots')).focus();
}
function updateVirtualDialogDetails(){
  const a=app.virtualAction;if(!a)return;
  const typ=$('virtualOrderType').value;
  $('virtualPriceRow').classList.toggle('hidden',a.mode==='close'||(a.mode==='open'&&typ==='MARKET'));
  const tick=app.status?.tick;
  const price=a.mode==='open'&&typ==='MARKET'?tick?.[$('virtualSide').value==='BUY'?'ask':'bid']:Number($('virtualPrice').value);
  const confirmation=a.mode==='open'?`Виртуальный ${$('virtualSide').value} ${typ}, лот ${$('virtualLots').value}, цена ${currency(price)}`:
    a.mode==='close'?`Закрыть ${a.side} · ${$('virtualLots').value} лота · ${currency(tick?.[a.side==='BUY'?'bid':'ask'])}`:
    `Сместить ${a.side} STOP на ${currency(price)}`;
  $('virtualActionDetails').textContent=confirmation+' · Никаких ордеров на биржу';
}
async function confirmVirtualAction(event){
  event.preventDefault();const action=app.virtualAction;if(!action)return;
  const button=$('virtualConfirm');button.disabled=true;
  try{
    const lots=Number($('virtualLots').value),price=Number($('virtualPrice').value);
    if(action.mode==='open'){
      await api('/api/virtual/strategy/open',{method:'POST',body:JSON.stringify({confirmation:'CONFIRM',
        side:$('virtualSide').value,order_type:$('virtualOrderType').value,
        lots,level:$('virtualOrderType').value==='STOP'?price:null})});
    }else if(action.mode==='close'){
      await api('/api/virtual/manual/close',{method:'POST',body:JSON.stringify({confirmation:'CONFIRM',
        kind:action.closeKind,lots,manual_id:action.manualId??null})});
    }else if(action.mode==='move'){
      await api('/api/virtual/trigger/move',{method:'POST',body:JSON.stringify({confirmation:'CONFIRM',
        kind:action.triggerKind,side:action.side,manual_id:action.manualId??null,price})});
    }
    $('virtualActionDialog').close();app.virtualAction=null;app.previewLevel=null;
    await fetchStatus();requestDraw();toast('Виртуальное действие выполнено и сохранено.');
  }catch(e){toast('Действие отклонено: '+e.message);}
  finally{button.disabled=false;}
}
function drawPriceLabels(ctx,overlay,yFor,left,right,top,bottom){
  // Resolve crowded tags, e.g. Bid/Ask with a 0.23 spread, without merging prices.
  const minGap=18;
  const tags=overlay.map(o=>({...o,lineY:yFor(o.price)}))
    .filter(o=>Number.isFinite(o.lineY)&&o.lineY>=top-1&&o.lineY<=bottom+1)
    .sort((a,b)=>a.lineY-b.lineY);
  if(!tags.length)return;
  const totalGap=minGap*(tags.length-1);
  let gap=totalGap>bottom-top?Math.max(10,(bottom-top)/(tags.length-1||1)):minGap;
  for(let i=0;i<tags.length;i++){
    const minY=top+10+i*gap;
    tags[i].tagY=Math.max(tags[i].lineY,minY);
  }
  if(tags[tags.length-1].tagY>bottom-9){
    tags[tags.length-1].tagY=bottom-9;
    for(let i=tags.length-2;i>=0;i--)
      tags[i].tagY=Math.min(tags[i].tagY,tags[i+1].tagY-gap);
  }
  for(const tag of tags){
    ctx.fillStyle='#111c28';ctx.fillRect(left+2,tag.tagY-9,right-4,17);
    ctx.fillStyle=tag.color;ctx.textAlign='left';ctx.font='bold 10px system-ui, Arial';
    ctx.fillText(`${tag.label} ${currency(tag.price)}`,left+5,tag.tagY);
    if(Math.abs(tag.tagY-tag.lineY)>3){
      ctx.strokeStyle=tag.color;ctx.globalAlpha=0.6;ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(left-6,tag.lineY);ctx.lineTo(left+1,tag.tagY);ctx.stroke();
      ctx.globalAlpha=1;
    }
  }
}
function chartData(){
  if(!app.replay)return app.marketCandles;
  const ticks=app.replay.ticks;let idx=app.replay.index;
  const bars=[];let last=null;
  for(let i=0;i<=idx&&i<ticks.length;i++){
    const tk=ticks[i],time=Math.floor(tk.t_ms/60000)*60;
    if(!last||last.time!==time){last={time,open:tk.bid,high:tk.bid,low:tk.bid,close:tk.bid};bars.push(last);}
    else{last.high=Math.max(last.high,tk.bid);last.low=Math.min(last.low,tk.bid);last.close=tk.bid;}
  }
  return bars;
}
function requestDraw(){if(app.rendering)return;app.rendering=true;requestAnimationFrame(()=>{app.rendering=false;drawChart();});}
function drawChart(){
  const cv=$('priceCanvas'),bounds=cv.getBoundingClientRect();
  if(!bounds.width||!bounds.height)return;
  const ratio=Math.min(3,window.devicePixelRatio||1),width=bounds.width,height=bounds.height;
  cv.width=Math.round(width*ratio);cv.height=Math.round(height*ratio);
  const ctx=cv.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);
  ctx.clearRect(0,0,width,height);ctx.fillStyle='#070b10';ctx.fillRect(0,0,width,height);
  const cs=chartData();$('chartEmpty').classList.toggle('hidden',cs.length>1);
  const msg=chartQualityMessage(cs);
  $('chartQuality').classList.toggle('hidden',!msg);
  $('chartQuality').textContent=msg;
  if(cs.length<2)return;
  const L=width<560?8:14,R=width<560?86:115,T=14,B=32;const w=width-L-R,h=height-T-B;
  if(w<65)return;
  app.visibleBars=Math.max(12,Math.min(260,app.visibleBars));
  const visible=app.visibleBars;
  app.rightOffset=Math.max(0,Math.min(cs.length-2,app.rightOffset));
  const end=Math.max(2,Math.min(cs.length,Math.ceil(cs.length-app.rightOffset)));
  const start=Math.max(0,Math.floor(end-visible));
  const sliced=cs.slice(start,end);
  const overlay=levels().filter(x=>Number.isFinite(x.price));
  const high=Math.max(...sliced.map(c=>c.high));
  const low=Math.min(...sliced.map(c=>c.low));
  // All active and live prices participate in the *same* y-axis as candles.
  const values=[high,low,...overlay.map(o=>o.price)];
  const ceiling=Math.max(...values),floor=Math.min(...values);
  const span=Math.max(.3,ceiling-floor);
  const maxP=ceiling+span*.09,minP=floor-span*.09;
  const priceY=p=>T+(maxP-p)/(maxP-minP)*h;
  app.chartGeometry={top:T,bottom:T+h,priceToY:priceY,
    yToPrice:y=>maxP-(y-T)/h*(maxP-minP)};
  // Thin SOLID grid, no dash arrays on the trading chart.
  ctx.textBaseline='middle';ctx.font='10px system-ui, Arial';
  for(let i=0;i<6;i++){
    const y=T+i*h/5;
    ctx.beginPath();ctx.strokeStyle='#1d2934';ctx.lineWidth=.65;
    ctx.moveTo(L,y);ctx.lineTo(width-R,y);ctx.stroke();
    ctx.fillStyle='#8d9cac';ctx.textAlign='right';
    ctx.fillText(currency(maxP-(maxP-minP)*i/5),width-4,y);
  }
  const stepX=w/visible;
  for(let j=0;j<7;j++){
    const xp=L+j*w/6;ctx.strokeStyle='#1a2530';ctx.lineWidth=.65;
    ctx.beginPath();ctx.moveTo(xp,T);ctx.lineTo(xp,T+h);ctx.stroke();
  }
  sliced.forEach((c,j)=>{
    const x=L+(j+.5)*stepX;
    const col=c.close>=c.open?'#00c56a':'#f2364d';
    ctx.strokeStyle=col;ctx.fillStyle=col;
    const hy=priceY(c.high),ly=priceY(c.low),oy=priceY(c.open),cy=priceY(c.close);
    ctx.beginPath();ctx.moveTo(x,hy);ctx.lineTo(x,ly);
    ctx.lineWidth=1.25;ctx.stroke();
    const bw=Math.max(1.2,Math.min(13,stepX*.65));
    ctx.fillRect(x-bw/2,Math.min(oy,cy),bw,Math.max(1.3,Math.abs(oy-cy)));
  });
  // Labels refer to actual candle timestamps, always UTC, not the phone's timezone.
  ctx.textAlign='center';ctx.fillStyle='#97a5b5';ctx.font='10px system-ui, Arial';
  const labels=Math.max(2,Math.floor(w/90));
  for(let i=0;i<=labels;i++){
    const j=Math.min(sliced.length-1,Math.floor(i*(sliced.length-1)/labels));
    const d=new Date(sliced[j].time*1000);
    ctx.fillText(d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'}),
      L+(j+.5)*stepX,height-13);
  }
  // Overlay levels and the corresponding axis prices use SOLID strokes.
  for(const o of overlay){
    const y=priceY(o.price);if(y<T-1||y>T+h+1)continue;
    ctx.strokeStyle=o.color;ctx.lineWidth=o.label.includes('STOP')||o.label==='ENTRY'?1.8:1.25;
    ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(width-R,y);ctx.stroke();
  }
  drawPriceLabels(ctx,overlay,priceY,width-R,R,T,T+h);
  if(Number.isFinite(app.previewLevel)){
    const yy=priceY(app.previewLevel);
    ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.beginPath();
    ctx.moveTo(L,yy);ctx.lineTo(width-R,yy);ctx.stroke();
    ctx.fillStyle='#fff';ctx.textAlign='right';ctx.font='bold 12px system-ui';
    ctx.fillText('STOP → '+currency(app.previewLevel),width-R-4,yy-12);
  }
  if(app.hover&&app.hover.x>=L&&app.hover.x<=width-R){
    const j=Math.floor((app.hover.x-L)/stepX),data=sliced[j];
    if(data){const x=L+(j+.5)*stepX;
      ctx.strokeStyle='#6e8295';ctx.lineWidth=.65;
      ctx.beginPath();ctx.moveTo(x,T);ctx.lineTo(x,T+h);ctx.stroke();
      const desc=`O ${currency(data.open)}  H ${currency(data.high)}  L ${currency(data.low)}  C ${currency(data.close)}`;
      ctx.font='10px system-ui';const tw=ctx.measureText(desc).width;
      ctx.fillStyle='#1e3246';ctx.fillRect(L+5,T+5,tw+12,22);
      ctx.fillStyle='#ccd8e6';ctx.textAlign='left';ctx.fillText(desc,L+11,T+16);
    }
  }
}
function setupChartInteraction(){
  const cv=$('priceCanvas');
  cv.addEventListener('wheel',e=>{e.preventDefault();app.visibleBars=Math.max(12,Math.min(260,app.visibleBars*(e.deltaY>0?1.16:.86)));requestDraw();},{passive:false});
  cv.addEventListener('pointerdown',e=>{
    cv.setPointerCapture(e.pointerId);app.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rect=cv.getBoundingClientRect();
    const item=selectedLine(e.clientY-rect.top);
    app.gesture={x:e.clientX,y:e.clientY,right:app.rightOffset,
      line:app.pointerMap.size===1?item:null,moved:false,wasPinch:false};
    app.hover=null;
    if(app.pointerMap.size===2){const p=[...app.pointerMap.values()];
      app.pinch={dist:Math.abs(p[0].x-p[1].x),startVisible:app.visibleBars};
      if(app.gesture)app.gesture.wasPinch=true;
    }
  });
  cv.addEventListener('pointermove',e=>{
    if(app.pointerMap.has(e.pointerId))app.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(app.pointerMap.size===2){const p=[...app.pointerMap.values()];const dist=Math.abs(p[0].x-p[1].x);
      if(app.pinch&&dist>5){app.visibleBars=Math.max(12,Math.min(260,app.pinch.startVisible*app.pinch.dist/dist));requestDraw();}
      if(app.gesture)app.gesture.wasPinch=true;
    }else if(app.pointerMap.size===1&&app.gesture){
      const g=app.gesture;
      if(Math.abs(e.clientX-g.x)+Math.abs(e.clientY-g.y)>8)g.moved=true;
      if(g.line?.kind==='move'&&!g.wasPinch){
        app.previewLevel=chartPriceFromClient(e.clientY);requestDraw();
      }else if(g.moved){const rect=cv.getBoundingClientRect(),step=(rect.width-(rect.width<560?94:129))/app.visibleBars;
        app.rightOffset=Math.max(0,g.right+(g.x-e.clientX)/Math.max(step,1));requestDraw();}
    }else if(e.pointerType==='mouse'){
      app.hover={x:e.clientX-cv.getBoundingClientRect().left,y:e.clientY};requestDraw();
    }
  });
  const release=e=>{
    const g=app.gesture;
    app.pointerMap.delete(e.pointerId);
    if(!app.pointerMap.size){
      app.gesture=null;app.pinch=null;
      const price=chartPriceFromClient(e.clientY);
      if(!g||g.wasPinch){app.previewLevel=null;requestDraw();return;}
      if(app.replay||app.rightOffset>.5){app.previewLevel=null;requestDraw();return;}
      if(g.line?.kind==='move'){
        openVirtualDialog({...g.line,mode:'move',price:g.moved?price:g.line.price});
      }else if(g.line?.kind==='close'&&!g.moved){
        openVirtualDialog({...g.line,mode:'close'});
      }else if(!g.moved&&price!==null){
        const first=app.status?.recovery;const defaultSide=first&&!first.stepped_mode?first.pending_stops?.[0]?.side:'BUY';
        openVirtualDialog({mode:'open',price,side:defaultSide||'BUY',orderType:'MARKET'});
      }
      app.previewLevel=null;requestDraw();
    }
  };
  cv.addEventListener('pointerup',release);
  cv.addEventListener('pointercancel',e=>{app.pointerMap.delete(e.pointerId);app.gesture=null;app.previewLevel=null;requestDraw();});
  cv.addEventListener('pointerleave',()=>{if(!app.pointerMap.size){app.hover=null;requestDraw();}});
  $('zoomIn').onclick=()=>{app.visibleBars=Math.max(12,app.visibleBars*.76);requestDraw();};
  $('zoomOut').onclick=()=>{app.visibleBars=Math.min(260,app.visibleBars*1.3);requestDraw();};
  $('zoomReset').onclick=()=>{app.visibleBars=window.matchMedia('(max-width:680px)').matches?46:76;app.rightOffset=0;requestDraw();};
  new ResizeObserver(requestDraw).observe(cv);
}
async function fetchStatus(){try{presentStatus(await api('/api/status'));}catch(e){$('connectionBanner').classList.remove('hidden');$('connectionError').textContent=e.message;}}
async function fetchChart(){
  if(app.replay)return;
  try{
    const rows=await api('/api/chart');
    if(rows.length){
      const maxMinute=Math.floor(Date.now()/60000)*60+60;
      const mapped=rows.map(c=>({time:+c.time,open:+c.open,high:+c.high,
        low:+c.low,close:+c.close})).filter(c=>Number.isFinite(c.time)&&
        c.time<=maxMinute&&Number.isFinite(c.close)&&c.low>0).sort((a,b)=>a.time-b.time);
      const merged=new Map(mapped.map(c=>[c.time,c]));
      // In-flight live updates can be newer than a 12-second HTTP chart refresh.
      const liveMinute=app.status?.tick?Math.floor(app.status.tick.t_ms/60000)*60:null;
      for(const bar of app.marketCandles.slice(-3)){
        if(liveMinute!==null && bar.time===liveMinute){
          const old=merged.get(bar.time);
          merged.set(bar.time,old?{...old,high:Math.max(old.high,bar.high),
            low:Math.min(old.low,bar.low),close:bar.close}:bar);
        }
      }
      app.marketCandles=[...merged.values()].sort((a,b)=>a.time-b.time).slice(-520);
      // Loaded M1 high/low is only the available chart history, not daily exchange high/low.
      const history=app.marketCandles;
      if(history.length){
        $('marketHigh').textContent=currency(Math.max(...history.map(c=>c.high)));
        $('marketLow').textContent=currency(Math.min(...history.map(c=>c.low)));
      }
      if(app.status?.tick)updateCurrentBidCandle(app.status.tick);
      requestDraw();
    }
  }catch(e){/* service may be temporarily offline */}
}
async function control(action){try{presentStatus(await api('/api/control/'+action,{method:'POST'}));toast(action==='start'?'Симуляция запущена: ожидаем закрытие свечи':action==='stop'?'Остановка после завершения цикла':'Виртуальный цикл прерван');}catch(e){toast('Ошибка: '+e.message);}}
function parseList(str){const values=str.split(/[;,\s]+/).filter(Boolean).map(v=>Number(v));if(!values.length||values.some(v=>!Number.isFinite(v)||v<=0||v>100))throw Error('Значения должны быть положительными числами, разделёнными запятыми');return [...new Set(values)];}
function updateCount(){try{
  const f=$('backtestForm').elements, v2=f.recovery_enabled.checked&&f.recovery_variant.value==='extreme';
  const v3=f.recovery_enabled.checked&&f.recovery_variant.value==='fixed_flip';
  const supportDistances=v3?[1]:v2?parseList(f.recovery_v2_support_sl_distances.value):parseList(f.recovery_trail_offsets.value);
  const n=parseList(f.distances.value).length*parseList(f.tps.value).length*parseList(f.sls.value).length*
    (f.recovery_enabled.checked?supportDistances.length:1)*
    (v2?parseList(f.recovery_v2_reentry_offsets.value).length*parseList(f.recovery_v2_trail_steps.value).length:1);
  $('comboCount').textContent=`${n} комбинаций${n>2000?' (максимум 2000)':''}`;
}catch{$('comboCount').textContent='Проверь список параметров';}}
async function submitBacktest(e){e.preventDefault();try{const f=$('backtestForm').elements;const p={start_date:f.start_date.value,end_date:f.end_date.value,distances:parseList(f.distances.value),tps:parseList(f.tps.value),sls:parseList(f.sls.value),volume_lots:Number(f.volume_lots.value),recovery_enabled:f.recovery_enabled.checked,recovery_variant:f.recovery_variant.value,
    recovery_trail_offsets:parseList(f.recovery_trail_offsets.value),
    recovery_v2_support_sl_distances:parseList(f.recovery_v2_support_sl_distances.value),
    recovery_v2_work_lots:Number(f.recovery_v2_work_lots.value),
    recovery_v3_work_lots:Number(f.recovery_v3_work_lots.value),
    recovery_v3_stop_gap:Number(f.recovery_v3_stop_gap.value),
    recovery_v3_partial_lots:Number(f.recovery_v3_partial_lots.value),
    recovery_v3_range_mode:f.recovery_v3_range_mode.value,
    recovery_v3_expansion:Number(f.recovery_v3_expansion.value),
    recovery_v2_opposite_max_range:Number(f.recovery_v2_opposite_max_range.value),
    recovery_v2_reentry_offsets:parseList(f.recovery_v2_reentry_offsets.value),
    recovery_v2_trail_steps:parseList(f.recovery_v2_trail_steps.value)};
  if(p.recovery_enabled && p.recovery_variant==='classic' && Math.abs(p.volume_lots-0.01)>0.000001)throw Error('Для RECOVERY V1 начальный лот 0.01');
  const selectedSupports=p.recovery_enabled&&p.recovery_variant==='fixed_flip'?[1]:p.recovery_enabled&&p.recovery_variant==='extreme'?p.recovery_v2_support_sl_distances:p.recovery_trail_offsets;
  const n=p.distances.length*p.tps.length*p.sls.length*(p.recovery_enabled?selectedSupports.length:1)*
    (p.recovery_enabled&&p.recovery_variant==='extreme'?p.recovery_v2_reentry_offsets.length*p.recovery_v2_trail_steps.length:1);
  if(n>2000)throw Error('Не более 2000 комбинаций');
  const job=await api('/api/backtests',{method:'POST',body:JSON.stringify(p)});app.currentRun=job.id;app.selectedVariant=null;
  $('variantDetails').classList.add('hidden');$('jobProgressPanel').classList.remove('hidden');$('variantsBody').innerHTML='<tr><td colspan="13" class="empty-table">Прогон запущен…</td></tr>';
  toast('Исследование '+job.id+' запущено. Можно закрыть браузер — расчёт продолжится на VPS.');
  await updateJob();
}catch(err){toast('Не удалось начать тест: '+err.message);}}
async function updateJob(){if(!app.currentRun)return;try{const j=await api('/api/backtests/'+app.currentRun);$('jobProgressPanel').classList.remove('hidden');$('jobTitle').textContent='Исследование '+j.id;$('jobStatus').textContent={queued:'В очереди',running:'Выполняется',completed:'Готово',failed:'Ошибка',interrupted:'Прерван рестартом'}[j.status]||j.status;
  $('progressFill').style.width=`${j.total?100*j.done/j.total:0}%`;
  $('jobProgressText').textContent=`${j.done} из ${j.total} комбинаций · ${j.day_progress||''}${j.error?' · '+j.error:''}`;
  if(j.status==='completed'&&!app.loadedRun?.includes(j.id)){app.loadedRun=(app.loadedRun||[]).concat([j.id]);await refreshVariants();}
  if(j.status==='failed')toast('Ошибка исследования: '+j.error);
}catch(e){console.warn(e);}}
async function refreshVariants(){
  if(!app.currentRun)return;
  try{
    const rows=await api('/api/backtests/'+app.currentRun+'/variants');app.variants=rows;
    if(!rows.length){$('variantsBody').innerHTML='<tr><td colspan="13" class="empty-table">Результаты ещё рассчитываются</td></tr>';return;}
    $('variantsBody').innerHTML=rows.map((r,i)=>{
      const c=r.config,s=r.summary,train=s.train?.equity_points??s.train?.pnl_points;
      const holdout=s.holdout?.equity_delta_points??s.holdout?.pnl_points;
      const total=s.equity_points??s.pnl_points;
      return `<tr><td>${i+1}</td><td><b>${currency(c.trigger_distance)}</b></td>
        <td>${currency(c.tp_distance)} / ${currency(c.sl_distance)}${c.recovery_enabled?(c.recovery_trail_activation>0?' / старый трейл +'+currency(c.recovery_trail_activation):' / SL поддерж. '+currency(c.recovery_trail_start_offset??1)):''}</td>
        <td>${s.trades}</td><td class="positive">${s.tp}</td><td class="negative">${s.sl}</td>
        <td>${s.recovered??0} / ${s.recovery_tp_cycles??0} TP</td><td>${currency(s.win_rate,1)}%</td>
        <td class="${train>=0?'positive':'negative'}">${train==null?'—':sign(train)+currency(train)}</td>
        <td class="${holdout>=0?'positive':'negative'}">${holdout==null?'—':sign(holdout)+currency(holdout)}</td>
        <td class="${total>=0?'positive':'negative'}"><b>${sign(total)}${currency(total)}</b>${s.unresolved_recovery?' ⚠ открыт':''}</td>
        <td>${currency(s.max_equity_drawdown_points??s.max_drawdown_points)}</td>
        <td><button class="table-action" data-variant="${r.id}">Детали</button></td></tr>`;
    }).join('');
  }catch(e){toast('Не удалось загрузить рейтинг: '+e.message);}
}
async function selectVariant(id){
 try{
  const variant=app.variants.find(x=>x.id===id);if(!variant)throw Error('Вариант не найден');app.selectedVariant=id;
  const c=variant.config,s=variant.summary;
  $('variantTitle').textContent=`Триггер ${currency(c.trigger_distance)} · TP ${currency(c.tp_distance)} / ${c.recovery_enabled?'RECOVERY':'SL'} ${currency(c.sl_distance)}${c.recovery_enabled?(c.recovery_variant==='fixed_flip'?' · V3 фиксированные BUY/SELL':c.recovery_trail_activation>0?' · старые правила +'+currency(c.recovery_trail_activation):' · SL поддерж. '+currency(c.recovery_trail_start_offset??1)):''}`;
  $('variantStats').innerHTML=[['Циклов',s.trades],['Обычный TP',s.tp],['RECOVERY полностью',s.recovered??0],
    ['TP 0.12 → новый цикл',s.recovery_tp_cycles??0],['TP 0.12 с остаточным убытком',s.recovery_tp_loss_cycles??0],
    ['SL',s.sl],['Прибыльных циклов %',currency(s.win_rate,1)+'%'],
    ['Итог с открытыми',sign(s.equity_points??s.pnl_points)+currency(s.equity_points??s.pnl_points)],
    ['Макс. плавающая просадка',currency(s.max_equity_drawdown_points??s.max_drawdown_points)],
    ['Контроль 30%',s.holdout?sign(s.holdout.equity_delta_points??s.holdout.pnl_points)+currency(s.holdout.equity_delta_points??s.holdout.pnl_points):'—'],
    ['Незавершён REC',s.unresolved_recovery??0],['Частичных TP',s.recovery_partial_tps??0],
    ['Повторных входов',s.recovery_reentries??0],['REC после почти TP ≤0.05',(s.near_tp_then_recovery||{})['0.05']??0]
  ].map(([k,v])=>`<div><small>${safe(k)}</small><b>${safe(v)}</b></div>`).join('');
  $('variantDetails').classList.remove('hidden');
  const trades=await api(`/api/variants/${id}/trades?limit=300`);
  $('variantTradesBody').innerHTML=trades.map(t=>`<tr><td>${ts(t.opened_ms,true)}</td>
    <td><span class="type ${t.side.toLowerCase()}">${t.side}</span></td>
    <td>${currency(t.entry)}</td><td>${t.tp==null?'—':currency(t.tp)}</td>
    <td>${t.sl==null?'—':currency(t.sl)}</td>
    <td><span class="result-pill ${t.result.toLowerCase()}">${t.result}</span></td>
    <td>${t.recovery_used?`${t.recovery_partial_tps??0} / ${t.recovery_reentries??0}`:t.result==='SL'?currency(t.gap_to_tp):'—'}</td>
    <td><button class="table-action" data-replay="${t.db_id}">▶ График</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty-table">Закрытых циклов нет; открытый RECOVERY смотри в общей статистике.</td></tr>';
  $('variantDetails').scrollIntoView({behavior:'smooth',block:'start'});await fetchInsights(id);
 }catch(e){toast('Ошибка загрузки варианта: '+e.message);}
}
async function refreshRegimes(){
  if(!app.currentRun)return;
  try{
    const rows=await api(`/api/backtests/${app.currentRun}/regimes`);
    $('regimesBody').innerHTML=rows.map(r=>`<tr><td>${safe(r.group)}</td><td>${safe(r.bucket)}</td><td>${currency(r.trigger_distance)}</td><td>${currency(r.tp_distance)} / ${currency(r.sl_distance)}</td><td>${r.trades}</td><td>${currency(r.win_rate,1)}%</td><td class="${r.pnl_points>=0?'positive':'negative'}">${sign(r.pnl_points)}${currency(r.pnl_points)}</td></tr>`).join('')||'<tr><td colspan="7" class="empty-table">Недостаточно сделок для сравнения (минимум 20 в каждой группе)</td></tr>';
  }catch(e){console.warn(e);}
}
async function fetchInsights(variantId){try{const rows=await api(`/api/variants/${variantId}/insights`);const variant=app.variants.find(v=>v.id===variantId);$('insightsLabel').textContent=variant?`Триггер ${currency(variant.config.trigger_distance)} / TP ${currency(variant.config.tp_distance)} / SL ${currency(variant.config.sl_distance)}`:'Выбранный вариант';
  const groups=Object.groupBy?Object.groupBy(rows,r=>r.type):rows.reduce((acc,r)=>((acc[r.type]??=[]).push(r),acc),{});
  $('insightsContent').innerHTML=Object.entries(groups).map(([type,items])=>`<div class="insight-section"><h3>${safe(type)}</h3>${items.map(g=>`<div class="insight-row"><span>${safe(g.bucket)}</span><div class="insight-track"><div class="insight-fill" style="width:${Math.max(0,Math.min(100,g.win_rate))}%"></div></div><small>${currency(g.win_rate,1)}% TP</small><small class="${g.pnl_points>=0?'positive':'negative'}">${sign(g.pnl_points)}${currency(g.pnl_points)} п.</small></div>`).join('')}</div>`).join('')||'<div class="empty-table">Нет данных</div>';
}catch(e){toast('Не удалось рассчитать закономерности: '+e.message);}}
async function refreshJobs(){try{const rows=await api('/api/backtests');$('jobsList').innerHTML=rows.map(j=>`<div class="history-item"><div><strong>${safe(j.id)} · ${j.total} комбинаций · ${j.config.recovery_enabled?'RECOVERY':'обычный TP/SL'}</strong><small>${new Date(j.created_ms).toLocaleString('ru-RU')} · ${new Date(j.start_ms).toLocaleDateString('ru-RU')}—${new Date(j.end_ms).toLocaleDateString('ru-RU')} UTC · ${j.source==='demo'?'Учебный поток':'MT5 CFD'}</small></div><div class="actions"><span class="history-status">${safe(j.status)} ${j.done}/${j.total}</span><button class="table-action" data-job="${safe(j.id)}">Открыть</button></div></div>`).join('')||'<div class="empty-table">Исследований ещё нет</div>';}catch(e){toast(e.message);}}
async function openRun(id){app.currentRun=id;toggleTab('backtest');await updateJob();await refreshVariants();}
async function loadReplay(tradeId){try{const obj=await api('/api/replay/'+tradeId);clearInterval(app.replayTimer);app.replay={...obj,index:0};app.visibleBars=75;app.rightOffset=0;toggleTab('live');
  $('replayBar').classList.remove('hidden');$('replaySlider').max=Math.max(0,obj.ticks.length-1);$('replaySlider').value=0;
  $('replayNote').textContent=`${obj.trade.side} ${currency(obj.trade.entry)} → ${obj.trade.result}${obj.truncated?' · фрагмент ограничен':''}${obj.source==='demo'?' · учебный поток':''}`;
  refreshReplayLabel();requestDraw();$('priceCanvas').scrollIntoView({behavior:'smooth',block:'center'});
}catch(e){toast('Не удалось открыть повтор: '+e.message);}}
function refreshReplayLabel(){if(!app.replay)return;const tk=app.replay.ticks[app.replay.index];$('replayTime').textContent=ts(tk?.t_ms);$('replaySlider').value=app.replay.index;}
function stopReplay(){clearInterval(app.replayTimer);app.replayTimer=null;$('replayPlay').textContent='▶';}
function closeReplay(){stopReplay();app.replay=null;$('replayBar').classList.add('hidden');app.rightOffset=0;requestDraw();}
function replayPlay(){if(!app.replay)return;if(app.replayTimer){stopReplay();return;}if(app.replay.index>=app.replay.ticks.length-1)app.replay.index=0;$('replayPlay').textContent='❚❚';
  app.replayTimer=setInterval(()=>{app.replay.index=Math.min(app.replay.index+Math.max(1,Math.round(app.replay.ticks.length/300)),app.replay.ticks.length-1);refreshReplayLabel();requestDraw();if(app.replay.index>=app.replay.ticks.length-1)stopReplay();},75);
}
async function performClearStatistics(){
  const confirmButton=$('btnDoClear');
  if($('clearConfirmText').value!=='CLEAR')return;
  confirmButton.disabled=true;
  try {
    await api('/api/statistics/reset',{method:'POST',body:JSON.stringify({confirmation:'CLEAR'})});
    $('clearStatsDialog').close();
    app.currentRun=null;app.selectedVariant=null;app.variants=[];app.loadedRun=[];
    if(app.replay)closeReplay();
    $('jobProgressPanel').classList.add('hidden');
    $('variantDetails').classList.add('hidden');
    $('variantsBody').innerHTML='<tr><td colspan="13" class="empty-table">Результаты очищены</td></tr>';
    $('regimesBody').innerHTML='<tr><td colspan="7" class="empty-table">Результаты очищены</td></tr>';
    $('insightsContent').innerHTML='<div class="empty-table">Нет выбранного варианта</div>';
    $('insightsLabel').textContent='Нет выбранного варианта';
    $('eventFeed').innerHTML='<div class="state-placeholder">События появятся здесь.</div>';
    $('jobsList').innerHTML='<div class="empty-table">Исследований ещё нет</div>';
    await fetchStatus();
    toast('Результаты очищены, виртуальный цикл остановлен. Настройки и архив тиков сохранены.');
  }catch(err){toast('Очистка не выполнена: '+err.message);}
  finally{confirmButton.disabled=$('clearConfirmText').value!=='CLEAR';}
}
function setup(){
  document.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>toggleTab(btn.dataset.tab)));
  const clearDialog=$('clearStatsDialog');
  $('btnClearStatistics').addEventListener('click',()=>{
    $('clearConfirmText').value='';$('btnDoClear').disabled=true;
    clearDialog.showModal();
  });
  $('btnCancelClear').addEventListener('click',()=>clearDialog.close());
  $('clearConfirmText').addEventListener('input',()=>{
    $('btnDoClear').disabled=$('clearConfirmText').value!=='CLEAR';
  });
  $('btnDoClear').addEventListener('click',performClearStatistics);
  $('btnStart').addEventListener('click',()=>control('start'));
  $('btnStop').addEventListener('click',()=>control('stop'));
  $('btnForce').addEventListener('click',()=>{if(confirm('Прервать текущий виртуальный цикл без TP/SL?'))control('force_stop');});
  $('settingsForm').addEventListener('input',()=>{app.settingsTouched=true;showRecoveryFields();});
  $('settingsForm').elements.recovery_enabled.addEventListener('change',e=>{
    if(e.target.checked){const f=$('settingsForm').elements;
      f.volume_lots.value=f.recovery_variant.value==='extreme'?f.recovery_v2_initial_lots.value:
        f.recovery_variant.value==='fixed_flip'?f.recovery_v3_initial_lots.value:'0.01';}
  });
  $('settingsForm').elements.recovery_variant.addEventListener('change',()=>{
    const f=$('settingsForm').elements;
    if(f.recovery_enabled.checked)f.volume_lots.value=f.recovery_variant.value==='extreme'?f.recovery_v2_initial_lots.value:
      f.recovery_variant.value==='fixed_flip'?f.recovery_v3_initial_lots.value:'0.01';
    showRecoveryFields();
  });
  document.querySelectorAll('[data-recovery-mode]').forEach(btn=>btn.addEventListener('click',()=>{
    const f=$('settingsForm').elements;
    f.recovery_variant.value=btn.dataset.recoveryMode;
    app.settingsTouched=true;
    if(f.recovery_enabled.checked){f.volume_lots.value=f.recovery_variant.value==='extreme'?f.recovery_v2_initial_lots.value:
      f.recovery_variant.value==='fixed_flip'?f.recovery_v3_initial_lots.value:'0.01';}
    showRecoveryFields();
  }));
  $('settingsForm').elements.recovery_v3_initial_lots.addEventListener('input',()=>{
    const f=$('settingsForm').elements;if(f.recovery_enabled.checked&&f.recovery_variant.value==='fixed_flip')f.volume_lots.value=f.recovery_v3_initial_lots.value;
  });
  $('settingsForm').elements.recovery_v2_initial_lots.addEventListener('input',()=>{
    const f=$('settingsForm').elements;if(f.recovery_enabled.checked&&f.recovery_variant.value==='extreme')f.volume_lots.value=f.recovery_v2_initial_lots.value;
  });
  $('backtestForm').elements.recovery_variant.addEventListener('change',()=>{
    const f=$('backtestForm').elements;
    if(f.recovery_enabled.checked)f.volume_lots.value=f.recovery_variant.value!=='classic'?'0.03':'0.01';
    showRecoveryFields();updateCount();
  });
  $('backtestForm').elements.recovery_enabled.addEventListener('change',()=>{
    const f=$('backtestForm').elements;
    if(f.recovery_enabled.checked)f.volume_lots.value=f.recovery_variant.value!=='classic'?'0.03':'0.01';
    showRecoveryFields();updateCount();
  });
  $('settingsForm').addEventListener('submit',async e=>{e.preventDefault();try{const f=$('settingsForm');const payload={};for(const key of ['trigger_distance','tp_distance','sl_distance','volume_lots','commission_per_lot_roundtrip',
      'recovery_trail_step','recovery_trail_start_offset','recovery_reentry_lots','recovery_partial_lots','recovery_opposite_max_range',
      'recovery_v2_initial_lots','recovery_v2_work_lots','recovery_v2_trigger_distance','recovery_v2_initial_tp_distance',
      'recovery_v2_initial_sl_distance','recovery_v2_support_sl_distance','recovery_v2_trail_step',
      'recovery_v2_reentry_offset','recovery_v2_opposite_max_range',
      'recovery_v3_initial_lots','recovery_v3_work_lots','recovery_v3_trigger_distance',
      'recovery_v3_initial_tp_distance','recovery_v3_stop_gap','recovery_v3_initial_sl_distance',
     'recovery_v3_partial_lots','recovery_v3_expansion'])payload[key]=floatField(f,key);
    payload.recovery_enabled=f.elements.recovery_enabled.checked;payload.recovery_variant=f.elements.recovery_variant.value;
    payload.recovery_v3_range_mode=f.elements.recovery_v3_range_mode.value;
    await api('/api/settings',{method:'POST',body:JSON.stringify(payload)});app.settingsTouched=false;toast('Параметры виртуальной стратегии сохранены');
  }catch(err){toast('Ошибка: '+err.message);}});
  $('backtestForm').addEventListener('submit',submitBacktest);
  for(const name of ['distances','tps','sls','recovery_trail_offsets','recovery_enabled',
    'recovery_v2_support_sl_distances','recovery_v2_reentry_offsets','recovery_v2_trail_steps'])$('backtestForm').elements[name].addEventListener('input',updateCount);
  $('variantsBody').addEventListener('click',e=>{const btn=e.target.closest('[data-variant]');if(btn)selectVariant(Number(btn.dataset.variant));});
  $('variantTradesBody').addEventListener('click',e=>{const btn=e.target.closest('[data-replay]');if(btn)loadReplay(Number(btn.dataset.replay));});
  $('jobsList').addEventListener('click',e=>{const btn=e.target.closest('[data-job]');if(btn)openRun(btn.dataset.job);});
  $('btnRefreshVariants').addEventListener('click',refreshVariants);$('btnJobsRefresh').addEventListener('click',refreshJobs);
  $('btnExportVariants').addEventListener('click',()=>{if(app.currentRun)window.location.href=`/api/backtests/${app.currentRun}/export.csv`;else toast('Сначала выбери исследование');});
  $('btnExportTrades').addEventListener('click',()=>{if(app.selectedVariant)window.location.href=`/api/variants/${app.selectedVariant}/export.csv`;});
  $('closeReplay').addEventListener('click',closeReplay);$('replayPlay').addEventListener('click',replayPlay);
  $('replaySlider').addEventListener('input',e=>{if(!app.replay)return;app.replay.index=Number(e.target.value);refreshReplayLabel();requestDraw();});
  const form=$('virtualActionForm');
  form.addEventListener('submit',confirmVirtualAction);
  $('virtualCancel').addEventListener('click',()=>{$('virtualActionDialog').close();app.virtualAction=null;app.previewLevel=null;});
  $('virtualPrice').addEventListener('input',updateVirtualDialogDetails);
  $('virtualLots').addEventListener('input',updateVirtualDialogDetails);
  $('virtualSide').addEventListener('change',updateVirtualDialogDetails);
  $('virtualOrderType').addEventListener('change',updateVirtualDialogDetails);
  $('virtualDeleteStop').addEventListener('click',async()=>{
    const action=app.virtualAction;if(!action?.manualId)return;
    if(!confirm('Отменить этот виртуальный STOP?'))return;
    try{await api('/api/virtual/manual/cancel-stop',{method:'POST',body:JSON.stringify({manual_id:action.manualId,confirmation:'CONFIRM'})});
      $('virtualActionDialog').close();app.virtualAction=null;await fetchStatus();requestDraw();}
    catch(e){toast(e.message);}
  });
  $('manualPositions').addEventListener('click',e=>{
    const s=app.status;if(!s)return;
    if(e.target.closest('[data-close-auto]') && s.position){
      openVirtualDialog({mode:'close',closeKind:'auto',side:s.position.side,
        lots:s.position.lots??s.settings.volume_lots});return;
    }
    if(e.target.closest('[data-close-rec]') && s.recovery?.active){
      openVirtualDialog({mode:'close',closeKind:'recovery',side:s.recovery.active.side,
        lots:s.recovery.active.lots});return;
    }
    if(e.target.closest('[data-move-auto]')&&s.pending){
      openVirtualDialog({mode:'move',triggerKind:'standard',side:s.pending.side,
        price:s.pending.level});return;
    }
    const rec=e.target.closest('[data-move-rec]');
    if(rec&&s.recovery){
      const side=rec.dataset.moveRec,st=s.recovery.pending_stops?.find(p=>p.side===side);
      const firstV2=s.recovery.variant==='extreme'&&s.recovery.reentries===0&&s.recovery.partial_stops===0&&s.recovery.pending_stops?.length===1;
      if(st)openVirtualDialog({mode:'move',triggerKind:s.recovery.variant==='fixed_flip'?'recovery':firstV2?'recovery_first':s.recovery.stepped_mode?'recovery':'recovery_first',
        side,price:st.level});
    }
  });
  setupChartInteraction();
  if(window.matchMedia('(max-width:680px)').matches)app.visibleBars=46;
  const today=new Date();const utcDay=today.toISOString().slice(0,10);const start=new Date(today.getTime()-7*86400000).toISOString().slice(0,10);
  $('backtestForm').elements.start_date.value=start;$('backtestForm').elements.end_date.value=utcDay;
  updateCount();fetchStatus();fetchChart();
  setInterval(()=>{$('utcClock').textContent='UTC '+new Date().toISOString().slice(11,19);},1000);
  setInterval(fetchStatus,1400);setInterval(fetchChart,12000);
  setInterval(()=>{if(app.currentRun)updateJob();},2500);
}
document.addEventListener('DOMContentLoaded',setup);

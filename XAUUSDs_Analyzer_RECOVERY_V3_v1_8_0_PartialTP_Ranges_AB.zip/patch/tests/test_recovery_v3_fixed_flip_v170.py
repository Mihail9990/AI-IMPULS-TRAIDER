"""Compatibility checks for upgrading an idle original V3 v1.7 snapshot."""
from analyzer.engine import PaperEngine, Settings, Tick

def test_old_idle_snapshot_loads_with_new_v3_settings():
    e=PaperEngine(Settings(recovery_enabled=True,recovery_variant="fixed_flip",volume_lots=.03))
    snapshot=e.to_snapshot()
    for key in ("recovery_v3_initial_sl_distance","recovery_v3_partial_lots",
                "recovery_v3_range_mode","recovery_v3_expansion",
                "volume_min_lots","volume_step_lots"):
        snapshot["settings"].pop(key,None)
    resumed=PaperEngine.from_snapshot(snapshot)
    assert resumed.settings.recovery_v3_initial_sl_distance==4.0
    assert resumed.settings.recovery_v3_stop_gap==1.5
    assert resumed.settings.recovery_v3_partial_lots==.01
    assert resumed.recovery is None

def test_saved_nominal_pending_survives_idle_snapshot():
    e=PaperEngine(Settings(recovery_enabled=True,recovery_variant="fixed_flip",volume_lots=.03))
    e.on_tick(Tick(0,3999.5,3999.73));e.start()
    e.on_tick(Tick(50000,4000,4000.23));e.on_tick(Tick(60000,4000,4000.23))
    saved=e.to_snapshot();saved["settings"].pop("recovery_v3_initial_sl_distance",None)
    # The updater blocks pending positions; this verifies the serializer only.
    resumed=PaperEngine.from_snapshot(saved)
    assert resumed.pending.level==4001.0

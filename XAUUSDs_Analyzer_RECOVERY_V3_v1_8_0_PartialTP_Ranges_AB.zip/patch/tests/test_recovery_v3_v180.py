"""V3 v1.8: only PAPER ticks, no connection/order calls to MT5."""
from dataclasses import asdict
import pytest
from analyzer.engine import PaperEngine, Settings, Tick, Position, RecoveryLeg, RecoveryState


def tk(sec, bid, spread=.23):
    return Tick(sec*1000,round(bid,8),round(bid+spread,8))


def settings(**kwargs):
    data=dict(recovery_enabled=True,recovery_variant='fixed_flip',volume_lots=.03,
              recovery_v3_initial_lots=.03,recovery_v3_work_lots=.03,
              recovery_v3_initial_sl_distance=4.,recovery_v3_stop_gap=1.5,
              recovery_v3_partial_lots=.01)
    data.update(kwargs)
    return Settings(**data)


def first_buy(**kwargs):
    e=PaperEngine(settings(**kwargs))
    e.on_tick(tk(0,3999.5));e.start();e.on_tick(tk(50,4000));e.on_tick(tk(60,4000))
    assert e.pending.level==pytest.approx(4001)
    e.on_tick(tk(61,4000.77))
    assert e.position.entry==pytest.approx(4001)
    assert e.position.sl==pytest.approx(3997)  # independent INITIAL SL=4
    assert e.position.tp==pytest.approx(4001.25)
    e.on_tick(tk(62,3997))
    assert e.recovery and e.recovery.active
    assert e.recovery.active.side=='SELL'
    assert e.recovery.active.stop==pytest.approx(3998.5)  # RECOVERY SL=1.5
    return e


def to_next_stop(e,sec,bid):
    e.on_tick(tk(sec,bid))
    return e.recovery


def test_v3_two_independent_sl_and_partial_levels_bid_ask():
    e=first_buy(recovery_v3_work_lots=.06)
    r=e.recovery
    assert r.active.lots==pytest.approx(.06)
    assert len(r.active.v3_tp_targets)==6
    assert r.active.v3_tp_targets[0]['price']<r.active.entry
    assert all(x['lots']==pytest.approx(.01) for x in r.active.v3_tp_targets)
    assert r.pending_stops[0]['level']==pytest.approx(3998.5)
    assert r.active.trail_step_index==-1


def test_v3_linear_targets_cover_weighted_debt_not_full_lot_debt():
    e=PaperEngine(settings(recovery_v3_work_lots=.06))
    origin=Position('BUY',4000,4000.25,3996,0,4000,0,0,0,'BUY',0,lots=.03)
    r=RecoveryState(0,origin,3996,4000,3996,
                    RecoveryLeg('BUY',4000,.06,0,'fixed_flip',3998.5,
                                v3_nominal_entry=4000),realized_weighted_points=-.18,
                    variant='fixed_flip')
    e.recovery=r
    e.mode='running'
    e.latest=tk(1,4000,0)
    e._v3_grid_rebuild(e.latest)
    assert len(r.active.v3_tp_targets)==6
    assert [round(x['price']-4000,2) for x in r.active.v3_tp_targets]==pytest.approx([.86,1.72,2.58,3.44,4.30,5.16])
    gross=sum(x['lots']*(x['price']-4000) for x in r.active.v3_tp_targets)
    assert gross>=.18-1e-9
    e._v3_plan_next(e.latest,'BUY',4000,1)
    e.on_tick(tk(2,4000.86,0))
    assert r.active.lots==pytest.approx(.05)
    assert r.partial_tps==1
    assert len(r.active.v3_tp_targets)==5
    assert r.active.v3_tp_targets[0]['price']>4000.86
    e.on_tick(tk(3,4003.70,0))
    assert e.recovery is None and e.trades[-1]['result']=='RECOVERED'
    assert e.trades[-1]['pnl_weighted_points_lots']>=-1e-8


def test_v3_partial_then_stop_preserves_credits_and_waits_far_stop():
    e=first_buy(recovery_v3_work_lots=.06,recovery_v3_range_mode='once')
    r=e.recovery
    first=r.active.v3_tp_targets[0]['price']
    e.on_tick(tk(63,first-.23)) # SELL closes on ASK exactly at the first TP
    assert r.partial_tps==1 and r.active.lots==pytest.approx(.05)
    realised_before=r.realized_weighted_points
    e.on_tick(tk(64,3998.27)) # SELL SL 3998.5; BUY stop 3998.5 same tick
    assert r.realized_weighted_points<realised_before
    assert r.active and r.active.side=='BUY'
    assert any(a['type']=='v3_partial_tp' for a in r.actions)
    assert any(a['type']=='v3_fixed_sl' for a in r.actions)


def test_v3_variant_A_two_narrow_two_wide_repeats():
    e=first_buy(recovery_v3_range_mode='alternating')
    r=e.recovery
    assert r.pending_stops[0]['level']==pytest.approx(3998.5) # #1 narrow
    e.on_tick(tk(63,3998.27))
    assert r.active.side=='BUY' and r.active.v3_nominal_entry==pytest.approx(3998.5)
    assert r.pending_stops[0]['level']==pytest.approx(3997) # #2 narrow
    e.on_tick(tk(64,3997))
    assert r.active.side=='SELL' and r.active.v3_nominal_entry==pytest.approx(3997)
    assert r.pending_stops[0]['level']==pytest.approx(3999.5) # #3 wide
    # Under same tick SELL 3997 cannot reach BUY 3999.5, wait for it.
    e.on_tick(tk(65,3999.27))
    assert r.active.side=='BUY' and r.pending_stops[0]['level']==pytest.approx(3997) # #4 wide
    e.on_tick(tk(66,3997))
    assert r.active.side=='SELL' and r.pending_stops[0]['level']==pytest.approx(3998.5) # #5 narrow


def test_v3_variant_B_expands_once_no_followup_additions():
    e=first_buy(recovery_v3_range_mode='once')
    r=e.recovery
    assert r.pending_stops[0]['level']==pytest.approx(3998.5) # #1 narrow
    e.on_tick(tk(63,3998.27))
    assert r.pending_stops[0]['level']==pytest.approx(3996) # #2 wider SELL
    e.on_tick(tk(64,3997)) # BUY SL 3997, next trigger SELL3996 not hit
    assert r.active is None and r.pending_stops[0]['level']==pytest.approx(3996)
    e.on_tick(tk(65,3996.8))
    assert r.active is None
    e.on_tick(tk(66,3996))
    assert r.active and r.active.side=='SELL'
    assert r.pending_stops[0]['level']==pytest.approx(3998.5) # #3 wide BUY
    e.on_tick(tk(67,3998.27))
    assert r.active and r.active.side=='BUY'
    assert r.pending_stops[0]['level']==pytest.approx(3996) # #4 wide SELL
    assert r.v3_flip_count==3


def test_v3_sl_real_execution_not_nominal_and_slippage_does_not_move_nominal():
    e=PaperEngine(settings())
    e.on_tick(tk(0,3999.5));e.start();e.on_tick(tk(50,4000));e.on_tick(tk(60,4000))
    e.on_tick(tk(61,4000.90)) # buy trigger 4001, actual Ask 4001.13
    assert e.position.entry==pytest.approx(4001.13)
    assert e.position.sl==pytest.approx(3997.13)
    e.on_tick(tk(62,3997.13)) # initial SL, SELL nominal3997.00 not yet hit
    r=e.recovery
    assert r.active is None
    assert r.sell_anchor==pytest.approx(3997)
    e.on_tick(tk(63,3997.))
    assert r.active.side=='SELL' and r.active.entry==pytest.approx(3997.)
    e.on_tick(tk(64,3998.40)) # Ask 3998.63 -> SELL stop at 3998.50, BUY nominal 3998.50
    assert r.active and r.active.side=='BUY'
    assert r.active.entry==pytest.approx(3998.63)
    assert r.active.stop==pytest.approx(3997.13)
    assert r.buy_anchor==pytest.approx(3998.50)


def test_v3_snapshot_preserves_partial_targets_and_range_counter():
    e=first_buy(recovery_v3_range_mode='once',recovery_v3_work_lots=.06)
    r=e.recovery
    snap=e.to_snapshot()
    e2=PaperEngine.from_snapshot(snap)
    assert asdict(e2.recovery.active)==asdict(r.active)
    assert e2.recovery.v3_flip_count==0
    assert e2.recovery.v3_next_nominal==pytest.approx(3998.5)
    assert e2.settings.recovery_v3_range_mode=='once'


def test_v3_invalid_volume_step_rejected():
    with pytest.raises(ValueError,match='minimum/step'):
        settings(volume_min_lots=.03,volume_step_lots=.01,recovery_v3_partial_lots=.01)
    with pytest.raises(ValueError,match='part cannot exceed'):
        settings(recovery_v3_partial_lots=.10)
    with pytest.raises(ValueError,match='range mode'):
        settings(recovery_v3_range_mode='more_and_more')


def test_v3_partial_tail_is_merged_and_no_below_min_chunks():
    e=PaperEngine(settings(recovery_v3_work_lots=.05,recovery_v3_partial_lots=.02))
    assert e._v3_chunks(.05)==pytest.approx([.02,.02,.01])
    assert e._v3_chunks(.04)==pytest.approx([.02,.02])


def test_original_tp_still_waits_for_closed_m1():
    e=PaperEngine(settings())
    e.on_tick(tk(0,3999.5));e.start();e.on_tick(tk(50,4000));e.on_tick(tk(60,4000))
    e.on_tick(tk(61,4000.77))
    e.on_tick(tk(62,4001.25))
    assert e.recovery is None and e.position is None
    assert e.trades[-1]['result']=='TP'
    assert e.pending is None
    e.on_tick(tk(100,4001.4))
    assert e.pending is None
    e.on_tick(tk(120,4001.4))
    assert e.pending is not None

@pytest.fixture
def api_client(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    import analyzer.server as server
    monkeypatch.setenv('WEB_PASSWORD','separate-v3-long-pass-for-paper-tests')
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as c:yield c


def test_v3_settings_api_and_visible_fields(api_client):
    payload=dict(trigger_distance=1,tp_distance=.25,sl_distance=3,volume_lots=.03,
       recovery_enabled=True,recovery_variant='fixed_flip',
       recovery_v3_initial_lots=.03,recovery_v3_work_lots=.06,
       recovery_v3_initial_sl_distance=4.0,recovery_v3_stop_gap=1.5,
       recovery_v3_partial_lots=.01,recovery_v3_expansion=1.0,
       recovery_v3_range_mode='alternating')
    auth=('admin','separate-v3-long-pass-for-paper-tests')
    assert api_client.post('/api/settings',json=payload).status_code==401
    result=api_client.post('/api/settings',json=payload,auth=auth)
    assert result.status_code==200,result.text
    result=api_client.get('/api/status',auth=auth).json()['settings']
    for name,value in payload.items():assert result[name]==value,(name,result[name],value)
    html=api_client.get('/',auth=auth).text
    assert 'name="recovery_v3_initial_sl_distance"' in html
    assert 'name="recovery_v3_stop_gap"' in html
    assert 'name="recovery_v3_partial_lots"' in html
    assert 'name="recovery_v3_range_mode"' in html


def test_v3_backtest_SL_independent_and_modes(api_client):
    import time
    auth=('admin','separate-v3-long-pass-for-paper-tests')
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1.0],tps=[.25],
        sls=[3.0,4.0],volume_lots=.03,recovery_enabled=True,
        recovery_variant='fixed_flip',recovery_v3_work_lots=.06,
        recovery_v3_stop_gap=1.5,recovery_v3_partial_lots=.01,
        recovery_v3_range_mode='once',recovery_v3_expansion=1.0)
    result=api_client.post('/api/backtests',json=payload,auth=auth)
    assert result.status_code==200,result.text
    uid=result.json()['id']
    deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        job=api_client.get('/api/backtests/'+uid,auth=auth).json()
        if job['status'] in ('completed','failed'):break
        time.sleep(.08)
    assert job['status']=='completed',job.get('error')
    rows=api_client.get('/api/backtests/'+uid+'/variants',auth=auth).json()
    assert len(rows)==2
    assert {x['config']['recovery_v3_initial_sl_distance'] for x in rows}=={3.,4.}
    assert {x['config']['recovery_v3_stop_gap'] for x in rows}=={1.5}
    assert {x['config']['recovery_v3_range_mode'] for x in rows}=={'once'}

﻿param([string]$TargetDirectory='')
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$files=@(
  'analyzer\engine.py',
  'analyzer\backtest.py',
  'analyzer\live.py',
  'analyzer\server.py',
  'web\index.html',
  'web\app.js',
  'tests\test_recovery_v3_v180.py',
  'tests\test_recovery_v3_fixed_flip_v170.py',
  'tools\precheck_v180.py'
)
function Main {
  Write-Host 'XAUUSD.s Analyzer: RECOVERY V3 v1.8.0 - PARTIAL TP + RANGE A/B' -ForegroundColor Cyan
  Write-Host 'Required existing Analyzer: v1.6.1 or v1.7.0. No MT5 trade orders.'
  Write-Host 'No changes to .env, broker MT5, SQLite results, tick cache, HTTPS or Caddy.'
  $manifest=Join-Path $here 'SHA256SUMS.txt'
  if(-not(Test-Path -LiteralPath $manifest -PathType Leaf)){throw 'Missing SHA256SUMS.txt'}
  $hashes=@{}
  foreach($line in (Get-Content -LiteralPath $manifest)) {
    if($line -match '^([0-9a-fA-F]{64})\s{2}(.+)$') {$hashes[$matches[2]]=$matches[1].ToLowerInvariant()}
  }
  foreach($rel in $files) {
    # Plain string replacement; no regex on Windows path separator.
    $key='patch/'+($rel.Replace('\','/'))
    $src=Join-Path (Join-Path $here 'patch') $rel
    if(-not(Test-Path -LiteralPath $src -PathType Leaf)){throw ('Missing '+$key)}
    if(-not $hashes.ContainsKey($key)){throw ('Missing checksum '+$key)}
    if((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hashes[$key]){
      throw ('SHA-256 mismatch: '+$key)
    }
  }
  Write-Host '[OK] Checksums verified.' -ForegroundColor Green
  if(-not $TargetDirectory) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description='Select INSTALLED analyzer folder with start_windows.bat and .env'
    $dialog.ShowNewFolderButton=$false
    if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
      Write-Host 'Cancelled; no files changed.'; return
    }
    $TargetDirectory=$dialog.SelectedPath
  }
  $target=[System.IO.Path]::GetFullPath($TargetDirectory)
  foreach($rel in @('start_windows.bat','.env','analyzer\engine.py',
                    'analyzer\server.py','web\app.js','web\index.html')) {
    if(-not(Test-Path -LiteralPath (Join-Path $target $rel) -PathType Leaf)){
      throw ('Wrong installed analyzer directory. Missing '+$rel)
    }
  }
  $prior=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\engine.py'))
  if(-not($prior.Contains('recovery_v2_initial_sl_distance') -and
           $prior.Contains('recovery_v2_support_sl_distance') -and
           $prior.Contains('strategy_manual_open'))) {
    throw 'Needs existing Analyzer v1.6.1 or v1.7.0. No files changed.'
  }
  $envFile=[System.IO.File]::ReadAllText((Join-Path $target '.env'))
  $port=8765
  $match=[regex]::Match($envFile,'(?m)^\s*WEB_PORT\s*=\s*(\d+)')
  if($match.Success){$port=[int]$match.Groups[1].Value}
  if(Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue){
    if(@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue).Count -gt 0){
      throw ('Stop start_windows.bat; analyzer still listens at port '+$port)
    }
  }
  $python=Join-Path $target '.venv\Scripts\python.exe'
  $useLauncher=$false
  if(-not(Test-Path -LiteralPath $python -PathType Leaf)){
    $candidate=Get-Command py -ErrorAction SilentlyContinue
    if(-not $candidate){throw 'Python not found for snapshot check'}
    $python=$candidate.Source;$useLauncher=$true
  }
  $backup=Join-Path $target ('backup_RECOVERY_V3_v1_8_0_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
  New-Item -ItemType Directory -Path $backup -Force|Out-Null
  $check=Join-Path (Join-Path $here 'patch') 'tools\precheck_v180.py'
  if($useLauncher){& $python -3.13 $check --target $target --backup (Join-Path $backup 'db')}
  else {& $python $check --target $target --backup (Join-Path $backup 'db')}
  if($LASTEXITCODE -ne 0){throw 'Active cycle or SQLite preflight failed: existing files unchanged'}
  $existed=@{}
  try {
    foreach($rel in $files){
      $dest=Join-Path $target $rel
      $existed[$rel]=Test-Path -LiteralPath $dest -PathType Leaf
      if($existed[$rel]){
        $bk=Join-Path $backup $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $bk) -Force|Out-Null
        Copy-Item -LiteralPath $dest -Destination $bk -Force
      }
    }
    foreach($rel in $files){
      $src=Join-Path (Join-Path $here 'patch') $rel
      $dest=Join-Path $target $rel
      New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
      Copy-Item -LiteralPath $src -Destination $dest -Force
      Write-Host ('Updated '+$rel)
    }
  }catch{
    Write-Host 'Copy failed; restoring previous files...' -ForegroundColor Yellow
    foreach($rel in $files){
      $dest=Join-Path $target $rel;$bk=Join-Path $backup $rel
      if(Test-Path -LiteralPath $bk -PathType Leaf){Copy-Item -LiteralPath $bk -Destination $dest -Force}
      elseif($existed.ContainsKey($rel) -and -not $existed[$rel] -and
             (Test-Path -LiteralPath $dest -PathType Leaf)){Remove-Item -LiteralPath $dest -Force}
    }
    throw
  }
  Write-Host '[OK] V3 v1.8.0 installed. Database/history/settings and HTTPS unchanged.' -ForegroundColor Green
  Write-Host ('Backup directory: '+$backup)
  Write-Host 'Start start_windows.bat. Refresh Android browser. Settings > RECOVERY V3.'
}
try {Main}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}

param([string]$TargetFolder = '')
$ErrorActionPreference = 'Stop'

try {
  Write-Host 'XAUUSD.s Strategy Analyzer - RECOVERY v1.2 update' -ForegroundColor Cyan
  Write-Host 'This only updates the PAPER analyzer. MT5 and the trading bot are not touched.'
  $patchDir = Join-Path $PSScriptRoot 'patch'
  $manifestPath = Join-Path $PSScriptRoot 'SHA256SUMS.txt'
  if (!(Test-Path -LiteralPath $manifestPath) -or
      !(Test-Path -LiteralPath (Join-Path $patchDir 'analyzer\engine.py'))) {
    throw 'Unpack the WHOLE ZIP archive before launching the updater.'
  }
  $files = @(
    'analyzer\engine.py',
    'analyzer\backtest.py',
    'analyzer\live.py',
    'analyzer\server.py',
    'analyzer\storage.py',
    'analyzer\telegram_control.py',
    'analyzer\sources.py',
    'web\index.html',
    'web\app.js',
    'web\styles.css',
    'tests\test_recovery.py',
    'tests\test_web.py',
    'RECOVERY_v1_2_README.md'
  )

  # Validate the archive before creating backups or modifying anything.
  $manifest = @{}
  foreach ($line in (Get-Content -LiteralPath $manifestPath -Encoding UTF8)) {
    if ($line -match '^([a-fA-F0-9]{64})\s+(.+)$') {
      $manifest[$matches[2].Trim()] = $matches[1].ToLowerInvariant()
    }
  }
  foreach ($rel in $files) {
    $key = $rel.Replace('\','/')
    $source = Join-Path $patchDir $rel
    if (!(Test-Path -LiteralPath $source -PathType Leaf)) {
      throw "Missing package file: $rel"
    }
    if (!$manifest.ContainsKey($key)) { throw "Missing hash for: $rel" }
    $hash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $manifest[$key]) {
      throw "Checksum mismatch: $rel. Download ZIP again."
    }
  }
  Write-Host '[OK] All update file checksums verified.' -ForegroundColor Green

  if ([string]::IsNullOrWhiteSpace($TargetFolder)) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'start_windows.bat')) {
      $TargetFolder = $PSScriptRoot
    } else {
      Add-Type -AssemblyName System.Windows.Forms
      $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
      $dialog.Description = 'Select the INSTALLED analyzer folder containing start_windows.bat'
      $dialog.ShowNewFolderButton = $false
      $dialog.RootFolder = [System.Environment+SpecialFolder]::MyComputer
      if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Cancelled; no files changed.' -ForegroundColor Yellow
        exit 2
      }
      $TargetFolder = $dialog.SelectedPath
    }
  }
  $TargetFolder = (Resolve-Path -LiteralPath $TargetFolder).Path
  if (!(Test-Path -LiteralPath (Join-Path $TargetFolder 'start_windows.bat')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder 'analyzer\server.py')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder 'web\app.js'))) {
    throw 'Wrong folder. Choose the directory containing start_windows.bat, analyzer, and web.'
  }

  # An active python process would keep using old modules even if files were copied.
  $listeners = @(Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue)
  if ($listeners.Count -gt 0) {
    throw 'Local port 8765 is still LISTENING. First close start_windows.bat; leave MT5 running.'
  }

  $backupDir = Join-Path $TargetFolder ('backup_recovery_v1_2_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  $replaced = New-Object System.Collections.ArrayList
  try {
    foreach ($rel in $files) {
      $old = Join-Path $TargetFolder $rel
      if (Test-Path -LiteralPath $old) {
        $save = Join-Path $backupDir $rel
        New-Item -ItemType Directory -Path (Split-Path -Path $save -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $old -Destination $save -Force -ErrorAction Stop
      }
    }
    foreach ($rel in $files) {
      $source = Join-Path $patchDir $rel
      $dest = Join-Path $TargetFolder $rel
      New-Item -ItemType Directory -Path (Split-Path -Path $dest -Parent) -Force | Out-Null
      Copy-Item -LiteralPath $source -Destination $dest -Force -ErrorAction Stop
      [void]$replaced.Add($rel)
      Write-Host "  Updated: $rel"
    }
  } catch {
    Write-Host 'An error occurred while copying. Attempting to roll back...' -ForegroundColor Yellow
    foreach ($rel in $replaced) {
      $saved = Join-Path $backupDir $rel
      $dest = Join-Path $TargetFolder $rel
      if (Test-Path -LiteralPath $saved) {
        Copy-Item -LiteralPath $saved -Destination $dest -Force -ErrorAction SilentlyContinue
      } else {
        Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
      }
    }
    throw
  }
  Write-Host ''
  Write-Host '[OK] RECOVERY v1.2 installed.' -ForegroundColor Green
  Write-Host "Old program files backed up in: $backupDir"
  Write-Host 'Unchanged: .env/password, .venv/Python, database, tick caches, MT5, HTTPS settings.'
  Write-Host 'Launch start_windows.bat, then open http://127.0.0.1:8765 and press Ctrl+F5.'
  Write-Host 'Go to strategy settings and ENABLE RECOVERY with initial 0.01 lot, then Save.'
  exit 0
} catch {
  Write-Host ''
  Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}

"""Deterministic paper RECOVERY basket tests; never connect to a broker."""
import pytest

from analyzer.engine import PaperEngine, Settings, Tick


def tk(m, sec, bid, spread=.23):
    return Tick((m*60+sec)*1000, round(bid, 5), round(bid+spread, 5))


def rec_engine(commission=0, spread=.23):
    e=PaperEngine(Settings(volume_lots=.01, recovery_enabled=True,
                            tick_size=.01, tick_value_per_lot=1.0,
                            commission_per_lot_roundtrip=commission))
    e.start()
    # Signal candle green, close 3999 -> BUY STOP 4000.
    e.on_tick(tk(0,0,3998.50,spread))
    e.on_tick(tk(0,50,3999.00,spread))
    e.on_tick(tk(1,0,3999.05,spread))
    assert e.pending and e.pending.level==4000.0
    e.on_tick(tk(1,1,3999.77,spread))
    assert e.position and e.position.side=='BUY' and e.position.entry==4000
    return e


def active_recovery(commission=0):
    e=rec_engine(commission)
    e.on_tick(tk(1,2,3997.00))
    assert e.recovery is not None
    return e


def test_original_tp_still_closes_cycle_and_next_m1_signal():
    e=rec_engine()
    e.on_tick(tk(1,2,4000.25))
    assert e.recovery is None
    assert e.summary()['tp']==1
    assert e.position is None and e.arm_minute==60
    # Next fully closed minute, normal original trigger returns.
    e.on_tick(tk(1,45,4000.50))
    e.on_tick(tk(2,0,4000.49))
    assert e.pending and e.pending.side=='BUY'
    assert e.pending.level==4001.5


def test_activation_is_no_real_sl_and_hedge_lots_exact():
    e=active_recovery()
    r=e.recovery
    assert e.summary()['sl']==0
    assert e.trades==[]
    assert e.position.side=='BUY'
    assert r.initial.entry==4000 and r.initial.lots==.01
    assert r.hedge_core.side=='SELL' and r.hedge_core.entry==3997 and r.hedge_core.lots==.01
    assert r.supplement.side=='SELL' and r.supplement.entry==3997 and r.supplement.lots==.12
    assert r.buy_anchor==4000 and r.sell_anchor==3997
    assert e.public_state()['recovery']['partial_stop']==3998
    weighted,cash=e._recovery_net(tk(1,2,3997))
    assert weighted==pytest.approx(-.0599)
    assert cash==pytest.approx(-5.99)


def test_continued_move_breakeven_closes_everything_then_new_signal():
    e=active_recovery()
    e.on_tick(tk(1,3,3996.50))
    assert e.recovery is None and e.position is None
    assert len(e.trades)==1 and e.trades[0]['result']=='RECOVERED'
    assert e.trades[0]['pnl_money_est']>=0
    assert e.summary()['recovered']==1 and e.summary()['sl']==0
    assert e.trades[0]['recovery_partial_stops']==0
    assert e.pending is None
    e.on_tick(tk(1,45,3995.9));e.on_tick(tk(2,0,3995.85))
    assert e.pending and e.pending.side=='SELL'
    assert e.pending.level==3994.9


def test_partial_stop_closes_only_point12_and_arms_both_stops():
    e=active_recovery()
    e.on_tick(tk(1,3,3997.80))  # ASK 3998.03 crosses SELL stop 3998
    r=e.recovery
    assert r is not None and r.supplement is None
    assert r.initial.lots==.01 and r.hedge_core.lots==.01
    assert r.realized_weighted_points==pytest.approx(-.1236)
    assert r.partial_stops==1 and e.summary()['sl']==0
    st=e.public_state()['recovery']
    assert len(st['pending_stops'])==2
    assert {x['side']:x['level'] for x in st['pending_stops']}=={'BUY':4000,'SELL':3997}
    assert e.trades==[]  # internal partial SL is NOT a finished cycle


def test_sell_reentry_after_partial_stop_and_recovery_target_includes_loss():
    e=active_recovery()
    e.on_tick(tk(1,3,3997.80))
    e.on_tick(tk(1,4,3997.0))
    r=e.recovery
    assert r and r.supplement and r.supplement.side=='SELL'
    assert r.supplement.lots==.12 and r.supplement.entry==3997
    assert r.reentries==1
    e.on_tick(tk(1,5,3996.5))
    assert e.recovery is not None  # cannot erase previously realized -$12.36
    e.on_tick(tk(1,6,3995.40))
    assert e.recovery is None
    assert e.trades[0]['result']=='RECOVERED'
    assert e.trades[0]['recovery_reentries']==1
    assert e.trades[0]['recovery_partial_stops']==1
    assert e.trades[0]['pnl_money_est']>=0


def test_buy_reentry_partial_stop_then_sell_reentry():
    e=active_recovery()
    e.on_tick(tk(1,3,3997.8))
    e.on_tick(tk(1,4,3999.77)) # ASK exactly 4000, BUY 0.12
    r=e.recovery
    assert r and r.supplement and r.supplement.side=='BUY'
    assert r.supplement.entry==4000 and e.public_state()['recovery']['partial_stop']==3999
    e.on_tick(tk(1,5,3999.0))
    assert r.supplement is None and r.partial_stops==2
    e.on_tick(tk(1,6,3997.0))
    assert r.supplement and r.supplement.side=='SELL'
    assert r.reentries==2
    assert r.realized_weighted_points < -.20


def test_snapshot_resume_mid_recovery_matches_continuous_ticks():
    e=active_recovery()
    e.on_tick(tk(1,3,3997.8))
    fresh=PaperEngine.from_snapshot(e.to_snapshot())
    assert fresh.recovery and fresh.recovery.supplement is None
    assert fresh.recovery.realized_weighted_points==pytest.approx(e.recovery.realized_weighted_points)
    for tick in (tk(1,4,3997.0),tk(1,5,3996.50),tk(1,6,3995.4)):
        e.on_tick(tick);fresh.on_tick(tick)
    assert e.trades==fresh.trades
    assert e.summary()==fresh.summary()


def test_stop_waits_for_unresolved_recovery_and_force_stop_accounts_loss():
    e=active_recovery()
    e.request_stop()
    assert e.mode=='stopping'
    e.on_tick(tk(1,3,3997.80))
    assert e.mode=='stopping' and e.recovery
    e.force_stop()
    assert e.mode=='stopped' and e.recovery is None and e.position is None
    assert e.trades[0]['result']=='ABORTED'
    assert e.trades[0]['pnl_points']<0
    assert e.summary()['aborted']==1 and e.summary()['sl']==0


def test_commission_prevents_premature_break_even():
    e=active_recovery(commission=1.0)  # USD per lot for both entry+exit
    e.on_tick(tk(1,3,3996.50))
    assert e.recovery is not None  # gross ~ 1 cent, costs $0.14
    gross,net=e._recovery_net(e.latest)
    assert gross>0 and net<0
    e.on_tick(tk(1,4,3996.45))
    assert e.recovery is None
    assert e.trades[0]['pnl_money_est']>=0


def test_recovery_no_history_closed_but_drawdown_and_float_visible():
    e=active_recovery()
    e.on_tick(tk(1,3,3997.8))
    s=e.summary()
    assert s['trades']==0 and s['unresolved_recovery']==1
    assert s['equity_points']<0 and s['max_equity_drawdown_points']>0
    assert s['pnl_money_est'] is not None and s['net_equity_money_est']<0


def test_invalid_recovery_volumes_and_unknown_tick_value_with_commission():
    with pytest.raises(ValueError,match='initial'):
        Settings(recovery_enabled=True,volume_lots=.1)
    with pytest.raises(ValueError,match='hedge'):
        Settings(recovery_enabled=True,volume_lots=.01,recovery_hedge_lots=.14)
    with pytest.raises(ValueError,match='tick_value'):
        Settings(recovery_enabled=True,volume_lots=.01,commission_per_lot_roundtrip=1)


def test_unknown_tick_value_still_works_but_no_fake_dollars():
    e=PaperEngine(Settings(recovery_enabled=True,volume_lots=.01,tick_value_per_lot=0))
    e.start();e.on_tick(tk(0,0,3998.5));e.on_tick(tk(0,50,3999));e.on_tick(tk(1,0,3999.05))
    e.on_tick(tk(1,1,3999.77));e.on_tick(tk(1,2,3997));e.on_tick(tk(1,3,3996.5))
    assert e.trades[0]['result']=='RECOVERED'
    assert e.trades[0]['pnl_money_est'] is None
    assert e.summary()['net_equity_money_est'] is None

"""Deterministic, tick-driven paper trading engine. Contains ZERO broker trade calls.

All input timestamps are Unix milliseconds UTC; candles use BID; executions use ASK
for buys and BID for sells, exits in the opposite quote. Historical and live modes
both drive this exact same engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from math import ceil, floor, isfinite
from typing import Any, Optional


@dataclass(frozen=True)
class Settings:
    trigger_distance: float = 1.0
    tp_distance: float = 0.25
    sl_distance: float = 3.0
    tick_size: float = 0.01
    volume_lots: float = 0.10
    tick_value_per_lot: float = 0.0  # currency value of 1 tick for ONE lot; 0 = unknown
    commission_per_lot_roundtrip: float = 0.0
    # Opt-in: old saved projects stay in the original SL/TP mode after upgrade.
    recovery_enabled: bool = False
    recovery_core_lots: float = 0.01
    recovery_reentry_lots: float = 0.12
    recovery_hedge_lots: float = 0.13
    recovery_partial_stop_distance: float = 1.0

    def __post_init__(self):
        for name in ('trigger_distance', 'tp_distance', 'sl_distance', 'tick_size', 'volume_lots'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        for name in ('tick_value_per_lot', 'commission_per_lot_roundtrip'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n < 0:
                raise ValueError(f'{name} must be finite and >= 0')
        if not isinstance(self.recovery_enabled, bool):
            raise ValueError('recovery_enabled must be boolean')
        for name in ('recovery_core_lots','recovery_reentry_lots',
                     'recovery_hedge_lots','recovery_partial_stop_distance'):
            n = getattr(self,name)
            if not isinstance(n,(int,float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        if self.recovery_enabled:
            if abs(self.volume_lots-self.recovery_core_lots)>1e-8:
                raise ValueError('RECOVERY: initial volume_lots must equal recovery_core_lots')
            if abs(self.recovery_hedge_lots-self.recovery_core_lots-self.recovery_reentry_lots)>1e-8:
                raise ValueError('RECOVERY: hedge volume must equal core + reentry lots')
            if self.commission_per_lot_roundtrip and not self.tick_value_per_lot:
                raise ValueError('RECOVERY with commission requires positive tick_value_per_lot')


@dataclass(frozen=True)
class Tick:
    t_ms: int
    bid: float
    ask: float

    def __post_init__(self):
        if not isinstance(self.t_ms, int) or self.t_ms < 0:
            raise ValueError('Invalid timestamp')
        if not all(isfinite(x) and x > 0 for x in (self.bid, self.ask)) or self.ask < self.bid:
            raise ValueError('Invalid Bid/Ask quote')


@dataclass
class Candle:
    time: int  # minute start in UNIX seconds UTC
    open: float
    high: float
    low: float
    close: float
    ticks: int = 1

    @property
    def color(self) -> str:
        return 'BUY' if self.close > self.open else ('SELL' if self.close < self.open else 'DOJI')

    def on_tick(self, bid: float):
        self.high = max(self.high, bid)
        self.low = min(self.low, bid)
        self.close = bid
        self.ticks += 1


@dataclass
class Pending:
    side: str
    level: float
    created_ms: int
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str


@dataclass
class Position:
    side: str
    entry: float
    tp: float
    sl: float
    opened_ms: int
    trigger_level: float
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str
    entry_spread: float
    mfe: float = 0.0
    mae: float = 0.0


@dataclass
class RecoveryLeg:
    side: str
    entry: float
    lots: float
    opened_ms: int
    role: str  # initial | hedge_core | supplement


@dataclass
class RecoveryState:
    started_ms: int
    buy_anchor: float
    sell_anchor: float
    initial: RecoveryLeg
    hedge_core: RecoveryLeg
    supplement: Optional[RecoveryLeg]
    # Realized results from closing each 0.12 supplement at its partial stop.
    realized_weighted_points: float = 0.0  # point * lot
    realized_commission_money: float = 0.0
    partial_stops: int = 0
    reentries: int = 0
    max_loss_points: float = 0.0  # measured per initial lot
    actions: list[dict] = field(default_factory=list)
    truncated_actions: int = 0


class PaperEngine:
    def __init__(self, settings: Settings = Settings()):
        self.settings = settings
        self.mode = 'stopped'  # stopped | running | stopping
        self.arm_minute: Optional[int] = None
        self.candle: Optional[Candle] = None
        self.candles: list[dict] = []
        self.pending: Optional[Pending] = None
        self.position: Optional[Position] = None
        self.recovery: Optional[RecoveryState] = None
        self.recovery_activations = 0
        self.recovery_completed = 0
        self.recovery_partial_stops = 0
        self.recovery_reentries = 0
        self.recovery_aborted = 0
        self.realized_cycle_points = 0.0
        self.max_active_recovery_loss_points = 0.0
        self.equity_peak_points = 0.0
        self.max_equity_drawdown_points = 0.0
        self.min_equity_points = 0.0
        self.latest: Optional[Tick] = None
        self.last_tick_signature: Optional[tuple] = None
        self.trade_seq = 0
        self.order_seq = 0
        self.trades: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.new_trades: list[dict[str, Any]] = []
        self.new_events: list[dict[str, Any]] = []
        self.canceled_orders = 0
        self.placed_orders = 0
        self.triggered_orders = 0
        self.skipped_invalid = 0
        self.tick_count = 0
        self.first_tick_ms: Optional[int] = None
        self.max_tick_gap_ms = 0

    def _level(self, p: float, higher: bool) -> float:
        """Snap protective/entry target outward to the symbol's tick grid."""
        tick = self.settings.tick_size
        scale = p / tick
        snapped = (ceil(scale - 1e-8) if higher else floor(scale + 1e-8)) * tick
        return round(snapped, 10)

    def _event(self, t_ms: int, typ: str, **extra):
        row = dict(t_ms=t_ms, type=typ, **extra)
        self.events.append(row)
        self.new_events.append(row)
        if len(self.events) > 250:
            self.events = self.events[-250:]

    def start(self) -> None:
        if self.mode != 'stopped':
            raise ValueError('Session is already running')
        self.mode = 'running'
        self.arm_minute = self.candle.time if self.candle else None
        self.pending = None
        self.position = None
        self.recovery = None
        self._event(self.latest.t_ms if self.latest else 0, 'start')

    def request_stop(self) -> None:
        """Finish the existing cycle (including waiting for a pending trigger)."""
        if self.mode == 'running':
            if self.pending is None and self.position is None:
                self.mode = 'stopped'
            else:
                self.mode = 'stopping'
            self._event(self.latest.t_ms if self.latest else 0, 'stop_requested')

    def force_stop(self) -> None:
        """Abandon virtual pending/position (not an SL/TP)."""
        if self.pending:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_cancel', side=self.pending.side, price=self.pending.level)
        if self.recovery and self.latest:
            # Aborted simulated baskets must be accounted as losses, not erased.
            self._end_recovery(self.latest, 'ABORTED')
            self.recovery_aborted += 1
        elif self.position:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_abandon', side=self.position.side, price=self.position.entry)
        self.mode = 'stopped'
        self.pending = None
        self.position = None
        self.recovery = None
        self._event(self.latest.t_ms if self.latest else 0, 'forced_stop')

    def _create_pending(self, bar: Candle, t_ms: int):
        side = bar.color
        if side == 'DOJI':
            return
        delta = self.settings.trigger_distance
        level = self._level(bar.close + delta if side == 'BUY' else bar.close - delta, side == 'BUY')
        if self.pending and self.pending.side == side:
            return
        if self.pending:
            self.canceled_orders += 1
            self._event(t_ms, 'cancel', side=self.pending.side, price=self.pending.level,
                        reason='opposite_closed_candle')
        self.pending = Pending(side, level, t_ms, bar.time, abs(bar.close-bar.open),
                               bar.high-bar.low, side)
        self.placed_orders += 1
        self.order_seq += 1
        self._event(t_ms, 'place', side=side, price=level, signal_time=bar.time)

    def _finish_bar(self, bar: Candle, t_ms: int):
        self.candles.append(asdict(bar))
        if len(self.candles) > 750:
            self.candles = self.candles[-750:]
        if self.mode in ('running', 'stopping') and self.position is None and self.recovery is None:
            if self.arm_minute is not None and bar.time < self.arm_minute:
                return
            self._create_pending(bar, t_ms)

    def _fill(self, tick: Tick):
        p = self.pending
        if p is None:
            return
        if p.side == 'BUY':
            if tick.ask < p.level:
                return
            fill = max(p.level, tick.ask)  # adverse gap/trigger slippage
            tp = self._level(fill + self.settings.tp_distance, True)
            sl = self._level(fill - self.settings.sl_distance, False)
        else:
            if tick.bid > p.level:
                return
            fill = min(p.level, tick.bid)
            tp = self._level(fill - self.settings.tp_distance, False)
            sl = self._level(fill + self.settings.sl_distance, True)
        self.position = Position(p.side, fill, tp, sl, tick.t_ms, p.level, p.signal_time,
                                 p.signal_body, p.signal_range, p.signal_color,
                                 tick.ask - tick.bid)
        self.pending = None
        self.triggered_orders += 1
        self._event(tick.t_ms, 'fill', side=p.side, price=fill, trigger_level=p.level,
                    tp=tp, sl=sl, spread=tick.ask-tick.bid)

    def _position_tick(self, tick: Tick):
        pos = self.position
        if pos is None:
            return
        if self.recovery is not None:
            self._recovery_tick(tick)
            return
        if self.settings.recovery_enabled:
            self._pre_recovery_tick(tick)
            return
        # Mark to market on the quote that actually CLOSES the position.
        exit_quote = tick.bid if pos.side == 'BUY' else tick.ask
        move = exit_quote - pos.entry if pos.side == 'BUY' else pos.entry - exit_quote
        pos.mfe = max(pos.mfe, move)
        pos.mae = max(pos.mae, -move)
        if pos.side == 'BUY':
            result = 'SL' if tick.bid <= pos.sl else ('TP' if tick.bid >= pos.tp else None)
            exit_price = min(pos.sl, tick.bid) if result == 'SL' else pos.tp
        else:
            result = 'SL' if tick.ask >= pos.sl else ('TP' if tick.ask <= pos.tp else None)
            exit_price = max(pos.sl, tick.ask) if result == 'SL' else pos.tp
        if result is None:
            return
        points = exit_price - pos.entry if pos.side == 'BUY' else pos.entry - exit_price
        gap_to_tp = max(0.0, abs(pos.tp-pos.entry)-pos.mfe)
        money = None
        if self.settings.tick_value_per_lot > 0:
            money = (points/self.settings.tick_size*self.settings.tick_value_per_lot
                     - self.settings.commission_per_lot_roundtrip) * self.settings.volume_lots
        self.trade_seq += 1
        trade = dict(
            id=self.trade_seq, side=pos.side, result=result, opened_ms=pos.opened_ms,
            closed_ms=tick.t_ms, entry=pos.entry, exit=round(exit_price, 10),
            tp=pos.tp, sl=pos.sl, trigger_level=pos.trigger_level,
            pnl_points=round(points, 10), pnl_money_est=round(money, 5) if money is not None else None,
            mfe_points=round(pos.mfe, 10), mae_points=round(pos.mae, 10),
            gap_to_tp=round(gap_to_tp, 10), duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
            signal_time=pos.signal_time, signal_body=round(pos.signal_body, 6),
            signal_range=round(pos.signal_range, 6), signal_color=pos.signal_color,
            spread_at_entry=round(pos.entry_spread, 10),
            entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000, timezone.utc).hour,
        )
        self.trades.append(trade)
        self.new_trades.append(trade)
        self.realized_cycle_points += trade['pnl_points']
        self._event(tick.t_ms, result.lower(), side=pos.side, price=exit_price, trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'], gap_to_tp=trade['gap_to_tp'])
        self.position = None
        self._next_cycle_after_close(tick)

    def _next_cycle_after_close(self, tick: Tick):
        if self.mode == 'stopping':
            self.mode = 'stopped'
            self.arm_minute = None
        else:
            # First complete candle ending AFTER the current tick can arm a new STOP.
            self.arm_minute = (tick.t_ms // 60000) * 60

    def _weighted_move(self, leg: RecoveryLeg, price: float) -> float:
        return (price-leg.entry if leg.side == 'BUY' else leg.entry-price)*leg.lots

    def _close_quote(self, side: str, tick: Tick) -> float:
        return tick.bid if side == 'BUY' else tick.ask

    def _recovery_ledger(self, tick: Tick, typ: str, **kwargs):
        rec=self.recovery
        if rec is None:
            return
        action=dict(t_ms=tick.t_ms,type=typ,**kwargs)
        if len(rec.actions)<500:
            rec.actions.append(action)
        else:
            rec.truncated_actions+=1
        self._event(tick.t_ms,typ,**kwargs)

    def _recovery_net(self, tick: Tick) -> tuple[float, Optional[float]]:
        """Executable-liquidation value, including previously lost 0.12 lots.

        Net in price-point*lot always includes BID/ASK spread. When the broker's
        tick value is known, the cash estimate also includes ALL round-trip fees:
        already closed 0.12 tranches + expected costs to close live legs.
        No dollar or fee estimate is fabricated when tick value is unknown.
        """
        rec=self.recovery
        if rec is None:
            return 0.0,None
        legs=[rec.initial,rec.hedge_core]
        if rec.supplement is not None:
            legs.append(rec.supplement)
        raw=rec.realized_weighted_points + sum(
            self._weighted_move(leg,self._close_quote(leg.side,tick)) for leg in legs)
        cash=None
        if self.settings.tick_value_per_lot>0:
            cost=rec.realized_commission_money + (
                sum(leg.lots for leg in legs)*self.settings.commission_per_lot_roundtrip)
            cash=raw/self.settings.tick_size*self.settings.tick_value_per_lot-cost
        return raw,cash

    def _recovery_target_met(self, tick: Tick) -> bool:
        raw,cash=self._recovery_net(tick)
        if cash is None:
            return raw>=-1e-9
        return cash>=-1e-9

    def _start_recovery(self, tick: Tick):
        pos=self.position
        if pos is None or self.recovery is not None:
            return
        # No actual order is sent. Opposite STOP executes using the triggering
        # quote, with worse-than-stop gaps modeled conservatively.
        if pos.side=='BUY':
            target=self._level(pos.entry-self.settings.sl_distance,False)
            if tick.bid>target:
                return
            opposite='SELL'; entry=min(target,tick.bid)
            buy_anchor=pos.entry; sell_anchor=entry
        else:
            target=self._level(pos.entry+self.settings.sl_distance,True)
            if tick.ask<target:
                return
            opposite='BUY'; entry=max(target,tick.ask)
            buy_anchor=entry; sell_anchor=pos.entry
        initial=RecoveryLeg(pos.side,pos.entry,self.settings.volume_lots,pos.opened_ms,'initial')
        core=RecoveryLeg(opposite,entry,self.settings.recovery_core_lots,tick.t_ms,'hedge_core')
        supplement=RecoveryLeg(opposite,entry,self.settings.recovery_reentry_lots,tick.t_ms,'supplement')
        self.recovery=RecoveryState(tick.t_ms,buy_anchor,sell_anchor,initial,core,supplement)
        self.recovery_activations+=1
        self._recovery_ledger(tick,'recovery_start',side=opposite,price=entry,
                              lots=self.settings.recovery_hedge_lots,
                              buy_anchor=buy_anchor,sell_anchor=sell_anchor,
                              partial_stop=self._supplement_stop())

    def _supplement_stop(self) -> Optional[float]:
        rec=self.recovery
        if rec is None or rec.supplement is None:
            return None
        pos=rec.supplement
        d=self.settings.recovery_partial_stop_distance
        return self._level(pos.entry-d if pos.side=='BUY' else pos.entry+d,
                           pos.side=='SELL')

    def _pre_recovery_tick(self, tick: Tick):
        pos=self.position
        if pos is None:
            return
        exit_quote=self._close_quote(pos.side,tick)
        move=exit_quote-pos.entry if pos.side=='BUY' else pos.entry-exit_quote
        pos.mfe=max(pos.mfe,move)
        pos.mae=max(pos.mae,-move)
        # First check ordinary TP. The initial leg has NO actual SL.
        if (pos.side=='BUY' and tick.bid>=pos.tp or
                pos.side=='SELL' and tick.ask<=pos.tp):
            self._close_initial_tp(tick)
        else:
            self._start_recovery(tick)

    def _close_initial_tp(self,tick:Tick):
        pos=self.position
        if pos is None:return
        close=pos.tp
        points=close-pos.entry if pos.side=='BUY' else pos.entry-close
        cash=None
        if self.settings.tick_value_per_lot>0:
            cash=(points/self.settings.tick_size*self.settings.tick_value_per_lot-
                  self.settings.commission_per_lot_roundtrip)*self.settings.volume_lots
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=pos.side,result='TP',opened_ms=pos.opened_ms,
                   closed_ms=tick.t_ms,entry=pos.entry,exit=close,tp=pos.tp,sl=None,
                   trigger_level=pos.trigger_level,pnl_points=round(points,10),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=round(pos.mfe,10),mae_points=round(pos.mae,10),
                   gap_to_tp=0.0,duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
                   signal_time=pos.signal_time,signal_body=round(pos.signal_body,6),
                   signal_range=round(pos.signal_range,6),signal_color=pos.signal_color,
                   spread_at_entry=round(pos.entry_spread,10),
                   entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000,timezone.utc).hour,
                   recovery_used=False,recovery_actions=[],recovery_partial_stops=0,
                   recovery_reentries=0)
        self.trades.append(trade);self.new_trades.append(trade)
        self._event(tick.t_ms,'tp',side=pos.side,price=close,trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'])
        self.position=None
        self._next_cycle_after_close(tick)

    def _recovery_tick(self, tick: Tick):
        rec=self.recovery
        if rec is None:return
        # Mark-to-market and full-basket recovery check take priority over any
        # new virtual trigger. Never close at the wrong side of the spread.
        raw,cash=self._recovery_net(tick)
        normalized=raw/self.settings.volume_lots
        rec.max_loss_points=max(rec.max_loss_points,-normalized)
        self.max_active_recovery_loss_points=max(self.max_active_recovery_loss_points,rec.max_loss_points)
        if self._recovery_target_met(tick):
            self._end_recovery(tick,'RECOVERED')
            return
        active=rec.supplement
        if active is not None:
            sl=self._supplement_stop()
            crossed=(tick.bid<=sl if active.side=='BUY' else tick.ask>=sl)
            if not crossed:return
            # Virtual partial stop affects ONLY 0.12, core 0.01 remains.
            close=min(sl,tick.bid) if active.side=='BUY' else max(sl,tick.ask)
            points=self._weighted_move(active,close)
            rec.realized_weighted_points+=points
            rec.realized_commission_money+=self.settings.commission_per_lot_roundtrip*active.lots
            rec.partial_stops+=1
            self.recovery_partial_stops+=1
            rec.supplement=None
            self._recovery_ledger(tick,'recovery_partial_sl',side=active.side,
                                  price=close,lots=active.lots,
                                  realized_weighted_points=round(points,9),
                                  accumulated_weighted_points=round(rec.realized_weighted_points,9))
            # The two reverse STOPs are now virtual-armed; do not fill on the
            # same tick as the partial SL (avoids duplicated impossible fills).
            return
        # Two virtual pending STOPs while both 0.01 cores stay open.
        buy_hit=tick.ask>=rec.buy_anchor
        sell_hit=tick.bid<=rec.sell_anchor
        if buy_hit and sell_hit:
            # Abnormally wide spread makes both trigger conditions true.
            # Without an inter-tick price path the fill order is unknowable.
            self._recovery_ledger(tick,'recovery_ambiguous_spread',bid=tick.bid,ask=tick.ask)
            return
        if not (buy_hit or sell_hit):return
        side='BUY' if buy_hit else 'SELL'
        limit=rec.buy_anchor if buy_hit else rec.sell_anchor
        entry=max(limit,tick.ask) if buy_hit else min(limit,tick.bid)
        rec.supplement=RecoveryLeg(side,entry,self.settings.recovery_reentry_lots,tick.t_ms,'supplement')
        rec.reentries+=1;self.recovery_reentries+=1
        self._recovery_ledger(tick,'recovery_reentry',side=side,price=entry,
                              lots=rec.supplement.lots,partial_stop=self._supplement_stop())

    def _end_recovery(self,tick:Tick,result:str):
        rec=self.recovery
        pos=self.position
        if rec is None or pos is None:return
        weighted,cash=self._recovery_net(tick)
        points=weighted/self.settings.volume_lots
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=pos.side,result=result,
                   opened_ms=pos.opened_ms,closed_ms=tick.t_ms,entry=pos.entry,
                   exit=self._close_quote(pos.side,tick),tp=None,sl=None,
                   trigger_level=pos.trigger_level,
                   pnl_points=round(points,10),
                   pnl_weighted_points_lots=round(weighted,10),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=round(pos.mfe,10),mae_points=round(pos.mae,10),
                   gap_to_tp=round(max(0.,abs(pos.tp-pos.entry)-pos.mfe),10),
                   duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
                   signal_time=pos.signal_time,signal_body=round(pos.signal_body,6),
                   signal_range=round(pos.signal_range,6),signal_color=pos.signal_color,
                   spread_at_entry=round(pos.entry_spread,10),
                   entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000,timezone.utc).hour,
                   recovery_used=True,recovery_actions=rec.actions[:],
                   recovery_actions_truncated=rec.truncated_actions,
                   recovery_partial_stops=rec.partial_stops,
                   recovery_reentries=rec.reentries,
                   recovery_max_loss_points=round(rec.max_loss_points,8),
                   buy_anchor=rec.buy_anchor,sell_anchor=rec.sell_anchor,
                   recovery_closed_legs=[dict(side=leg.side,entry=leg.entry,lots=leg.lots,
                                             exit=self._close_quote(leg.side,tick))
                                         for leg in ([rec.initial,rec.hedge_core]+
                                                   ([rec.supplement] if rec.supplement else []))])
        self.trades.append(trade);self.new_trades.append(trade)
        self.realized_cycle_points += trade['pnl_points']
        if result=='RECOVERED':self.recovery_completed+=1
        self._event(tick.t_ms,'recovery_complete' if result=='RECOVERED' else 'recovery_aborted',
                    trade_id=self.trade_seq,pnl_points=trade['pnl_points'],
                    pnl_money_est=trade['pnl_money_est'],partial_stops=rec.partial_stops,
                    reentries=rec.reentries)
        self.position=None
        self.recovery=None
        self._next_cycle_after_close(tick)

    def _equity_points(self, tick: Optional[Tick] = None) -> float:
        closed=self.realized_cycle_points
        now=tick or self.latest
        if now is None:return closed
        if self.recovery:
            raw,_=self._recovery_net(now)
            return closed+raw/self.settings.volume_lots
        if self.position:
            pos=self.position
            quote=self._close_quote(pos.side,now)
            move=quote-pos.entry if pos.side=='BUY' else pos.entry-quote
            return closed+move
        return closed

    def _track_equity(self):
        if self.latest is None:return
        equity=self._equity_points(self.latest)
        self.equity_peak_points=max(self.equity_peak_points,equity)
        self.min_equity_points=min(self.min_equity_points,equity)
        self.max_equity_drawdown_points=max(self.max_equity_drawdown_points,
                                            self.equity_peak_points-equity)

    def on_tick(self, tick: Tick):
        if self.last_tick_signature == (tick.t_ms,tick.bid,tick.ask):
            return
        if self.latest and tick.t_ms < self.latest.t_ms:
            self.skipped_invalid += 1
            return
        if self.latest:
            self.max_tick_gap_ms = max(self.max_tick_gap_ms, tick.t_ms-self.latest.t_ms)
        else:
            self.first_tick_ms = tick.t_ms
        self.last_tick_signature = (tick.t_ms,tick.bid,tick.ask)
        self.latest = tick
        self.tick_count += 1
        minute = (tick.t_ms // 60000) * 60
        if self.candle is None:
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            if self.mode == 'running' and self.arm_minute is None:
                self.arm_minute = minute
        elif minute != self.candle.time:
            # The old STOP still exists at the *first tick* of a new minute.
            # Broker may execute it before our simulated cancel/replace request.
            if self.mode in ('running', 'stopping') and self.pending is not None and self.position is None:
                self._fill(tick)
                filled_on_boundary = self.position is not None
            else:
                filled_on_boundary = False
            old = self.candle
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            self._finish_bar(old,tick.t_ms)
            if filled_on_boundary:
                self._position_tick(tick)
                self._track_equity()
                return
        else:
            self.candle.on_tick(tick.bid)
        if self.mode in ('running', 'stopping'):
            if self.position:
                self._position_tick(tick)
            elif self.pending:
                self._fill(tick)
                # No same-tick exit for freshly filled position.
        self._track_equity()

    def summary(self) -> dict:
        trades=self.trades
        tp=sum(t['result']=='TP' for t in trades)
        sl=sum(t['result']=='SL' for t in trades)
        recovered=sum(t['result']=='RECOVERED' for t in trades)
        aborted=sum(t['result']=='ABORTED' for t in trades)
        gross_win=sum(max(0,t['pnl_points']) for t in trades)
        gross_loss=-sum(min(0,t['pnl_points']) for t in trades)
        balance=peak=max_dd=0.0
        for t in trades:
            balance+=t['pnl_points']
            peak=max(peak,balance)
            max_dd=max(max_dd,peak-balance)
        near={f'{v:.2f}':sum(t['result']=='SL' and t['gap_to_tp']<=v+1e-9 for t in trades)
              for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        near_recovery={f'{v:.2f}':sum(t.get('recovery_used',False) and
                          t.get('gap_to_tp',float('inf'))<=v+1e-9 for t in trades)
                       for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        weighted=None;active_money=None;open_recovery=None
        if self.recovery and self.latest:
            rec=self.recovery
            weighted,active_money=self._recovery_net(self.latest)
            open_recovery=dict(started_ms=rec.started_ms,buy_anchor=rec.buy_anchor,
                sell_anchor=rec.sell_anchor,partial_stops=rec.partial_stops,
                reentries=rec.reentries,
                realized_weighted_points=round(rec.realized_weighted_points,7),
                unrealized_and_realized_points_equivalent=round(weighted/self.settings.volume_lots,5),
                net_money_est=round(active_money,4) if active_money is not None else None)
        equity=self._equity_points()
        cash_closed=(round(sum(t['pnl_money_est'] for t in trades),4)
                     if all(t['pnl_money_est'] is not None for t in trades) else None)
        active_cost_est=None
        if self.position and not self.recovery and self.latest and self.settings.tick_value_per_lot>0:
            pos=self.position
            quote=self._close_quote(pos.side,self.latest)
            points=quote-pos.entry if pos.side=='BUY' else pos.entry-quote
            active_cost_est=(points/self.settings.tick_size*self.settings.tick_value_per_lot-
                             self.settings.commission_per_lot_roundtrip)*self.settings.volume_lots
        if cash_closed is not None:
            if self.recovery and active_money is not None:
                net_cash=cash_closed+active_money
            elif active_cost_est is not None:
                net_cash=cash_closed+active_cost_est
            else:
                net_cash=cash_closed
        else:
            net_cash=None
        return dict(trades=len(trades),tp=tp,sl=sl,recovered=recovered,aborted=aborted,
            win_rate=round(100*(tp+recovered)/len(trades),2) if trades else 0,
            pnl_points=round(balance,5),max_drawdown_points=round(max_dd,5),
            equity_points=round(equity,5),
            max_equity_drawdown_points=round(self.max_equity_drawdown_points,5),
            min_equity_points=round(self.min_equity_points,5),
            profit_factor=round(gross_win/gross_loss,3) if gross_loss else None,
            pnl_money_est=cash_closed,net_equity_money_est=round(net_cash,4) if net_cash is not None else None,
            near_tp_then_sl=near,near_tp_then_recovery=near_recovery,
            recovery_activations=self.recovery_activations,
            recovery_completed=self.recovery_completed,
            recovery_partial_stops=self.recovery_partial_stops,
            recovery_reentries=self.recovery_reentries,
            recovery_aborted=self.recovery_aborted,
            max_active_recovery_loss_points=round(self.max_active_recovery_loss_points,5),
            open_recovery=open_recovery,unresolved_recovery=1 if self.recovery else 0,
            unfinished_cycle=1 if self.position is not None else 0,
            placed=self.placed_orders,canceled=self.canceled_orders,triggered=self.triggered_orders,
            tick_count=self.tick_count,max_tick_gap_seconds=round(self.max_tick_gap_ms/1000,3))

    def public_state(self) -> dict:
        rec=self.recovery
        recovery_info=None
        if rec is not None:
            weighted,cash=self._recovery_net(self.latest) if self.latest else (0.,None)
            recovery_info=dict(started_ms=rec.started_ms,buy_anchor=rec.buy_anchor,
                sell_anchor=rec.sell_anchor,
                initial=asdict(rec.initial),hedge_core=asdict(rec.hedge_core),
                supplement=asdict(rec.supplement) if rec.supplement else None,
                partial_stop=self._supplement_stop(),
                pending_stops=([dict(side='BUY',level=rec.buy_anchor,lots=self.settings.recovery_reentry_lots),
                                dict(side='SELL',level=rec.sell_anchor,lots=self.settings.recovery_reentry_lots)]
                               if rec.supplement is None else []),
                realized_weighted_points=round(rec.realized_weighted_points,7),
                equity_points_equivalent=round(weighted/self.settings.volume_lots,6),
                equity_money_est=round(cash,5) if cash is not None else None,
                partial_stops=rec.partial_stops,reentries=rec.reentries)
        return dict(mode=self.mode,settings=asdict(self.settings),
                    tick=asdict(self.latest) if self.latest else None,
                    candle=asdict(self.candle) if self.candle else None,
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    recovery=recovery_info,
                    summary=self.summary(),events=self.events[-30:],trades=self.trades[-35:])

    def chart_candles(self, max_rows=450) -> list[dict]:
        data = self.candles[-max_rows:]
        if self.candle:
            data = data + [asdict(self.candle)]
        return data

    def to_snapshot(self) -> dict:
        # No transient output buffers, they are already stored separately.
        return dict(settings=asdict(self.settings),mode=self.mode,arm_minute=self.arm_minute,
                    candle=asdict(self.candle) if self.candle else None,candles=self.candles[-750:],
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    recovery=asdict(self.recovery) if self.recovery else None,
                    latest=asdict(self.latest) if self.latest else None,
                    trade_seq=self.trade_seq,order_seq=self.order_seq,
                    trades=self.trades,events=self.events[-250:],canceled_orders=self.canceled_orders,
                    placed_orders=self.placed_orders, triggered_orders=self.triggered_orders,
                    tick_count=self.tick_count,skipped_invalid=self.skipped_invalid,
                    first_tick_ms=self.first_tick_ms,max_tick_gap_ms=self.max_tick_gap_ms,
                    realized_cycle_points=self.realized_cycle_points,
                    recovery_activations=self.recovery_activations,
                    recovery_completed=self.recovery_completed,
                    recovery_partial_stops=self.recovery_partial_stops,
                    recovery_reentries=self.recovery_reentries,
                    recovery_aborted=self.recovery_aborted,
                    max_active_recovery_loss_points=self.max_active_recovery_loss_points,
                    equity_peak_points=self.equity_peak_points,
                    max_equity_drawdown_points=self.max_equity_drawdown_points,
                    min_equity_points=self.min_equity_points)

    @classmethod
    def from_snapshot(cls, data: dict) -> 'PaperEngine':
        e = cls(Settings(**data['settings']))
        for attr, typ in [('candle',Candle),('pending',Pending),('position',Position),('latest',Tick)]:
            if data.get(attr):
                setattr(e,attr,typ(**data[attr]))
        rec=data.get('recovery')
        if rec:
            leg=lambda d: RecoveryLeg(**d) if d is not None else None
            e.recovery=RecoveryState(started_ms=rec['started_ms'],
                buy_anchor=rec['buy_anchor'],sell_anchor=rec['sell_anchor'],
                initial=leg(rec['initial']),hedge_core=leg(rec['hedge_core']),
                supplement=leg(rec.get('supplement')),
                realized_weighted_points=rec.get('realized_weighted_points',0.0),
                realized_commission_money=rec.get('realized_commission_money',0.0),
                partial_stops=rec.get('partial_stops',0),reentries=rec.get('reentries',0),
                max_loss_points=rec.get('max_loss_points',0.0),
                actions=rec.get('actions',[]),truncated_actions=rec.get('truncated_actions',0))
        for attr in ('mode','arm_minute','trade_seq','order_seq','canceled_orders','placed_orders',
                     'triggered_orders','skipped_invalid','tick_count','first_tick_ms','max_tick_gap_ms',
                     'recovery_activations','recovery_completed','recovery_partial_stops',
                     'recovery_reentries','recovery_aborted','max_active_recovery_loss_points',
                     'equity_peak_points','max_equity_drawdown_points','min_equity_points',
                     'realized_cycle_points'):
            if attr in data:
                setattr(e,attr,data[attr])
        e.candles = data.get('candles',[])
        e.trades = data.get('trades',[])
        if 'realized_cycle_points' not in data:
            e.realized_cycle_points=sum(t['pnl_points'] for t in e.trades)
        e.events = data.get('events',[])
        e.last_tick_signature = (e.latest.t_ms,e.latest.bid,e.latest.ask) if e.latest else None
        return e

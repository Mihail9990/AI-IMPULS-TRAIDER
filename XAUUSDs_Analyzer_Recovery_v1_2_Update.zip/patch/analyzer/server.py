"""Authenticated responsive control panel / REST API for paper simulation only."""
from __future__ import annotations

from contextlib import asynccontextmanager
from dataclasses import asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse
import os
import secrets
import time

from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, Response
import csv
import io
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .engine import Settings
from .live import AnalyzerService
from .telegram_control import TelegramControl

BASE=Path(__file__).resolve().parent.parent
security=HTTPBasic(auto_error=False)
service:AnalyzerService|None=None


def ensure_auth(credentials:HTTPBasicCredentials|None=Depends(security)):
    username=os.getenv('WEB_USERNAME','admin')
    password=os.getenv('WEB_PASSWORD','')
    if (not password or not credentials or
        not secrets.compare_digest(credentials.username.encode(),username.encode()) or
        not secrets.compare_digest(credentials.password.encode(),password.encode())):
        raise HTTPException(status_code=401,detail='Login required',headers={'WWW-Authenticate':'Basic realm="XAU Strategy Analyzer"'})
    return credentials.username


def same_origin(request:Request):
    origin=request.headers.get('origin')
    if origin and urlparse(origin).netloc.lower()!=request.headers.get('host','').lower():
        raise HTTPException(403,'Cross-origin request rejected')


def svc():
    if service is None:
        raise HTTPException(503,'Analyzer not started')
    return service


@asynccontextmanager
async def lifespan(app:FastAPI):
    global service
    if len(os.getenv('WEB_PASSWORD','')) < 16 or os.getenv('WEB_PASSWORD','').startswith('REPLACE_'):
        raise RuntimeError('Set a unique WEB_PASSWORD of at least 16 characters in .env')
    service=AnalyzerService(Path(os.getenv('DATA_DIR',str(BASE/'data'))))
    service.start_worker()
    tg=TelegramControl(service)
    tg.start()
    try:
        yield
    finally:
        service.shutdown()
        service=None


app=FastAPI(title='XAUUSD.s Strategy Analyzer',version='1.2.0',lifespan=lifespan,docs_url=None,redoc_url=None,openapi_url=None)
app.mount('/assets',StaticFiles(directory=BASE/'web'),name='web')


@app.get('/',response_class=HTMLResponse)
def index(_:str=Depends(ensure_auth)):
    return (BASE/'web'/'index.html').read_text(encoding='utf-8')


@app.get('/api/status')
def status(_:str=Depends(ensure_auth)):
    return svc().status()


@app.get('/api/chart')
def chart(_:str=Depends(ensure_auth)):
    return svc().chart()


class EditSettings(BaseModel):
    trigger_distance:float=Field(gt=0,le=100)
    tp_distance:float=Field(gt=0,le=100)
    sl_distance:float=Field(gt=0,le=100)
    volume_lots:float=Field(gt=0,le=100)
    commission_per_lot_roundtrip:float=Field(ge=0,le=10000,default=0.0)
    recovery_enabled:bool=False
    recovery_core_lots:float=Field(default=0.01,gt=0,le=100)
    recovery_reentry_lots:float=Field(default=0.12,gt=0,le=100)
    recovery_hedge_lots:float=Field(default=0.13,gt=0,le=100)
    recovery_partial_stop_distance:float=Field(default=1.0,gt=0,le=100)


@app.post('/api/settings')
def settings(payload:EditSettings,req:Request,_:str=Depends(ensure_auth)):
    same_origin(req)
    s=svc()
    details=s.details
    try:
        new=Settings(tick_size=details['tick_size'],
                     tick_value_per_lot=details['tick_value_per_lot'],
                     **payload.model_dump())
        s.update_settings(new)
        return dict(ok=True,settings=asdict(new))
    except ValueError as exc:
        raise HTTPException(409,str(exc)) from exc


@app.post('/api/control/{action}')
def control(action:Literal['start','stop','force_stop'],req:Request,_:str=Depends(ensure_auth)):
    same_origin(req)
    try:
        return svc().control(action)
    except ValueError as exc:
        raise HTTPException(409,str(exc)) from exc


class BacktestRequest(BaseModel):
    start_date:str
    end_date:str
    distances:list[float]=Field(min_length=1,max_length=300)
    tps:list[float]=Field(min_length=1,max_length=100)
    sls:list[float]=Field(min_length=1,max_length=100)
    volume_lots:float=Field(default=0.1,gt=0,le=100)
    commission_roundtrip:float=Field(default=0,ge=0,le=10000)
    recovery_enabled:bool=False
    recovery_stop_distances:list[float]=Field(default_factory=lambda:[1.0],min_length=1,max_length=200)


@app.post('/api/backtests')
def run_backtest(payload:BacktestRequest,req:Request,_:str=Depends(ensure_auth)):
    same_origin(req)
    try:
        start=datetime.strptime(payload.start_date,'%Y-%m-%d').replace(tzinfo=timezone.utc)
        end=datetime.strptime(payload.end_date,'%Y-%m-%d').replace(tzinfo=timezone.utc)+timedelta(days=1)
        now=datetime.now(timezone.utc)
        end=min(end,now)
        if start>=end:raise ValueError('Start date must precede end date and cannot be in the future')
        if (end-start).days>90:raise ValueError('Maximum 90 calendar days per run (VPS resource limit)')
        for ls in (payload.distances,payload.tps,payload.sls):
            if any((x<=0 or x>100) for x in ls):raise ValueError('Distances must be between 0 and 100')
        if (payload.recovery_enabled and any(x<=0 or x>100 for x in payload.recovery_stop_distances)):
            raise ValueError('RECOVERY partial stop distances must be between 0 and 100')
        if (payload.recovery_enabled and abs(payload.volume_lots-0.01)>1e-8):
            raise ValueError('RECOVERY initial volume must be 0.01 lot (core volume)')
        if (len(payload.distances)*len(payload.tps)*len(payload.sls)*
                (len(payload.recovery_stop_distances) if payload.recovery_enabled else 1))>2000:
            raise ValueError('Maximum 2000 combinations')
        s=svc()
        details=s.source.symbol_details()  # validates connection and exact broker symbol
        s.backtester.details=details
        run_id=s.backtester.submit(int(start.timestamp()*1000),int(end.timestamp()*1000)-1,
                                   payload.distances,payload.tps,payload.sls,
                                   payload.volume_lots,payload.commission_roundtrip,
                                   payload.recovery_enabled,payload.recovery_stop_distances)
        return dict(id=run_id,ok=True)
    except (ValueError,RuntimeError) as exc:
        raise HTTPException(400,str(exc)) from exc
    except Exception as exc:
        raise HTTPException(503,str(exc)) from exc


@app.get('/api/backtests')
def list_backtests(_:str=Depends(ensure_auth)):
    return svc().store.list_jobs()


@app.get('/api/backtests/{run_id}')
def get_backtest(run_id:str,_:str=Depends(ensure_auth)):
    job=svc().store.job(run_id)
    if job is None:raise HTTPException(404,'Unknown test')
    return job


@app.get('/api/backtests/{run_id}/variants')
def variants(run_id:str,_:str=Depends(ensure_auth)):
    if svc().store.job(run_id) is None:raise HTTPException(404,'Unknown test')
    return svc().store.variants(run_id)


@app.get('/api/backtests/{run_id}/export.csv')
def export_run(run_id:str,_:str=Depends(ensure_auth)):
    if svc().store.job(run_id) is None:
        raise HTTPException(404,'Unknown test')
    out=io.StringIO()
    writer=csv.writer(out)
    writer.writerow(['variant_id','recovery_enabled','trigger_distance','tp_distance','recovery_start_distance',
                     'partial_stop_distance','trades','tp','sl','recovered','aborted',
                     'completed_pct','train_equity_points','holdout_equity_delta_points',
                     'closed_cycle_points','final_equity_points','max_equity_drawdown_points',
                     'unresolved_recovery','recovery_partial_stops','sl_within_0.05_of_tp'])
    for row in svc().store.variants(run_id):
        cfg=row['config'];s=row['summary']
        writer.writerow([row['id'],cfg.get('recovery_enabled',False),cfg['trigger_distance'],
                         cfg['tp_distance'],cfg['sl_distance'],cfg.get('recovery_partial_stop_distance',1),
                         s['trades'],s['tp'],s['sl'],s.get('recovered',0),s.get('aborted',0),
                         s['win_rate'],s.get('train',{}).get('equity_points',''),
                         s.get('holdout',{}).get('equity_delta_points',''),s['pnl_points'],
                         s.get('equity_points'),s.get('max_equity_drawdown_points'),
                         s.get('unresolved_recovery',0),s.get('recovery_partial_stops',0),
                         s['near_tp_then_sl']['0.05']])
    return Response(content='\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',
                    headers={'Content-Disposition':f'attachment; filename="analyzer_{run_id}.csv"'})


@app.get('/api/variants/{variant_id}/export.csv')
def export_variant(variant_id:int,_:str=Depends(ensure_auth)):
    out=io.StringIO();writer=csv.writer(out)
    names=['id','side','result','opened_ms','closed_ms','entry','exit','tp','sl',
           'pnl_points','pnl_money_est','recovery_used','recovery_partial_stops',
           'recovery_reentries','recovery_max_loss_points','buy_anchor','sell_anchor',
           'mfe_points','mae_points','gap_to_tp','signal_body','signal_range',
           'spread_at_entry','duration_seconds']
    writer.writerow(names)
    offset=0
    while True:
        rows=svc().store.trades(variant_id,1000,offset)
        if not rows:break
        for tr in rows:writer.writerow([tr.get(k,'') for k in names])
        offset+=len(rows)
    return Response(content='\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',
                    headers={'Content-Disposition':f'attachment; filename="virtual_trades_{variant_id}.csv"'})


@app.get('/api/backtests/{run_id}/regimes')
def regimes(run_id:str,_:str=Depends(ensure_auth)):
    if svc().store.job(run_id) is None:
        raise HTTPException(404,'Unknown test')
    return svc().store.regimes(run_id)


@app.get('/api/variants/{variant_id}/trades')
def variant_trades(variant_id:int,limit:int=150,offset:int=0,_:str=Depends(ensure_auth)):
    if limit<1 or limit>1000 or offset<0:raise HTTPException(400,'Invalid limit / offset')
    return svc().store.trades(variant_id,limit,offset)


@app.get('/api/variants/{variant_id}/insights')
def variant_insights(variant_id:int,_:str=Depends(ensure_auth)):
    return svc().store.group_trade_stats(variant_id)


@app.get('/api/replay/{trade_db_id}')
def replay(trade_db_id:int,_:str=Depends(ensure_auth)):
    s=svc()
    trade=s.store.trade(trade_db_id)
    if trade is None:raise HTTPException(404,'Trade not found')
    job=s.store.job(trade['backtest_id'])
    if job is None or job['source']!=s.data_source:
        raise HTTPException(409,'Source mismatch: replay unavailable')
    # Replays are deliberately bounded: an excessively long trade cannot exhaust VPS RAM.
    start=max(job['start_ms'],min(trade['signal_time']*1000-60000,trade['opened_ms']-120000))
    end=min(job['end_ms'],trade['closed_ms']+30000,start+30*60000)
    ticks=[]
    for tk in s.archive.iter_range(start,end):
        ticks.append(tk)
        if len(ticks)>=6500:break
    if not ticks:raise HTTPException(404,'Cached ticks unavailable for replay')
    bars={}
    for tk in ticks:
        minute=(tk.t_ms//60000)*60
        c=bars.get(minute)
        if c is None:
            bars[minute]=dict(time=minute,open=tk.bid,high=tk.bid,low=tk.bid,close=tk.bid)
        else:
            c['high']=max(c['high'],tk.bid);c['low']=min(c['low'],tk.bid);c['close']=tk.bid
    return dict(trade=trade, ticks=[dict(t_ms=t.t_ms,bid=t.bid,ask=t.ask) for t in ticks],
                candles=list(bars.values()),
                truncated=bool(ticks[-1].t_ms < trade['closed_ms']),
                source=s.data_source)

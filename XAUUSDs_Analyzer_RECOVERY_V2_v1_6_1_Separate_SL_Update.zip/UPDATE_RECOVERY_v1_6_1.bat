@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_RECOVERY_v1_6_1.ps1"
if errorlevel 1 (echo Update FAILED. Check messages above.) else (echo Update finished.)
pause

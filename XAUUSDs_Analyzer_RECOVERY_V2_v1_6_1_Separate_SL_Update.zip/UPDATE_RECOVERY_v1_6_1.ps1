﻿param([string]$TargetDirectory='')
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$files=@(
  'analyzer\engine.py',
  'analyzer\backtest.py',
  'analyzer\live.py',
  'analyzer\server.py',
  'web\app.js',
  'web\index.html',
  'web\terminal.css',
  'tests\test_recovery.py',
  'tests\test_reset_statistics_v141.py',
  'tests\test_recovery_v2_v160.py',
  'tests\test_recovery_v2_api_v160.py',
  'tests\test_recovery_v2_separate_sl_v161.py',
  'tools\precheck_v160.py'
)
function Main {
  Write-Host 'XAUUSD.s Strategy Analyzer v1.6.1 - two RECOVERY variants' -ForegroundColor Cyan
  Write-Host 'PAPER ONLY. MT5, Caddy/HTTPS, .env, stats, cache and SQLite will NOT be changed.'
  $manifest=Join-Path $here 'SHA256SUMS.txt'
  if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)){throw 'Missing manifest'}
  $hashes=@{}
  foreach($line in (Get-Content -LiteralPath $manifest)) {
    if($line -match '^([0-9a-fA-F]{64})\s{2}(.+)$') { $hashes[$matches[2]]=$matches[1].ToLowerInvariant() }
  }
  foreach($rel in $files) {
    $key='patch/'+($rel -replace '\\','/')
    $src=Join-Path (Join-Path $here 'patch') $rel
    if(-not(Test-Path -LiteralPath $src -PathType Leaf)){throw ('Missing '+$key)}
    if(-not $hashes.ContainsKey($key)){throw ('Missing checksum '+$key)}
    if((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hashes[$key]){throw ('Checksum mismatch: '+$key)}
  }
  Write-Host '[OK] SHA-256 checksums verified.' -ForegroundColor Green
  if(-not $TargetDirectory){
    Add-Type -AssemblyName System.Windows.Forms
    $picker=New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description='Select installed analyzer folder (v1.5.0 or v1.6.0) with start_windows.bat'
    $picker.ShowNewFolderButton=$false
    if($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {Write-Host 'Cancelled; nothing changed.';return}
    $TargetDirectory=$picker.SelectedPath
  }
  $target=[System.IO.Path]::GetFullPath($TargetDirectory)
  foreach($rel in @('start_windows.bat','.env','analyzer\engine.py','analyzer\live.py','analyzer\server.py','web\app.js','web\index.html')) {
    if(-not (Test-Path -LiteralPath (Join-Path $target $rel) -PathType Leaf)){throw ('Wrong installed folder. Missing: '+$rel)}
  }
  $engine=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\engine.py'))
  $live=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\live.py'))
  $server=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\server.py'))
  if(-not ($engine.Contains('strategy_manual_open') -and $live.Contains('def paper_manual_open') -and $server.Contains('/api/virtual/strategy/open'))) {
    throw 'v1.5.0 is required. Install v1.5.0 first. No files changed.'
  }
  $envFile=[System.IO.File]::ReadAllText((Join-Path $target '.env'))
  $port=8765
  $m=[regex]::Match($envFile,'(?m)^\s*WEB_PORT\s*=\s*(\d+)')
  if($m.Success){$port=[int]$m.Groups[1].Value}
  if(Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue){
    if(@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue).Count -gt 0){
      throw ('Port '+$port+' is active. Close start_windows.bat before update. Nothing changed.')
    }
  }
  $python=Join-Path $target '.venv\Scripts\python.exe'
  if(-not(Test-Path -LiteralPath $python -PathType Leaf)){
    $candidate=Get-Command py -ErrorAction SilentlyContinue
    if(-not $candidate){throw 'Python or .venv not found for read-only preflight'}
    $python=$candidate.Source
  }
  $preflight=Join-Path (Join-Path $here 'patch') 'tools\precheck_v160.py'
  if($python -match '\\py.exe$') { & $python -3.13 $preflight --target $target }
  else { & $python $preflight --target $target }
  if($LASTEXITCODE -ne 0){throw 'Active virtual cycle or database check failed; no files changed.'}
  $backup=Join-Path $target ('backup_v1_6_1_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
  New-Item -ItemType Directory -Path $backup -Force | Out-Null
  $existed=@{}
  try {
    foreach($rel in $files){
      $dest=Join-Path $target $rel
      $existed[$rel]=Test-Path -LiteralPath $dest -PathType Leaf
      if($existed[$rel]){
        $b=Join-Path $backup $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $b) -Force|Out-Null
        Copy-Item -LiteralPath $dest -Destination $b -Force
      }
    }
    foreach($rel in $files){
      $src=Join-Path (Join-Path $here 'patch') $rel
      $dest=Join-Path $target $rel
      New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
      Copy-Item -LiteralPath $src -Destination $dest -Force
      Write-Host ('Patched '+$rel)
    }
  } catch {
    Write-Host 'Copy failed; rolling back source files...' -ForegroundColor Yellow
    foreach($rel in $files){
      $dest=Join-Path $target $rel
      $b=Join-Path $backup $rel
      if(Test-Path -LiteralPath $b -PathType Leaf){Copy-Item -LiteralPath $b -Destination $dest -Force}
      elseif($existed.ContainsKey($rel) -and (-not $existed[$rel]) -and (Test-Path -LiteralPath $dest -PathType Leaf)){Remove-Item -LiteralPath $dest -Force}
    }
    throw
  }
  Write-Host '[OK] RECOVERY V2 v1.6.1 (separate SL distances) installed; previous trades and settings preserved.' -ForegroundColor Green
  Write-Host ('Source backup: '+$backup)
  Write-Host 'Start start_windows.bat, refresh Android HTTPS page (close browser tab if cache persists).'
}
try{Main}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red; exit 1}

"""Tick-deterministic RECOVERY v1.3: initial SL, 0.12 independent trading,
step trailing, partial TPs, opposite OCO STOP re-entry. Zero broker trade calls.
"""
import pytest
from analyzer.engine import PaperEngine, Settings, Tick


def tk(m,s,b,spread=.23):
    return Tick((m*60+s)*1000,round(b,5),round(b+spread,5))


def initial_buy(commission=0,spread=.23):
    e=PaperEngine(Settings(volume_lots=.01,recovery_enabled=True,tick_size=.01,
                           tick_value_per_lot=1,commission_per_lot_roundtrip=commission,
                           recovery_opposite_max_range=100))
    e.start()
    for x in (tk(0,0,3998.50,spread),tk(0,50,3999,spread),
              tk(1,0,3999.05,spread),tk(1,1,3999.77,spread)):
        e.on_tick(x)
    assert e.position and e.position.entry==4000
    return e


def started():
    e=initial_buy()
    e.on_tick(tk(1,2,3997))
    assert e.recovery and e.position is None
    return e


def active():
    e=started()
    e.on_tick(tk(1,3,3996.80))
    assert e.recovery.active
    assert e.recovery.active.role=='fixed_tp'
    assert e.recovery.active.tp==3996.55
    assert e.recovery.active.stop==3999.8
    return e


def stepped_active():
    e=active()
    # First 0.12 must actually hit its SL before partial TPs / trailing exist.
    e.on_tick(tk(1,4,3999.57))  # SELL liquidation by Ask=3999.80
    assert e.recovery and e.recovery.active is None
    assert e.recovery.stepped_mode and e.recovery.recovery_sls==1
    assert e.recovery.sell_anchor == pytest.approx(3995.80)  # last fill 3996.80 minus 1
    e.on_tick(tk(1,5,3995.80))  # New SELL STOP beyond previous 0.12 entry
    assert e.recovery.active and e.recovery.active.role=='stepped'
    assert e.recovery.active.entry == pytest.approx(3995.80)
    return e


def test_original_tp_then_new_m1_cycle():
    e=initial_buy()
    e.on_tick(tk(1,2,4000.25))
    assert e.recovery is None and e.summary()['tp']==1
    e.on_tick(tk(1,45,4000.5));e.on_tick(tk(2,0,4000.49))
    assert e.pending and e.pending.side=='BUY'


def test_initial_sl_is_closed_and_loss_is_realized():
    e=started();r=e.recovery
    assert r.active is None and e.position is None
    assert r.original_sl_exit==3997
    assert r.realized_weighted_points==pytest.approx(-.03)
    assert r.pending_stops==[dict(side='SELL',level=3997,lots=.12,armed=True)]
    assert e.summary()['unresolved_recovery']==1
    assert e.summary()['equity_points']==pytest.approx(-3)
    assert not e.trades  # completed cycle not yet known


def test_first_recovery_stop_cannot_fill_same_tick_as_initial_sl():
    e=started()
    assert e.recovery.active is None
    e.on_tick(tk(1,3,3996.80))
    assert e.recovery.active.side=='SELL'
    assert e.recovery.active.entry==3996.8
    assert e.recovery.active.lots==.12
    assert e.recovery.active.stop==3999.8


def test_v134_support_sl_starts_immediately_and_moves_every_point10_sell():
    e=stepped_active()
    e.recovery.realized_weighted_points=-.55  # keep this RECOVERY open
    p=e.recovery.active
    assert p.stop==pytest.approx(3996.80)  # entry 3995.80 plus 1.00; no +0.50 gate
    assert p.trail_step_index==0
    e.on_tick(tk(1,6,3995.48))  # SELL Ask 3995.71: profit +0.09
    assert p.trail_step_index==0 and p.stop==pytest.approx(3996.80)
    e.on_tick(tk(1,7,3995.47))  # SELL Ask 3995.70: profit +0.10
    assert p.trail_step_index==1 and p.stop==pytest.approx(3996.70)
    e.on_tick(tk(1,8,3995.42))  # +0.15, still one step
    assert p.stop==pytest.approx(3996.70)
    e.on_tick(tk(1,9,3995.37))  # +0.20, step two
    assert p.trail_step_index==2 and p.stop==pytest.approx(3996.60)
    e.on_tick(tk(1,10,3995.57))  # adverse move, do not loosen SL
    assert p.stop==pytest.approx(3996.60)


def test_partials_at_one_two_three_and_last_runner():
    e=stepped_active();e.recovery.realized_weighted_points=-.60
    p=e.recovery.active
    for i,(bid,remaining) in enumerate(((3994.57,.09),(3993.57,.06),(3992.57,.03)),6):
        e.on_tick(tk(1,i,bid))
        assert e.recovery is not None
        assert p.lots==pytest.approx(remaining)
        assert e.recovery.partial_tps==i-5
    assert p.stop<3999.8 and p.trail_step_index>=0
    e.on_tick(tk(1,9,3993.7))  # ASK = 3994.93 crosses trail stop ~3994.8
    assert e.recovery is not None and e.recovery.active is None
    assert e.recovery.recovery_sls==2  # first 0.12 SL + subsequent trailing SL
    assert len(e.recovery.pending_stops)==2
    assert e.recovery.realized_weighted_points<0


def test_first_recovery_tp_ends_cycle_even_if_net_negative():
    e=active()
    e.on_tick(tk(1,4,3996.32))  # ASK 3996.55, exactly fixed TP
    assert e.recovery is None and e.position is None
    assert e.trades[-1]['result']=='RECOVERY_TP'
    assert e.trades[-1]['pnl_money_est']==pytest.approx(0)
    assert e.summary()['recovery_tp_cycles']==1
    assert e.summary()['recovered']==0
    e.on_tick(tk(1,40,3996));e.on_tick(tk(2,0,3995.9))
    assert e.pending and e.pending.side=='SELL'


def test_first_recovery_tp_with_commission_leaves_loss_in_global_pnl():
    e=initial_buy(commission=1)
    e.on_tick(tk(1,2,3997))
    e.on_tick(tk(1,3,3996.8))
    e.on_tick(tk(1,4,3996.32))
    t=e.trades[-1]
    assert t['result']=='RECOVERY_TP'
    assert t['pnl_money_est']==pytest.approx(-0.13)
    assert t['unrecovered_loss_money_est']==pytest.approx(-0.13)
    assert e.summary()['pnl_money_est']==pytest.approx(-0.13)
    assert e.summary()['recovery_tp_loss_cycles']==1
    assert e.summary()['unresolved_recovery']==0
    assert e.summary()['win_rate']==0
    # A new NORMAL cycle resumes; the earlier loss is not a RECOVERY debt.
    e.on_tick(tk(1,40,3996));e.on_tick(tk(2,0,3995.9))
    assert e.pending and e.recovery is None


def test_first_recovery_tp_with_slippage_deficit_subtracts_from_total():
    e=initial_buy()
    e.on_tick(tk(1,2,3994))  # Initial SL 3997, market gap fills 3994 -> -6
    e.on_tick(tk(1,3,3993.9))  # SELL 0.12 opens on next tick
    assert e.recovery.active and e.recovery.active.role=='fixed_tp'
    e.on_tick(tk(1,4,3993.42))  # Ask 3993.65 = SELL TP
    t=e.trades[-1]
    assert t['result']=='RECOVERY_TP'
    assert t['pnl_money_est']==pytest.approx(-3)
    assert e.summary()['pnl_money_est']==pytest.approx(-3)
    assert e.summary()['recovery_tp_loss_cycles']==1
    assert e.recovery is None
    # Follow-up successful base trade adds to global balance, not RECOVERY debt.
    e.on_tick(tk(1,40,3993.8));e.on_tick(tk(2,0,3993.9))
    assert e.pending and e.pending.side=='SELL'
    e.on_tick(tk(2,1,3992.70))  # Bid crosses SELL STOP
    assert e.position and e.position.side=='SELL'
    e.on_tick(tk(2,2,e.position.tp-.23))  # Ask reaches fixed SELL TP
    assert e.trades[-1]['result']=='TP'
    assert e.summary()['pnl_money_est']==pytest.approx(-2.75)


def test_no_stepped_tp_before_first_012_sl():
    e=active()
    leg=e.recovery.active
    e.on_tick(tk(1,4,3996.70))  # Ask=3996.93, not yet TP
    assert leg.role=='fixed_tp' and leg.trail_step_index==-1
    assert e.recovery.partial_tps==0
    assert e.recovery.stepped_mode is False
    # SL transitions to a new stepped entry, not to a trailing-first position.
    e.on_tick(tk(1,5,3999.57))
    assert e.recovery.stepped_mode is True
    assert e.recovery.active is None
    assert len(e.recovery.pending_stops)==2


def test_dynamic_sl_adds_loss_and_two_stop_rearm():
    e=stepped_active();e.recovery.realized_weighted_points=-.55
    e.on_tick(tk(1,6,3994.57)) # TP #1
    e.on_tick(tk(1,7,3995.90)) # ask 3997.13 crosses trail near 3996.8
    r=e.recovery
    assert r and r.active is None
    assert r.recovery_sls==2 and r.partial_tps==1
    assert {x['side'] for x in r.pending_stops}=={'BUY','SELL'}
    # Triggering one cancels the other (after valid-side rearming).
    # First re-arm BUY below anchor 4000, then cross BUY at ASK=4000.
    e.on_tick(tk(1,8,3999.77))
    assert r.active and r.active.side=='BUY'
    assert r.pending_stops==[]


def test_force_stop_accounts_unrealized_and_keeps_loss():
    e=active();e.request_stop()
    assert e.mode=='stopping'
    e.force_stop()
    assert e.mode=='stopped' and e.recovery is None
    assert e.trades[-1]['result']=='ABORTED' and e.trades[-1]['pnl_points']<0


def test_snapshot_mid_trailing_equals_continuous():
    e=stepped_active();e.recovery.realized_weighted_points=-.50
    e.on_tick(tk(1,6,3994.57))
    b=PaperEngine.from_snapshot(e.to_snapshot())
    for x in (tk(1,7,3993.57),tk(1,8,3992.57),tk(1,9,3994.70)):
        e.on_tick(x);b.on_tick(x)
    assert e.summary()==b.summary()
    assert e.trades==b.trades


def test_wide_spread_gap_affects_real_loss():
    e=initial_buy()
    e.on_tick(tk(1,2,3994))  # jumped 3 extra points beyond SL
    assert e.recovery.original_sl_exit==3994
    assert e.recovery.realized_weighted_points==pytest.approx(-.06)


def test_commission_and_unknown_value():
    e=initial_buy(commission=1)
    e.on_tick(tk(1,2,3997))
    assert e.summary()['open_recovery']['net_money_est']==pytest.approx(-3.01)
    other=PaperEngine(Settings(recovery_enabled=True,volume_lots=.01,tick_value_per_lot=0))
    other.start()
    for x in (tk(0,0,3998.5),tk(0,50,3999),tk(1,0,3999.05),tk(1,1,3999.77),tk(1,2,3997)):
        other.on_tick(x)
    assert other.summary()['open_recovery']['net_money_est'] is None
    with pytest.raises(ValueError,match='tick_value'):
        Settings(recovery_enabled=True,volume_lots=.01,commission_per_lot_roundtrip=1)


def test_recovery_settings_reject_volume_and_partial():
    with pytest.raises(ValueError,match='initial'):
        Settings(recovery_enabled=True,volume_lots=.1)
    with pytest.raises(ValueError,match='runner'):
        Settings(recovery_enabled=True,volume_lots=.01,recovery_partial_lots=.04)


def test_stopping_while_oco_pending_does_not_abandon_recovery():
    e=started();e.request_stop()
    assert e.mode=='stopping'

# RECOVERY v1.3.2: next same-side entry must depend on WHICH SL closed 0.12.

def test_v132_fixed_first_sl_requires_one_price_point_beyond_actual_sell_entry():
    e=active()
    entry=e.recovery.active.entry  # SELL 3996.80
    e.on_tick(tk(1,4,3999.57))  # ASK crosses SELL initial SL3
    r=e.recovery
    assert r and r.stepped_mode and r.active is None
    assert r.sell_anchor==pytest.approx(entry-1.0)
    assert r.buy_anchor==pytest.approx(4000.0)  # opposite side unchanged
    assert {p['side']:p['level'] for p in r.pending_stops}==pytest.approx(
        {'SELL':entry-1,'BUY':4000})
    assert r.actions[-2]['type']=='recovery_stepped_activated'
    assert any(a['type']=='recovery_reentry_anchor' and a['reason']=='opposite_side_sl'
               and a['price']==pytest.approx(entry-1) for a in r.actions)
    e.on_tick(tk(1,5,entry-.5))  # above SELL STOP: no premature fill
    assert r.active is None
    e.on_tick(tk(1,6,entry-1.0))
    assert r.active and r.active.side=='SELL' and r.active.entry==pytest.approx(entry-1)
    assert r.pending_stops==[]  # OCO cancellation


def test_v134_stepped_sell_support_immediate_even_before_point50():
    e=stepped_active();r=e.recovery
    entry=r.active.entry  # 3995.80
    e.on_tick(tk(1,6,entry-.4))  # +0.17 net; support SL already active
    assert r.active.trail_step_index==1
    e.on_tick(tk(1,7,entry+3-.23))  # wide gap above support SL; adverse real quote
    assert r.active is None
    assert r.sell_anchor==pytest.approx(entry-1.4)  # best bid was entry-.4, then -1
    assert r.buy_anchor==pytest.approx(4000)
    assert {p['side'] for p in r.pending_stops}=={'BUY','SELL'}
    assert [a for a in r.actions if a['type']=='recovery_reentry_anchor'][-1]['reason']=='support_trailing_sl'


def test_v134_stepped_buy_immediate_support_and_extreme_plus_one():
    e=stepped_active();r=e.recovery
    # The stepped SELL already has a protective SL=entry+1.
    e.on_tick(tk(1,6,3998.57))  # SELL exits at ASK 3998.80 on gap
    assert r.active is None
    e.on_tick(tk(1,7,3999.77))  # ASK=4000.00, BUY STOP fills
    assert r.active and r.active.side=='BUY' and r.active.entry==pytest.approx(4000)
    assert r.active.stop==pytest.approx(3999.00)
    assert r.active.trail_step_index==0
    e.on_tick(tk(1,8,4000.42))  # Bid +.42, four 0.1 support steps
    assert r.active.trail_step_index==4
    assert r.active.stop==pytest.approx(3999.40)
    e.on_tick(tk(1,9,3996.97))  # gap through BUY support SL
    assert r.active is None
    assert r.buy_anchor==pytest.approx(4001.65) # best Ask 4000.65 plus 1
    assert r.sell_anchor==pytest.approx(3994.80)
    assert {p['side'] for p in r.pending_stops}=={'BUY','SELL'}


def test_v133_trailing_sell_reentry_one_full_point_below_observed_low():
    e=stepped_active();r=e.recovery
    entry=r.active.entry
    e.on_tick(tk(1,6,entry-.85))  # SELL close quote ask, gain .62 => trailing active
    assert r.active.trail_step_index>=0
    observed_low=r.active.best_trigger_quote
    assert observed_low==pytest.approx(entry-.85)
    e.on_tick(tk(1,7,entry+.30))  # Ask above trailing stop, below SL3
    assert r.active is None
    assert r.sell_anchor==pytest.approx(observed_low-1.0)  # >= 1 beyond reached low
    assert r.buy_anchor==pytest.approx(4000)  # opposite STOP stays
    reason=[a for a in r.actions if a['type']=='recovery_reentry_anchor'][-1]['reason']
    assert reason=='support_trailing_sl'
    assert {p['side']:p['level'] for p in r.pending_stops}==pytest.approx(
        {'BUY':4000,'SELL':round(observed_low-1.0,2)})
    # Touching old low is NOT enough: need another full price point down.
    e.on_tick(tk(1,8,observed_low))
    assert r.active is None
    e.on_tick(tk(1,9,round(observed_low-1.0,2)))
    assert r.active and r.active.side=='SELL'
    assert r.pending_stops==[]


def test_v133_trailing_buy_reentry_one_full_point_above_observed_high():
    e=stepped_active();r=e.recovery
    e.on_tick(tk(1,6,3998.57))  # SL3 SELL -> next BUY
    e.on_tick(tk(1,7,3999.77))  # Ask 4000, buy fill
    assert r.active and r.active.side=='BUY'
    e.on_tick(tk(1,8,4000.58))  # Bid +.58; Ask 4000.81 = max observed
    assert r.active.trail_step_index>=0
    observed_high=r.active.best_trigger_quote
    assert observed_high==pytest.approx(4000.81)
    e.on_tick(tk(1,9,3999.48))  # Bid below trailing SL
    assert r.active is None
    assert r.buy_anchor==pytest.approx(observed_high+1.0)  # >= 1 beyond reached high
    assert r.sell_anchor==pytest.approx(3994.8)
    assert {p['side'] for p in r.pending_stops}=={'BUY','SELL'}
    assert [a for a in r.actions if a['type']=='recovery_reentry_anchor'][-1]['reason']=='support_trailing_sl'
    # Old high is not a valid new breakout; BUY must reach high + 1.
    e.on_tick(tk(1,10,round(observed_high-.23,2)))
    assert r.active is None
    e.on_tick(tk(1,11,round(observed_high+1-.23,2)))
    assert r.active and r.active.side=='BUY'
    assert r.pending_stops==[]


def test_v132_opposite_sl_uses_more_distant_peak_when_beyond_one():
    e=stepped_active();r=e.recovery
    p=r.active
    # Isolated extreme-selection branch: normally a +1 favorable move would
    # already activate trailing, but a restored/migrated leg may hold this high.
    p.best_trigger_quote=p.entry-1.75
    e._recovery_advance_reentry(tk(1,6,p.entry+.5),p,trailing_stop=False)
    assert r.sell_anchor==pytest.approx(p.entry-1.75)
    assert r.buy_anchor==pytest.approx(4000)


def test_v132_best_trigger_quote_persists_between_process_restarts():
    e=stepped_active();r=e.recovery
    e.on_tick(tk(1,6,3995.35))  # no trailing yet; best SELL BID updated
    assert r.active.best_trigger_quote==pytest.approx(3995.35)
    resumed=PaperEngine.from_snapshot(e.to_snapshot())
    assert resumed.recovery.active.best_trigger_quote==pytest.approx(3995.35)
    for item in [tk(1,7,3994.95),tk(1,8,3996.5)]:
        e.on_tick(item);resumed.on_tick(item)
    assert resumed.summary()==e.summary()
    assert resumed.public_state()['recovery']==e.public_state()['recovery']


def test_v132_spread_jump_on_sl_does_not_fabricate_favorable_peak():
    e=stepped_active();r=e.recovery
    entry=r.active.entry
    # SELL ASK reaches SL even though an abnormal spread makes BID appear
    # far below the entry.  The stop-tick BID must not become a reentry low.
    e.on_tick(tk(1,6,entry-2.00,spread=5.01))  # ASK=entry+3.01
    assert r.active is None
    assert r.sell_anchor==pytest.approx(entry-1)
    assert r.buy_anchor==pytest.approx(4000)

# RECOVERY v1.3.3: support/trailing SL must require at least 1 price point
# BEYOND the best executable trigger quote observed during that leg.

def test_v133_sell_support_extreme_farther_than_one_point():
    e=stepped_active();r=e.recovery
    r.realized_weighted_points=-.80  # avoid ending on a transient basket net
    entry=r.active.entry
    e.on_tick(tk(1,6,entry-2.50))  # SELL Bid low; 2 partial TPs
    peak=r.active.best_trigger_quote
    assert peak==pytest.approx(entry-2.50)
    assert r.active.trail_step_index>=0
    e.on_tick(tk(1,7,entry+.3))  # SELL liquidated on Ask at support SL
    assert r.active is None
    assert r.sell_anchor==pytest.approx(peak-1.0)
    assert r.buy_anchor==pytest.approx(4000)
    assert {o['side']:o['level'] for o in r.pending_stops}==pytest.approx(
        {'BUY':4000,'SELL':round(peak-1,2)})
    e.on_tick(tk(1,8,peak))
    assert r.active is None  # old extreme alone cannot trigger new entry
    e.on_tick(tk(1,9,round(peak-1,2)))
    assert r.active is not None and r.active.side=='SELL'
    assert r.pending_stops==[]


def test_v133_buy_support_extreme_farther_than_one_point():
    e=stepped_active();r=e.recovery
    e.on_tick(tk(1,6,3998.57))  # close SELL at original SL
    e.on_tick(tk(1,7,3999.77))  # BUY at Ask 4000
    assert r.active and r.active.side=='BUY'
    r.realized_weighted_points=-.80
    e.on_tick(tk(1,8,4002.40))  # BUY Bid high, Ask high 4002.63
    observed=r.active.best_trigger_quote
    assert observed==pytest.approx(4002.63)
    assert r.active.trail_step_index>=0
    e.on_tick(tk(1,9,3999.48))  # support SL closes BUY
    assert r.active is None
    assert r.buy_anchor==pytest.approx(4003.63)
    assert r.sell_anchor==pytest.approx(3994.80)
    e.on_tick(tk(1,10,observed-.23))  # old high still 1 point short
    assert r.active is None
    e.on_tick(tk(1,11,observed+1-.23))
    assert r.active and r.active.side=='BUY'
    assert r.pending_stops==[]


def test_v133_support_sl_never_reduces_more_distant_anchor():
    e=stepped_active();r=e.recovery
    e.on_tick(tk(1,6,3994.95))  # trailing on, SELL best bid 3994.95
    assert r.active and r.active.trail_step_index>=0
    r.sell_anchor=3993.0  # previous cycle had a more distant STOP
    e.on_tick(tk(1,7,3996.12))
    assert r.active is None
    assert r.sell_anchor==pytest.approx(3993.0)
    assert {x['side']:x['level'] for x in r.pending_stops}['SELL']==pytest.approx(3993.0)


def test_v133_support_sl_uses_outward_tick_grid_rounding():
    from dataclasses import replace
    e=stepped_active();r=e.recovery
    e.settings=replace(e.settings,tick_size=.05)
    p=r.active
    p.best_trigger_quote=3995.33
    e._recovery_advance_reentry(tk(1,6,3996),p,trailing_stop=True)
    assert r.sell_anchor==pytest.approx(3994.30)  # >=1.0 below 3995.33
    assert r.buy_anchor==pytest.approx(4000)
    e.settings=replace(e.settings,tick_size=.01)
    p=r.active
    p.side='BUY';p.entry=4000;p.best_trigger_quote=4000.81
    e.settings=replace(e.settings,tick_size=.05)
    e._recovery_advance_reentry(tk(1,7,4000),p,trailing_stop=True)
    assert r.buy_anchor==pytest.approx(4001.85)  # >=1.0 above 4000.81


def test_v133_support_sl_wide_spread_does_not_make_fake_low():
    e=stepped_active();r=e.recovery
    entry=r.active.entry
    e.on_tick(tk(1,6,entry-.85))  # activate SELL trailing
    prior_low=r.active.best_trigger_quote
    # Huge spread blows ASK through stop while BID appears at a new low.
    e.on_tick(tk(1,7,entry-3.0,spread=4.0))
    assert r.active is None
    assert r.sell_anchor==pytest.approx(prior_low-1.0)
    assert r.buy_anchor==pytest.approx(4000)


def test_v133_pending_reentry_survives_restart_with_new_support_offset():
    e=stepped_active();r=e.recovery
    entry=r.active.entry
    e.on_tick(tk(1,6,entry-.85))
    extreme=r.active.best_trigger_quote
    e.on_tick(tk(1,7,entry+.3))
    b=PaperEngine.from_snapshot(e.to_snapshot())
    assert b.recovery.sell_anchor==pytest.approx(extreme-1)
    assert b.recovery.pending_stops==e.recovery.pending_stops
    for item in [tk(1,8,extreme),tk(1,9,round(extreme-1,2))]:
        e.on_tick(item);b.on_tick(item)
    assert e.summary()==b.summary()
    assert e.public_state()['recovery']==b.public_state()['recovery']


# RECOVERY v1.3.4 - immediate support SL (no +0.50 gate), trailing by 0.10.

def test_v134_stepped_buy_step_at_point10_and_persistent():
    e=stepped_active();r=e.recovery
    r.realized_weighted_points=-.90
    e.on_tick(tk(1,6,3998.57))  # close SELL, BUY at 4000 is opposing trigger
    e.on_tick(tk(1,7,3999.77))
    p=r.active
    assert p and p.side=='BUY' and p.stop==pytest.approx(3999.0)
    e.on_tick(tk(1,8,4000.09))
    assert p.trail_step_index==0 and p.stop==pytest.approx(3999.0)
    e.on_tick(tk(1,9,4000.10))
    assert p.trail_step_index==1 and p.stop==pytest.approx(3999.10)
    e.on_tick(tk(1,10,4000.19))
    assert p.trail_step_index==1
    e.on_tick(tk(1,11,4000.20))
    assert p.trail_step_index==2 and p.stop==pytest.approx(3999.2)
    restored=PaperEngine.from_snapshot(e.to_snapshot())
    assert restored.recovery.active.stop==p.stop
    assert restored.recovery.active.trail_step_index==2


def test_v134_old_saved_snapshot_defaults_are_migrated_without_data_loss():
    e=stepped_active()
    e.on_tick(tk(1,6,3995.47))
    old=e.to_snapshot()
    old.pop('support_sl_rules_version')
    old['settings']['recovery_trail_activation']=0.50
    old['settings']['recovery_trail_start_offset']=0.50
    assert len(old['events'])>0
    # Migration is safe for idle snapshots; installer separately blocks active RECOVERY.
    old['recovery']=None
    e2=PaperEngine.from_snapshot(old)
    assert e2.settings.recovery_trail_activation==0
    assert e2.settings.recovery_trail_start_offset==1.0
    assert e2.trades==e.trades and e2.events==e.events
    assert e2.to_snapshot()['support_sl_rules_version']==134
    e3=PaperEngine.from_snapshot(e2.to_snapshot())
    assert e3.settings.recovery_trail_start_offset==1.0


def test_v134_fixed_first_recovery_keeps_sl3_tp025_until_first_sl():
    e=active()
    p=e.recovery.active
    assert p.stop==pytest.approx(p.entry+3.0)
    assert p.tp==pytest.approx(p.entry-.25)
    assert p.trail_step_index==-1
    e.on_tick(tk(1,4,3999.57))
    assert e.recovery.active is None and e.recovery.stepped_mode is True


def test_v134_support_stop_hit_before_any_favorable_movement():
    e=stepped_active();r=e.recovery
    p=r.active
    assert p.stop==pytest.approx(p.entry+1.00)
    # Direct adverse move below previous threshold; should hit support anyway.
    e.on_tick(tk(1,6,p.entry+.77))  # bid+0.23 = entry+1.00 (exact stop)
    assert r.active is None
    assert r.sell_anchor==pytest.approx(p.entry-1.00)
    assert [x for x in r.actions if x['type']=='recovery_reentry_anchor'][-1]['reason']=='support_trailing_sl'

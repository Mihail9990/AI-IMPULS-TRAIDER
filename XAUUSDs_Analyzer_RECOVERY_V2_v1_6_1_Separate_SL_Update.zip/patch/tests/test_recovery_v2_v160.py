"""RECOVERY V2: tests against synthetic ticks, never sends a broker order."""
import math
from dataclasses import replace
import pytest
from analyzer.engine import PaperEngine, Settings, Tick


def q(m,s,bid,spread=.23):
    return Tick((m*60+s)*1000,round(bid,8),round(bid+spread,8))


def new(**changes):
    opts=dict(recovery_enabled=True,recovery_variant='extreme',volume_lots=.03,
              tick_size=.01,recovery_v2_initial_lots=.03,recovery_v2_work_lots=.03)
    opts.update(changes)
    return PaperEngine(Settings(**opts))


def first_buy(**settings):
    e=new(**settings)
    e.on_tick(q(0,0,3999.5));e.start()
    e.on_tick(q(0,50,4000));e.on_tick(q(1,0,4000))
    assert e.pending and e.pending.side=='BUY' and e.pending.level==pytest.approx(4001)
    e.on_tick(q(1,1,4000.77))
    assert e.position and e.position.side=='BUY'
    return e


def first_recovery_sell(**settings):
    e=first_buy(**settings)
    e.on_tick(q(1,2,3999.99))
    assert e.recovery and len(e.recovery.pending_stops)==1
    e.on_tick(q(1,3,3999.80))
    r=e.recovery
    assert r.active and r.active.side=='SELL' and r.active.role=='extreme'
    return e


def after_support_sell(**settings):
    e=first_recovery_sell(**settings)
    e.on_tick(q(1,4,3999.3))  # moves SELL SL from 4000.8 down to 4000.6
    e.on_tick(q(1,5,4000.50))  # ASK 4000.73 hits support SL
    assert e.recovery and e.recovery.active is None
    return e


def test_v2_initial_trigger_tracks_closed_candle_and_uses_own_distances():
    e=first_buy(recovery_v2_initial_tp_distance=.31,recovery_v2_initial_sl_distance=1.20)
    assert e.position.lots==pytest.approx(.03)
    assert e.position.tp==pytest.approx(4001.31)
    assert e.position.sl==pytest.approx(3999.80)
    assert e.pending is None


def test_v2_disabled_keeps_old_strategy_and_volume_free():
    s=Settings(recovery_variant='extreme',recovery_enabled=False,volume_lots=.07)
    assert s.volume_lots==.07
    e=PaperEngine(s);e.start();e.on_tick(q(0,0,3999.5));e.on_tick(q(0,50,4000));e.on_tick(q(1,0,4000))
    assert e.pending.level==pytest.approx(4001.0)


def test_v2_first_tp_finishes_and_waits_for_next_closed_m1():
    e=first_buy()
    e.on_tick(q(1,2,4001.25))
    assert not e.position and e.recovery is None
    assert e.trades[-1]['result']=='TP'
    e.on_tick(q(1,40,4001.26));e.on_tick(q(2,0,4001.26))
    assert e.pending and e.pending.side=='BUY'


def test_v2_first_sl_opposite_stop_only_not_oco():
    e=first_buy()
    e.on_tick(q(1,2,3999.99))
    r=e.recovery
    assert r.variant=='extreme' and r.stepped_mode
    assert r.realized_weighted_points==pytest.approx(-.0303)
    assert len(r.pending_stops)==1
    assert r.pending_stops[0]['side']=='SELL'
    assert r.pending_stops[0]['level']==pytest.approx(3999.99)
    assert r.pending_stops[0]['lots']==.03
    assert r.original_buy_anchor==4001
    assert r.original_sell_anchor==pytest.approx(3999.99)


def test_v2_first_recovery_fill_uses_real_execution_and_tp_for_loss_only():
    e=first_recovery_sell()
    r=e.recovery
    assert r.original_sell_anchor==pytest.approx(3999.80)  # actual fill, not SL 3999.99
    assert r.active.stop==pytest.approx(4000.80)
    assert r.active.tp==pytest.approx(3998.79)  # initial 1.01 loss / same 0.03 lots
    assert r.pending_stops==[]
    assert not any(a['type']=='recovery_partial_tp' for a in r.actions)


def test_v2_recovery_completes_no_extra_025_target():
    e=first_recovery_sell()
    e.on_tick(q(1,4,3998.56))  # Ask 3998.79, recover 1.01 from SELL
    assert e.recovery is None and e.position is None
    t=e.trades[-1]
    assert t['result']=='RECOVERED' and t['recovery_variant']=='extreme'
    assert t['pnl_weighted_points_lots']>=-1e-7
    assert e.summary()['recovered']==1


def test_v2_support_sl_trails_immediately_in_010_steps():
    e=first_recovery_sell();p=e.recovery.active
    assert p.stop==pytest.approx(4000.8)
    e.on_tick(q(1,4,3999.47))  # Ask 3999.70 => SELL +.10
    assert p.stop==pytest.approx(4000.70) and p.trail_step_index==1
    e.on_tick(q(1,5,3999.35))  # Ask 3999.58 => +.22
    assert p.stop==pytest.approx(4000.60) and p.trail_step_index==2
    e.on_tick(q(1,6,3999.40))  # adverse move never relaxes SL
    assert p.stop==pytest.approx(4000.60)


def test_v2_support_sl_has_two_oco_at_extreme_and_original_opposite_price():
    e=after_support_sell();r=e.recovery
    assert r.recovery_sls==1
    assert r.original_sell_anchor==pytest.approx(3999.80)
    assert r.buy_anchor==pytest.approx(4001.0)
    assert r.sell_anchor==pytest.approx(3998.80)  # best SELL Bid 3999.3 - .5
    assert {x['side'] for x in r.pending_stops}=={'BUY','SELL'}
    assert len(r.pending_stops)==2
    assert r.realized_weighted_points<-.0303


def test_v2_oco_buy_fill_cancels_sell_and_has_dynamic_debt_target():
    e=after_support_sell();r=e.recovery
    e.on_tick(q(1,6,4000.77))  # Ask 4001 -> BUY fills
    assert r.active and r.active.side=='BUY'
    assert r.active.stop==pytest.approx(4000.0)
    assert r.active.tp>4001.25
    assert r.pending_stops==[]
    assert r.reentries==1


def test_v2_buy_support_sl_then_same_buy_reentry_above_observed_ask_and_sell_original():
    e=after_support_sell()
    e.on_tick(q(1,6,4000.77))  # BUY Ask 4001.0
    e.on_tick(q(1,7,4001.30))  # BUY Bid +.30; highest Ask=4001.53
    p=e.recovery.active
    assert p.stop==pytest.approx(4000.30)
    e.on_tick(q(1,8,4000.28))  # Bid below trailing stop
    r=e.recovery
    assert r and r.active is None
    assert r.buy_anchor==pytest.approx(4002.03)  # 4001.53 + .50
    assert r.sell_anchor==pytest.approx(3999.80) # original SELL fill
    assert len(r.pending_stops)==2


def test_v2_custom_offset_and_stop_distance_and_trail_step():
    e=first_recovery_sell(recovery_v2_reentry_offset=.85,
                          recovery_v2_support_sl_distance=1.35,
                          recovery_v2_trail_step=.20)
    assert e.recovery.active.stop==pytest.approx(4001.15)
    e.on_tick(q(1,4,3999.30))  # Ask3999.53 gain .27, one step only
    assert e.recovery.active.stop==pytest.approx(4000.95)
    e.on_tick(q(1,5,4001.00)) # Ask 4001.23 crosses stop
    assert e.recovery.sell_anchor==pytest.approx(3998.45)


def test_v2_max_range_only_clips_opposite_when_explicitly_enabled():
    e=after_support_sell(recovery_v2_opposite_max_range=1.20)
    r=e.recovery
    assert r.sell_anchor==pytest.approx(3998.80)
    assert r.buy_anchor-r.sell_anchor<=1.20+1e-8
    assert r.buy_anchor<r.original_buy_anchor


def test_v2_snapshot_round_trip_preserves_both_origin_anchors_and_variant():
    e=after_support_sell()
    restored=PaperEngine.from_snapshot(e.to_snapshot())
    assert restored.recovery.variant=='extreme'
    assert restored.recovery.original_sell_anchor==pytest.approx(3999.8)
    assert restored.recovery.original_buy_anchor==pytest.approx(4001)
    assert restored.recovery.sell_anchor==pytest.approx(3998.80)
    restored.on_tick(q(1,6,4000.77))
    assert restored.recovery.active.side=='BUY'


def test_v2_first_manual_stop_move_can_change_level_after_sl():
    e=first_buy();e.on_tick(q(1,2,3999.99))
    e.move_trigger('recovery_first',3999.50,side='SELL')
    assert e.recovery.pending_stops[0]['level']==pytest.approx(3999.50)
    assert e.recovery.pending_stops[0]['created_ms']>0


def test_v2_validation_requires_correct_volume_and_positive_distances():
    with pytest.raises(ValueError):Settings(recovery_enabled=True,recovery_variant='extreme',volume_lots=.01)
    with pytest.raises(ValueError):Settings(recovery_v2_reentry_offset=0)
    with pytest.raises(ValueError):Settings(recovery_v2_trail_step=-.1)
    with pytest.raises(ValueError):Settings(recovery_v2_opposite_max_range=-1)


def test_v2_initial_sell_is_mirrored():
    e=new();e.on_tick(q(0,0,4000.5));e.start();e.on_tick(q(0,40,4000.0));e.on_tick(q(1,0,4000.0))
    assert e.pending.side=='SELL' and e.pending.level==pytest.approx(3999.0)
    e.on_tick(q(1,1,3998.99))
    assert e.position.side=='SELL' and e.position.sl==pytest.approx(3999.99)
    e.on_tick(q(1,2,3999.9))  # ask 4000.13 -> SELL SL
    assert e.recovery and e.recovery.pending_stops[0]['side']=='BUY'
    assert e.recovery.original_sell_anchor==pytest.approx(3998.99)
    assert e.recovery.original_buy_anchor==pytest.approx(4000.13)
    e.on_tick(q(1,3,4000.0)) # BUY Ask 4000.23 -> fill with positive gap
    assert e.recovery.active and e.recovery.active.side=='BUY'
    assert e.recovery.original_buy_anchor==pytest.approx(4000.23)


def test_v2_market_open_enters_managed_strategy_with_v2_sl_and_tp():
    e=new();e.on_tick(q(0,0,4000));e.strategy_manual_open('BUY',.03,'MARKET')
    assert e.position and e.position.tp==pytest.approx(4000.48)
    assert e.position.sl==pytest.approx(3999.23)
    e.on_tick(q(0,1,3999.2))
    assert e.recovery and e.recovery.variant=='extreme'


def test_v1_classic_settings_unmodified_by_v2_options():
    e=PaperEngine(Settings(recovery_enabled=True,recovery_variant='classic',volume_lots=.01,
                           recovery_v2_initial_sl_distance=7,recovery_v2_reentry_offset=.99))
    e.on_tick(q(0,0,3999.5));e.start();e.on_tick(q(0,50,4000));e.on_tick(q(1,0,4000));e.on_tick(q(1,1,4000.77))
    assert e.position.sl==pytest.approx(3998.0) # 4001 - original SL3
    assert e.position.tp==pytest.approx(4001.25)

"""Read-only guard before replacing code. Never touches MT5, trades, or database."""
from __future__ import annotations
import argparse
import json
import sqlite3
from pathlib import Path


def env_vars(path: Path) -> dict[str, str]:
    result={}
    for raw in path.read_text(encoding='utf-8-sig').splitlines():
        raw=raw.strip()
        if raw.startswith('#') or '=' not in raw:continue
        k,v=raw.split('=',1)
        result[k.strip()]=v.strip().strip('"').strip("'")
    return result


def check(target:Path)->None:
    target=target.resolve()
    for rel in ('start_windows.bat','.env','analyzer/engine.py','analyzer/live.py','analyzer/server.py'):
        if not (target/rel).is_file():
            raise ValueError(f'Not installed analyzer folder; missing {rel}')
    env=env_vars(target/'.env')
    source=(env.get('DATA_SOURCE','mt5') or 'mt5').lower()
    symbol=env.get('MT5_SYMBOL','XAUUSD.s') if source=='mt5' else 'SYNTHETIC-DEMO'
    name=''.join(c for c in symbol if c.isalnum() or c in '._-')
    data_dir=Path(env.get('DATA_DIR') or str(target/'data'))
    if not data_dir.is_absolute():data_dir=target/data_dir
    db=data_dir/f'{source}_{name}'/'analyzer.sqlite3'
    if not db.exists():
        print('No previous database at configured DATA_DIR; safe to copy files.')
        return
    with sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True,timeout=6) as conn:
        row=conn.execute("SELECT value FROM state WHERE key='live_snapshot'").fetchone()
        if row:
            state=json.loads(row[0])
            active=any((state.get('pending'),state.get('position'),state.get('recovery'),
                        state.get('manual_positions'),state.get('manual_stops')))
            if active:
                raise ValueError('An active virtual order/position/RECOVERY is saved. Finish or explicitly abort this cycle in OLD analyzer, close start_windows.bat, retry. History untouched.')
    print('OK: no active virtual orders/positions. Database was READ ONLY.')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--target',required=True,type=Path)
    args=parser.parse_args()
    try:check(args.target)
    except Exception as exc:
        print('PRECHECK BLOCKED:',str(exc))
        raise SystemExit(2)

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo =================================================
echo    XAUUSD.s Strategy Analyzer - FIRST INSTALL
 echo =================================================
echo.
echo Checking 64-bit Python 3.12 / 3.11 ...
set "PY_LAUNCH="
where py >nul 2>nul
if not errorlevel 1 (
    py -3.12 -c "import sys; assert sys.maxsize > 2**32" >nul 2>nul
    if not errorlevel 1 set "PY_LAUNCH=py -3.12"
    if not defined PY_LAUNCH (
        py -3.11 -c "import sys; assert sys.maxsize > 2**32" >nul 2>nul
        if not errorlevel 1 set "PY_LAUNCH=py -3.11"
    )
)
if not defined PY_LAUNCH (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; assert sys.version_info[:2] in ((3,11),(3,12)) and sys.maxsize > 2**32" >nul 2>nul
        if not errorlevel 1 set "PY_LAUNCH=python"
    )
)
if not defined PY_LAUNCH (
    echo.
    echo ERROR: 64-bit Python 3.11 / 3.12 not found.
    echo Install Python 3.12 for Windows x64 from https://www.python.org/downloads/windows/
    echo Enable Python Launcher and Add Python to PATH in the installer.
    echo Then run this install_windows.bat again.
    pause
    exit /b 1
)
echo Using %PY_LAUNCH%
if not exist ".venv\Scripts\python.exe" (
    %PY_LAUNCH% -m venv ".venv"
    if errorlevel 1 (
        echo ERROR: virtual environment creation failed.
        pause
        exit /b 1
    )
)
echo Updating pip ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
    echo ERROR: pip upgrade failed. Check the VPS internet connection.
    pause
    exit /b 1
)
echo Installing required packages ...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: dependency installation failed. See error details above.
    pause
    exit /b 1
)
if not exist ".env" copy ".env.example" ".env" >nul
echo.
echo =================================================
echo   Python installation complete.
echo   Now edit .env in Notepad:
echo   1. Set your unique WEB_PASSWORD (16+ chars).
echo   2. Set DATA_SOURCE=mt5 and MT5_SYMBOL=XAUUSD.s.
echo   3. Keep WEB_HOST=127.0.0.1 and WEB_PORT=8765.
echo   4. Save the file, then run start_windows.bat.
echo =================================================
notepad ".env"
pause

"""Run from project root to verify MT5 account and read-only XAUUSD.s prices."""
import os
import sys
import time
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dotenv import load_dotenv
from analyzer.sources import MT5Quotes
load_dotenv(Path(__file__).resolve().parents[1]/'.env')

symbol=os.getenv('MT5_SYMBOL','XAUUSD.s')
src=MT5Quotes(symbol,os.getenv('MT5_TERMINAL_PATH',''),os.getenv('MT5_EXPECTED_LOGIN',''),
              os.getenv('MT5_TIME_OFFSET_HOURS','auto'))
try:
    details=src.symbol_details()
    print('Read-only MT5 connected. Instrument diagnostics:')
    for k,v in details.items():
        if k == 'account_login':
            v = '***' + str(v)[-4:]
        print(f'  {k}: {v}')
    raw_quote=src.mt5.symbol_info_tick(symbol)
    if raw_quote:
        print('Raw MT5 tick:',raw_quote.time_msc,
              '| Adjusted UTC:',datetime.fromtimestamp((raw_quote.time_msc-src.time_offset_ms)/1000,timezone.utc).isoformat())
    now=int(time.time()*1000)
    ticks=src.range(now-90_000,now)
    print('Quote updates in past 90 seconds:',len(ticks))
    if ticks:
        tk=ticks[-1]
        print('Last UTC:',datetime.fromtimestamp(tk.t_ms/1000,timezone.utc).isoformat())
        print('Bid:',tk.bid,'Ask:',tk.ask,'Spread:',round(tk.ask-tk.bid,5))
    else:
        print('No recent UTC-aligned ticks. The market may be closed; check MT5 Market Watch.')
    bars=src.chart(5)
    if bars:
        print('Last broker bar UTC:', datetime.fromtimestamp(bars[-1]['time'],timezone.utc).isoformat(),
              'Close:',bars[-1]['close'])
        print('Newest broker bar vs UTC clock, seconds:',int(time.time())-bars[-1]['time'])
    print('No trading or broker order operations were executed.')
except Exception as exc:
    print('DIAGNOSTICS FAILED:',exc)
    sys.exit(1)

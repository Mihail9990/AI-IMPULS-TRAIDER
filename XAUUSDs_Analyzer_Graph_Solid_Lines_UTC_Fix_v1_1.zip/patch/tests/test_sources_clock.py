"""Regression tests for the chart/tick 3h mismatch visible on MT5 brokers."""
from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace
import sys
import pytest

from analyzer.sources import MT5Quotes, SourceError, infer_mt5_clock_offset_ms

NOW = 1_780_000_025_000
HOUR = 3_600_000


def test_clock_recognizes_whole_hour_shift_only_if_quote_is_fresh():
    assert infer_mt5_clock_offset_ms(NOW + 3*HOUR - 1200,NOW)==3*HOUR
    assert infer_mt5_clock_offset_ms(NOW - 1200,NOW)==0
    assert infer_mt5_clock_offset_ms(NOW - HOUR + 2000,NOW)==-HOUR
    with pytest.raises(SourceError):
        infer_mt5_clock_offset_ms(NOW-5*60_000,NOW)
    with pytest.raises(SourceError):
        infer_mt5_clock_offset_ms(NOW+35*60_000,NOW)


class FakeMetaTrader:
    COPY_TICKS_INFO=1
    TIMEFRAME_M1=1

    def __init__(self, offset):
        self.offset=offset
        self.last_tick_time=NOW+offset-1200
        self.range_args=None

    def initialize(self,*a):return True
    def account_info(self):return SimpleNamespace(login=23456)
    def symbol_select(self,s,visible):return s=='XAUUSD.s'
    def symbol_info(self,s):return SimpleNamespace(
        trade_tick_size=.01,point=.01,digits=2,trade_tick_value=1.,
        volume_min=.01,volume_step=.01,trade_stops_level=0)
    def symbol_info_tick(self,s):return SimpleNamespace(time_msc=self.last_tick_time, bid=4012.32,ask=4012.55)
    def last_error(self):return 'no error'
    def copy_ticks_range(self,s,st,en,flags):
        self.range_args=(st,en)
        return [{'time_msc':self.last_tick_time,'bid':4012.32,'ask':4012.55}]
    def copy_rates_from_pos(self,s,tf,start,count):
        minute=(NOW//60000)*60
        return [dict(time=(minute-60)*1+int(self.offset/1000),
                     open=4011,high=4012,low=4011,close=4011.8),
                dict(time=minute+int(self.offset/1000),
                     open=4011.8,high=4012.32,low=4011.7,close=4012.32)]


@pytest.mark.parametrize('hours',[0,3,-2])
def test_same_utc_time_for_normalized_tick_and_broker_candle(monkeypatch,hours):
    import analyzer.sources as src_module
    monkeypatch.setattr(src_module.time,'time',lambda: NOW/1000)
    fake=FakeMetaTrader(hours*HOUR)
    monkeypatch.setitem(sys.modules,'MetaTrader5',fake)
    adapter=MT5Quotes(symbol='XAUUSD.s',expected_login='23456')
    details=adapter.symbol_details()
    assert details['clock_offset_hours']==hours
    rows=adapter.range(NOW-90_000,NOW)
    assert len(rows)==1 and rows[0].t_ms==NOW-1200
    assert fake.range_args[0]==datetime.fromtimestamp((NOW-90000+hours*HOUR)/1000,timezone.utc)
    candles=adapter.chart(10)
    assert len(candles)==2
    assert candles[-1]['time']==(NOW//60000)*60
    assert candles[-1]['close']==rows[-1].bid


def test_source_refuses_stale_clock_in_auto_mode(monkeypatch):
    import analyzer.sources as src_module
    monkeypatch.setattr(src_module.time,'time',lambda:NOW/1000)
    fake=FakeMetaTrader(0)
    fake.last_tick_time=NOW-15*60_000
    monkeypatch.setitem(sys.modules,'MetaTrader5',fake)
    with pytest.raises(SourceError,match='Время последнего тика'):
        MT5Quotes().connect()


def test_manual_offset_for_testing_market_closed(monkeypatch):
    import analyzer.sources as src_module
    monkeypatch.setattr(src_module.time,'time',lambda:NOW/1000)
    fake=FakeMetaTrader(3*HOUR)
    fake.last_tick_time=NOW-200*60_000+3*HOUR
    monkeypatch.setitem(sys.modules,'MetaTrader5',fake)
    assert MT5Quotes(time_offset_hours='3').symbol_details()['clock_mode']=='manual'


def test_candles_can_have_independent_clock_when_recent_prices_match(monkeypatch):
    import analyzer.sources as src_module
    monkeypatch.setattr(src_module.time,'time',lambda:NOW/1000)
    fake=FakeMetaTrader(0)  # tick timestamps are already in UTC
    original_rates=fake.copy_rates_from_pos
    def shifted_rates(*args):
        return [{**r, 'time':r['time']+3*3600} for r in original_rates(*args)]
    fake.copy_rates_from_pos=shifted_rates
    monkeypatch.setitem(sys.modules,'MetaTrader5',fake)
    adapter=MT5Quotes()
    assert adapter.symbol_details()['clock_offset_hours']==0
    assert adapter.chart()[-1]['time']==(NOW//60000)*60
    assert adapter.bar_offset_ms==3*HOUR

﻿param([string]$TargetFolder = '')
$ErrorActionPreference = 'Stop'
try {
  Write-Host 'XAUUSD.s Strategy Analyzer: Chart & UTC time synchronization update v1.1' -ForegroundColor Cyan
  $patchDir = Join-Path $PSScriptRoot 'patch'
  if (!(Test-Path -LiteralPath (Join-Path $patchDir 'web\app.js'))) {
    throw 'Не найдена папка patch. Полностью распакуйте ZIP, затем запустите UPDATE_CHART_v1_1.bat.'
  }
  if ([string]::IsNullOrWhiteSpace($TargetFolder)) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'start_windows.bat')) {
      $TargetFolder = $PSScriptRoot
    } else {
      Add-Type -AssemblyName System.Windows.Forms
      $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
      $dialog.Description = 'Выбери папку установленного анализатора, где находится start_windows.bat'
      $dialog.ShowNewFolderButton = $false
      $dialog.RootFolder = [System.Environment+SpecialFolder]::MyComputer
      if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Отменено. Файлы не изменены.' -ForegroundColor Yellow
        exit 2
      }
      $TargetFolder = $dialog.SelectedPath
    }
  }
  $TargetFolder = (Resolve-Path -LiteralPath $TargetFolder).Path
  if (!(Test-Path -LiteralPath (Join-Path $TargetFolder 'start_windows.bat')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder 'analyzer\server.py')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder 'web\app.js'))) {
    throw 'Выбрана не папка анализатора. Нужна папка с start_windows.bat, analyzer и web.'
  }
  # Never replace files while the running server is importing them.
  $busy = @(Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue)
  if ($busy.Count -gt 0) {
    throw 'Порт 8765 занят. Закройте окно start_windows.bat (сервер анализатора) и запустите обновление снова.'
  }
  $files = @(
    'analyzer\sources.py', 'analyzer\live.py',
    'web\app.js', 'web\index.html', 'web\styles.css',
    'tools\check_mt5.py', 'tests\test_sources_clock.py', '.env.example'
  )
  # Back up precisely the files being overwritten. Never touch .env, .venv or data.
  $backupDir = Join-Path $TargetFolder ('backup_chart_v1_1_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  foreach ($rel in $files) {
    $from = Join-Path $patchDir $rel
    $to = Join-Path $TargetFolder $rel
    if (!(Test-Path -LiteralPath $from)) { throw "Отсутствует файл обновления: $rel" }
    $old = Join-Path $backupDir $rel
    if (Test-Path -LiteralPath $to) {
      New-Item -ItemType Directory -Path (Split-Path $old -Parent) -Force | Out-Null
      Copy-Item -LiteralPath $to -Destination $old -Force
    }
  }
  foreach ($rel in $files) {
    $from = Join-Path $patchDir $rel
    $to = Join-Path $TargetFolder $rel
    New-Item -ItemType Directory -Path (Split-Path $to -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $from -Destination $to -Force
    Write-Host "Обновлено: $rel"
  }
  Write-Host ''
  Write-Host 'Готово. Пароль (.env), Python (.venv) и история (data) не изменены.' -ForegroundColor Green
  Write-Host "Резервная копия старых файлов: $backupDir"
  Write-Host 'Запусти start_windows.bat; затем обнови вкладку браузера через Ctrl+F5.' -ForegroundColor Green
  Write-Host 'Веб-панель остаётся на http://127.0.0.1:8765; публичный HTTPS обновление не настраивает.'
  exit 0
} catch {
  Write-Host ''
  Write-Host "ОШИБКА: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}

@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_CHART_v1_1.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Update not applied. Exit code: %RC%
pause
exit /b %RC%

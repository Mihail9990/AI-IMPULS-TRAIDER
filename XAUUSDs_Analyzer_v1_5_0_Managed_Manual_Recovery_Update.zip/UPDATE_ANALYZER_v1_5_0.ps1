param([string]$TargetDirectory = '')
$ErrorActionPreference = 'Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest=Join-Path $here 'SHA256SUMS.txt'
$files=@(
 'analyzer\engine.py', 'analyzer\live.py', 'analyzer\server.py',
 'web\app.js', 'web\index.html', 'web\terminal.css',
 'tests\test_managed_intervention_v150.py', 'tests\test_reset_statistics_v141.py'
)
function Main {
 Write-Host 'XAUUSD.s Analyzer v1.5.0 - Managed Virtual RECOVERY / chart controls' -ForegroundColor Cyan
 Write-Host 'No real orders. No history / .env / Caddy / HTTPS files will be modified.'
 if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'SHA256 manifest missing' }
 $hashes=@{}
 foreach ($line in (Get-Content -LiteralPath $manifest)) {
   if ($line -match '^([0-9a-fA-F]{64})\s{2}(.+)$') { $hashes[$matches[2]]=$matches[1].ToLowerInvariant() }
 }
 foreach ($rel in $files) {
   $key='patch/' + ($rel -replace '\\','/')
   $src=Join-Path (Join-Path $here 'patch') $rel
   if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw ('Missing: ' + $key) }
   if (-not $hashes.ContainsKey($key)) { throw ('Manifest missing entry: ' + $key) }
   $actual=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
   if ($actual -ne $hashes[$key]) { throw ('Checksum mismatch: ' + $key) }
 }
 Write-Host '[OK] Verified all SHA256 file checksums.' -ForegroundColor Green
 if (-not $TargetDirectory) {
   Add-Type -AssemblyName System.Windows.Forms
   $picker=New-Object System.Windows.Forms.FolderBrowserDialog
   $picker.Description='Choose INSTALLED analyzer folder containing start_windows.bat'
   $picker.ShowNewFolderButton=$false
   if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Cancelled; nothing changed.';return }
   $TargetDirectory=$picker.SelectedPath
 }
 $target=[System.IO.Path]::GetFullPath($TargetDirectory)
 foreach($rel in @('start_windows.bat','.env','analyzer\engine.py','analyzer\live.py','analyzer\server.py','web\index.html','web\app.js','web\terminal.css')) {
   if(-not (Test-Path -LiteralPath (Join-Path $target $rel) -PathType Leaf)) { throw ('Wrong target folder, missing: ' + $rel) }
 }
 $engine=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\engine.py'))
 if(-not ($engine.Contains('recovery_trail_start_offset') -and $engine.Contains('best_trigger_quote'))) {
   throw 'Expected installed RECOVERY v1.3.4 engine. No files changed.'
 }
 $server=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\server.py'))
 if(-not $server.Contains('/api/statistics/reset')) { throw 'Expected UI v1.4.1 with statistics reset endpoint. No files changed.' }
 $envFile=[System.IO.File]::ReadAllText((Join-Path $target '.env'))
 $port=8765
 $m=[regex]::Match($envFile,'(?m)^\s*WEB_PORT\s*=\s*(\d+)')
 if($m.Success){ $port=[int]$m.Groups[1].Value }
 if(Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue){
   $listeners=@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
   if($listeners.Count -gt 0){ throw ('Port ' + $port + ' is in use. Close start_windows.bat, then retry. Nothing changed.') }
 }
 $backup=Join-Path $target ('backup_managed_v1_5_0_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
 New-Item -ItemType Directory -Path $backup -Force | Out-Null
 $existed=@{}
 try {
  foreach($rel in $files){
    $dest=Join-Path $target $rel
    $existed[$rel]=Test-Path -LiteralPath $dest -PathType Leaf
    if($existed[$rel]){
      $bf=Join-Path $backup $rel
      New-Item -ItemType Directory -Path (Split-Path -Parent $bf) -Force | Out-Null
      Copy-Item -LiteralPath $dest -Destination $bf -Force
    }
  }
  foreach($rel in $files){
    $src=Join-Path (Join-Path $here 'patch') $rel
    $dest=Join-Path $target $rel
    $dir=Split-Path -Parent $dest
    if(-not(Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Copy-Item -LiteralPath $src -Destination $dest -Force
    Write-Host ('Updated: ' + $rel)
  }
 } catch {
   Write-Host 'Copy failure; restoring saved source files...' -ForegroundColor Yellow
   foreach($rel in $files){
     $dst=Join-Path $target $rel;$bf=Join-Path $backup $rel
     if(Test-Path -LiteralPath $bf -PathType Leaf) { Copy-Item -LiteralPath $bf -Destination $dst -Force }
     elseif($existed.ContainsKey($rel) -and -not $existed[$rel] -and (Test-Path -LiteralPath $dst)){ Remove-Item -LiteralPath $dst -Force }
   }
   throw
 }
 Write-Host '[OK] Virtual analyzer v1.5.0 installed. History / credentials / Caddy preserved.' -ForegroundColor Green
 Write-Host ('Source backup: ' + $backup)
 Write-Host 'Start start_windows.bat then hard-refresh the HTTPS page on Android.'
}
try{Main}catch{Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red; exit 1}

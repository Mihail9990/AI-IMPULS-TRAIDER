"""Manual phone interventions remain inside one deterministic virtual strategy cycle."""
from dataclasses import asdict
import pytest
from analyzer.engine import PaperEngine,Settings,Tick
from fastapi.testclient import TestClient
import analyzer.server as server


def tk(n,b,spread=.23):return Tick(n*1000,round(b,4),round(b+spread,4))


def core(recovery=False):
    e=PaperEngine(Settings(volume_lots=.01,recovery_core_lots=.01,
        recovery_enabled=recovery,tick_size=.01,tick_value_per_lot=1,
        recovery_opposite_max_range=2.5))
    e.on_tick(tk(100,4000))
    return e


def start_first_recovery():
    e=core(True)
    e.strategy_manual_open('BUY',.01,'MARKET')  # Ask 4000.23, SL 3997.23
    e.on_tick(tk(101,3997.20))  # Initial SL hit on Bid
    assert e.recovery and e.recovery.active is None
    assert e.recovery.pending_stops[0]['side']=='SELL'
    return e


def start_stepped():
    e=start_first_recovery()
    e.on_tick(tk(102,3997.1))  # fixed SELL .12, fill next tick
    assert e.recovery.active and e.recovery.active.role=='fixed_tp'
    sl=e.recovery.active.stop
    e.on_tick(tk(103,sl))  # Ask is above SELL stop
    assert e.recovery.stepped_mode and e.recovery.active is None
    return e


def test_initial_market_managed_and_restarts_on_next_closed_candle():
    e=core()
    e.strategy_manual_open('BUY',.01,'MARKET')
    assert e.mode=='running' and e.position and not e.manual_positions
    p=e.position
    assert p.tp==pytest.approx(p.entry+.25) and p.sl==pytest.approx(p.entry-3)
    e.on_tick(tk(101,p.tp))
    assert e.position is None and e.trades[-1]['result']=='TP'
    assert e.trades[-1]['lots']==pytest.approx(.01)
    assert e.arm_minute==60  # first completed candle after exit arms cycle
    assert e.latest is not None


def test_manual_partial_close_then_remnant_auto_tp_and_weighting():
    e=core()
    e.strategy_manual_open('BUY',.03,'MARKET')
    e.on_tick(tk(101,4000.08))
    e.manual_close('auto',.01)
    assert e.position and e.position.lots==pytest.approx(.02)
    assert e.trades[-1]['manual'] is True
    assert e.summary()['pnl_points']==pytest.approx(-.15)  # 4000.08 - 4000.23
    e.on_tick(tk(102,4000.48))
    assert e.position is None and e.trades[-1]['result']=='TP'
    assert e.trades[-1]['pnl_points']==pytest.approx(.50)  # 0.25 * .02/.01
    assert e.summary()['pnl_points']==pytest.approx(.35)
    assert not e.manual_positions


def test_manual_standard_stop_in_strategy_and_changed_on_opposite_closed_candle():
    e=core()
    e.strategy_manual_open('SELL',.02,'STOP',3999)
    assert e.pending and e.pending.side=='SELL' and e.pending.lots==pytest.approx(.02)
    snap=e.to_snapshot()
    restored=PaperEngine.from_snapshot(snap)
    assert restored.pending.lots==pytest.approx(.02)
    restored.on_tick(tk(101,3998.88))
    assert restored.position and restored.position.lots==pytest.approx(.02)
    assert not restored.manual_positions


def test_first_recovery_stop_drag_and_market_override_remain_fixed_tp():
    e=start_first_recovery()
    old=e.recovery.pending_stops[0]['level']
    e.move_trigger('recovery_first',old-.60,'SELL')
    assert e.recovery.pending_stops[0]['level']==pytest.approx(old-.60)
    e.strategy_manual_open('SELL',.12,'MARKET')
    assert e.recovery.active and e.recovery.active.role=='fixed_tp'
    assert e.recovery.active.lots==pytest.approx(.12)
    assert not e.recovery.pending_stops
    # Opposite BUY is forbidden before the first recovery SL.
    with pytest.raises(ValueError):
        e.strategy_manual_open('BUY',.12,'MARKET')
    entry=e.recovery.active.entry
    e.on_tick(tk(102,entry-.50))  # ask below first SELL TP .25
    assert e.recovery is None and e.trades[-1]['result']=='RECOVERY_TP'
    assert e.trades[-1]['pnl_points']!=0 or e.trades[-1]['pnl_money_est'] is not None


def test_manual_full_rec_close_keeps_debt_and_rebuilds_oco():
    e=start_stepped()
    r=e.recovery
    debt=r.realized_weighted_points
    assert debt < 0
    e.update_opposite_range(2.0)
    e.strategy_manual_open('SELL',.15,'MARKET')
    assert r.active and r.active.role=='stepped' and r.active.lots==pytest.approx(.15)
    assert r.active.stop==pytest.approx(r.active.entry+1)
    e.on_tick(tk(104,r.active.entry-.40))
    assert r.active and r.active.trail_step_index>=1
    e.manual_close('recovery',.03)
    assert r.active and r.active.lots==pytest.approx(.12)
    assert r.realized_weighted_points!=debt
    e.manual_close('recovery',.12)
    assert r.active is None and len(r.pending_stops)==2
    assert r.buy_anchor-r.sell_anchor<=2.0+1e-8
    assert e.recovery is r and r.realized_weighted_points<0
    snap=e.to_snapshot()
    after=PaperEngine.from_snapshot(snap)
    assert after.recovery and len(after.recovery.pending_stops)==2
    assert after.recovery.realized_weighted_points==pytest.approx(r.realized_weighted_points)


def test_manual_replacement_of_oco_stop_and_opposite_cap():
    e=start_stepped(); r=e.recovery
    limit=1.5
    e.update_opposite_range(limit)
    e.strategy_manual_open('SELL',.15,'STOP',e.latest.bid-1)
    assert r.active is None and len(r.pending_stops)==2
    assert r.sell_anchor == pytest.approx(e.latest.bid-1)
    assert r.buy_anchor-r.sell_anchor<=limit+1e-8
    sl=[x for x in r.pending_stops if x['side']=='SELL'][0]
    assert sl['lots']==pytest.approx(.15)
    fill=e.latest.bid-1.1
    e.on_tick(tk(104,fill))
    assert r.active and r.active.side=='SELL' and r.active.lots==pytest.approx(.15)
    assert not r.pending_stops  # OCO cancellation


def test_actions_rejected_when_already_has_position():
    e=core();e.strategy_manual_open('BUY',.01,'MARKET')
    with pytest.raises(ValueError,match='закрой'):
        e.strategy_manual_open('SELL',.01,'MARKET')
    assert len(e.trades)==0 and e.position.side=='BUY'


def test_legacy_snapshot_loads_with_no_lots_attribute():
    e=core();e.strategy_manual_open('BUY',.01,'MARKET')
    snap=e.to_snapshot();snap['position'].pop('lots')
    restored=PaperEngine.from_snapshot(snap)
    assert restored._position_lots(restored.position)==pytest.approx(.01)


def test_api_requires_auth_and_confirm_for_managed_open(tmp_path,monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD','test-user-password-long-12345')
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as client:
        payload=dict(side='BUY',lots=.01,order_type='MARKET',confirmation='CONFIRM')
        assert client.post('/api/virtual/strategy/open',json=payload).status_code==401
        assert client.post('/api/virtual/strategy/open',json={**payload,'confirmation':'NO'},auth=('admin','test-user-password-long-12345')).status_code==422
        assert client.post('/api/virtual/strategy/open',json=payload,auth=('admin','test-user-password-long-12345'),headers={'Origin':'https://evil.example'}).status_code==403
        # Avoid clock/thread timing flakiness: inject a known fresh quote.
        svc=server.service
        import time
        with svc.engine_lock:
            from analyzer.engine import Tick
            now=int(time.time()*1000)
            svc.engine.latest=Tick(now,4000.,4000.23)
            svc.engine.candle=None
            svc.connection_status='connected'
        res=client.post('/api/virtual/strategy/open',json=payload,auth=('admin','test-user-password-long-12345'))
        assert res.status_code==200,res.text
        assert res.json().get('managed_strategy') is True
        with svc.engine_lock:
            assert svc.engine.position is not None
            assert svc.engine.position.tp>svc.engine.position.entry


def test_manual_full_close_first_recovery_rearms_fixed_phase_and_allows_reopen():
    e=start_first_recovery()
    e.strategy_manual_open('SELL',.12,'MARKET')
    r=e.recovery
    old=r.realized_weighted_points
    e.manual_close('recovery',.12)
    assert e.recovery is r and r.active is None and r.stepped_mode is False
    assert len(r.pending_stops)==1 and r.pending_stops[0]['side']=='SELL'
    assert r.realized_weighted_points<old  # spread loss was booked
    # Choose another MARKET entry manually; the strategy still applies fixed TP.
    e.strategy_manual_open('SELL',.12,'MARKET')
    assert r.active and r.active.tp is not None
    assert r.active.role=='fixed_tp'

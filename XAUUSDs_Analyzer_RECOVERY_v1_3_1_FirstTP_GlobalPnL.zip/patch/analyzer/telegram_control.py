"""OPTIONAL remote control via a SEPARATE Telegram bot. No exchange credentials.

Only TG_ALLOWED_CHAT_ID is accepted. Disable by leaving TG_BOT_TOKEN unset.
Never reuse the same Telegram bot token as the user's live trading bot.
"""
from __future__ import annotations

import json
import os
import threading
import time
from urllib import parse, request


class TelegramControl:
    def __init__(self,analyzer):
        self.analyzer=analyzer
        self.token=os.getenv('TG_BOT_TOKEN','').strip()
        self.chat_id=os.getenv('TG_ALLOWED_CHAT_ID','').strip()
        self.thread=None
        self.boot_time=int(time.time())
        self.last_update_id=None

    def start(self):
        if not self.token:
            return
        if not self.chat_id or not self.chat_id.lstrip('-').isdigit():
            raise ValueError('TG_ALLOWED_CHAT_ID is required when TG_BOT_TOKEN is set')
        self.thread=threading.Thread(target=self._loop,daemon=True,name='AnalyzerTelegramControl')
        self.thread.start()

    def _telegram(self,method,params):
        url='https://api.telegram.org/bot'+self.token+'/'+method
        data=parse.urlencode(params).encode('utf-8')
        res=request.urlopen(request.Request(url,data=data),timeout=27)
        with res:
            obj=json.loads(res.read().decode('utf-8'))
        if not obj.get('ok'):
            raise RuntimeError('Telegram API rejected the request')
        return obj.get('result')

    def _send(self,text):
        try:
            self._telegram('sendMessage',{'chat_id':self.chat_id,'text':text[:3700]})
        except Exception:
            pass  # no exchange/MT5 operation depends on Telegram connectivity

    def _handle(self,msg):
        if str(msg.get('chat',{}).get('id',''))!=self.chat_id:
            return
        if int(msg.get('date',0))<self.boot_time-15:
            return  # do NOT run stale /start messages from last week on VPS boot
        command=msg.get('text','').split(maxsplit=1)[0].split('@')[0].lower()
        if not command:
            return
        try:
            if command=='/start':
                state=self.analyzer.control('start')
                reply='Анализатор: /start принят. Ожидаю закрытие свечи M1. Реальных ордеров нет.'
            elif command=='/stop':
                state=self.analyzer.control('stop')
                reply='Анализатор: /stop принят. Текущий виртуальный цикл завершается штатно.'
            elif command=='/force_stop':
                self.analyzer.control('force_stop')
                reply='Анализатор: виртуальная позиция/триггер принудительно сброшены, без TP/SL.'
            elif command=='/status':
                s=self.analyzer.status();t=s['summary']
                reply=(f"Анализатор: {s['mode']} ({s['connection']})\n"
                       f"{s['symbol']}: Bid {s['tick']['bid'] if s['tick'] else '—'} / "
                       f"Ask {s['tick']['ask'] if s['tick'] else '—'}\n"
                       f"TP: {t['tp']} · REC: {t.get('recovered',0)} · SL: {t['sl']}\n"
                       f"Equity, экв. п.: {t.get('equity_points',t['pnl_points'])} · "
                       f"Частичных TP: {t.get('recovery_partial_tps',0)}\n"
                       'Только виртуальные сделки.')
            elif command=='/settings':
                s=self.analyzer.status()['settings']
                reply=(f"Виртуальные настройки: STOP distance {s['trigger_distance']} / "
                       f"TP {s['tp_distance']} / SL {s['sl_distance']} / "
                       f"lot {s['volume_lots']} · "
                       f"RECOVERY {'ON' if s.get('recovery_enabled') else 'OFF'}\n"
                       'Изменения выполняются через веб-панель.')
            elif command=='/help':
                reply='/start · /stop · /force_stop · /status · /settings\nТолько анализатор; никаких реальных сделок.'
            else:
                return
            self._send(reply)
        except Exception as exc:
            self._send('Команда не выполнена: '+str(exc))

    def _loop(self):
        while not self.analyzer.stop_flag.is_set():
            try:
                data={'timeout':18,'allowed_updates':json.dumps(['message'])}
                if self.last_update_id is not None:
                    data['offset']=self.last_update_id+1
                updates=self._telegram('getUpdates',data)
                for u in updates or []:
                    self.last_update_id=int(u['update_id'])
                    self._handle(u.get('message',{}))
            except Exception:
                # Avoid logging Telegram token (present in request URL).
                self.analyzer.stop_flag.wait(8)

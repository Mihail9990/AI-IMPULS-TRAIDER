"""SQLite persists settings, live state, virtual trades, and backtest results."""
from __future__ import annotations
import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path


class Store:
    def __init__(self,db_path:Path):
        Path(db_path).parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(str(db_path),check_same_thread=False,timeout=30)
        self.db.row_factory=sqlite3.Row
        self.lock=threading.RLock()
        with self.lock,self.db:
            self.db.execute('PRAGMA journal_mode=WAL')
            self.db.execute('PRAGMA foreign_keys=ON')
            self.db.executescript('''
            CREATE TABLE IF NOT EXISTS state (
              key TEXT PRIMARY KEY, value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS live_trades (
              id INTEGER PRIMARY KEY, payload TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS backtests (
              id TEXT PRIMARY KEY, created_ms INTEGER NOT NULL,
              status TEXT NOT NULL, source TEXT NOT NULL,
              start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL,
              config TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0,
              total INTEGER NOT NULL, day_progress TEXT NOT NULL DEFAULT '',
              error TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS variants (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              backtest_id TEXT NOT NULL REFERENCES backtests(id) ON DELETE CASCADE,
              config TEXT NOT NULL, summary TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_variants_run ON variants(backtest_id);
            CREATE TABLE IF NOT EXISTS backtest_trades (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              variant_id INTEGER NOT NULL REFERENCES variants(id) ON DELETE CASCADE,
              backtest_id TEXT NOT NULL REFERENCES backtests(id) ON DELETE CASCADE,
              opened_ms INTEGER NOT NULL,
              result TEXT NOT NULL,
              payload TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_trades_variant ON backtest_trades(variant_id, opened_ms);
            ''')
            # Threads don't survive a Windows restart. Keep partial results,
            # but never show an orphaned backtest as still running.
            self.db.execute("UPDATE backtests SET status='interrupted', error='VPS process restarted before completion' WHERE status IN ('queued','running')")

    def set_state(self,key,value):
        with self.lock,self.db:
            self.db.execute('INSERT INTO state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                            (key,json.dumps(value,ensure_ascii=False)))

    def get_state(self,key,default=None):
        with self.lock:
            r=self.db.execute('SELECT value FROM state WHERE key=?',(key,)).fetchone()
        return json.loads(r['value']) if r else default

    def save_live(self,snapshot, trades):
        with self.lock,self.db:
            self.db.execute('INSERT INTO state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                            ('live_snapshot',json.dumps(snapshot)))
            self.db.executemany('INSERT OR REPLACE INTO live_trades(id,payload) VALUES(?,?)',
                                [(t['id'],json.dumps(t)) for t in trades])

    def make_job(self,start_ms,end_ms,config,total,source):
        run_id=uuid.uuid4().hex[:12]
        with self.lock,self.db:
            self.db.execute('INSERT INTO backtests(id,created_ms,status,source,start_ms,end_ms,config,total) VALUES(?,?,?,?,?,?,?,?)',
                            (run_id,int(time.time()*1000),'queued',source,start_ms,end_ms,json.dumps(config),total))
        return run_id

    def update_job(self,run_id,status=None,done=None,progress=None,error=None):
        updates={}
        if status is not None:updates['status']=status
        if done is not None:updates['done']=done
        if progress is not None:updates['day_progress']=progress
        if error is not None:updates['error']=error
        if not updates: return
        cols=', '.join(f'{k}=?' for k in updates)
        with self.lock,self.db:
            self.db.execute(f'UPDATE backtests SET {cols} WHERE id=?',(*updates.values(),run_id))

    def save_variant(self,run_id,settings,summary,trades):
        with self.lock,self.db:
            cur=self.db.execute('INSERT INTO variants(backtest_id,config,summary) VALUES(?,?,?)',
                                (run_id,json.dumps(settings),json.dumps(summary)))
            vid=cur.lastrowid
            self.db.executemany('INSERT INTO backtest_trades(variant_id,backtest_id,opened_ms,result,payload) VALUES(?,?,?,?,?)',
                                [(vid,run_id,t['opened_ms'],t['result'],json.dumps(t)) for t in trades])
        return vid

    def list_jobs(self,limit=40):
        with self.lock:
            rows=self.db.execute('SELECT * FROM backtests ORDER BY created_ms DESC LIMIT ?', (limit,)).fetchall()
        return [self._job(r) for r in rows]

    @staticmethod
    def _job(row):
        result=dict(row)
        result['config']=json.loads(result['config'])
        return result

    def job(self,run_id):
        with self.lock:
            row=self.db.execute('SELECT * FROM backtests WHERE id=?',(run_id,)).fetchone()
        return self._job(row) if row else None

    def variants(self,run_id,limit=2000):
        with self.lock:
            rows=self.db.execute('SELECT * FROM variants WHERE backtest_id=? LIMIT ?',(run_id,limit)).fetchall()
        items=[]
        for r in rows:
            items.append(dict(id=r['id'],config=json.loads(r['config']),summary=json.loads(r['summary'])))
        items.sort(key=lambda x:(x['summary'].get('train',{}).get('equity_points',
                       x['summary'].get('train',{}).get('pnl_points',x['summary']['pnl_points'])),
                       -x['summary'].get('max_equity_drawdown_points',x['summary']['max_drawdown_points'])),
                       reverse=True)
        return items

    def trades(self,variant_id,limit=600,offset=0):
        with self.lock:
            rows=self.db.execute('SELECT * FROM backtest_trades WHERE variant_id=? ORDER BY opened_ms LIMIT ? OFFSET ?',
                                 (variant_id,limit,offset)).fetchall()
        return [dict(db_id=r['id'],**json.loads(r['payload'])) for r in rows]

    def trade(self,trade_id):
        with self.lock:
            row=self.db.execute('SELECT * FROM backtest_trades WHERE id=?',(trade_id,)).fetchone()
        if not row: return None
        return dict(db_id=row['id'],backtest_id=row['backtest_id'],variant_id=row['variant_id'],
                    **json.loads(row['payload']))

    def group_trade_stats(self,variant_id):
        with self.lock:
            rows=self.db.execute('SELECT payload FROM backtest_trades WHERE variant_id=?',(variant_id,)).fetchall()
        groups={}
        for row in rows:
            t=json.loads(row['payload'])
            hr=t['entry_utc_hour']
            buckets={
                'Сессия (UTC)': ('00–05' if hr<6 else '06–11' if hr<12 else '12–17' if hr<18 else '18–23'),
                'Спред': ('< 0.20' if t['spread_at_entry']<0.20 else '0.20–0.30' if t['spread_at_entry']<=0.30 else '> 0.30'),
                'Тело сигнальной свечи': ('< 0.50' if t['signal_body']<0.50 else '0.50–1.50' if t['signal_body']<1.50 else '>= 1.50'),
            }
            for typ,value in buckets.items():
                key=(typ,value)
                if key not in groups:
                    groups[key]=dict(type=typ,bucket=value,trades=0,tp=0,sl=0,
                                     recovered=0,aborted=0,profitable_cycles=0,pnl_points=0)
                g=groups[key]
                g['trades']+=1
                g['profitable_cycles']+=(t.get('pnl_money_est') if t.get('pnl_money_est') is not None
                                         else t['pnl_points'])>1e-8
                g.setdefault(t['result'].lower(),0)
                g[t['result'].lower()]+=1
                g['pnl_points']+=t['pnl_points']
        return [dict(v,pnl_points=round(v['pnl_points'],3),
                     win_rate=round(100*v['profitable_cycles']/v['trades'],2))
                for _,v in sorted(groups.items())]

    def regimes(self,run_id,min_trades=20):
        """Exploratory conditional grid comparison. Training period ONLY.

        The grouping is based on attributes observed AT ENTRY (no future data).
        These groups are not causal or an automatically tradable regime model.
        """
        run=self.job(run_id)
        if run is None:
            return []
        train_until=run['config'].get('train_until_ms',run['end_ms'])
        variants={v['id']:v for v in self.variants(run_id)}
        aggregates={}
        with self.lock:
            cursor=self.db.execute('SELECT variant_id,payload FROM backtest_trades WHERE backtest_id=? ORDER BY id',(run_id,))
            for row in cursor:
                t=json.loads(row['payload'])
                if t['closed_ms']>=train_until:
                    continue
                hr=t['entry_utc_hour']
                conditions={
                    'Сессия UTC': '00–05' if hr<6 else '06–11' if hr<12 else '12–17' if hr<18 else '18–23',
                    'Спред при входе': '<0.20' if t['spread_at_entry']<.2 else '0.20–0.30' if t['spread_at_entry']<=.3 else '>0.30',
                    'Тело сигнальной M1': '<0.50' if t['signal_body']<.5 else '0.50–1.50' if t['signal_body']<1.5 else '≥1.50',
                }
                for group,bucket in conditions.items():
                    key=(group,bucket,row['variant_id'])
                    if key not in aggregates:
                        aggregates[key]=dict(n=0,tp=0,pnl=0.0)
                    a=aggregates[key]
                    a['n']+=1
                    a['tp']+=(t.get('pnl_money_est') if t.get('pnl_money_est') is not None
                              else t['pnl_points'])>1e-8
                    a['pnl']+=t['pnl_points']
        winners={}
        for (group,bucket,vid),score in aggregates.items():
            if score['n']<min_trades:continue
            key=(group,bucket)
            if key not in winners or score['pnl']>winners[key][1]['pnl']:
                winners[key]=(vid,score)
        result=[]
        for (group,bucket),(vid,score) in sorted(winners.items()):
            config=variants[vid]['config']
            result.append(dict(group=group,bucket=bucket,variant_id=vid,
                               trigger_distance=config['trigger_distance'],tp_distance=config['tp_distance'],
                               sl_distance=config['sl_distance'],trades=score['n'],
                               tp=score['tp'],win_rate=round(100*score['tp']/score['n'],2),
                               pnl_points=round(score['pnl'],5),min_trades=min_trades))
        return result

"""Long-running, read-only quote ingestion. The phone is only a remote web client."""
from __future__ import annotations

from dataclasses import asdict,replace
import os
from pathlib import Path
import threading
import time
from datetime import datetime,timezone

from .engine import PaperEngine,Settings
from .sources import MT5Quotes,DemoQuotes,SourceError
from .storage import Store
from .tickcache import TickArchive
from .backtest import Backtester


class AnalyzerService:
    def __init__(self,root:Path):
        self.data_source=os.getenv('DATA_SOURCE','mt5').lower()
        if self.data_source not in ('mt5','demo'):
            raise ValueError('DATA_SOURCE must be mt5 or demo')
        self.symbol=os.getenv('MT5_SYMBOL','XAUUSD.s') if self.data_source=='mt5' else 'SYNTHETIC-DEMO'
        self.source=(MT5Quotes(symbol=self.symbol, terminal_path=os.getenv('MT5_TERMINAL_PATH',''),
                               expected_login=os.getenv('MT5_EXPECTED_LOGIN',''),
                               time_offset_hours=os.getenv('MT5_TIME_OFFSET_HOURS','auto'))
                     if self.data_source=='mt5' else DemoQuotes())
        safe_name=''.join(x for x in self.symbol if x.isalnum() or x in '._-')
        self.data_path=Path(root)/f'{self.data_source}_{safe_name}'
        self.data_path.mkdir(parents=True,exist_ok=True)
        self.store=Store(self.data_path/'analyzer.sqlite3')
        saved=self.store.get_state('live_snapshot')
        if saved is None:
            # Fresh v1.3 project: no pre-v1.3 results to migrate later.
            self.store.set_state('recovery_v13_results_cleared',True)
        self.engine=PaperEngine.from_snapshot(saved) if saved else PaperEngine()
        # The old release did not verify broker timestamp offsets. Never keep an
        # active virtual cycle from that unknown timebase, or fill it hours later.
        self.data_quality_warning = ''
        if saved and self.data_source == 'mt5' and saved.get('timebase_version') != 2:
            if self.engine.mode != 'stopped' or self.engine.pending or self.engine.position:
                self.engine.force_stop()  # PAPER ONLY; never touches MT5 orders.
            self.engine.latest = None
            self.engine.candle = None
            self.engine.candles = []
            self.engine.last_tick_signature = None
            self.engine.arm_minute = None
            self.data_quality_warning = ('Старая виртуальная сессия остановлена: до исправления часы '
                                         'источника не были проверены. Предыдущие итоги могут быть неточными.')
        # Old tick cache could be indexed in the broker's clock, not UTC.
        self.archive=TickArchive(Path(root)/'cache_utc_v2',self.source,self.data_source)
        self.details=dict(symbol=self.symbol,tick_size=0.01,tick_value_per_lot=0.0,
                          account_login='DISCONNECTED')
        self.backtester=Backtester(self.archive,self.store,self.details)
        self.engine_lock=threading.RLock()
        self.stop_flag=threading.Event()
        self.worker=None
        self.connection_status='connecting'
        self.error=''
        self.last_connected_ms=0
        self.last_persist=0.0
        self.last_chart_read=0
        self.cached_chart=[]
        # Poll watermark may be ahead of the last tick during a quiet market.
        now_utc_ms=int(time.time()*1000)
        self.cursor_ms=(self.engine.latest.t_ms if self.engine.latest and
                        0 <= now_utc_ms-self.engine.latest.t_ms <= 120_000 else None)

    def start_worker(self):
        if self.worker and self.worker.is_alive():
            return
        self.worker=threading.Thread(target=self._run,name='LiveQuoteCollector',daemon=True)
        self.worker.start()

    def _run(self):
        while not self.stop_flag.is_set():
            try:
                details=self.source.symbol_details()
                with self.engine_lock:
                    self.details=details
                    self.backtester.details=details
                    if self.engine.settings.tick_size!=details['tick_size'] or (
                        self.engine.settings.tick_value_per_lot!=details['tick_value_per_lot']):
                        if self.engine.pending or self.engine.position or self.engine.recovery:
                            # Do not move levels of an active virtual cycle on reconnect.
                            pass
                        else:
                            self.engine.settings=replace(self.engine.settings,
                                tick_size=details['tick_size'],
                                tick_value_per_lot=details['tick_value_per_lot'])
                    self.connection_status='catching_up' if self.data_source=='mt5' else 'connected'
                    self.error=''
                break
            except Exception as exc:
                self.connection_status='disconnected'
                self.error=str(exc)
                self.stop_flag.wait(7)
        while not self.stop_flag.is_set():
            try:
                # Read a little behind wall-clock and replay a brief overlap:
                # historical tick publication may lag the visible terminal quote.
                now_ms=int(time.time()*1000)-1000
                if self.cursor_ms is None:
                    self.cursor_ms=now_ms-90_000
                # Work through outages in bounded time chunks; preserve tick order.
                lower=max(0,self.cursor_ms-3000)
                upper=min(now_ms,self.cursor_ms+45_000)
                if upper>lower:
                    ticks=self.source.range(lower,upper)
                    with self.engine_lock:
                        for tick in ticks:
                            self.engine.on_tick(tick)
                        self.last_connected_ms=int(time.time()*1000)
                    self.cursor_ms=upper
                    lag_ms=max(0,int(time.time()*1000)-self.cursor_ms)
                    self.connection_status='catching_up' if lag_ms>5000 and self.data_source=='mt5' else 'connected'
                    self.error=f'Восстановление тиков: отставание {round(lag_ms/1000)} сек.' if self.connection_status=='catching_up' else ''
                now=time.monotonic()
                if now-self.last_persist>3:
                    self.persist()
                    self.last_persist=now
                if self.cursor_ms >= now_ms-1000:
                    self.stop_flag.wait(0.7)
            except Exception as exc:
                self.connection_status='disconnected'
                self.error=str(exc)
                self.stop_flag.wait(5)
                try:
                    self.source.connected=False  # reconnect after terminal restart
                except Exception:
                    pass
                try:
                    self.source.connect()
                except Exception:
                    pass
        self.persist()

    def persist(self):
        with self.engine_lock:
            # Keep DB writes under the engine lock so two thread snapshots cannot
            # be written in reverse order, losing a recently opened position.
            snapshot=self.engine.to_snapshot()
            snapshot['timebase_version']=2
            self.store.save_live(snapshot,self.engine.new_trades[:])
            self.engine.new_trades.clear()
            self.engine.new_events.clear()

    def status(self):
        with self.engine_lock:
            result=self.engine.public_state()
            now_ms=int(time.time()*1000)
            quote_ms=self.engine.latest.t_ms if self.engine.latest else None
            lot_warning=''
            if self.data_source=='mt5' and self.engine.settings.recovery_enabled:
                vmin=float(self.details.get('volume_min') or 0)
                step=float(self.details.get('volume_step') or 0)
                lots=[self.engine.settings.volume_lots,
                      self.engine.settings.recovery_core_lots,
                      self.engine.settings.recovery_reentry_lots,
                      self.engine.settings.recovery_hedge_lots]
                invalid=[v for v in lots if (vmin>0 and v < vmin-1e-8) or
                         (step>0 and abs(round(v/step)*step-v)>1e-8)]
                if invalid:
                    lot_warning=('Внимание: объёмы RECOVERY не соответствуют минимальному лоту '
                                 f'или шагу {self.symbol}: min={vmin}, step={step}, '
                                 f'некорректные={invalid}. Это только виртуальный тест.')
            result.update(source=self.data_source, symbol=self.symbol, details=self.details,
                          recovery_volume_warning=lot_warning,
                          connection=self.connection_status,error=self.error,
                          last_contact_ms=self.last_connected_ms,
                          quote_age_seconds=round((now_ms-quote_ms)/1000,1) if quote_ms else None,
                          data_quality_warning=self.data_quality_warning)
            return result

    def chart(self):
        """Canonical UTC M1 bars, extended with the *same ticks* as simulation.

        MT5 broker OHLC are authoritative for older bars. Recent bars are
        patched from the live normalized Bid feed. A broker server-clock bar
        in the future is not allowed to displace the real current candle.
        """
        now=time.monotonic()
        if self.data_source=='mt5' and now-self.last_chart_read>15:
            try:
                self.cached_chart=self.source.chart(520)
                self.last_chart_read=now
            except Exception as exc:
                # Keep a coherent previous chart; diagnostics remain visible.
                self.error = str(exc)
        with self.engine_lock:
            latest=self.engine.latest
            now_ms=int(time.time()*1000)
            local=self.engine.chart_candles(520)
            if latest is None or abs(now_ms-latest.t_ms)>90_000:
                local=[]
            if self.data_source=='demo':
                merged={int(c['time']):dict(c) for c in self.source.chart(520)}
            else:
                merged={int(c['time']):dict(c) for c in self.cached_chart}
            utc_min=(now_ms//60000)*60
            # Include no future-dated bars. Doing so previously made the
            # live Bid/Ask float above an unrelated block of candles.
            merged={minute:bar for minute,bar in merged.items() if minute <= utc_min + 60}
            for c in local:
                minute=int(c['time'])
                if minute>utc_min+60:
                    continue
                old=merged.get(minute)
                if old is None:
                    merged[minute]=dict(c)
                else:
                    merged[minute]={**old,'high':max(float(old['high']),c['high']),
                                    'low':min(float(old['low']),c['low']),
                                    'close':c['close']}
            return [merged[k] for k in sorted(merged)[-520:]]

    def update_settings(self,setting:Settings):
        with self.engine_lock:
            if self.engine.pending or self.engine.position or self.engine.recovery:
                raise ValueError('Finish or force-stop current virtual cycle before changing settings')
            self.engine.settings=setting
        self.persist()

    def control(self,action:str):
        with self.engine_lock:
            if action=='start':
                if self.data_source=='mt5' and self.connection_status!='connected':
                    raise ValueError('MT5 is not ready or restoring tick history; start after quotes synchronize')
                self.engine.start()
                # If market was closed for hours/days, do not use Friday's last
                # incomplete bar as the first signal when pressing /start on Sunday.
                if self.data_source=='mt5':
                    utc_minute=(int(time.time())//60)*60
                    if self.engine.arm_minute is None or self.engine.arm_minute<utc_minute:
                        self.engine.arm_minute=utc_minute
            elif action=='stop':
                self.engine.request_stop()
            elif action=='force_stop':
                self.engine.force_stop()
            else:
                raise ValueError('Unknown action')
        self.persist()
        return self.status()

    def shutdown(self):
        self.stop_flag.set()
        if self.worker:
            self.worker.join(timeout=3)
        self.persist()

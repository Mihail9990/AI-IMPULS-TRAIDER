"""Deterministic, tick-driven paper trading engine. Contains ZERO broker trade calls.

All input timestamps are Unix milliseconds UTC; candles use BID; executions use ASK
for buys and BID for sells, exits in the opposite quote. Historical and live modes
both drive this exact same engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from math import ceil, floor, isfinite
from typing import Any, Optional


@dataclass(frozen=True)
class Settings:
    trigger_distance: float = 1.0
    tp_distance: float = 0.25
    sl_distance: float = 3.0
    tick_size: float = 0.01
    volume_lots: float = 0.10
    tick_value_per_lot: float = 0.0  # currency value of 1 tick for ONE lot; 0 = unknown
    commission_per_lot_roundtrip: float = 0.0
    # Opt-in: old saved projects stay in the original SL/TP mode after upgrade.
    recovery_enabled: bool = False
    recovery_core_lots: float = 0.01   # legacy v1.2, initial size matched to volume_lots
    recovery_reentry_lots: float = 0.12
    recovery_hedge_lots: float = 0.13  # legacy v1.2, unused in v1.3
    recovery_partial_stop_distance: float = 1.0  # LEGACY v1.2 (ignored by v1.3)
    recovery_trail_activation: float = 0.50
    recovery_trail_start_offset: float = 0.50
    recovery_trail_step: float = 0.10
    recovery_partial_lots: float = 0.03
    recovery_take_levels: tuple[float, float, float] = (1.0, 2.0, 3.0)

    def __post_init__(self):
        for name in ('trigger_distance', 'tp_distance', 'sl_distance', 'tick_size', 'volume_lots'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        for name in ('tick_value_per_lot', 'commission_per_lot_roundtrip'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n < 0:
                raise ValueError(f'{name} must be finite and >= 0')
        if not isinstance(self.recovery_enabled, bool):
            raise ValueError('recovery_enabled must be boolean')
        for name in ('recovery_core_lots','recovery_reentry_lots',
                     'recovery_hedge_lots','recovery_partial_stop_distance',
                     'recovery_trail_activation','recovery_trail_start_offset',
                     'recovery_trail_step','recovery_partial_lots'):
            n = getattr(self,name)
            if not isinstance(n,(int,float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        if self.recovery_enabled:
            if abs(self.volume_lots-self.recovery_core_lots)>1e-8:
                raise ValueError('RECOVERY: initial volume_lots must equal recovery_core_lots')
            if not (self.recovery_reentry_lots > 3*self.recovery_partial_lots+1e-8):
                raise ValueError('RECOVERY: volume must leave a positive runner after 3 partial TP tranches')
            if len(self.recovery_take_levels)!=3 or any(not isfinite(x) or x<=0 for x in self.recovery_take_levels):
                raise ValueError('RECOVERY: need 3 positive partial TP distances')
            if list(self.recovery_take_levels)!=sorted(set(self.recovery_take_levels)):
                raise ValueError('RECOVERY: partial TP levels must be increasing')
            if self.recovery_trail_activation>=self.recovery_take_levels[0]:
                raise ValueError('RECOVERY: trailing must activate before first partial TP')
            if self.commission_per_lot_roundtrip and not self.tick_value_per_lot:
                raise ValueError('RECOVERY with commission requires positive tick_value_per_lot')


@dataclass(frozen=True)
class Tick:
    t_ms: int
    bid: float
    ask: float

    def __post_init__(self):
        if not isinstance(self.t_ms, int) or self.t_ms < 0:
            raise ValueError('Invalid timestamp')
        if not all(isfinite(x) and x > 0 for x in (self.bid, self.ask)) or self.ask < self.bid:
            raise ValueError('Invalid Bid/Ask quote')


@dataclass
class Candle:
    time: int  # minute start in UNIX seconds UTC
    open: float
    high: float
    low: float
    close: float
    ticks: int = 1

    @property
    def color(self) -> str:
        return 'BUY' if self.close > self.open else ('SELL' if self.close < self.open else 'DOJI')

    def on_tick(self, bid: float):
        self.high = max(self.high, bid)
        self.low = min(self.low, bid)
        self.close = bid
        self.ticks += 1


@dataclass
class Pending:
    side: str
    level: float
    created_ms: int
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str


@dataclass
class Position:
    side: str
    entry: float
    tp: float
    sl: float
    opened_ms: int
    trigger_level: float
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str
    entry_spread: float
    mfe: float = 0.0
    mae: float = 0.0


@dataclass
class RecoveryLeg:
    side: str
    entry: float
    lots: float
    opened_ms: int
    role: str
    stop: float
    tp: Optional[float] = None  # FIXED-TP first RECOVERY phase only
    peak_favorable: float = 0.0
    trail_step_index: int = -1  # -1 = initial SL, 0 = trailing activated
    next_take_index: int = 0


@dataclass
class RecoveryState:
    started_ms: int
    origin: Position  # original position is already CLOSED at initial SL
    original_sl_exit: float
    buy_anchor: float
    sell_anchor: float
    active: Optional[RecoveryLeg]
    pending_stops: list[dict] = field(default_factory=list)
    # Closed initial loss and later realized recovery losses/profit.
    realized_weighted_points: float = 0.0
    realized_commission_money: float = 0.0
    partial_tps: int = 0
    fixed_tps: int = 0
    stepped_mode: bool = False  # Activate only after a RECOVERY 0.12 SL
    recovery_sls: int = 0
    reentries: int = 0
    max_loss_points: float = 0.0
    actions: list[dict] = field(default_factory=list)
    truncated_actions: int = 0


class PaperEngine:
    def __init__(self, settings: Settings = Settings()):
        self.settings = settings
        self.mode = 'stopped'  # stopped | running | stopping
        self.arm_minute: Optional[int] = None
        self.candle: Optional[Candle] = None
        self.candles: list[dict] = []
        self.pending: Optional[Pending] = None
        self.position: Optional[Position] = None
        self.recovery: Optional[RecoveryState] = None
        self.recovery_activations = 0
        self.recovery_completed = 0
        self.recovery_partial_stops = 0  # retained in JSON for compatibility: counts RECOVERY SLs
        self.recovery_partial_tps = 0
        self.recovery_fixed_tps = 0
        self.recovery_reentries = 0
        self.recovery_sls = 0
        self.recovery_aborted = 0
        self.realized_cycle_points = 0.0
        self.max_active_recovery_loss_points = 0.0
        self.equity_peak_points = 0.0
        self.max_equity_drawdown_points = 0.0
        self.min_equity_points = 0.0
        self.latest: Optional[Tick] = None
        self.last_tick_signature: Optional[tuple] = None
        self.trade_seq = 0
        self.order_seq = 0
        self.trades: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.new_trades: list[dict[str, Any]] = []
        self.new_events: list[dict[str, Any]] = []
        self.canceled_orders = 0
        self.placed_orders = 0
        self.triggered_orders = 0
        self.skipped_invalid = 0
        self.tick_count = 0
        self.first_tick_ms: Optional[int] = None
        self.max_tick_gap_ms = 0

    def _level(self, p: float, higher: bool) -> float:
        """Snap protective/entry target outward to the symbol's tick grid."""
        tick = self.settings.tick_size
        scale = p / tick
        snapped = (ceil(scale - 1e-8) if higher else floor(scale + 1e-8)) * tick
        return round(snapped, 10)

    def _event(self, t_ms: int, typ: str, **extra):
        row = dict(t_ms=t_ms, type=typ, **extra)
        self.events.append(row)
        self.new_events.append(row)
        if len(self.events) > 250:
            self.events = self.events[-250:]

    def start(self) -> None:
        if self.mode != 'stopped':
            raise ValueError('Session is already running')
        self.mode = 'running'
        self.arm_minute = self.candle.time if self.candle else None
        self.pending = None
        self.position = None
        self.recovery = None
        self._event(self.latest.t_ms if self.latest else 0, 'start')

    def request_stop(self) -> None:
        """Finish the existing cycle (including waiting for a pending trigger)."""
        if self.mode == 'running':
            if self.pending is None and self.position is None and self.recovery is None:
                self.mode = 'stopped'
            else:
                self.mode = 'stopping'
            self._event(self.latest.t_ms if self.latest else 0, 'stop_requested')

    def force_stop(self) -> None:
        """Abandon virtual pending/position (not an SL/TP)."""
        if self.pending:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_cancel', side=self.pending.side, price=self.pending.level)
        if self.recovery and self.latest:
            # Aborted simulated baskets must be accounted as losses, not erased.
            self._end_recovery(self.latest, 'ABORTED')
            self.recovery_aborted += 1
        elif self.position:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_abandon', side=self.position.side, price=self.position.entry)
        self.mode = 'stopped'
        self.pending = None
        self.position = None
        self.recovery = None
        self._event(self.latest.t_ms if self.latest else 0, 'forced_stop')

    def _create_pending(self, bar: Candle, t_ms: int):
        side = bar.color
        if side == 'DOJI':
            return
        delta = self.settings.trigger_distance
        level = self._level(bar.close + delta if side == 'BUY' else bar.close - delta, side == 'BUY')
        if self.pending and self.pending.side == side:
            return
        if self.pending:
            self.canceled_orders += 1
            self._event(t_ms, 'cancel', side=self.pending.side, price=self.pending.level,
                        reason='opposite_closed_candle')
        self.pending = Pending(side, level, t_ms, bar.time, abs(bar.close-bar.open),
                               bar.high-bar.low, side)
        self.placed_orders += 1
        self.order_seq += 1
        self._event(t_ms, 'place', side=side, price=level, signal_time=bar.time)

    def _finish_bar(self, bar: Candle, t_ms: int):
        self.candles.append(asdict(bar))
        if len(self.candles) > 750:
            self.candles = self.candles[-750:]
        if self.mode in ('running', 'stopping') and self.position is None and self.recovery is None:
            if self.arm_minute is not None and bar.time < self.arm_minute:
                return
            self._create_pending(bar, t_ms)

    def _fill(self, tick: Tick):
        p = self.pending
        if p is None:
            return
        if p.side == 'BUY':
            if tick.ask < p.level:
                return
            fill = max(p.level, tick.ask)  # adverse gap/trigger slippage
            tp = self._level(fill + self.settings.tp_distance, True)
            sl = self._level(fill - self.settings.sl_distance, False)
        else:
            if tick.bid > p.level:
                return
            fill = min(p.level, tick.bid)
            tp = self._level(fill - self.settings.tp_distance, False)
            sl = self._level(fill + self.settings.sl_distance, True)
        self.position = Position(p.side, fill, tp, sl, tick.t_ms, p.level, p.signal_time,
                                 p.signal_body, p.signal_range, p.signal_color,
                                 tick.ask - tick.bid)
        self.pending = None
        self.triggered_orders += 1
        self._event(tick.t_ms, 'fill', side=p.side, price=fill, trigger_level=p.level,
                    tp=tp, sl=sl, spread=tick.ask-tick.bid)

    def _position_tick(self, tick: Tick):
        pos = self.position
        if pos is None:
            return
        if self.recovery is not None:
            self._recovery_tick(tick)
            return
        if self.settings.recovery_enabled:
            self._pre_recovery_tick(tick)
            return
        # Mark to market on the quote that actually CLOSES the position.
        exit_quote = tick.bid if pos.side == 'BUY' else tick.ask
        move = exit_quote - pos.entry if pos.side == 'BUY' else pos.entry - exit_quote
        pos.mfe = max(pos.mfe, move)
        pos.mae = max(pos.mae, -move)
        if pos.side == 'BUY':
            result = 'SL' if tick.bid <= pos.sl else ('TP' if tick.bid >= pos.tp else None)
            exit_price = min(pos.sl, tick.bid) if result == 'SL' else pos.tp
        else:
            result = 'SL' if tick.ask >= pos.sl else ('TP' if tick.ask <= pos.tp else None)
            exit_price = max(pos.sl, tick.ask) if result == 'SL' else pos.tp
        if result is None:
            return
        points = exit_price - pos.entry if pos.side == 'BUY' else pos.entry - exit_price
        gap_to_tp = max(0.0, abs(pos.tp-pos.entry)-pos.mfe)
        money = None
        if self.settings.tick_value_per_lot > 0:
            money = (points/self.settings.tick_size*self.settings.tick_value_per_lot
                     - self.settings.commission_per_lot_roundtrip) * self.settings.volume_lots
        self.trade_seq += 1
        trade = dict(
            id=self.trade_seq, side=pos.side, result=result, opened_ms=pos.opened_ms,
            closed_ms=tick.t_ms, entry=pos.entry, exit=round(exit_price, 10),
            tp=pos.tp, sl=pos.sl, trigger_level=pos.trigger_level,
            pnl_points=round(points, 10), pnl_money_est=round(money, 5) if money is not None else None,
            mfe_points=round(pos.mfe, 10), mae_points=round(pos.mae, 10),
            gap_to_tp=round(gap_to_tp, 10), duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
            signal_time=pos.signal_time, signal_body=round(pos.signal_body, 6),
            signal_range=round(pos.signal_range, 6), signal_color=pos.signal_color,
            spread_at_entry=round(pos.entry_spread, 10),
            entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000, timezone.utc).hour,
        )
        self.trades.append(trade)
        self.new_trades.append(trade)
        self.realized_cycle_points += trade['pnl_points']
        self._event(tick.t_ms, result.lower(), side=pos.side, price=exit_price, trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'], gap_to_tp=trade['gap_to_tp'])
        self.position = None
        self._next_cycle_after_close(tick)

    def _next_cycle_after_close(self, tick: Tick):
        if self.mode == 'stopping':
            self.mode = 'stopped'
            self.arm_minute = None
        else:
            # First complete candle ending AFTER the current tick can arm a new STOP.
            self.arm_minute = (tick.t_ms // 60000) * 60

    def _close_quote(self, side: str, tick: Tick) -> float:
        return tick.bid if side == 'BUY' else tick.ask

    def _weighted_move(self, leg: RecoveryLeg, price: float) -> float:
        return (price-leg.entry if leg.side == 'BUY' else leg.entry-price)*leg.lots

    def _recovery_ledger(self, tick: Tick, typ: str, **kwargs):
        r=self.recovery
        if r is None:return
        action=dict(t_ms=tick.t_ms,type=typ,**kwargs)
        if len(r.actions)<500:r.actions.append(action)
        else:r.truncated_actions+=1
        self._event(tick.t_ms,typ,**kwargs)

    def _recovery_net(self, tick: Tick) -> tuple[float, Optional[float]]:
        r=self.recovery
        if not r:return 0.0,None
        live=(self._weighted_move(r.active,self._close_quote(r.active.side,tick))
              if r.active else 0.0)
        weighted=r.realized_weighted_points+live
        cash=None
        if self.settings.tick_value_per_lot>0:
            fees=r.realized_commission_money + (
                r.active.lots*self.settings.commission_per_lot_roundtrip if r.active else 0.0)
            cash=weighted/self.settings.tick_size*self.settings.tick_value_per_lot-fees
        return weighted,cash

    def _recovery_target_met(self,tick:Tick)->bool:
        weighted,cash=self._recovery_net(tick)
        return cash>=-1e-8 if cash is not None else weighted>=-1e-9

    def _open_recovery_leg(self, tick: Tick, side: str, entry: float, initial: bool):
        r=self.recovery
        if r is None:return
        stop=self._level(entry-self.settings.sl_distance if side=='BUY' else entry+self.settings.sl_distance,
                         side=='SELL')
        # The first 0.12 phase uses a fixed TP 0.25 and NO trailing/partials.
        # Only an actual SL of a 0.12 position enables stepped RECOVERY.
        fixed_tp = not r.stepped_mode
        take=(self._level(entry+self.settings.tp_distance if side=='BUY' else
                          entry-self.settings.tp_distance,side=='BUY') if fixed_tp else None)
        r.active=RecoveryLeg(side,entry,self.settings.recovery_reentry_lots,tick.t_ms,
                             'fixed_tp' if fixed_tp else 'stepped',stop,tp=take)
        r.pending_stops=[]  # OCO: other virtual trigger canceled upon fill.
        if not initial:
            r.reentries+=1;self.recovery_reentries+=1
        self._recovery_ledger(tick,'recovery_first_fill' if initial else 'recovery_reentry',
                              side=side,price=entry,lots=r.active.lots,sl=stop,
                              tp=take,phase='fixed_tp' if fixed_tp else 'stepped')

    def _start_recovery(self,tick:Tick):
        """First real (virtual) initial SL; next RECOVERY order is a PENDING STOP.

        Same-tick fill is disallowed. Stop orders placed after a price has already
        crossed their level may not be valid at a real broker. This is paper
        modeling, with the fill performed on a future tick only.
        """
        pos=self.position
        if pos is None or self.recovery:return
        side=pos.side
        crossed=tick.bid<=pos.sl if side=='BUY' else tick.ask>=pos.sl
        if not crossed:return
        exit_price=min(pos.sl,tick.bid) if side=='BUY' else max(pos.sl,tick.ask)
        weighted=(exit_price-pos.entry if side=='BUY' else pos.entry-exit_price)*self.settings.volume_lots
        r=RecoveryState(started_ms=tick.t_ms,origin=pos,original_sl_exit=exit_price,
                        buy_anchor=pos.entry if side=='BUY' else exit_price,
                        sell_anchor=pos.entry if side=='SELL' else exit_price,
                        active=None,realized_weighted_points=weighted,
                        realized_commission_money=(self.settings.volume_lots*
                            self.settings.commission_per_lot_roundtrip))
        self.recovery=r
        self.position=None  # initial SL truly closes position, unlike v1.2 hedge
        recovery_side='SELL' if side=='BUY' else 'BUY'
        r.pending_stops=[dict(side=recovery_side,level=exit_price,
                              lots=self.settings.recovery_reentry_lots,armed=True)]
        self.recovery_activations+=1
        self._recovery_ledger(tick,'recovery_start',side=side,price=exit_price,
                              initial_sl_weighted=weighted,pending_side=recovery_side,
                              recovery_trigger=exit_price)

    def _pre_recovery_tick(self,tick:Tick):
        pos=self.position
        if pos is None:return
        quote=self._close_quote(pos.side,tick)
        move=(quote-pos.entry if pos.side=='BUY' else pos.entry-quote)
        pos.mfe=max(pos.mfe,move)
        pos.mae=max(pos.mae,-move)
        # Both TP and SL use liquidation quote (BUY Bid, SELL Ask).
        if (pos.side=='BUY' and tick.bid>=pos.tp or
                pos.side=='SELL' and tick.ask<=pos.tp):
            self._close_initial_tp(tick)
        else:
            self._start_recovery(tick)

    def _close_initial_tp(self,tick:Tick):
        pos=self.position
        if not pos:return
        close=pos.tp
        points=(close-pos.entry if pos.side=='BUY' else pos.entry-close)
        cash=None
        if self.settings.tick_value_per_lot>0:
            cash=(points/self.settings.tick_size*self.settings.tick_value_per_lot-
                  self.settings.commission_per_lot_roundtrip)*self.settings.volume_lots
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=pos.side,result='TP',opened_ms=pos.opened_ms,
                   closed_ms=tick.t_ms,entry=pos.entry,exit=close,tp=pos.tp,sl=pos.sl,
                   trigger_level=pos.trigger_level,pnl_points=round(points,10),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=round(pos.mfe,10),mae_points=round(pos.mae,10),
                   gap_to_tp=0.0,duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
                   signal_time=pos.signal_time,signal_body=round(pos.signal_body,6),
                   signal_range=round(pos.signal_range,6),signal_color=pos.signal_color,
                   spread_at_entry=round(pos.entry_spread,10),
                   entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000,timezone.utc).hour,
                   recovery_used=False,recovery_actions=[],recovery_partial_stops=0,
                   recovery_partial_tps=0,recovery_reentries=0)
        self.trades.append(trade);self.new_trades.append(trade)
        self.realized_cycle_points+=trade['pnl_points']
        self._event(tick.t_ms,'tp',side=pos.side,price=close,trade_id=self.trade_seq)
        self.position=None
        self._next_cycle_after_close(tick)

    def _recovery_close_lots(self,tick:Tick,lots:float,typ:str,execution_price:Optional[float]=None):
        r=self.recovery
        if not r or not r.active:return
        active=r.active
        lots=min(lots,active.lots)
        quote=(self._close_quote(active.side,tick) if execution_price is None else execution_price)
        weighted=(quote-active.entry if active.side=='BUY' else active.entry-quote)*lots
        r.realized_weighted_points+=weighted
        r.realized_commission_money+=lots*self.settings.commission_per_lot_roundtrip
        active.lots=round(active.lots-lots,8)
        self._recovery_ledger(tick,typ,side=active.side,price=quote,lots=lots,
                              weighted=round(weighted,8),remaining_lots=active.lots)
        if active.lots<=1e-8:r.active=None

    def _recovery_trail_update(self,tick:Tick):
        r=self.recovery
        if not r or not r.active:return
        p=r.active
        q=self._close_quote(p.side,tick)
        favourable=q-p.entry if p.side=='BUY' else p.entry-q
        p.peak_favorable=max(p.peak_favorable,favourable)
        activate=self.settings.recovery_trail_activation
        if favourable+1e-9<activate:return
        i=max(0,floor((p.peak_favorable-activate+1e-8)/self.settings.recovery_trail_step))
        if i<=p.trail_step_index:return
        offset=self.settings.recovery_trail_start_offset
        raw=(p.entry-offset+i*self.settings.recovery_trail_step if p.side=='BUY' else
             p.entry+offset-i*self.settings.recovery_trail_step)
        new_stop=self._level(raw,p.side=='SELL')
        p.stop=max(p.stop,new_stop) if p.side=='BUY' else min(p.stop,new_stop)
        p.trail_step_index=i
        self._recovery_ledger(tick,'recovery_trail',side=p.side,price=p.stop,
                              step=i,peak_favorable=round(p.peak_favorable,7))

    def _recovery_reset_triggers(self,tick:Tick):
        r=self.recovery
        if not r:return
        # Both STOP directions, anchored at the observed BEST price reached on
        # that side and at the opposite side's prior entry/extreme.
        # Mark armed only after price trades on the valid side of trigger.
        r.pending_stops=[dict(side='BUY',level=r.buy_anchor,lots=self.settings.recovery_reentry_lots,
                              armed=tick.ask < r.buy_anchor-1e-9),
                         dict(side='SELL',level=r.sell_anchor,lots=self.settings.recovery_reentry_lots,
                              armed=tick.bid > r.sell_anchor+1e-9)]
        self._recovery_ledger(tick,'recovery_oco_placed',buy_level=r.buy_anchor,
                              sell_level=r.sell_anchor)

    def _recovery_tick(self,tick:Tick):
        r=self.recovery
        if r is None:return
        weighted,cash=self._recovery_net(tick)
        r.max_loss_points=max(r.max_loss_points,-weighted/self.settings.volume_lots)
        self.max_active_recovery_loss_points=max(self.max_active_recovery_loss_points,r.max_loss_points)
        active=r.active
        if active and active.role=='fixed_tp':
            quote=self._close_quote(active.side,tick)
            sl_hit=(quote<=active.stop if active.side=='BUY' else quote>=active.stop)
            tp_hit=(quote>=active.tp if active.side=='BUY' else quote<=active.tp)
            # Fixed TP has priority on its own favorable tick; no first-phase trailing.
            if sl_hit:
                self._recovery_close_lots(tick,active.lots,'recovery_sl')
                r.recovery_sls+=1;self.recovery_sls+=1
                self.recovery_partial_stops+=1
                r.stepped_mode=True
                self._recovery_ledger(tick,'recovery_stepped_activated',after='first_recovery_sl')
                self._recovery_reset_triggers(tick)
                return
            if tp_hit:
                # A take-profit limit is modeled at its TP price, while stop
                # gaps always use the adverse executable quote.
                self._recovery_close_lots(tick,active.lots,'recovery_fixed_tp',
                                          execution_price=active.tp)
                r.fixed_tps+=1;self.recovery_fixed_tps+=1
                # Fixed TP ends the ENTIRE cycle, regardless of whether it
                # reimbursed the initial SL. The remaining deficit is realized
                # in the cumulative global P/L, not carried to new RECOVERY.
                self._end_recovery(tick,'RECOVERY_TP')
                return
            # The first 0.12 leg stays on fixed TP / SL exclusively; no
            # stepped trailing or net-P/L early liquidation before TP or SL.
            return
        if self._recovery_target_met(tick):
            self._end_recovery(tick,'RECOVERED')
            return
        if active:
            quote=self._close_quote(active.side,tick)
            stop_hit=(quote<=active.stop if active.side=='BUY' else quote>=active.stop)
            if stop_hit:
                # In adverse gaps the exit is not guaranteed at old SL exactly.
                if active.side=='BUY':
                    r.buy_anchor=max(r.buy_anchor,active.entry+max(active.peak_favorable,0))
                else:
                    r.sell_anchor=min(r.sell_anchor,active.entry-max(active.peak_favorable,0))
                self._recovery_close_lots(tick,active.lots,'recovery_sl')
                r.recovery_sls+=1;self.recovery_sls+=1
                self.recovery_partial_stops+=1  # deprecated field for older UI clients
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                else:
                    self._recovery_reset_triggers(tick)
                return
            self._recovery_trail_update(tick)
            if not r.active:return
            for i,level in enumerate(self.settings.recovery_take_levels):
                p=r.active
                if p is None or i<p.next_take_index:continue
                profit=self._close_quote(p.side,tick)-p.entry if p.side=='BUY' else p.entry-self._close_quote(p.side,tick)
                if profit+1e-8<level:break
                # Guard each take index; if gaps jump 1→3 all three close at the
                # next executable quote (not at invented intermediate prints).
                p.next_take_index=i+1
                self._recovery_close_lots(tick,self.settings.recovery_partial_lots,'recovery_partial_tp')
                r.partial_tps+=1;self.recovery_partial_tps+=1
                if self._recovery_target_met(tick):
                    self._end_recovery(tick,'RECOVERED')
                    return
            return
        if not r.pending_stops:
            self._recovery_reset_triggers(tick)
            return
        hits=[]
        for p in r.pending_stops:
            # STOP level must be armed from its valid side. Initial recovery
            # trigger is pre-armed at SL for transition, but only fills NEXT tick.
            if not p.get('armed'):
                if p['side']=='BUY' and tick.ask < p['level']-1e-9:
                    p['armed']=True
                elif p['side']=='SELL' and tick.bid > p['level']+1e-9:
                    p['armed']=True
            elif ((p['side']=='BUY' and tick.ask>=p['level']) or
                  (p['side']=='SELL' and tick.bid<=p['level'])):
                hits.append(p)
        if len(hits)>1:
            self._recovery_ledger(tick,'recovery_ambiguous_spread',bid=tick.bid,ask=tick.ask)
            return
        if len(hits)==1:
            p=hits[0]
            entry=(max(p['level'],tick.ask) if p['side']=='BUY' else
                   min(p['level'],tick.bid))
            self._open_recovery_leg(tick,p['side'],entry,
                initial=r.reentries==0 and r.fixed_tps==0 and r.recovery_sls==0)

    def _end_recovery(self,tick:Tick,result:str):
        r=self.recovery
        if r is None:return
        weighted,cash=self._recovery_net(tick)
        origin=r.origin
        if r.active:
            # Entire remaining runner is liquidated at executable Bid/Ask.
            self._recovery_close_lots(tick,r.active.lots,'recovery_flatten')
        points=weighted/self.settings.volume_lots
        self.trade_seq+=1
        trade=dict(id=self.trade_seq,side=origin.side,result=result,opened_ms=origin.opened_ms,
                   closed_ms=tick.t_ms,entry=origin.entry,exit=r.original_sl_exit,
                   tp=origin.tp,sl=origin.sl,trigger_level=origin.trigger_level,
                   pnl_points=round(points,10),pnl_weighted_points_lots=round(weighted,10),
                   pnl_money_est=round(cash,5) if cash is not None else None,
                   mfe_points=round(origin.mfe,10),mae_points=round(origin.mae,10),
                   gap_to_tp=round(max(0.,abs(origin.tp-origin.entry)-origin.mfe),10),
                   duration_seconds=round((tick.t_ms-origin.opened_ms)/1000,3),
                   signal_time=origin.signal_time,signal_body=round(origin.signal_body,6),
                   signal_range=round(origin.signal_range,6),signal_color=origin.signal_color,
                   spread_at_entry=round(origin.entry_spread,10),
                   entry_utc_hour=datetime.fromtimestamp(origin.opened_ms/1000,timezone.utc).hour,
                   recovery_used=True,recovery_actions=r.actions[:],
                   recovery_actions_truncated=r.truncated_actions,
                   recovery_partial_stops=r.recovery_sls,recovery_partial_tps=r.partial_tps,
                   recovery_fixed_tps=r.fixed_tps,
                   recovery_reentries=r.reentries,recovery_max_loss_points=round(r.max_loss_points,7),
                   unrecovered_loss_points=round(min(0.,points),10),
                   unrecovered_loss_money_est=round(min(0.,cash),5) if cash is not None else None,
                   buy_anchor=r.buy_anchor,sell_anchor=r.sell_anchor)
        self.trades.append(trade);self.new_trades.append(trade)
        self.realized_cycle_points+=trade['pnl_points']
        if result=='RECOVERED':self.recovery_completed+=1
        event_type=('recovery_complete' if result=='RECOVERED' else
                    'recovery_fixed_cycle_complete' if result=='RECOVERY_TP' else 'recovery_aborted')
        self._event(tick.t_ms,event_type,trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'],pnl_money_est=trade['pnl_money_est'],
                    unrecovered_loss_points=trade['unrecovered_loss_points'])
        self.position=None;self.recovery=None
        self._next_cycle_after_close(tick)

    def _equity_points(self, tick: Optional[Tick] = None) -> float:
        closed=self.realized_cycle_points
        now=tick or self.latest
        if now is None:return closed
        if self.recovery:
            raw,_=self._recovery_net(now)
            return closed+raw/self.settings.volume_lots
        if self.position:
            pos=self.position
            quote=self._close_quote(pos.side,now)
            move=quote-pos.entry if pos.side=='BUY' else pos.entry-quote
            return closed+move
        return closed

    def _track_equity(self):
        if self.latest is None:return
        equity=self._equity_points(self.latest)
        self.equity_peak_points=max(self.equity_peak_points,equity)
        self.min_equity_points=min(self.min_equity_points,equity)
        self.max_equity_drawdown_points=max(self.max_equity_drawdown_points,
                                            self.equity_peak_points-equity)

    def on_tick(self, tick: Tick):
        if self.last_tick_signature == (tick.t_ms,tick.bid,tick.ask):
            return
        if self.latest and tick.t_ms < self.latest.t_ms:
            self.skipped_invalid += 1
            return
        if self.latest:
            self.max_tick_gap_ms = max(self.max_tick_gap_ms, tick.t_ms-self.latest.t_ms)
        else:
            self.first_tick_ms = tick.t_ms
        self.last_tick_signature = (tick.t_ms,tick.bid,tick.ask)
        self.latest = tick
        self.tick_count += 1
        minute = (tick.t_ms // 60000) * 60
        if self.candle is None:
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            if self.mode == 'running' and self.arm_minute is None:
                self.arm_minute = minute
        elif minute != self.candle.time:
            # The old STOP still exists at the *first tick* of a new minute.
            # Broker may execute it before our simulated cancel/replace request.
            if self.mode in ('running', 'stopping') and self.pending is not None and self.position is None and self.recovery is None:
                self._fill(tick)
                filled_on_boundary = self.position is not None
            else:
                filled_on_boundary = False
            old = self.candle
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            self._finish_bar(old,tick.t_ms)
            if filled_on_boundary:
                self._position_tick(tick)
                self._track_equity()
                return
        else:
            self.candle.on_tick(tick.bid)
        if self.mode in ('running', 'stopping'):
            if self.recovery:
                self._recovery_tick(tick)
            elif self.position:
                self._position_tick(tick)
            elif self.pending:
                self._fill(tick)
                # No same-tick exit for freshly filled position.
        self._track_equity()

    def summary(self) -> dict:
        trades=self.trades
        tp=sum(t['result']=='TP' for t in trades)
        sl=sum(t['result']=='SL' for t in trades)
        recovered=sum(t['result']=='RECOVERED' for t in trades)
        recovery_tp_cycles=sum(t['result']=='RECOVERY_TP' for t in trades)
        recovery_tp_loss_cycles=sum(t['result']=='RECOVERY_TP' and
                                    (t.get('pnl_money_est') if t.get('pnl_money_est') is not None
                                     else t['pnl_points']) < -1e-8 for t in trades)
        aborted=sum(t['result']=='ABORTED' for t in trades)
        gross_win=sum(max(0,t['pnl_points']) for t in trades)
        gross_loss=-sum(min(0,t['pnl_points']) for t in trades)
        balance=peak=max_dd=0.0
        for t in trades:
            balance+=t['pnl_points']
            peak=max(peak,balance)
            max_dd=max(max_dd,peak-balance)
        near={f'{v:.2f}':sum(t['result']=='SL' and t['gap_to_tp']<=v+1e-9 for t in trades)
              for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        near_recovery={f'{v:.2f}':sum(t.get('recovery_used',False) and
                          t.get('gap_to_tp',float('inf'))<=v+1e-9 for t in trades)
                       for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        weighted=None;active_money=None;open_recovery=None
        if self.recovery and self.latest:
            rec=self.recovery
            weighted,active_money=self._recovery_net(self.latest)
            open_recovery=dict(started_ms=rec.started_ms,buy_anchor=rec.buy_anchor,
                sell_anchor=rec.sell_anchor,partial_stops=rec.recovery_sls,
                partial_tps=rec.partial_tps,fixed_tps=rec.fixed_tps,
                stepped_mode=rec.stepped_mode,reentries=rec.reentries,
                realized_weighted_points=round(rec.realized_weighted_points,7),
                unrealized_and_realized_points_equivalent=round(weighted/self.settings.volume_lots,5),
                net_money_est=round(active_money,4) if active_money is not None else None)
        equity=self._equity_points()
        cash_closed=(round(sum(t['pnl_money_est'] for t in trades),4)
                     if all(t['pnl_money_est'] is not None for t in trades) else None)
        active_cost_est=None
        if self.position and not self.recovery and self.latest and self.settings.tick_value_per_lot>0:
            pos=self.position
            quote=self._close_quote(pos.side,self.latest)
            points=quote-pos.entry if pos.side=='BUY' else pos.entry-quote
            active_cost_est=(points/self.settings.tick_size*self.settings.tick_value_per_lot-
                             self.settings.commission_per_lot_roundtrip)*self.settings.volume_lots
        if cash_closed is not None:
            if self.recovery and active_money is not None:
                net_cash=cash_closed+active_money
            elif active_cost_est is not None:
                net_cash=cash_closed+active_cost_est
            else:
                net_cash=cash_closed
        else:
            net_cash=None
        positive_cycles=sum((t.get('pnl_money_est') if t.get('pnl_money_est') is not None
                                  else t['pnl_points'])>1e-8 for t in trades)
        return dict(trades=len(trades),tp=tp,sl=sl,recovered=recovered,aborted=aborted,
            recovery_tp_cycles=recovery_tp_cycles,recovery_tp_loss_cycles=recovery_tp_loss_cycles,
            win_rate=round(100*positive_cycles/len(trades),2) if trades else 0,
            pnl_points=round(balance,5),max_drawdown_points=round(max_dd,5),
            equity_points=round(equity,5),
            max_equity_drawdown_points=round(self.max_equity_drawdown_points,5),
            min_equity_points=round(self.min_equity_points,5),
            profit_factor=round(gross_win/gross_loss,3) if gross_loss else None,
            pnl_money_est=cash_closed,net_equity_money_est=round(net_cash,4) if net_cash is not None else None,
            near_tp_then_sl=near,near_tp_then_recovery=near_recovery,
            recovery_activations=self.recovery_activations,
            recovery_completed=self.recovery_completed,
            recovery_partial_stops=self.recovery_partial_stops,
            recovery_partial_tps=self.recovery_partial_tps,
            recovery_fixed_tps=self.recovery_fixed_tps,recovery_sls=self.recovery_sls,
            recovery_reentries=self.recovery_reentries,
            recovery_aborted=self.recovery_aborted,
            max_active_recovery_loss_points=round(self.max_active_recovery_loss_points,5),
            open_recovery=open_recovery,unresolved_recovery=1 if self.recovery else 0,
            unfinished_cycle=1 if self.position is not None else 0,
            placed=self.placed_orders,canceled=self.canceled_orders,triggered=self.triggered_orders,
            tick_count=self.tick_count,max_tick_gap_seconds=round(self.max_tick_gap_ms/1000,3))

    def public_state(self) -> dict:
        rec=self.recovery
        recovery_info=None
        if rec is not None:
            weighted,cash=self._recovery_net(self.latest) if self.latest else (0.,None)
            recovery_info=dict(started_ms=rec.started_ms,buy_anchor=rec.buy_anchor,
                sell_anchor=rec.sell_anchor,initial_sl_exit=rec.original_sl_exit,
                active=asdict(rec.active) if rec.active else None,
                pending_stops=rec.pending_stops[:],
                realized_weighted_points=round(rec.realized_weighted_points,7),
                equity_points_equivalent=round(weighted/self.settings.volume_lots,6),
                equity_money_est=round(cash,5) if cash is not None else None,
                partial_stops=rec.recovery_sls,partial_tps=rec.partial_tps,
                fixed_tps=rec.fixed_tps,stepped_mode=rec.stepped_mode,
                reentries=rec.reentries)
        return dict(mode=self.mode,settings=asdict(self.settings),
                    tick=asdict(self.latest) if self.latest else None,
                    candle=asdict(self.candle) if self.candle else None,
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    recovery=recovery_info,
                    summary=self.summary(),events=self.events[-30:],trades=self.trades[-35:])

    def chart_candles(self, max_rows=450) -> list[dict]:
        data = self.candles[-max_rows:]
        if self.candle:
            data = data + [asdict(self.candle)]
        return data

    def to_snapshot(self) -> dict:
        # No transient output buffers, they are already stored separately.
        return dict(settings=asdict(self.settings),mode=self.mode,arm_minute=self.arm_minute,
                    candle=asdict(self.candle) if self.candle else None,candles=self.candles[-750:],
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    recovery=asdict(self.recovery) if self.recovery else None,
                    latest=asdict(self.latest) if self.latest else None,
                    trade_seq=self.trade_seq,order_seq=self.order_seq,
                    trades=self.trades,events=self.events[-250:],canceled_orders=self.canceled_orders,
                    placed_orders=self.placed_orders, triggered_orders=self.triggered_orders,
                    tick_count=self.tick_count,skipped_invalid=self.skipped_invalid,
                    first_tick_ms=self.first_tick_ms,max_tick_gap_ms=self.max_tick_gap_ms,
                    realized_cycle_points=self.realized_cycle_points,
                    recovery_activations=self.recovery_activations,
                    recovery_completed=self.recovery_completed,
                    recovery_partial_stops=self.recovery_partial_stops,
                    recovery_partial_tps=self.recovery_partial_tps,recovery_sls=self.recovery_sls,
                    recovery_reentries=self.recovery_reentries,
                    recovery_fixed_tps=self.recovery_fixed_tps,
                    recovery_aborted=self.recovery_aborted,
                    max_active_recovery_loss_points=self.max_active_recovery_loss_points,
                    equity_peak_points=self.equity_peak_points,
                    max_equity_drawdown_points=self.max_equity_drawdown_points,
                    min_equity_points=self.min_equity_points)

    @classmethod
    def from_snapshot(cls, data: dict) -> 'PaperEngine':
        e = cls(Settings(**data['settings']))
        for attr, typ in [('candle',Candle),('pending',Pending),('position',Position),('latest',Tick)]:
            if data.get(attr):
                setattr(e,attr,typ(**data[attr]))
        rec=data.get('recovery')
        if rec:
            # Migration safeguard: v1.2 hedge baskets cannot be resumed using
            # v1.3 stop-based accounting. Stop rather than reinterpret them.
            if 'origin' not in rec:
                raise ValueError('Old RECOVERY state requires reset before v1.3')
            e.recovery=RecoveryState(started_ms=rec['started_ms'],
                origin=Position(**rec['origin']),
                original_sl_exit=rec['original_sl_exit'],
                buy_anchor=rec['buy_anchor'],sell_anchor=rec['sell_anchor'],
                active=RecoveryLeg(**rec['active']) if rec.get('active') else None,
                pending_stops=rec.get('pending_stops',[]),
                realized_weighted_points=rec.get('realized_weighted_points',0.),
                realized_commission_money=rec.get('realized_commission_money',0.),
                partial_tps=rec.get('partial_tps',0),
                fixed_tps=rec.get('fixed_tps',0),
                # Old v1.3 active state must not silently be treated as first TP.
                stepped_mode=rec.get('stepped_mode',True),
                recovery_sls=rec.get('recovery_sls',0),
                reentries=rec.get('reentries',0),
                max_loss_points=rec.get('max_loss_points',0.),
                actions=rec.get('actions',[]),
                truncated_actions=rec.get('truncated_actions',0))
        for attr in ('mode','arm_minute','trade_seq','order_seq','canceled_orders','placed_orders',
                     'triggered_orders','skipped_invalid','tick_count','first_tick_ms','max_tick_gap_ms',
                     'recovery_activations','recovery_completed','recovery_partial_stops',
                     'recovery_reentries','recovery_partial_tps','recovery_fixed_tps','recovery_sls',
                     'recovery_aborted','max_active_recovery_loss_points',
                     'equity_peak_points','max_equity_drawdown_points','min_equity_points',
                     'realized_cycle_points'):
            if attr in data:
                setattr(e,attr,data[attr])
        e.candles = data.get('candles',[])
        e.trades = data.get('trades',[])
        if 'realized_cycle_points' not in data:
            e.realized_cycle_points=sum(t['pnl_points'] for t in e.trades)
        e.events = data.get('events',[])
        e.last_tick_signature = (e.latest.t_ms,e.latest.bid,e.latest.ask) if e.latest else None
        return e

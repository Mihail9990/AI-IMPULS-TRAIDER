"""Read-only MT5 quotes and explicitly synthetic DEMO quotes.

IMPORTANT: All public Tick/Candle timestamps in this module are UTC Unix times.
Some broker/terminal combinations expose the trading-server clock in the numeric
MT5 tick/bar fields. We check this against the wall-clock on a *fresh* quote,
rather than silently assuming the broker has a UTC clock.
"""
from __future__ import annotations

from datetime import datetime, timezone
import math
import os
import random
import threading
import time
from typing import Iterator

from .engine import Tick

UTC = timezone.utc
HOUR_MS = 3_600_000
MAX_CLOCK_RESIDUAL_MS = 45_000


class SourceError(RuntimeError):
    pass


def infer_mt5_clock_offset_ms(raw_tick_ms: int, utc_now_ms: int) -> int:
    """Return raw MT5 timestamp minus UTC, only when a quote is demonstrably fresh.

    If ticks are stale (e.g. overnight) then guessing the nearest hour is unsafe:
    it might assign an arbitrary offset and corrupt a live paper-trade simulation.
    Explicit offset configuration is available for unusual MT5 installations.
    """
    if raw_tick_ms <= 0:
        raise SourceError('MT5 не сообщил время последнего тика')
    difference = raw_tick_ms - utc_now_ms
    hours = round(difference / HOUR_MS)
    residual = difference - hours * HOUR_MS
    if abs(hours) > 14 or abs(residual) > MAX_CLOCK_RESIDUAL_MS:
        mins = round(difference / 60000, 1)
        raise SourceError(
            f'Время последнего тика MT5 не совпадает с UTC (разница {mins} мин). '
            'Возможно, рынок закрыт, терминал не получает котировки или часы VPS не синхронизированы. '
            'Дождитесь свежего тика; при необходимости проверьте MT5_TIME_OFFSET_HOURS.'
        )
    return int(hours * HOUR_MS)


class MT5Quotes:
    """Never calls order_send(), positions_*, orders_* or any trade API."""
    def __init__(self, symbol='XAUUSD.s', terminal_path='', expected_login='', time_offset_hours='auto'):
        self.symbol = symbol
        self.terminal_path = terminal_path
        self.expected_login = str(expected_login or '')
        self.requested_offset = str(time_offset_hours).strip().lower()
        self.time_offset_ms = 0
        self.time_mode = 'unverified'
        self.lock = threading.RLock()
        self.mt5 = None
        self.last_error = None
        self.connected = False
        self.last_clock_check = 0.0
        self.bar_offset_ms = None

    def _read_offset(self) -> int:
        if self.requested_offset != 'auto':
            try:
                hours = float(self.requested_offset)
            except ValueError as exc:
                raise SourceError('MT5_TIME_OFFSET_HOURS должен быть auto или числом часов') from exc
            if not math.isfinite(hours) or abs(hours) > 14 or hours * 3600 % 60:
                raise SourceError('Недопустимое значение MT5_TIME_OFFSET_HOURS')
            self.time_mode = 'manual'
            return int(hours * HOUR_MS)
        quote = self.mt5.symbol_info_tick(self.symbol)
        if quote is None:
            raise SourceError(f'Нет последнего тика MT5 {self.symbol}: {self.mt5.last_error()}')
        raw = int(getattr(quote, 'time_msc', 0) or (int(quote.time) * 1000))
        value = infer_mt5_clock_offset_ms(raw, int(time.time() * 1000))
        self.time_mode = 'auto_verified'
        return value

    def connect(self):
        with self.lock:
            if self.connected:
                return
            try:
                import MetaTrader5 as mt5
            except ImportError as exc:
                raise SourceError('MetaTrader5 requires 64-bit Windows Python and pip install MetaTrader5') from exc
            self.mt5 = mt5
            ok = mt5.initialize(self.terminal_path) if self.terminal_path else mt5.initialize()
            if not ok:
                raise SourceError(f'MT5 initialize failed: {mt5.last_error()}')
            account = mt5.account_info()
            if not account:
                raise SourceError('No active MT5 account. Log into Bybit CFD in the terminal.')
            if self.expected_login and str(account.login) != self.expected_login:
                raise SourceError(f'Unexpected MT5 account {account.login}; expected {self.expected_login}')
            if not mt5.symbol_select(self.symbol, True):
                raise SourceError(f'Symbol {self.symbol!r} not available: {mt5.last_error()}')
            self.time_offset_ms = self._read_offset()
            self.last_clock_check = time.monotonic()
            self.connected = True

    def _check_clock(self):
        # Broker DST/time-zone changes must not silently corrupt the virtual session.
        now = time.monotonic()
        if now - self.last_clock_check < 30 or self.requested_offset != 'auto':
            return
        offset = self._read_offset()
        self.last_clock_check = now
        if offset != self.time_offset_ms:
            self.connected = False
            raise SourceError('MT5 изменил смещение времени. Приостановите виртуальный цикл и перезапустите анализатор.')

    def symbol_details(self) -> dict:
        with self.lock:
            self.connect()
            info = self.mt5.symbol_info(self.symbol)
            if info is None:
                raise SourceError(f'No symbol info: {self.symbol}')
            size = float(info.trade_tick_size or info.point or 0.01)
            return dict(symbol=self.symbol, tick_size=size,
                        digits=int(info.digits), tick_value_per_lot=float(info.trade_tick_value or 0.0),
                        volume_min=float(info.volume_min), volume_step=float(info.volume_step),
                        stops_level=int(info.trade_stops_level),
                        account_login=str(self.mt5.account_info().login),
                        clock_offset_hours=self.time_offset_ms / HOUR_MS,
                        clock_mode=self.time_mode)

    def range(self, start_ms: int, end_ms: int) -> list[Tick]:
        if end_ms < start_ms:
            return []
        with self.lock:
            self.connect()
            self._check_clock()
            # Convert desired UTC range to the broker's raw clock when necessary.
            st = datetime.fromtimestamp((start_ms + self.time_offset_ms) / 1000, UTC)
            en = datetime.fromtimestamp((end_ms + self.time_offset_ms) / 1000, UTC)
            values = self.mt5.copy_ticks_range(self.symbol, st, en, self.mt5.COPY_TICKS_INFO)
            if values is None:
                self.last_error = str(self.mt5.last_error())
                raise SourceError(f'copy_ticks_range failed: {self.last_error}')
            out = []
            for row in values:
                t = int(row['time_msc']) - self.time_offset_ms
                b, a = float(row['bid']), float(row['ask'])
                if start_ms <= t <= end_ms and b > 0 and a >= b and math.isfinite(a):
                    out.append(Tick(t,b,a))
            return out

    def chart(self, count=450) -> list[dict]:
        with self.lock:
            self.connect()
            self._check_clock()
            rates = self.mt5.copy_rates_from_pos(self.symbol, self.mt5.TIMEFRAME_M1, 0, count)
            if rates is None:
                raise SourceError(f'copy_rates_from_pos failed: {self.mt5.last_error()}')
            # Some terminals encode rates and ticks on different clock bases.
            # Determine the bar clock separately ONLY when a freshly timed bar
            # also agrees with the latest broker Bid, otherwise trust the tick
            # clock and reject future bars below (never fabricate history).
            now_s=int(time.time())
            now_minute=(now_s//60)*60
            bar_offset_sec=self.time_offset_ms//1000
            if len(rates):
                last=rates[-1]
                difference=int(last['time'])-now_s
                candidate_hours=round(difference/3600)
                residual=difference-candidate_hours*3600
                quote=self.mt5.symbol_info_tick(self.symbol)
                last_bid=float(getattr(quote,'bid',0) or 0) if quote else 0
                recent=rates[-10:]
                typical_range=sum(float(r['high'])-float(r['low']) for r in recent)/len(recent)
                if (abs(candidate_hours)<=14 and -150<=residual<=60 and
                        last_bid>0 and abs(float(last['close'])-last_bid)<=max(1.,5*typical_range)):
                    bar_offset_sec=candidate_hours*3600
            self.bar_offset_ms=bar_offset_sec*1000
            shifted=[]
            for r in rates:
                stamp=int(r['time'])-bar_offset_sec
                if stamp > now_minute + 60:
                    continue
                o, h, lo, c = (float(r[k]) for k in ('open', 'high', 'low', 'close'))
                if not (all(math.isfinite(x) and x > 0 for x in (o,h,lo,c)) and
                        lo <= min(o,c) and h >= max(o,c)):
                    continue
                shifted.append(dict(time=stamp,open=o,high=h,low=lo,close=c))
            return sorted(shifted,key=lambda c:c['time'])[-count:]


class DemoQuotes:
    """Synthetic random walk. STRICTLY demo; never label the values as real broker ticks."""
    def __init__(self, symbol='SYNTHETIC-DEMO'):
        self.symbol = symbol
        self.value = 4000.0
        self.rng = random.Random(20261025)
        self.last_ms = 0
        self.lock = threading.RLock()
        self.history = []
        fake = random.Random(8242)
        minute = (int(time.time()) // 60)*60
        for i in range(240, 0, -1):
            start = self.value
            finish = round(max(100,start+fake.gauss(0,0.38)),2)
            high = round(max(start,finish)+abs(fake.gauss(0,0.12)),2)
            low = round(min(start,finish)-abs(fake.gauss(0,0.12)),2)
            self.history.append(dict(time=minute-i*60,open=round(start,2),high=high,low=low,close=finish))
            self.value = finish

    def symbol_details(self):
        return dict(symbol=self.symbol,tick_size=0.01,digits=2,
                    tick_value_per_lot=0.0,volume_min=0.01,volume_step=0.01,
                    stops_level=0,account_login='DEMO / NO BROKER',
                    clock_offset_hours=0,clock_mode='demo')

    def range(self, start_ms: int, end_ms: int) -> list[Tick]:
        with self.lock:
            now = int(time.time()*1000)
            if self.last_ms >= now:
                return []
            steps = min(50,max(1,(now-self.last_ms)//400)) if self.last_ms else 1
            out=[]
            for i in range(steps):
                self.value = max(1,self.value+self.rng.gauss(0,0.09))
                spread = max(0.10,0.22+self.rng.uniform(-0.04,0.04))
                t = now-(steps-i-1)*30
                out.append(Tick(t,round(self.value,2),round(self.value+spread,2)))
            self.last_ms = now
            return out

    def chart(self,count=450):
        return self.history[-count:]


def demo_historical_ticks(start_ms: int,end_ms: int) -> Iterator[Tick]:
    """Deterministic synthetic tick set for testing the web/app, NOT market data."""
    rng = random.Random(1985+(start_ms//86400000))
    price = 4000.0
    for t in range(start_ms, end_ms, 1500):
        price = max(10,price+rng.gauss(0,0.09))
        bid = round(price,2)
        ask = round(bid+0.23+rng.uniform(-0.04,0.04),2)
        yield Tick(t,bid,max(bid,ask))

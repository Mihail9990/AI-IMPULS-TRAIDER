"""One-time DESTRUCTIVE v1.3.1 migration of ONLY PAPER ANALYZER RESULTS.

Clears completed virtual trades, runs, variants, and past active simulation state.
Keeps .env, external MT5, tick cache, original code and user strategy settings.
Idempotent: a per-database marker stops a second v1.3.1 update from erasing
new results. Runs only after manual updater confirmation and code validation.
"""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
from dataclasses import asdict,fields
from pathlib import Path

BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE))
from analyzer.engine import PaperEngine,Settings  # noqa: E402

MARKER='recovery_v131_results_cleared'


def clear_db(path:Path)->str:
    con=sqlite3.connect(str(path),timeout=3,isolation_level=None)
    try:
        con.execute('PRAGMA foreign_keys=ON')
        exists=con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='state'").fetchone()
        if not exists:
            raise RuntimeError(f'Not a known analyzer database: {path}')
        if con.execute('SELECT 1 FROM state WHERE key=?',(MARKER,)).fetchone():
            return 'already_reset'
        saved=con.execute("SELECT value FROM state WHERE key='live_snapshot'").fetchone()
        settings_in=json.loads(saved[0]).get('settings',{}) if saved else {}
        allowed={f.name for f in fields(Settings)}
        settings_in={k:v for k,v in settings_in.items() if k in allowed}
        # Standard initial entry after this update is 0.01 with RECOVERY enabled;
        # the old hedge sizes do not carry over as executable live orders.
        settings_in.update(volume_lots=.01,recovery_enabled=True,
                           recovery_core_lots=.01,recovery_reentry_lots=.12,
                           recovery_trail_activation=.50,recovery_trail_start_offset=.50,
                           recovery_trail_step=.10,recovery_partial_lots=.03)
        settings=Settings(**settings_in)
        engine=PaperEngine(settings)
        snapshot=engine.to_snapshot()
        snapshot.update(timebase_version=2,strategy_release='v1.3.1')
        con.execute('BEGIN IMMEDIATE')
        try:
            # These tables are created by v1.2. Check each before deleting so
            # older schemas can be migrated safely without dropping source data.
            tables={row[0] for row in con.execute('SELECT name FROM sqlite_master WHERE type="table"')}
            for table in ('backtest_trades','variants','backtests','live_trades'):
                if table in tables:con.execute(f'DELETE FROM {table}')
            con.execute("DELETE FROM state WHERE key='live_snapshot'")
            con.execute('INSERT INTO state(key,value) VALUES(?,?)',
                        ('live_snapshot',json.dumps(snapshot,ensure_ascii=False)))
            con.execute('INSERT INTO state(key,value) VALUES(?,?)',
                        (MARKER,json.dumps(True)))
            con.commit()
        except Exception:
            con.rollback()
            raise
        con.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        con.execute('VACUUM')
        return 'cleared'
    finally:
        con.close()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--confirm-clear-results-v131',action='store_true')
    args=ap.parse_args()
    if not args.confirm_clear_results_v131:
        ap.error('Confirmation flag required. No data was modified.')
    try:
        from dotenv import load_dotenv
        load_dotenv(BASE/'.env')
    except ImportError:
        pass
    data_root=Path(os.getenv('DATA_DIR',str(BASE/'data'))).expanduser()
    if not data_root.is_absolute():data_root=BASE/data_root
    dbs=sorted(data_root.rglob('analyzer.sqlite3')) if data_root.is_dir() else []
    n=0
    for path in dbs:
        result=clear_db(path)
        print(f'{result.upper()}: {path}')
        n+=result=='cleared'
    print(f'One-time v1.3.1 reset complete: {n} analyzer DB(s) wiped; '
          'password/MT5/tick cache files left unchanged.')

if __name__=='__main__':
    main()

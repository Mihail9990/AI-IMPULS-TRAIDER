"""Verify v1.3.1 migration wipes old experimental data only once."""
import sqlite3
from analyzer.engine import PaperEngine,Settings
from analyzer.storage import Store
from tools.reset_old_results_v131 import clear_db


def test_reset_wipes_old_trades_backtests_keeps_user_settings(tmp_path):
    db=tmp_path/'mt5_XAUUSD.s'/'analyzer.sqlite3'
    store=Store(db)
    eng=PaperEngine(Settings(trigger_distance=1.5,volume_lots=.01,recovery_enabled=True))
    eng.start()
    eng.trade_seq=99
    eng.trades=[{'id':1,'pnl_points':-3,'pnl_money_est':-3,'result':'SL'}]
    store.save_live(eng.to_snapshot(),eng.trades)
    job=store.make_job(0,3600000,{},1,'mt5')
    store.save_variant(job,{'x':1},{'pnl_points':-10},[{'id':1,'opened_ms':2,'result':'SL'}])
    store.db.close()
    assert clear_db(db)=='cleared'
    c=sqlite3.connect(str(db))
    assert c.execute('SELECT COUNT(*) FROM live_trades').fetchone()[0]==0
    assert c.execute('SELECT COUNT(*) FROM backtests').fetchone()[0]==0
    assert c.execute('SELECT COUNT(*) FROM variants').fetchone()[0]==0
    assert c.execute('SELECT COUNT(*) FROM backtest_trades').fetchone()[0]==0
    s=c.execute("SELECT value FROM state WHERE key='live_snapshot'").fetchone()[0]
    c.close()
    import json
    x=json.loads(s)
    assert x['settings']['trigger_distance']==1.5
    assert x['settings']['recovery_enabled'] is True
    assert x['mode']=='stopped' and x['trades']==[]
    assert clear_db(db)=='already_reset'

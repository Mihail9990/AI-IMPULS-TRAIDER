"""Tick-deterministic RECOVERY v1.3: initial SL, 0.12 independent trading,
step trailing, partial TPs, opposite OCO STOP re-entry. Zero broker trade calls.
"""
import pytest
from analyzer.engine import PaperEngine, Settings, Tick


def tk(m,s,b,spread=.23):
    return Tick((m*60+s)*1000,round(b,5),round(b+spread,5))


def initial_buy(commission=0,spread=.23):
    e=PaperEngine(Settings(volume_lots=.01,recovery_enabled=True,tick_size=.01,
                           tick_value_per_lot=1,commission_per_lot_roundtrip=commission))
    e.start()
    for x in (tk(0,0,3998.50,spread),tk(0,50,3999,spread),
              tk(1,0,3999.05,spread),tk(1,1,3999.77,spread)):
        e.on_tick(x)
    assert e.position and e.position.entry==4000
    return e


def started():
    e=initial_buy()
    e.on_tick(tk(1,2,3997))
    assert e.recovery and e.position is None
    return e


def active():
    e=started()
    e.on_tick(tk(1,3,3996.80))
    assert e.recovery.active
    assert e.recovery.active.role=='fixed_tp'
    assert e.recovery.active.tp==3996.55
    assert e.recovery.active.stop==3999.8
    return e


def stepped_active():
    e=active()
    # First 0.12 must actually hit its SL before partial TPs / trailing exist.
    e.on_tick(tk(1,4,3999.57))  # SELL liquidation by Ask=3999.80
    assert e.recovery and e.recovery.active is None
    assert e.recovery.stepped_mode and e.recovery.recovery_sls==1
    e.on_tick(tk(1,5,3996.80))  # SELL STOP reentry on its anchor
    assert e.recovery.active and e.recovery.active.role=='stepped'
    return e


def test_original_tp_then_new_m1_cycle():
    e=initial_buy()
    e.on_tick(tk(1,2,4000.25))
    assert e.recovery is None and e.summary()['tp']==1
    e.on_tick(tk(1,45,4000.5));e.on_tick(tk(2,0,4000.49))
    assert e.pending and e.pending.side=='BUY'


def test_initial_sl_is_closed_and_loss_is_realized():
    e=started();r=e.recovery
    assert r.active is None and e.position is None
    assert r.original_sl_exit==3997
    assert r.realized_weighted_points==pytest.approx(-.03)
    assert r.pending_stops==[dict(side='SELL',level=3997,lots=.12,armed=True)]
    assert e.summary()['unresolved_recovery']==1
    assert e.summary()['equity_points']==pytest.approx(-3)
    assert not e.trades  # completed cycle not yet known


def test_first_recovery_stop_cannot_fill_same_tick_as_initial_sl():
    e=started()
    assert e.recovery.active is None
    e.on_tick(tk(1,3,3996.80))
    assert e.recovery.active.side=='SELL'
    assert e.recovery.active.entry==3996.8
    assert e.recovery.active.lots==.12
    assert e.recovery.active.stop==3999.8


def test_trailing_moves_only_in_point10_steps_after_point50():
    e=stepped_active()
    # Make a large pre-existing loss to exercise long trade before breakeven.
    e.recovery.realized_weighted_points=-.55
    p=e.recovery.active
    e.on_tick(tk(1,6,3996.08))  # ASK 3996.31: profit .49
    assert p.trail_step_index==-1 and p.stop==3999.8
    e.on_tick(tk(1,7,3996.07))  # ASK 3996.30: +.50
    assert p.trail_step_index==0 and p.stop==3997.30
    e.on_tick(tk(1,8,3996.02))  # +.55, no new step
    assert p.stop==3997.30
    e.on_tick(tk(1,9,3995.97))  # +.60, step 1
    assert p.stop==3997.20
    e.on_tick(tk(1,10,3996.17))  # price rebounds: trailing cannot worsen
    assert p.stop==3997.20


def test_partials_at_one_two_three_and_last_runner():
    e=stepped_active();e.recovery.realized_weighted_points=-.60
    p=e.recovery.active
    for i,(bid,remaining) in enumerate(((3995.57,.09),(3994.57,.06),(3993.57,.03)),6):
        e.on_tick(tk(1,i,bid))
        assert e.recovery is not None
        assert p.lots==pytest.approx(remaining)
        assert e.recovery.partial_tps==i-5
    assert p.stop<3999.8 and p.trail_step_index>=0
    e.on_tick(tk(1,9,3994.7))  # ASK = 3994.93 crosses trail stop ~3994.8
    assert e.recovery is not None and e.recovery.active is None
    assert e.recovery.recovery_sls==2  # first 0.12 SL + subsequent trailing SL
    assert len(e.recovery.pending_stops)==2
    assert e.recovery.realized_weighted_points<0


def test_first_recovery_tp_ends_cycle_even_if_net_negative():
    e=active()
    e.on_tick(tk(1,4,3996.32))  # ASK 3996.55, exactly fixed TP
    assert e.recovery is None and e.position is None
    assert e.trades[-1]['result']=='RECOVERY_TP'
    assert e.trades[-1]['pnl_money_est']==pytest.approx(0)
    assert e.summary()['recovery_tp_cycles']==1
    assert e.summary()['recovered']==0
    e.on_tick(tk(1,40,3996));e.on_tick(tk(2,0,3995.9))
    assert e.pending and e.pending.side=='SELL'


def test_first_recovery_tp_with_commission_leaves_loss_in_global_pnl():
    e=initial_buy(commission=1)
    e.on_tick(tk(1,2,3997))
    e.on_tick(tk(1,3,3996.8))
    e.on_tick(tk(1,4,3996.32))
    t=e.trades[-1]
    assert t['result']=='RECOVERY_TP'
    assert t['pnl_money_est']==pytest.approx(-0.13)
    assert t['unrecovered_loss_money_est']==pytest.approx(-0.13)
    assert e.summary()['pnl_money_est']==pytest.approx(-0.13)
    assert e.summary()['recovery_tp_loss_cycles']==1
    assert e.summary()['unresolved_recovery']==0
    assert e.summary()['win_rate']==0
    # A new NORMAL cycle resumes; the earlier loss is not a RECOVERY debt.
    e.on_tick(tk(1,40,3996));e.on_tick(tk(2,0,3995.9))
    assert e.pending and e.recovery is None


def test_first_recovery_tp_with_slippage_deficit_subtracts_from_total():
    e=initial_buy()
    e.on_tick(tk(1,2,3994))  # Initial SL 3997, market gap fills 3994 -> -6
    e.on_tick(tk(1,3,3993.9))  # SELL 0.12 opens on next tick
    assert e.recovery.active and e.recovery.active.role=='fixed_tp'
    e.on_tick(tk(1,4,3993.42))  # Ask 3993.65 = SELL TP
    t=e.trades[-1]
    assert t['result']=='RECOVERY_TP'
    assert t['pnl_money_est']==pytest.approx(-3)
    assert e.summary()['pnl_money_est']==pytest.approx(-3)
    assert e.summary()['recovery_tp_loss_cycles']==1
    assert e.recovery is None
    # Follow-up successful base trade adds to global balance, not RECOVERY debt.
    e.on_tick(tk(1,40,3993.8));e.on_tick(tk(2,0,3993.9))
    assert e.pending and e.pending.side=='SELL'
    e.on_tick(tk(2,1,3992.70))  # Bid crosses SELL STOP
    assert e.position and e.position.side=='SELL'
    e.on_tick(tk(2,2,e.position.tp-.23))  # Ask reaches fixed SELL TP
    assert e.trades[-1]['result']=='TP'
    assert e.summary()['pnl_money_est']==pytest.approx(-2.75)


def test_no_stepped_tp_before_first_012_sl():
    e=active()
    leg=e.recovery.active
    e.on_tick(tk(1,4,3996.70))  # Ask=3996.93, not yet TP
    assert leg.role=='fixed_tp' and leg.trail_step_index==-1
    assert e.recovery.partial_tps==0
    assert e.recovery.stepped_mode is False
    # SL transitions to a new stepped entry, not to a trailing-first position.
    e.on_tick(tk(1,5,3999.57))
    assert e.recovery.stepped_mode is True
    assert e.recovery.active is None
    assert len(e.recovery.pending_stops)==2


def test_dynamic_sl_adds_loss_and_two_stop_rearm():
    e=stepped_active();e.recovery.realized_weighted_points=-.55
    e.on_tick(tk(1,6,3995.57)) # TP #1
    e.on_tick(tk(1,7,3996.90)) # ask 3997.13 crosses trail near 3996.8
    r=e.recovery
    assert r and r.active is None
    assert r.recovery_sls==2 and r.partial_tps==1
    assert {x['side'] for x in r.pending_stops}=={'BUY','SELL'}
    # Triggering one cancels the other (after valid-side rearming).
    # First re-arm BUY below anchor 4000, then cross BUY at ASK=4000.
    e.on_tick(tk(1,8,3999.77))
    assert r.active and r.active.side=='BUY'
    assert r.pending_stops==[]


def test_force_stop_accounts_unrealized_and_keeps_loss():
    e=active();e.request_stop()
    assert e.mode=='stopping'
    e.force_stop()
    assert e.mode=='stopped' and e.recovery is None
    assert e.trades[-1]['result']=='ABORTED' and e.trades[-1]['pnl_points']<0


def test_snapshot_mid_trailing_equals_continuous():
    e=stepped_active();e.recovery.realized_weighted_points=-.50
    e.on_tick(tk(1,6,3995.57))
    b=PaperEngine.from_snapshot(e.to_snapshot())
    for x in (tk(1,7,3994.57),tk(1,8,3993.57),tk(1,9,3994.70)):
        e.on_tick(x);b.on_tick(x)
    assert e.summary()==b.summary()
    assert e.trades==b.trades


def test_wide_spread_gap_affects_real_loss():
    e=initial_buy()
    e.on_tick(tk(1,2,3994))  # jumped 3 extra points beyond SL
    assert e.recovery.original_sl_exit==3994
    assert e.recovery.realized_weighted_points==pytest.approx(-.06)


def test_commission_and_unknown_value():
    e=initial_buy(commission=1)
    e.on_tick(tk(1,2,3997))
    assert e.summary()['open_recovery']['net_money_est']==pytest.approx(-3.01)
    other=PaperEngine(Settings(recovery_enabled=True,volume_lots=.01,tick_value_per_lot=0))
    other.start()
    for x in (tk(0,0,3998.5),tk(0,50,3999),tk(1,0,3999.05),tk(1,1,3999.77),tk(1,2,3997)):
        other.on_tick(x)
    assert other.summary()['open_recovery']['net_money_est'] is None
    with pytest.raises(ValueError,match='tick_value'):
        Settings(recovery_enabled=True,volume_lots=.01,commission_per_lot_roundtrip=1)


def test_recovery_settings_reject_volume_and_partial():
    with pytest.raises(ValueError,match='initial'):
        Settings(recovery_enabled=True,volume_lots=.1)
    with pytest.raises(ValueError,match='runner'):
        Settings(recovery_enabled=True,volume_lots=.01,recovery_partial_lots=.04)


def test_stopping_while_oco_pending_does_not_abandon_recovery():
    e=started();e.request_stop()
    assert e.mode=='stopping'

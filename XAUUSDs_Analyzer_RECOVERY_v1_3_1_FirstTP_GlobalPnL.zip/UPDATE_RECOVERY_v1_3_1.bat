@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_RECOVERY_v1_3_1.ps1"
set "code=%ERRORLEVEL%"
echo.
if not "%code%"=="0" echo Update failed, check the error above. Nothing has been changed after a cancelled confirmation.
pause
exit /b %code%

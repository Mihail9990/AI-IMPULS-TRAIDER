param([string]$TargetFolder = '')
$ErrorActionPreference = 'Stop'
try {
  Write-Host 'XAUUSD.s Strategy Analyzer - RECOVERY v1.3.1 PAPER update' -ForegroundColor Cyan
  Write-Host 'WARNING: OLD virtual trades/backtests/results will be DELETED once.' -ForegroundColor Yellow
  Write-Host 'UNCHANGED: MT5, real orders, .env/password, raw tick cache, HTTPS setup.'
  $patchDir = Join-Path $PSScriptRoot 'patch'
  $manifestPath = Join-Path $PSScriptRoot 'SHA256SUMS.txt'
  if (!(Test-Path -LiteralPath $manifestPath) -or !(Test-Path -LiteralPath (Join-Path $patchDir 'analyzer\engine.py'))) {
    throw 'Unpack the WHOLE ZIP before running the updater.'
  }
  $files=@(
    'analyzer\engine.py', 'analyzer\backtest.py', 'analyzer\live.py',
    'analyzer\server.py','analyzer\storage.py','analyzer\sources.py',
    'analyzer\telegram_control.py', 'web\index.html','web\app.js','web\styles.css',
    'tests\test_engine.py','tests\test_recovery.py','tests\test_history_reset.py',
    'tests\test_web.py','tools\reset_old_results_v131.py',
    'RECOVERY_v1_3_README_RU.md'
  )
  $manifest=@{}
  foreach($line in (Get-Content -LiteralPath $manifestPath -Encoding UTF8)) {
    if($line -match '^([a-fA-F0-9]{64})\s+(.+)$') {
      $manifest[$matches[2].Trim()]=$matches[1].ToLowerInvariant()
    }
  }
  foreach($rel in $files) {
    $source=Join-Path $patchDir $rel
    $key=$rel.Replace('\','/')
    if (!(Test-Path -LiteralPath $source -PathType Leaf)) {throw "Missing patch file $rel"}
    if (!$manifest.ContainsKey($key)) {throw "Missing hash: $key"}
    $hash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    if($hash -ne $manifest[$key]) {throw "SHA256 mismatch: $rel"}
  }
  Write-Host '[OK] Patch file checksums verified.' -ForegroundColor Green
  if ([string]::IsNullOrWhiteSpace($TargetFolder)) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description='Choose INSTALLED analyzer directory containing start_windows.bat'
    $dialog.ShowNewFolderButton=$false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {throw 'Cancelled. No changes made.'}
    $TargetFolder=$dialog.SelectedPath
  }
  $TargetFolder=(Resolve-Path -LiteralPath $TargetFolder).Path
  if (!(Test-Path -LiteralPath (Join-Path $TargetFolder 'start_windows.bat')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder 'analyzer\engine.py')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder '.env'))) {
    throw 'Incorrect installation folder. Expected start_windows.bat, analyzer/engine.py, .env.'
  }
  $port=8765
  foreach($line in (Get-Content -LiteralPath (Join-Path $TargetFolder '.env') -Encoding UTF8)) {
    if($line -match '^WEB_PORT\s*=\s*(\d+)\s*$') {$port=[int]$matches[1]}
  }
  $listeners=@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
  if($listeners.Count -gt 0) {throw "Port $port is listening. CLOSE the analyzer first. Do not stop MT5."}
  Write-Host 'This v1.3.1 update ERASES all prior ANALYZER RESULTS (once per database).'
  Write-Host 'Historical raw ticks, password, and MT5 remain untouched.'
  $consent=Read-Host 'Type CLEAR to confirm irreversibly deleting the old VIRTUAL history'
  if($consent -cne 'CLEAR') {throw 'No CLEAR confirmation. No changes made.'}
  $py=Join-Path $TargetFolder '.venv\Scripts\python.exe'
  if(!(Test-Path -LiteralPath $py)) {throw 'Python .venv not found. Installer cannot safely migrate DB.'}
  $backupDir=Join-Path $TargetFolder ('backup_recovery_v1_3_1_CODE_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  $replaced=New-Object System.Collections.ArrayList
  foreach($rel in $files) {
    $old=Join-Path $TargetFolder $rel
    if(Test-Path -LiteralPath $old) {
      $dest=Join-Path $backupDir $rel
      New-Item -ItemType Directory -Path (Split-Path -Path $dest -Parent) -Force | Out-Null
      Copy-Item -LiteralPath $old -Destination $dest -Force
    }
  }
  try {
    foreach($rel in $files) {
      $from=Join-Path $patchDir $rel
      $dest=Join-Path $TargetFolder $rel
      New-Item -ItemType Directory -Path (Split-Path -Path $dest -Parent) -Force | Out-Null
      Copy-Item -LiteralPath $from -Destination $dest -Force
      [void]$replaced.Add($rel)
      Write-Host "  Patched $rel"
    }
    # Syntax check before history reset. Errors should stop before any destructive step.
    & $py -m compileall -q (Join-Path $TargetFolder 'analyzer')
    if($LASTEXITCODE -ne 0) {throw 'Python syntax verification failed; no history reset performed.'}
    & $py (Join-Path $TargetFolder 'tools\reset_old_results_v131.py') --confirm-clear-results-v131
    if($LASTEXITCODE -ne 0) {throw 'DB reset failed; see error. DO NOT restart the analyzer until repaired.'}
  } catch {
    Write-Host 'Failed to complete patch or DB reset. Restoring program files.' -ForegroundColor Yellow
    foreach($rel in $replaced) {
      $saved=Join-Path $backupDir $rel
      $dest=Join-Path $TargetFolder $rel
      if(Test-Path -LiteralPath $saved) {
        Copy-Item -LiteralPath $saved -Destination $dest -Force -ErrorAction SilentlyContinue
      }else{
        Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
      }
    }
    throw
  }
  Write-Host ''
  Write-Host '[OK] RECOVERY v1.3.1 installed and previous results cleared ONCE.' -ForegroundColor Green
  Write-Host "Source-code backup: $backupDir (database was intentionally NOT backed up)"
  Write-Host 'Launch start_windows.bat, then Ctrl+F5 in browser. Press /start manually.'
  exit 0
}catch{
  Write-Host ''
  Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red
  exit 1
}

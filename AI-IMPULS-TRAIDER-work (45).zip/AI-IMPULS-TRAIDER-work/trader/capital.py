from __future__ import annotations

from decimal import Decimal
from datetime import datetime
import itertools
import hashlib
import json
import logging
import threading
import time
import requests

from .config import Settings
from .scheduler import scheduler_for


LOG = logging.getLogger(__name__)
SENSITIVE_KEYS = {
    "password", "identifier", "apiKey", "x-cap-api-key", "cst",
    "x-security-token", "token", "telegram_bot_token", "accountId", "currentAccountId", "clientId",
}


class CapitalError(RuntimeError):
    """Capital failure with a machine-readable broker outcome classification."""

    def __init__(self, message: str, *, http_status: int | None = None,
                 error_code: str = "", outcome: str = "UNKNOWN"):
        super().__init__(message)
        self.http_status = http_status
        self.error_code = error_code
        self.outcome = outcome

    @property
    def rejected(self) -> bool:
        return self.outcome == "REJECTED"


class CapitalClient:
    """Small wrapper around Capital.com's REST API (v1 endpoints)."""

    def __init__(self, settings: Settings):
        self.settings = settings
        host = "https://demo-api-capital.backend-capital.com" if settings.demo else "https://api-capital.backend-capital.com"
        self.base = host + "/api/v1"
        self.scheduler = scheduler_for(host)
        self.http = requests.Session()
        self.http.headers.update({"X-CAP-API-KEY": settings.api_key, "Content-Type": "application/json"})
        self.last_login = 0.0
        self.session_generation = 0
        self._login_lock = threading.Lock()
        self._request_ids = itertools.count(1)
        self._activity_log_lock = threading.Lock()
        self._logged_activity_events: set[str] = set()

    def login(self, *, force: bool = False) -> None:
        with self._login_lock:
            # Scenario 9 sends two DELETEs in parallel. Recheck under the lock so both workers
            # share one refresh instead of violating Capital's POST /session rate limit.
            if not force and time.time() - self.last_login <= 540:
                return
            LOG.info("CAPITAL LOGIN request url=%s/session credentials=<redacted>", self.base)
            started = time.monotonic()
            response = self.http.post(self.base + "/session", json={"identifier": self.settings.identifier, "password": self.settings.password, "encryptedPassword": False}, timeout=20)
            self._log_response("LOGIN", response, started)
            self._check(response)
            self.http.headers.update({"CST": response.headers["CST"], "X-SECURITY-TOKEN": response.headers["X-SECURITY-TOKEN"]})
            self.last_login = time.time()
            self.session_generation += 1
            LOG.info("CAPITAL SESSION ready generation=%s", self.session_generation)

    def streaming_tokens(self) -> tuple[str, str, int]:
        """Return the current REST session tokens used to authenticate WebSocket subscriptions."""
        return (
            str(self.http.headers.get("CST", "")),
            str(self.http.headers.get("X-SECURITY-TOKEN", "")),
            self.session_generation,
        )

    def _auth_snapshot(self) -> tuple[int, dict[str, str]]:
        """Atomically bind a generation to the exact tokens passed to one HTTP send."""
        with self._login_lock:
            return self.session_generation, {
                "CST": str(self.http.headers.get("CST", "")),
                "X-SECURITY-TOKEN": str(self.http.headers.get("X-SECURITY-TOKEN", "")),
            }

    def _refresh_failed_session(self, failed_generation: int) -> None:
        """Refresh exactly the generation that produced a 401.

        Concurrent callers which failed on the same generation share the first caller's refresh.
        """
        with self._login_lock:
            if self.session_generation != failed_generation:
                return
            LOG.info("CAPITAL LOGIN request url=%s/session credentials=<redacted>", self.base)
            started = time.monotonic()
            response = self.http.post(
                self.base + "/session",
                json={"identifier": self.settings.identifier,
                      "password": self.settings.password, "encryptedPassword": False},
                timeout=20,
            )
            self._log_response("LOGIN", response, started)
            self._check(response)
            self.http.headers.update({
                "CST": response.headers["CST"],
                "X-SECURITY-TOKEN": response.headers["X-SECURITY-TOKEN"],
            })
            self.last_login = time.time()
            self.session_generation += 1
            LOG.info("CAPITAL SESSION ready generation=%s", self.session_generation)

    def request(self, method: str, path: str, **kwargs) -> dict:
        method_upper = method.upper()
        priority = (0 if method_upper != "GET" else
                    1 if path.startswith(("/confirms/", "/history/activity")) else
                    3 if path.startswith("/history/transactions") else 2)
        # Query parameters are part of read identity; mutations deliberately receive unique keys.
        encoded_params = json.dumps(kwargs.get("params", {}), sort_keys=True, default=str)
        key = f"{method_upper}:{path}:{encoded_params}"
        return self.scheduler.execute(
            key, priority, lambda: self._request_now(method, path, **kwargs),
            coalesce=method_upper == "GET",
        )

    def _request_now(self, method: str, path: str, **kwargs) -> dict:
        if time.time() - self.last_login > 540:
            self.login()
        request_id = next(self._request_ids)
        request_generation, auth_headers = self._auth_snapshot()
        supplied_headers = dict(kwargs.pop("headers", {}))
        send_headers = {**supplied_headers, **auth_headers}
        safe_kwargs = {key: _redact(value) for key, value in kwargs.items()}
        LOG.info("CAPITAL REQUEST id=%s method=%s path=%s data=%s", request_id, method, path,
                 _json_text(safe_kwargs))
        started = time.monotonic()
        # GET requests are idempotent and safe to retry. Mutations are sent once: a timeout can
        # happen after the broker accepted them, so retrying POST/PUT/DELETE could duplicate risk.
        attempts = 3 if method.upper() == "GET" else 1
        response = None
        for attempt in range(attempts):
            try:
                response = self.http.request(
                    method, self.base + path, timeout=20, headers=send_headers, **kwargs
                )
            except requests.RequestException as exc:
                LOG.warning(
                    "CAPITAL transport failure id=%s attempt=%s/%s method=%s path=%s: %s",
                    request_id, attempt + 1, attempts, method, path, exc,
                )
                if attempt + 1 == attempts:
                    raise CapitalError(
                        f"Capital transport error {method} {path}: {exc}"
                    ) from exc
                time.sleep(0.5 * (attempt + 1))
                continue
            if response.status_code not in {429, 500, 502, 503, 504} or attempt + 1 == attempts:
                break
            LOG.warning(
                "CAPITAL transient response id=%s status=%s attempt=%s/%s",
                request_id, response.status_code, attempt + 1, attempts,
            )
            time.sleep(0.5 * (attempt + 1))
        assert response is not None
        if response.status_code == 401:
            LOG.warning("CAPITAL REQUEST id=%s received 401; refreshing session", request_id)
            self._refresh_failed_session(request_generation)
            _, retry_auth_headers = self._auth_snapshot()
            try:
                response = self.http.request(
                    method, self.base + path, timeout=20,
                    headers={**supplied_headers, **retry_auth_headers}, **kwargs
                )
            except requests.RequestException as exc:
                raise CapitalError(
                    f"Capital transport error after session refresh {method} {path}: {exc}"
                ) from exc
        self._log_response(request_id, response, started, path=path)
        self._check(response)
        return response.json() if response.content else {}

    def _log_response(self, request_id, response: requests.Response, started: float,
                      *, path: str = "") -> None:
        try:
            payload = _redact(response.json()) if response.content else None
            if path == "/history/activity" and isinstance(payload, dict):
                activities = payload.get("activities", [])
                if isinstance(activities, list):
                    unique = []
                    with self._activity_log_lock:
                        for event in activities:
                            encoded = _json_text(event)
                            digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
                            if digest not in self._logged_activity_events:
                                self._logged_activity_events.add(digest)
                                unique.append(event)
                        # A bounded cache prevents an unusually long process from leaking memory.
                        # Clearing only affects diagnostic de-duplication, never broker recovery.
                        if len(self._logged_activity_events) > 20000:
                            self._logged_activity_events.clear()
                    body = _json_text({
                        "activities_total": len(activities),
                        "new_unique_activities": unique,
                        "repeated_activities_suppressed": len(activities) - len(unique),
                    })
                else:
                    body = _json_text(payload)
            else:
                body = _json_text(payload) if response.content else "<empty>"
        except (ValueError, TypeError):
            body = response.text
        LOG.info(
            "CAPITAL RESPONSE id=%s status=%s elapsed=%.3fs body=%s",
            request_id, response.status_code, time.monotonic() - started, body,
        )

    @staticmethod
    def _check(response: requests.Response) -> None:
        if not response.ok:
            try:
                payload = response.json()
            except (TypeError, ValueError):
                payload = {}
            error_code = str(payload.get("errorCode", "")) if isinstance(payload, dict) else ""
            # A concrete Capital errorCode in a final 4xx response proves rejection of this
            # request. A generic/malformed response or server failure remains UNKNOWN.
            outcome = (
                "REJECTED"
                if 400 <= response.status_code < 500 and error_code
                else "UNKNOWN"
            )
            raise CapitalError(
                f"Capital API {response.status_code}: {response.text[:500]}",
                http_status=response.status_code, error_code=error_code, outcome=outcome,
            )

    def quote(self, epic: str) -> tuple[Decimal, Decimal]:
        market = self.request("GET", f"/markets/{epic}")["snapshot"]
        return Decimal(str(market["bid"])), Decimal(str(market["offer"]))

    def candle_range(self, epic: str, minutes: int) -> Decimal:
        resolution = "MINUTE" if minutes == 1 else f"MINUTE_{minutes}"
        prices = self.request("GET", f"/prices/{epic}", params={"resolution": resolution, "max": 2})["prices"]
        candle = prices[-2]
        high = Decimal(str(candle["highPrice"]["bid"]))
        low = Decimal(str(candle["lowPrice"]["bid"]))
        return high - low

    def open_position(self, epic: str, direction: str, size: Decimal,
                      stop: Decimal | None = None, target: Decimal | None = None,
                      *, stop_distance: Decimal | None = None,
                      profit_distance: Decimal | None = None) -> str:
        body = {
            "epic": epic, "direction": direction, "size": float(size),
            "guaranteedStop": False,
        }
        if stop_distance is not None:
            body["stopDistance"] = float(stop_distance)
        elif stop is not None:
            body["stopLevel"] = float(stop)
        if profit_distance is not None:
            body["profitDistance"] = float(profit_distance)
        elif target is not None:
            body["profitLevel"] = float(target)
        return self.request("POST", "/positions", json=body)["dealReference"]

    def confirmation(self, reference: str) -> dict:
        return self.request("GET", f"/confirms/{reference}")

    def wait_confirmation(self, reference: str, attempts: int = 10) -> dict:
        last = {}
        for _ in range(attempts):
            try:
                last = self.confirmation(reference)
                if last.get("dealStatus") in {"ACCEPTED", "REJECTED"}:
                    return last
            except CapitalError as exc:
                if "404" not in str(exc):
                    raise
            time.sleep(0.5)
        raise CapitalError(f"No final confirmation for {reference}: {last}")

    def positions(self) -> list[dict]:
        return self.request("GET", "/positions").get("positions", [])

    def position(self, deal_id: str) -> dict:
        return self.request("GET", f"/positions/{deal_id}")

    def wait_position(self, deal_id: str, deal_reference: str, direction: str,
                      attempts: int = 20, excluded_ids: set[str] | None = None,
                      epic: str = "") -> dict:
        """Resolve the permanent position id after an accepted create confirmation."""
        last_positions = []
        for _ in range(attempts):
            last_positions = self.positions()
            normalized = []
            for item in last_positions:
                position = item.get("position", item)
                item_epic = str(item.get("market", {}).get("epic") or position.get("epic", ""))
                if epic and item_epic != epic:
                    continue
                normalized.append(position)
            exact = next((item for item in normalized if str(item.get("dealId", "")) == deal_id), None)
            if exact:
                return exact
            by_reference = next((item for item in normalized
                                 if str(item.get("dealReference", "")) == deal_reference), None)
            if by_reference:
                return by_reference
            excluded = excluded_ids or set()
            same_direction = [
                item for item in normalized
                if item.get("direction") == direction
                and str(item.get("dealId", "")) not in excluded
            ]
            if len(same_direction) == 1:
                LOG.warning(
                    "Resolved %s position by new-direction fallback: dealId=%s reference=%s",
                    direction, same_direction[0].get("dealId"), deal_reference,
                )
                return same_direction[0]
            time.sleep(0.5)
        raise CapitalError(
            f"Accepted {direction} position did not appear in /positions; confirmation dealId={deal_id}; "
            f"last positions={last_positions}"
        )

    def working_orders(self) -> list[dict]:
        return self.request("GET", "/workingorders").get("workingOrders", [])

    def update_position(self, deal_id: str, stop: Decimal | None, target: Decimal | None) -> str:
        body = {
            "stopLevel": float(stop) if stop is not None else None,
            "profitLevel": float(target) if target is not None else None,
        }
        last_error = None
        for attempt in range(5):
            try:
                return self.request("PUT", f"/positions/{deal_id}", json=body)["dealReference"]
            except CapitalError as exc:
                last_error = exc
                if "error.not-found.dealId" not in str(exc) or attempt == 4:
                    raise
                time.sleep(0.5)
        raise last_error  # pragma: no cover

    def close_position(self, deal_id: str) -> str:
        """Close an open position at market and return its confirmation reference."""
        return self.request("DELETE", f"/positions/{deal_id}")["dealReference"]

    def working_stop(self, epic: str, direction: str, size: Decimal, level: Decimal,
                     stop: Decimal | None = None, target: Decimal | None = None) -> str:
        body = {"epic": epic, "direction": direction, "size": float(size), "level": float(level),
                "type": "STOP", "guaranteedStop": False}
        if stop is not None:
            body["stopLevel"] = float(stop)
        if target is not None:
            body["profitLevel"] = float(target)
        return self.request("POST", "/workingorders", json=body)["dealReference"]

    def delete_working_order(self, deal_id: str) -> bool:
        """Cancel a working order, treating an already absent order as an idempotent result.

        A 404 is expected when TP and trigger race: the trigger may have executed between the
        positions snapshot and DELETE.  The caller must inspect activity/positions after a False
        result rather than crashing or assuming cancellation succeeded.
        """
        try:
            payload = self.request("DELETE", f"/workingorders/{deal_id}")
            reference = payload.get("dealReference")
            if reference:
                confirmation = self.wait_confirmation(str(reference))
                if confirmation.get("dealStatus") != "ACCEPTED":
                    raise CapitalError(
                        confirmation.get("reason")
                        or f"Working order cancellation rejected: {deal_id}"
                    )
            return True
        except CapitalError as exc:
            if "error.not-found.dealId" in str(exc):
                return False
            raise

    def activity(
        self, deal_id: str = "", last_period: int = 86400, *,
        from_date: str = "", to_date: str = "",
    ) -> list[dict]:
        """Return activity for at most one day, as required by Capital.com.

        Explicit UTC boundaries are used for durable jobs older than 24 hours.  Capital.com does
        not allow combining them with ``lastPeriod`` and limits both forms to a one-day window.
        """
        if from_date or to_date:
            if from_date and to_date:
                start = datetime.fromisoformat(from_date.replace("Z", "+00:00"))
                end = datetime.fromisoformat(to_date.replace("Z", "+00:00"))
                seconds = (end - start).total_seconds()
                if not 0 < seconds <= 86400:
                    raise ValueError(
                        "Capital.com activity from/to range must be positive and at most one day"
                    )
            params = {"detailed": "true"}
            if from_date:
                params["from"] = from_date
            if to_date:
                params["to"] = to_date
        else:
            if not 0 < last_period <= 86400:
                raise ValueError("Capital.com activity lastPeriod must be between 1 and 86400")
            params = {"lastPeriod": last_period, "detailed": "true"}
        if deal_id:
            params["dealId"] = deal_id
        return self.request("GET", "/history/activity", params=params).get("activities", [])

    def transactions(self, last_period: int = 86400, *, from_date: str = "",
                     to_date: str = "", all_types: bool = False) -> list[dict]:
        params: dict = {}
        if from_date or to_date:
            if from_date:
                params["from"] = from_date
            if to_date:
                params["to"] = to_date
        else:
            params["lastPeriod"] = last_period
        # /pnl keeps its historical TRADE-only meaning. Attempt reconciliation deliberately omits
        # the optional filter so documented swaps, commissions, corrections and adjustments arrive.
        if not all_types:
            params["type"] = "TRADE"
        return self.request("GET", "/history/transactions", params=params).get("transactions", [])

    def candle_ranges(self, epic: str, minutes: int) -> tuple[Decimal, Decimal]:
        """Return ranges of the last closed candle and the forming candle."""
        # Capital exposes MINUTE and MINUTE_5, but not 2/3/4-minute resolutions.
        # Aggregate one-minute bars so all selectable periods have identical semantics.
        prices = self.request(
            "GET", f"/prices/{epic}", params={"resolution": "MINUTE", "max": minutes * 3 + 2}
        )["prices"]
        if len(prices) < 2:
            raise CapitalError("Capital API returned fewer than two candles")

        def timestamp(candle: dict) -> datetime:
            value = candle.get("snapshotTimeUTC") or candle.get("snapshotTime")
            if not value:
                raise CapitalError("Candle has no timestamp")
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))

        groups: dict[datetime, list[dict]] = {}
        for candle in prices:
            moment = timestamp(candle)
            bucket_minute = moment.minute - moment.minute % minutes
            bucket = moment.replace(minute=bucket_minute, second=0, microsecond=0)
            groups.setdefault(bucket, []).append(candle)
        ordered = sorted(groups.items())
        if len(ordered) < 2:
            raise CapitalError("Not enough aggregated candles")

        def group_range(candles: list[dict]) -> Decimal:
            high = max(Decimal(str(candle["highPrice"]["bid"])) for candle in candles)
            low = min(Decimal(str(candle["lowPrice"]["bid"])) for candle in candles)
            return high - low

        return group_range(ordered[-2][1]), group_range(ordered[-1][1])


def _redact(value):
    sensitive = {item.lower() for item in SENSITIVE_KEYS}
    if isinstance(value, dict):
        return {
            key: "<redacted>" if str(key).lower() in sensitive else _redact(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact(item) for item in value]
    return value


def _json_text(value) -> str:
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))

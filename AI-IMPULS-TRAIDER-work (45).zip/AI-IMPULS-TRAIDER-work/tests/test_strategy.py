from decimal import Decimal as D
from datetime import datetime, timezone
import json
import os
import sqlite3
import sys
import types
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import Mock, patch
from zipfile import ZipFile
import requests

from pydroid_installer import copy_project, create_config, safe_extract
from trader.app import Bot
from trader.capital import CapitalClient, CapitalError
from trader.config import Settings
from trader.cycle_continuation import CycleContinuation
from trader.diagnostics import CycleFileHandler
from trader.engine import Strategy
from trader.events import (
    find_close_event,
    find_trigger_open_event,
    find_working_order_cancellation,
    find_working_order_execution,
    normalize_event, normalize_events, protection_range_diagnostic,
)
from trader.execution import ExecutionPolicy, is_crossed_level_rejection, trigger_level_passed
from trader.model import (
    CycleState, Leg, remaining_recovery_distance, stop_slippage, target_for,
    trigger_slippage,
)
from trader.notifications import (
    NotificationHistoryWorker, TransactionHistoryWorker, migrate_notification_jobs, split_report,
)
from trader.reconcile import RemoteSnapshot
from trader.reporting import (
    broker_attempt_pnl, cycle_result_text, leg_details, pnl_text, recovery_change_text,
    recovery_snapshot, transaction_result_fingerprint,
)
from trader.streaming import PriceWatch, QuoteStream
from trader.storage import StateStore, StorageFailure, database_path
from trader.telegram import Telegram


_RUNTIME_STATE_PATH = Path(__file__).resolve().parents[1] / "bot_state.json"
_RUNTIME_STATE_EXISTED = _RUNTIME_STATE_PATH.exists()
_RUNTIME_STATE_BYTES = _RUNTIME_STATE_PATH.read_bytes() if _RUNTIME_STATE_EXISTED else None
_RUNTIME_DB_FILES = [Path(str(database_path(_RUNTIME_STATE_PATH)) + suffix)
                     for suffix in ("", "-wal", "-shm", ".lock")]
_RUNTIME_DB_SNAPSHOTS = {path: path.read_bytes() for path in _RUNTIME_DB_FILES if path.exists()}


def tearDownModule():
    """Never leave test state in the project or overwrite a user's pre-existing state."""
    if _RUNTIME_STATE_EXISTED:
        _RUNTIME_STATE_PATH.write_bytes(_RUNTIME_STATE_BYTES)
    else:
        _RUNTIME_STATE_PATH.unlink(missing_ok=True)
    for path in _RUNTIME_DB_FILES:
        if path in _RUNTIME_DB_SNAPSHOTS:
            path.write_bytes(_RUNTIME_DB_SNAPSHOTS[path])
        else:
            path.unlink(missing_ok=True)


class StrategyTest(unittest.TestCase):
    def setUp(self):
        self.state = CycleState()
        self.strategy = Strategy(Settings(), self.state)
        self.strategy.begin(D("4010.30"), D("4010.00"))
        self.strategy.confirm_initial_fills(D("4010.30"), D("4010.00"))

    def test_first_targets_use_each_leg_actual_entry(self):
        self.assertEqual(self.state.general_recovery, D("0.060"))
        self.assertEqual(self.state.long.stop, D("4009.30"))
        self.assertEqual(self.state.short.stop, D("4011.00"))
        self.assertEqual(self.state.long.take_profit, D("4011.90"))
        self.assertEqual(self.state.short.take_profit, D("4008.40"))

    def test_detailed_report_uses_persisted_recovery_components(self):
        before = recovery_snapshot(self.state)
        self.strategy.stopped("BUY", D("4009.20"), "report-sl")
        text = recovery_change_text(self.state, before, event="SL", direction="BUY")
        self.assertIn("GENERAL_RECOVERY", text)
        self.assertIn("pending D", text)
        self.assertNotIn("temporary:", text)

    def test_trigger_open_is_found_by_working_order_in_global_activity(self):
        activity = [{
            "dateUTC": "2026-08-25T13:34:09.000",
            "dealId": "new-buy",
            "source": "USER",
            "type": "POSITION",
            "status": "ACCEPTED",
            "details": {
                "workingOrderId": "trigger-buy",
                "direction": "BUY",
                "level": 4622.63,
            },
        }]
        event = find_trigger_open_event(activity, "trigger-buy", "BUY")
        self.assertIsNotNone(event)
        self.assertEqual(event.deal_id, "new-buy")
        self.assertEqual(event.level, D("4622.63"))

    def test_executed_trigger_is_detected_before_position_event_is_published(self):
        activity = [{
            "dateUTC": "2026-08-26T12:30:09.364",
            "dealId": "trigger-sell",
            "source": "USER",
            "type": "WORKING_ORDER",
            "status": "EXECUTED",
            "details": {"direction": "SELL", "level": 4620.63},
        }]
        event = find_working_order_execution(activity, "trigger-sell")
        self.assertIsNotNone(event)
        self.assertEqual(event.level, D("4620.63"))

    def test_working_order_cancellation_requires_explicit_cancelled_event(self):
        quiet = [{
            "dealId": "another-order", "type": "WORKING_ORDER", "status": "CANCELLED",
        }]
        self.assertIsNone(find_working_order_cancellation(quiet, "trigger-sell"))
        cancelled = quiet + [{
            "dealId": "trigger-sell", "type": "WORKING_ORDER", "status": "CANCELLED",
        }]
        self.assertIsNotNone(find_working_order_cancellation(cancelled, "trigger-sell"))

    def test_actual_initial_fills_define_immutable_trigger_anchors(self):
        state = CycleState(); strategy = Strategy(Settings(), state)
        strategy.begin(D("4010.30"), D("4010.00"))
        strategy.confirm_initial_fills(D("4010.35"), D("4010.00"))
        self.assertEqual(state.general_recovery, D("0.065"))
        self.assertEqual(state.long.original_trigger_level, D("4010.35"))
        strategy.stopped("BUY", state.long.stop, "anchor-stop")
        strategy.reopened("BUY", D("4010.45"), "buy-2", "anchor-open")
        self.assertEqual(state.long.original_trigger_level, D("4010.35"))
        self.assertEqual(state.long.current_entry, D("4010.45"))

    def test_favorable_sequential_fill_gap_is_absolute_spread(self):
        state = CycleState(); strategy = Strategy(Settings(), state)
        strategy.begin(D("4658.50"), D("4658.70"))
        strategy.confirm_initial_fills(D("4658.48"), D("4658.72"))
        self.assertEqual(state.entry_spread, D("0.24"))
        self.assertEqual(state.general_recovery, D("0.054"))
        self.assertEqual(state.long.take_profit, D("4660.02"))
        self.assertEqual(state.short.take_profit, D("4657.18"))

    def test_absolute_stop_slippage_is_added_in_both_directions(self):
        self.strategy.stopped("SELL", D("4011.10"), "stop-1")
        self.assertEqual(self.state.general_recovery, D("0.070"))
        second = CycleState(); strategy = Strategy(Settings(), second)
        strategy.begin(D("4010.30"), D("4010.00")); strategy.confirm_initial_fills(D("4010.30"), D("4010.00"))
        strategy.stopped("BUY", D("4009.20"), "stop-2")
        self.assertEqual(second.general_recovery, D("0.070"))

    def test_completion_calculates_gross_losses_and_net_result(self):
        self.strategy.stopped("SELL", D("4011.10"), "stop-1")
        self.strategy.complete("BUY", D("4011.70"))
        self.assertEqual(self.state.gross_take_profit, D("1.40"))
        self.assertEqual(self.state.realized_losses, D("1.10"))
        self.assertEqual(self.state.net_cycle_result, D("0.30"))
        self.assertEqual(self.state.completed_cycles, 1)

    def test_completed_cycle_counter_survives_reset_and_state_round_trip(self):
        self.strategy.complete("BUY", D("4011.60"))
        self.state.reset()
        with tempfile.NamedTemporaryFile() as file:
            self.state.save(file.name)
            restored = CycleState.load(file.name)
        self.assertEqual(restored.completed_cycles, 1)

    def test_reopen_uses_current_entry_for_stop_and_anchor_for_slippage(self):
        self.strategy.stopped("SELL", D("4011.10"), "sell-stop")
        self.strategy.reopened("SELL", D("4009.90"), "short-2", "sell-open")
        self.assertEqual(self.state.general_recovery, D("0.180"))
        self.assertEqual(self.state.short.original_trigger_level, D("4010.00"))
        self.assertEqual(self.state.short.current_entry, D("4009.90"))

    def test_target_helper_is_symmetric_and_independent_of_opposite_stop(self):
        self.assertEqual(target_for("BUY", D("4011.05"), D("1"), D("0.65")), D("4012.70"))
        self.assertEqual(target_for("SELL", D("4010.70"), D("1"), D("0.65")), D("4009.05"))
        before = self.state.long.take_profit
        self.state.short.stop = D("9999")
        self.strategy._targets_from_entries()
        self.assertEqual(self.state.long.take_profit, before)

    def test_recovery_table_scenarios_one_through_nine(self):
        previous = self.state.general_recovery
        for index, direction in enumerate(("SELL", "BUY", "SELL", "BUY", "SELL", "BUY", "SELL", "BUY"), 2):
            leg = self.state.short if direction == "SELL" else self.state.long
            self.strategy.stopped(direction, leg.stop, f"stop-{index}")
            self.strategy.reopened(direction, leg.original_trigger_level, f"deal-{index}", f"open-{index}")
            self.assertGreater(self.state.general_recovery, previous)
            previous = self.state.general_recovery
        self.assertEqual(self.state.scenario, 9)
        self.assertEqual(self.state.phase, "SCENARIO_9_CLOSING")

    def test_refresh_targets_migrates_old_tp_without_changing_recovery(self):
        recovery = self.state.recovery
        self.state.long.take_profit = D("999")
        self.state.short.take_profit = D("-999")
        self.strategy.refresh_targets()
        self.assertEqual(self.state.recovery, recovery)
        self.assertEqual(self.state.long.take_profit, D("4011.90"))
        self.assertEqual(self.state.short.take_profit, D("4008.40"))

    def test_scenario_nine_enters_automatic_closing_phase(self):
        self.state.scenario = 8
        self.strategy.stopped("SELL", self.state.short.stop, "s8-stop")
        self.strategy.reopened("SELL", self.state.short.original_trigger_level, "short-9", "s9-open")
        self.assertEqual(self.state.phase, "SCENARIO_9_CLOSING")

    def test_scenario_nine_result_uses_actual_close_gap_and_prior_losses(self):
        self.state.realized_losses = D("20")
        self.strategy.complete_scenario_nine(D("4001.5"), D("4000.3"), D("0.2"))
        self.assertEqual(self.state.scenario_nine_prior_losses, D("20"))
        self.assertEqual(self.state.scenario_nine_close_gap, D("1.2"))
        self.assertEqual(self.state.scenario_nine_extra_loss, D("0.2"))
        self.assertEqual(self.state.scenario_nine_total_loss, D("21.4"))
        self.assertEqual(self.state.scenario_nine_long_fill, D("4001.5"))
        self.assertEqual(self.state.scenario_nine_short_fill, D("4000.3"))
        self.assertEqual(self.state.net_cycle_result, D("-21.4"))
        self.assertFalse(self.state.manual)
        self.assertFalse(self.state.active)

    def test_zero_profit_override_is_not_replaced_by_config_default(self):
        self.state.reset(); self.state.profit_override = D("0"); self.state.profit_override_remaining = 1
        self.strategy.begin(D("4010.3"), D("4010")); self.strategy.confirm_initial_fills(D("4010.3"), D("4010"))
        self.assertEqual(self.state.target_value, D("0.0"))
        self.assertEqual(self.state.general_recovery, D("0.03"))

    def test_profit_override_applies_to_exactly_200_completed_cycles(self):
        self.state.reset()
        self.state.profit_override = D("0.4")
        self.state.profit_override_remaining = 200
        for index in range(200):
            self.strategy.begin(D("4010.3"), D("4010"))
            self.assertEqual(self.state.cycle_target_profit, D("0.4"))
            self.strategy.complete("BUY", self.state.long.take_profit)
            self.state.reset()
            self.assertEqual(self.state.profit_override_remaining, 199 - index)
        self.assertIsNone(self.state.profit_override)
        self.strategy.begin(D("4010.3"), D("4010"))
        self.assertEqual(self.state.cycle_target_profit, D("0.3"))

    def test_event_is_idempotent(self):
        self.strategy.stopped("SELL", D("4011.10"), "event")
        recovery = self.state.recovery
        self.strategy.stopped("SELL", D("4011.10"), "event")
        self.assertEqual(self.state.recovery, recovery)

    def test_state_round_trip(self):
        with tempfile.NamedTemporaryFile() as file:
            self.state.save(file.name); restored = CycleState.load(file.name)
        self.assertEqual(restored.general_recovery, self.state.general_recovery)
        self.assertEqual(restored.target_value, self.state.target_value)
        self.assertEqual(restored.recovery_events, self.state.recovery_events)

    def test_reset_does_not_restore_prior_cycle_deal_ids(self):
        self.state.long.deal_id = "long-1"
        self.state.long.deal_reference = "ref-1"
        self.state.remember_deal(self.state.long)
        self.strategy.stopped("SELL", D("4011.10"), "stop-short")
        self.strategy.reopened("SELL", D("4009.90"), "short-2", "reopen-short")
        self.state.remember_close("long-1", "TP", D("4012.70"))
        self.state.reset()
        with tempfile.NamedTemporaryFile() as file:
            self.state.save(file.name)
            restored = CycleState.load(file.name)
        self.assertEqual(restored.deal_history, [])
        self.assertEqual(restored.attempt_history, [])

    def test_slippage_helpers_use_absolute_deviation(self):
        self.assertEqual(stop_slippage("BUY", D("10"), D("9.9")), D("0.1"))
        self.assertEqual(stop_slippage("BUY", D("10"), D("10.1")), D("0.1"))
        self.assertEqual(trigger_slippage("SELL", D("10"), D("9.9")), D("0.1"))
        self.assertEqual(trigger_slippage("SELL", D("10"), D("10.1")), D("0.1"))


class ScenarioParameterStrategyTest(unittest.TestCase):
    SIZES = tuple(map(D, ("10", "10", "10", "10", "20", "20", "20", "20", "20")))
    STOPS = tuple(map(D, ("1", "1", "3", "4", "4", "4", "4", "4", "4")))

    def make_strategy(self, sizes=None):
        state = CycleState()
        cfg = Settings(size=D("10"), stop_distance=D("1"), target_profit=D("0.30"),
                       scenario_sizes=sizes or self.SIZES,
                       scenario_stop_distances=self.STOPS)
        strategy = Strategy(cfg, state)
        strategy.begin(D("4010.50"), D("4010.00"))
        strategy.confirm_initial_fills(D("4010.50"), D("4010.00"))
        return strategy, state

    @staticmethod
    def reopen_exact(strategy, state, direction):
        leg = state.long if direction == "BUY" else state.short
        strategy.stopped(direction, leg.stop, f"stop-{state.scenario}-{direction}")
        strategy.reopened(direction, leg.original_trigger_level,
                          f"deal-{state.scenario + 1}-{direction}")

    def test_full_control_example_without_slippage(self):
        strategy, state = self.make_strategy()
        for direction in ("BUY", "SELL", "BUY", "SELL", "BUY", "SELL", "BUY", "SELL"):
            self.reopen_exact(strategy, state, direction)
        self.assertEqual(state.scenario, 9)
        self.assertEqual(state.phase, "SCENARIO_9_CLOSING")
        self.assertTrue(all(leg.temporary_recovery == 0 for leg in (state.long, state.short)))

    def test_first_increase_slippage_is_divided_after_old_slippage_but_not_trigger_slippage(self):
        strategy, state = self.make_strategy()
        for direction in ("BUY", "SELL", "BUY"): self.reopen_exact(strategy, state, direction)
        before = state.general_recovery
        strategy.stopped("SELL", state.short.stop + D("0.10"), "sell-slip")
        self.assertEqual(state.general_recovery, before + D("41"))
        strategy.reopened("SELL", state.short.original_trigger_level - D("0.10"), "sell-5", "sell-open")
        self.assertEqual(state.short.size, D("20"))

    def test_first_buy_increase_is_mirror_of_sell_increase(self):
        strategy, state = self.make_strategy()
        for direction in ("SELL", "BUY", "SELL"): self.reopen_exact(strategy, state, direction)
        strategy.stopped("BUY", state.long.stop - D("0.10"), "buy-slip")
        strategy.reopened("BUY", state.long.original_trigger_level + D("0.10"), "buy-5", "buy-open")
        self.assertEqual(state.long.size, D("20"))
        self.assertEqual(state.short.size, D("10"))

    def test_second_increase_removes_only_temporary_parts_and_synchronizes_recovery(self):
        strategy, state = self.make_strategy()
        for direction in ("BUY", "SELL", "BUY", "SELL", "BUY"): self.reopen_exact(strategy, state, direction)
        self.assertEqual((state.long.size, state.short.size), (D("20"), D("20")))
        self.assertEqual(state.general_recovery / state.long.size, state.general_recovery / state.short.size)
        self.assertEqual((state.long.temporary_recovery, state.short.temporary_recovery), (D("0"), D("0")))

    def test_same_large_side_can_reopen_twice_without_another_division(self):
        strategy, state = self.make_strategy()
        for direction in ("BUY", "SELL", "BUY", "SELL", "SELL"): self.reopen_exact(strategy, state, direction)
        self.assertEqual(state.short.size, D("20")); self.assertEqual(state.long.size, D("10"))
        self.assertEqual(state.scenario, 6)

    def test_increase_may_begin_at_scenario_three_or_seven(self):
        for start in (3, 7):
            sizes = tuple(D("10") if scenario < start else D("20")
                          for scenario in range(1, 10))
            strategy, state = self.make_strategy(sizes)
            direction = "BUY"
            while state.scenario < start:
                self.reopen_exact(strategy, state, direction)
                direction = "SELL" if direction == "BUY" else "BUY"
            increased = state.long if state.long.size == 20 else state.short
            unchanged = state.short if increased is state.long else state.long
            self.assertEqual(increased.size, D("20"))
            self.assertEqual(unchanged.size, D("10"))

    def test_state_round_trip_preserves_scaled_recovery_and_temporary_parts(self):
        strategy, state = self.make_strategy(); self.reopen_exact(strategy, state, "BUY")
        with tempfile.NamedTemporaryFile() as file:
            state.save(file.name); restored = CycleState.load(file.name)
        self.assertEqual(restored.general_recovery, state.general_recovery)
        self.assertEqual(restored.pending_recovery, state.pending_recovery)

    def test_continuation_rebuilds_equal_pair_from_money_without_temporary_parts(self):
        strategy, state = self.make_strategy(); state.scenario = 6; state.cycle_attempt = 2
        state.general_recovery = D("100")
        strategy.begin_continuation(D("4020.50"), D("4020.00"))
        self.assertEqual(state.general_recovery, D("100"))
        strategy.confirm_continuation_fills(D("4020.50"), D("4020.00"))
        self.assertEqual(state.general_recovery, D("110"))

    def test_invalid_size_sequences_are_rejected(self):
        for sizes in ((D("10"),) * 8,
                      (D("10"), D("20"), D("10")) + (D("10"),) * 6,
                      (D("10"), D("30")) + (D("30"),) * 7):
            with self.assertRaises(ValueError):
                Settings(scenario_sizes=sizes,
                         scenario_stop_distances=(D("1"),) * 9).validate()


class EntryRetryTest(unittest.TestCase):
    def make_bot(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings(dry_run=False, api_key="key", identifier="id", password="password")
        bot.capital = Mock()
        bot.capital.positions.return_value = []
        def position(deal_id):
            leg = next((candidate for candidate in (bot.state.long, bot.state.short)
                        if candidate and candidate.deal_id == deal_id), None)
            if leg:
                return {"position": {"dealId": deal_id, "stopLevel": leg.stop,
                                     "profitLevel": leg.take_profit}}
            return {"position": {}}
        bot.capital.position.side_effect = position
        bot.capital.working_orders.return_value = []
        bot.telegram = Mock()
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.execution_policy = ExecutionPolicy()
        bot._flat_checks = 0
        bot.strategy.begin(D("4010.30"), D("4010.00"))
        bot.strategy.confirm_initial_fills(D("4010.30"), D("4010.00"))
        return bot

    def test_double_initial_stop_report_is_separate_and_idempotent(self):
        bot = self.make_bot()
        bot.state.cycle_id = 270
        bot.state.cycle_attempt = 1
        bot.state.attempt_result_total = D("17.25")
        buy, sell = bot.state.long, bot.state.short
        buy.size, buy.current_entry, buy.stop, buy.deal_id = D("10"), D("4286.07"), D("4285.07"), "buy"
        sell.size, sell.current_entry, sell.stop, sell.deal_id = D("10"), D("4285.12"), D("4286.12"), "sell"

        bot._report_initial_pair_closures(sell, "SL", D("4286.14"), buy, ("SL", D("4285.04")))
        text = bot.telegram.send.call_args.args[0]
        self.assertIn("Цикл №270; попытка 1", text)
        self.assertIn("-10.20", text)
        self.assertIn("-10.30", text)
        self.assertIn("-20.50", text)
        self.assertIn("НЕ добавлен", text)
        self.assertEqual(bot.state.attempt_result_total, D("17.25"))
        bot._report_initial_pair_closures(sell, "SL", D("4286.14"), buy, ("SL", D("4285.04")))
        self.assertEqual(bot.telegram.send.call_count, 1)

    def test_initial_stop_report_does_not_treat_absence_as_close(self):
        bot = self.make_bot()
        buy, sell = bot.state.long, bot.state.short
        buy.deal_id, sell.deal_id = "buy", "sell"
        bot._report_initial_pair_closures(buy, "SL", D("4009.30"), sell, None)
        text = bot.telegram.send.call_args.args[0]
        self.assertIn("не доказательство закрытия", text)
        self.assertIn("итог пары пока не объявлен", text)

    def test_initial_leg_gets_three_retries(self):
        bot = self.make_bot()
        bot.capital.open_position.return_value = "reference"
        bot.capital.wait_position.return_value = {"dealId": "deal", "level": 4010.35}
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "REJECTED", "reason": "busy"},
            {"dealStatus": "REJECTED", "reason": "busy"},
            {"dealStatus": "REJECTED", "reason": "busy"},
            {"dealStatus": "ACCEPTED", "dealId": "deal", "level": 4010.35},
        ]
        with patch("trader.app.time.sleep"):
            error = bot._open_initial_leg(bot.state.long)
        self.assertIsNone(error)
        self.assertEqual(bot.capital.open_position.call_count, 4)
        self.assertEqual(bot.state.long.current_entry, D("4010.35"))
        kwargs = bot.capital.open_position.call_args.kwargs
        self.assertEqual(kwargs["stop_distance"], D("1"))
        self.assertNotIn("profit_distance", kwargs)

    def test_trigger_and_market_fallback_use_next_scenario_parameters(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            scenario_sizes=(D("10"), D("20")) + (D("20"),) * 7,
            scenario_stop_distances=(D("1"), D("3")) + (D("3"),) * 7,
        )
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4010.50"), D("4010.00"))
        bot.strategy.confirm_initial_fills(D("4010.50"), D("4010.00"))
        bot.strategy.stopped("BUY", D("4009.50"), "buy-stop")
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "buy-trigger"
        }
        bot.capital.working_stop.return_value = "trigger-ref"

        bot._create_trigger(bot.state.long)

        args = bot.capital.working_stop.call_args.args
        self.assertEqual(args[2], D("20"))
        self.assertEqual(args[3:], (D("4010.50"), D("4007.50"), D("4013.50")))

        bot.capital.working_stop.reset_mock()
        bot.capital.open_position.return_value = "market-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "buy-2", "level": 4010.4,
            "affectedDeals": [{"dealId": "buy-2", "status": "OPENED"}],
        }
        bot.capital.wait_position.return_value = {
            "dealId": "buy-2", "direction": "BUY", "level": 4010.4,
        }
        bot.state.long.trigger_id = ""
        bot._open_passed_trigger_at_market(bot.state.long, D("4015.40"))
        market_args = bot.capital.open_position.call_args.args
        self.assertEqual(market_args[2], D("20"))
        self.assertEqual(market_args[3], D("4007.50"))

    def test_trigger_transition_notification_precedes_protection_reports(self):
        bot = self.make_bot()
        bot.strategy.stopped("SELL", D("4011.00"), "stop-short")
        bot.state.short.trigger_id = "trigger-short"
        bot.telegram.reset_mock()
        bot._apply_protection = Mock(return_value=True)
        positions = {
            "short-2": {
                "dealId": "short-2", "direction": "SELL", "level": 4010.00,
                "workingOrderId": "trigger-short",
            }
        }

        bot._detect_trigger_fill(positions)

        first_report = bot.telegram.send.call_args_list[0].args[0]
        self.assertIn("Trigger исполнен — переход в сценарий 2", first_report)
        self.assertEqual(bot._apply_protection.call_count, 2)

    def test_scenario_nine_removes_protection_and_closes_both_sides(self):
        bot = self.make_bot()
        bot.state.scenario = 8
        bot.state.realized_losses = D("20")
        bot.strategy.stopped("SELL", bot.state.short.stop, "sell-sl-8")
        bot.strategy.reopened("SELL", D("4010"), "short-9", "sell-open-9")
        bot.state.long.deal_id = "long-9"
        bot.capital.positions.return_value = [
            {"position": {"dealId": "long-9", "direction": "BUY", "level": 4010.3},
             "market": {"epic": "GOLD"}},
            {"position": {"dealId": "short-9", "direction": "SELL", "level": 4010},
             "market": {"epic": "GOLD"}},
        ]
        bot.capital.update_position.side_effect = lambda deal_id, _sl, _tp: f"update-{deal_id}"
        bot.capital.close_position.side_effect = lambda deal_id: f"close-{deal_id}"

        def confirmation(reference):
            levels = {"close-long-9": 4001.5, "close-short-9": 4000.3}
            payload = {"dealStatus": "ACCEPTED"}
            if reference in levels:
                payload["level"] = levels[reference]
                payload["dealId"] = reference.removeprefix("close-")
            return payload

        bot.capital.wait_confirmation.side_effect = confirmation
        with tempfile.NamedTemporaryFile() as state_file:
            bot.cfg = Settings(
                dry_run=False, api_key="key", identifier="id", password="password",
                state_file=state_file.name,
            )
            bot.strategy = Strategy(bot.cfg, bot.state)
            bot._enter_manual_nine()

        self.assertFalse(bot.state.active)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.scenario_nine_total_loss, D("22.20"))
        self.assertTrue(bot.state.scenario_nine_triggers_verified)
        self.assertEqual(bot.state.scenario_nine_extra_loss, D("0"))
        self.assertEqual(len(bot.state.pending_transaction_jobs), 1)
        self.assertEqual(bot.state.pending_transaction_jobs[0]["status"], "PENDING")
        self.assertEqual(bot.capital.close_position.call_count, 2)
        bot.capital.update_position.assert_any_call("long-9", None, None)
        bot.capital.update_position.assert_any_call("short-9", None, None)

    def test_inactive_completed_cycle_never_recreates_trigger(self):
        bot = self.make_bot()
        bot.state.short.open = False
        bot.state.short.trigger_id = ""
        bot.state.short.stop = None
        bot.state.active = False
        bot.state.phase = "FILTER"

        bot._ensure_expected_trigger()

        bot.capital.working_stop.assert_not_called()

    def test_scenario_nine_ignores_foreign_close_confirmation_price(self):
        bot = self.make_bot()
        bot.state.scenario = 8
        bot.state.realized_losses = D("0")
        bot.state.long.deal_id = "00000000-618c-b0bf"
        bot.state.long.current_entry = D("4406.78")
        bot.state.short.deal_id = "00000000-618c-d4ed"
        bot.state.short.current_entry = D("4406.18")
        bot.capital.positions.return_value = [
            {"position": {"dealId": bot.state.long.deal_id, "direction": "BUY",
                          "level": 4406.78}, "market": {"epic": bot.cfg.epic}},
            {"position": {"dealId": bot.state.short.deal_id, "direction": "SELL",
                          "level": 4406.18}, "market": {"epic": bot.cfg.epic}},
        ]
        bot.capital.update_position.side_effect = lambda deal_id, stop, tp: f"update-{deal_id}"
        bot.capital.close_position.side_effect = lambda deal_id: f"close-{deal_id}"

        def confirmation(reference):
            if reference.startswith("update-"):
                return {"dealStatus": "ACCEPTED"}
            if reference.endswith("b0bf"):
                return {"dealStatus": "ACCEPTED", "dealId": "00000000-618c-b0bf",
                        "affectedDeals": [{"dealId": "00000000-618c-b0bf",
                                           "status": "CLOSED"}], "level": 4406.02}
            # Reproduce the journal defect: SELL confirmation carries the BUY id and price.
            return {"dealStatus": "ACCEPTED", "dealId": "00000000-618c-b0bf",
                    "affectedDeals": [{"dealId": "00000000-618c-b0bf",
                                       "status": "CLOSED"}], "level": 4406.02}

        bot.capital.wait_confirmation.side_effect = confirmation
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: ([{
            "dealId": "00000000-618c-d4ed", "source": "USER", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 4406.50, "direction": "BUY",
                                                   "size": "0.1"},
        }] if deal_id == "00000000-618c-d4ed" else [])
        with patch("trader.app.time.sleep"):
            bot._enter_manual_nine()

        self.assertEqual(bot.state.scenario_nine_long_fill, D("4406.02"))
        self.assertEqual(bot.state.scenario_nine_short_fill, D("4406.50"))
        self.assertEqual(bot.state.scenario_nine_close_gap, D("0.48"))

    def test_scenario_nine_actual_deal_result_updates_attempt_total_once(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            size=D("10"), state_file=bot.cfg.state_file,
        )
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.state.scenario = 8
        bot.state.attempt_counter = bot.state.active_attempt_id = 9
        bot.state.diagnostic_cycle_number = 9
        bot.state.attempt_result_total = D("20")
        bot.state.long.deal_id, bot.state.long.current_entry = "long-9", D("100")
        bot.state.short.deal_id, bot.state.short.current_entry = "short-9", D("100")
        bot.state.long.size = bot.state.short.size = D("10")
        bot.state.attempt_deal_ids = ["long-9", "short-9"]
        bot.state.remember_deal(bot.state.long)
        bot.state.remember_deal(bot.state.short)
        bot.capital.positions.return_value = [
            {"position": {"dealId": "long-9", "direction": "BUY", "level": 100},
             "market": {"epic": bot.cfg.epic}},
            {"position": {"dealId": "short-9", "direction": "SELL", "level": 100},
             "market": {"epic": bot.cfg.epic}},
        ]
        bot.capital.update_position.side_effect = lambda deal_id, stop, tp: f"update-{deal_id}"
        bot.capital.close_position.side_effect = lambda deal_id: f"close-{deal_id}"
        bot.capital.wait_confirmation.side_effect = lambda reference: (
            {"dealStatus": "ACCEPTED"} if reference.startswith("update-") else
            {"dealStatus": "ACCEPTED", "dealId": reference.removeprefix("close-"),
             "level": 94 if reference.endswith("long-9") else 107}
        )

        with patch("trader.app.time.sleep"):
            bot._enter_manual_nine()
            bot._refresh_actual_attempt_result()

        # Completion archives and clears the per-cycle ledger; the durable aggregate remains.
        self.assertEqual(bot.state.attempt_history, [])
        self.assertIsNotNone(bot.state.completed_cycle_report)
        self.assertEqual(bot.state.attempt_result_total, D("-110"))
        self.assertEqual(bot.state.pending_actual_attempt_id, 0)

    def test_actual_attempt_result_uses_each_deal_own_size(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            scenario_sizes=(D("10"), D("20")) + (D("20"),) * 7,
            scenario_stop_distances=(D("1"),) * 9,
            state_file=bot.cfg.state_file,
        )
        bot.state.pending_actual_attempt_id = 31
        bot.state.pending_actual_deal_ids = ["small", "large"]
        bot.state.attempt_history = [{"attempt_id": 31, "status": "PENDING"}]
        bot.state.deal_history = [
            {"deal_id": "small", "direction": "BUY", "entry": "100",
             "close_level": "99", "size": "10"},
            {"deal_id": "large", "direction": "SELL", "entry": "100",
             "close_level": "102", "size": "20"},
        ]

        self.assertTrue(bot._refresh_actual_attempt_result())
        self.assertEqual(bot.state.attempt_history[0]["actual_result"], "-50")
        self.assertEqual(bot.state.attempt_result_total, D("-50"))

    def test_pending_scenario_nine_actual_result_survives_reload_and_is_idempotent(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            size=D("10"), state_file=bot.cfg.state_file,
        )
        bot.state.attempt_history = [{
            "attempt_id": 12, "status": "COMPLETED_SCENARIO_9",
            "result": "-99", "actual_result_status": "PENDING",
        }]
        bot.state.deal_history = [{
            "deal_id": "scenario9-deal", "direction": "BUY", "entry": "100",
            "size": "10", "close_level": None,
        }]
        bot.state.pending_actual_attempt_id = 12
        bot.state.pending_actual_deal_ids = ["scenario9-deal"]
        bot.capital.activity.return_value = []
        self.assertFalse(bot._refresh_actual_attempt_result())
        restored = CycleState.load(bot.cfg.state_file)
        self.assertEqual(restored.pending_actual_attempt_id, 12)

        bot.state = restored
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.capital.activity.return_value = [{
            "dealId": "scenario9-deal", "source": "USER", "type": "POSITION",
            "status": "ACCEPTED", "details": {"direction": "SELL", "level": 97,
                                                   "size": 10},
        }]
        self.assertTrue(bot._refresh_actual_attempt_result())
        self.assertTrue(bot._refresh_actual_attempt_result())
        self.assertEqual(bot.state.attempt_result_total, D("-30"))
        self.assertEqual(bot.state.attempt_history[0]["actual_result_status"], "CONFIRMED")

    def test_scenario_nine_closes_trigger_that_executes_during_cancellation(self):
        bot = self.make_bot()
        bot.capital.activity.return_value = []
        bot.capital.positions.return_value = [{
            "position": {
                "dealId": "extra-sell", "workingOrderId": "trigger-sell",
                "direction": "SELL", "level": 4000,
            },
            "market": {"epic": "GOLD"},
        }]
        bot.capital.close_position.return_value = "close-extra"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "extra-sell", "level": 4001,
        }

        with patch("trader.app.time.sleep"):
            loss = bot._close_scenario_nine_trigger_races(
                {"trigger-sell"}, {"long-9", "short-9"}
            )

        self.assertEqual(loss, D("1"))
        bot.capital.close_position.assert_called_once_with("extra-sell")
        self.assertIn("исполнился во время отмены", bot.telegram.send.call_args.args[0])

    def test_scenario_nine_verifies_trigger_cancellation_with_three_empty_reads(self):
        bot = self.make_bot()
        order = {
            "workingOrderData": {"dealId": "trigger-buy"},
            "marketData": {"epic": "GOLD"},
        }
        bot.state.cycle_trigger_ids = ["trigger-buy"]
        bot.capital.working_orders.side_effect = [[order], [], [], []]
        bot.capital.delete_working_order.return_value = True

        with patch("trader.app.time.sleep"):
            uncertain = bot._cancel_and_verify_scenario_nine_triggers()

        self.assertEqual(uncertain, set())
        self.assertTrue(bot.state.scenario_nine_triggers_verified)
        bot.capital.delete_working_order.assert_called_once_with("trigger-buy")

    def test_exact_stop_is_confirmed_before_take_profit(self):
        bot = self.make_bot()
        leg = bot.state.long
        leg.deal_id = "long-1"
        bot.capital.update_position.return_value = "stop-ref"
        bot.capital.wait_confirmation.return_value = {"dealStatus": "ACCEPTED"}
        bot.capital.position.return_value = {
            "position": {"dealId": "long-1", "stopLevel": 4009.30, "profitLevel": None}
        }

        bot._apply_stop_only(leg)

        bot.capital.update_position.assert_called_once_with("long-1", D("4009.30"), None)
        bot.capital.position.assert_called_once_with("long-1")
        self.assertIn("TP пока не установлен", bot.telegram.send.call_args.args[0])

    def test_take_profit_is_read_back_after_both_stops(self):
        bot = self.make_bot()
        leg = bot.state.long
        leg.deal_id = "long-1"
        leg.take_profit = D("4011.60")
        bot.capital.update_position.return_value = "tp-ref"
        bot.capital.wait_confirmation.return_value = {"dealStatus": "ACCEPTED"}
        bot.capital.position.return_value = {
            "position": {
                "dealId": "long-1",
                "stopLevel": 4009.30,
                "profitLevel": 4011.60,
            }
        }

        bot._apply_take_profit_only(leg)

        bot.capital.update_position.assert_called_once_with(
            "long-1", D("4009.30"), D("4011.60")
        )
        bot.capital.position.assert_called_once_with("long-1")
        self.assertIn("Take Profit подтверждён", bot.telegram.send.call_args.args[0])

    def test_survivor_is_closed_when_target_was_crossed_before_tp_update(self):
        bot = self.make_bot()
        leg = bot.state.short
        bot.strategy.stopped("BUY", D("4009.25"), "stop-long")
        leg.deal_id = "short-1"
        bot.capital.quote.return_value = (D("4008.00"), D("4008.20"))
        bot.capital.close_position.return_value = "close-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "short-1", "level": 4008.18,
        }

        protected = bot._apply_protection(leg)

        self.assertFalse(protected)
        bot.capital.update_position.assert_not_called()
        bot.capital.close_position.assert_called_once_with("short-1")
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.net_cycle_result, D("0.77"))
        self.assertIn("Целевая цена достигнута", bot.telegram.send.call_args.args[0])

    def test_market_take_profit_cancels_pending_trigger_before_completion(self):
        bot = self.make_bot()
        winner = bot.state.short
        bot.strategy.stopped("BUY", D("4009.25"), "stop-long")
        winner.deal_id = "short-1"
        bot.state.long.trigger_id = "buy-trigger"
        bot.capital.quote.return_value = (D("4008.00"), D("4008.20"))
        bot.capital.close_position.return_value = "close-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "short-1", "level": 4008.18,
        }
        bot.capital.delete_working_order.return_value = True

        self.assertFalse(bot._apply_protection(winner))

        bot.capital.delete_working_order.assert_called_once_with("buy-trigger")
        self.assertIsNone(bot.state.long)
        self.assertFalse(bot.state.active)

    def test_market_take_profit_accounts_for_trigger_race_before_completion(self):
        bot = self.make_bot()
        winner = bot.state.short
        bot.strategy.stopped("BUY", D("4009.25"), "stop-long")
        winner.deal_id = "short-1"
        bot.state.long.trigger_id = "buy-trigger"
        bot.capital.quote.return_value = (D("4008.00"), D("4008.20"))
        bot.capital.close_position.return_value = "close-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "short-1", "level": 4008.18,
        }
        bot.capital.delete_working_order.return_value = False
        bot._close_trigger_that_raced_with_tp = Mock(return_value=D("0.20"))

        self.assertFalse(bot._apply_protection(winner))

        self.assertEqual(bot.state.realized_losses, D("1.05"))
        self.assertEqual(bot.state.net_cycle_result, D("0.77"))
        self.assertEqual(bot._close_trigger_that_raced_with_tp.call_count, 1)

    def test_market_take_profit_waits_across_ticks_for_uncertain_trigger(self):
        bot = self.make_bot()
        winner = bot.state.short
        bot.strategy.stopped("BUY", D("4009.25"), "stop-long")
        winner.deal_id = "short-1"
        bot.state.long.trigger_id = "buy-trigger"
        bot.capital.quote.return_value = (D("4008.00"), D("4008.20"))
        bot.capital.close_position.return_value = "close-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "short-1", "level": 4008.18,
        }
        bot.capital.delete_working_order.return_value = False
        bot._close_trigger_that_raced_with_tp = Mock(side_effect=[None, D("0.20")])

        self.assertFalse(bot._apply_protection(winner))
        self.assertTrue(bot.state.active)
        self.assertEqual(bot.state.pending_tp_direction, "SELL")
        self.assertEqual(bot.state.pending_tp_fill, D("4008.18"))

        bot._tick_cycle()

        bot.capital.close_position.assert_called_once_with("short-1")
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.pending_tp_direction, "")
        self.assertIsNone(bot.state.pending_tp_fill)
        self.assertEqual(bot.state.net_cycle_result, D("0.77"))

    def test_identifierless_close_waits_for_history_without_second_delete(self):
        bot = self.make_bot()
        winner = bot.state.long
        winner.deal_id = "buy-close-id"
        winner.take_profit = D("4011.60")
        bot.state.phase = "LONG_ONLY"
        bot.state.short.open = False
        bot.capital.quote.return_value = D("4011.70"), D("4011.90")
        bot.capital.close_position.return_value = "close-ref"
        # ACCEPTED level is deliberately untrusted because both dealId and affectedDeals are absent.
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "level": 4011.72,
        }
        close_visible = False
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: ([{
            "dealId": "buy-close-id", "source": "TP", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 4011.71, "direction": "SELL",
                                               "size": 0.1},
        }] if close_visible else [])

        with patch("trader.app.time.sleep"):
            self.assertFalse(bot._apply_protection(winner))
        self.assertEqual(bot.state.pending_close_reference, "close-ref")
        bot.capital.close_position.assert_called_once()

        close_visible = True
        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
        bot.capital.close_position.assert_called_once()
        self.assertEqual(bot.state.pending_close_reference, "")
        self.assertFalse(bot.state.active)

    def test_take_profit_maxvalue_race_falls_back_to_market_close(self):
        bot = self.make_bot()
        leg = bot.state.short
        bot.strategy.stopped("BUY", D("4009.25"), "stop-long")
        leg.deal_id = "short-1"
        bot.capital.quote.side_effect = [
            (D("4009.00"), D("4009.20")),
            (D("4008.00"), D("4008.20")),
        ]
        bot.capital.update_position.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.invalid.takeprofit.maxvalue: 4008.20"}'
        )
        bot.capital.close_position.return_value = "close-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "short-1", "level": 4008.18,
        }

        self.assertFalse(bot._apply_protection(leg))
        bot.capital.close_position.assert_called_once_with("short-1")
        self.assertFalse(bot.state.active)

    def test_take_profit_during_initial_protection_completes_cycle(self):
        bot = self.make_bot()
        bot.capital.activity.return_value = [{
            "dateUTC": "2026-09-23T00:00:01Z", "dealId": "short-1",
            "source": "SL", "type": "POSITION", "status": "ACCEPTED",
            "details": {"level": 4011.05, "size": 0.1},
        }]
        bot.state.long.deal_id = "long-1"
        bot.state.short.deal_id = "short-1"
        bot.capital.positions.side_effect = [
            [{"position": {"dealId": "short-1"}, "market": {"epic": bot.cfg.epic}}],
            *([[]] * 10),
        ]
        bot._closing_fill = Mock(
            side_effect=lambda leg, source="SL": {
                ("long-1", "TP"): D("4011.60"),
                ("short-1", "SL"): D("4011.05"),
            }.get((leg.deal_id, source))
        )

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.phase, "FILTER")
        self.assertEqual(bot.state.realized_losses, D("1.05"))
        self.assertEqual(bot.state.gross_take_profit, D("1.30"))
        self.assertEqual(bot.state.net_cycle_result, D("0.25"))
        self.assertIn("Итог завершённого цикла", bot.telegram.send.call_args.args[0])

    def test_accepted_unresolved_position_is_not_opened_twice(self):
        bot = self.make_bot()
        bot.capital.open_position.return_value = "accepted-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "confirmation-id",
        }
        bot.capital.wait_position.side_effect = CapitalError("positions synchronization timeout")
        bot.capital.activity.return_value = []

        with patch("trader.app.time.sleep"):
            error = bot._open_initial_leg(bot.state.long)

        self.assertIn("заявка принята", error)
        self.assertEqual(bot.state.long.deal_reference, "accepted-ref")
        bot.capital.open_position.assert_called_once()

    def test_initial_transport_timeout_reconciles_reference_without_second_market_order(self):
        bot = self.make_bot()
        bot.capital.open_position.side_effect = CapitalError("transport timeout")
        bot.capital.wait_confirmation.side_effect = CapitalError("confirmation unavailable")

        with patch("trader.app.time.sleep"):
            error = bot._open_initial_leg(bot.state.long)

        self.assertIn("повторное открытие заблокировано", error)
        bot.capital.open_position.assert_called_once()
        bot.capital.wait_confirmation.assert_not_called()
        self.assertFalse(bot.state.manual)
        self.assertTrue(bot.state.active)
        self.assertEqual(bot.state.long.pending_market_kind, "INITIAL")

    def test_initial_confirmation_timeout_persists_reference_and_blocks_filter_reset(self):
        bot = self.make_bot()
        bot.capital.open_position.return_value = "initial-ref"
        bot.capital.wait_confirmation.side_effect = CapitalError("confirmation unavailable")
        bot.capital.positions.return_value = []

        with patch("trader.app.time.sleep"):
            error = bot._open_initial_leg(bot.state.long)

        self.assertIn("повторное открытие заблокировано", error)
        bot.capital.open_position.assert_called_once()
        self.assertFalse(bot.state.manual)
        self.assertTrue(bot.state.active)
        self.assertFalse(bot.state.armed)
        self.assertEqual(bot.state.long.pending_market_reference, "initial-ref")

    def test_accepted_position_closed_before_positions_sync_is_classified_from_activity(self):
        bot = self.make_bot()
        bot.capital.open_position.return_value = "accepted-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED",
            "dealId": "fast-close",
            "level": 4621.38,
        }
        bot.capital.wait_position.side_effect = CapitalError("positions synchronization timeout")
        bot.capital.activity.return_value = [{
            "dateUTC": "2026-08-25T02:51:38.000",
            "dealId": "fast-close",
            "source": "SL",
            "type": "POSITION",
            "status": "ACCEPTED",
            "details": {"level": 4620.31, "direction": "SELL"},
        }]

        error = bot._open_initial_leg(bot.state.long)

        self.assertIn("закрылась по SL", error)
        self.assertEqual(bot.state.long.deal_id, "fast-close")
        self.assertEqual(bot.state.long.current_entry, D("4621.38"))
        self.assertEqual(bot.state.long.original_trigger_level, D("4621.38"))
        self.assertEqual(bot.state.long.stop, D("4620.38"))
        self.assertFalse(bot.state.long.open)
        self.assertEqual(
            bot._initial_entry_close,
            (bot.state.long, "SL", D("4620.31")),
        )
        bot.capital.open_position.assert_called_once()

    def test_accepted_close_waits_for_delayed_deal_history(self):
        bot = self.make_bot()
        bot.capital.open_position.return_value = "accepted-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED",
            "dealId": "delayed-close",
            "level": 4621.38,
        }
        bot.capital.wait_position.side_effect = CapitalError("positions synchronization timeout")
        bot.capital.activity.side_effect = [[], [], [{
            "dateUTC": "2026-08-25T02:51:50.000",
            "dealId": "delayed-close",
            "source": "TP",
            "type": "POSITION",
            "status": "ACCEPTED",
            "details": {"level": 4622.70, "direction": "SELL"},
        }]]

        with patch("trader.app.time.sleep"):
            error = bot._open_initial_leg(bot.state.long)

        self.assertIn("закрылась по TP", error)
        self.assertEqual(bot.capital.activity.call_count, 3)
        self.assertEqual(
            bot._initial_entry_close,
            (bot.state.long, "TP", D("4622.70")),
        )

    def test_initial_empty_affected_deals_links_open_and_sl_then_pauses(self):
        bot = self.make_bot()
        bot.state.reset()
        bot._flat_checks = 2
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            size=D("10"), state_file=bot.cfg.state_file,
        )
        bot.strategy = Strategy(bot.cfg, bot.state)
        execution_id = "00000000-618f-7312"
        position_id = "00000000-618f-7315"
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []
        bot.capital.quote.return_value = D("4405.10"), D("4405.60")
        bot.capital.open_position.return_value = "initial-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": execution_id,
            "affectedDeals": [], "level": 4405.60, "direction": "BUY",
        }
        bot.capital.wait_position.side_effect = CapitalError("position already absent")
        opening = {
            "dealId": position_id, "source": "USER", "type": "POSITION",
            "status": "ACCEPTED", "details": {
                "workingOrderId": execution_id, "direction": "BUY", "level": 4405.60,
            },
        }
        closing = {
            "dealId": position_id, "source": "SL", "type": "POSITION",
            "status": "ACCEPTED", "details": {
                "direction": "SELL", "level": 4404.08, "openPrice": 4405.60,
            },
        }
        global_reads = 0

        def activity(deal_id="", last_period=86400):
            nonlocal global_reads
            if deal_id:
                return [{"dealId": execution_id, "source": "USER",
                         "type": "WORKING_ORDER", "status": "EXECUTED"}]
            global_reads += 1
            return [] if global_reads == 1 else [opening, closing]

        bot.capital.activity.side_effect = activity
        with patch("trader.app.time.sleep"):
            bot._start_cycle("demo candle")

        self.assertTrue(bot.state.paused)
        self.assertEqual(bot.state.phase, "PAUSED")
        self.assertFalse(bot.state.armed)
        self.assertEqual(bot.state.attempt_counter, 1)
        self.assertEqual(bot.state.attempt_result_total, D("-15.20"))
        self.assertEqual(bot.state.attempt_history, [])
        self.assertEqual(bot.state.deal_history, [])
        self.assertEqual(bot.capital.open_position.call_count, 1)
        report = bot.telegram.send.call_args.args[0]
        self.assertIn("следующий вход только после /start", report)
        self.assertIn("-15.20", report)

    def test_failed_initial_attempt_ids_are_unique_and_do_not_enter_recovery(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            size=D("10"), state_file=bot.cfg.state_file,
        )
        results = [(D("4405.60"), D("4404.05")),
                   (D("4406.00"), D("4404.43")),
                   (D("4405.60"), D("4404.08"))]
        for attempt_id, (entry, close) in enumerate(results, 1):
            bot.state.attempt_counter = attempt_id
            bot.state.active_attempt_id = attempt_id
            bot.state.diagnostic_cycle_number = attempt_id
            leg = Leg("BUY", entry, entry, deal_id=f"buy-{attempt_id}")
            bot.state.long = leg
            bot._finish_failed_initial_attempt(leg, "SL", close, opposite_sent=False)

        self.assertEqual(bot.state.attempt_history, [])
        self.assertEqual(bot.state.attempt_result_total, D("-46.40"))
        self.assertEqual(bot.state.recovery, D("0"))
        self.assertEqual(bot.state.completed_cycles, 0)

    def test_historical_opening_stays_pending_until_linked_close_arrives(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            size=D("10"), state_file=bot.cfg.state_file,
        )
        bot.strategy = Strategy(bot.cfg, bot.state)
        leg = bot.state.long
        execution_id, position_id = "execution-7312", "position-7315"
        leg.pending_market_kind = "INITIAL"
        leg.pending_market_reference = "initial-ref"
        leg.pending_market_preexisting_ids = []
        bot.state.active_attempt_id = bot.state.attempt_counter = 17
        bot.state.diagnostic_cycle_number = 17
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": execution_id,
            "affectedDeals": [], "level": 4405.60, "direction": "BUY",
        }
        bot.capital.wait_position.side_effect = CapitalError("already closed")
        bot.capital.positions.return_value = []
        opening = {
            "dealId": position_id, "source": "USER", "type": "POSITION",
            "status": "ACCEPTED", "details": {
                "workingOrderId": execution_id, "direction": "BUY", "level": 4405.60,
            },
        }
        closing = {
            "dealId": position_id, "source": "SL", "type": "POSITION",
            "status": "ACCEPTED", "details": {"direction": "SELL", "level": 4404.08},
        }
        close_visible = False

        def activity(deal_id="", last_period=86400):
            if deal_id == position_id:
                return [closing] if close_visible else []
            return [opening] + ([closing] if close_visible else [])

        bot.capital.activity.side_effect = activity
        with patch("trader.app.time.sleep"):
            self.assertTrue(bot._resume_pending_market())
        self.assertEqual(leg.pending_market_kind, "INITIAL")
        self.assertFalse(bot.state.paused)

        close_visible = True
        with patch("trader.app.time.sleep"):
            self.assertTrue(bot._resume_pending_market())
        self.assertTrue(bot.state.paused)
        self.assertEqual(bot.state.attempt_history, [])
        self.assertEqual(bot.state.attempt_result_total, D("-15.20"))

    def _pending_second_initial_bot(self, both_closed=False):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            size=D("10"), stop_distance=D("1.5"), target_profit=D("0.5"),
            state_file=bot.cfg.state_file,
        )
        bot.state.reset()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("100"), D("99.5"))
        bot.state.attempt_counter = bot.state.active_attempt_id = 21
        bot.state.diagnostic_cycle_number = 21
        bot.state.initial_submitted_directions = ["BUY", "SELL"]
        bot.state.long.deal_id = "buy-position"
        bot.state.long.deal_reference = "buy-ref"
        bot.state.short.pending_market_kind = "INITIAL"
        bot.state.short.pending_market_reference = "sell-ref"
        bot.state.short.pending_market_preexisting_ids = ["buy-position"]
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "sell-execution",
            "affectedDeals": [{"dealId": "sell-position", "status": "OPENED"}],
            "level": 99.5, "direction": "SELL",
        }
        bot.capital.wait_position.return_value = {
            "dealId": "sell-position", "direction": "SELL", "level": 99.5,
        }
        sell_position = {"position": {
            "dealId": "sell-position", "direction": "SELL", "level": 99.5,
            "stopLevel": 101.0, "profitLevel": 97.5,
        }, "market": {"epic": bot.cfg.epic}}
        bot.capital.positions.return_value = [] if both_closed else [sell_position]
        events = [{
            "dealId": "buy-position", "source": "SL", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 98.5, "direction": "SELL", "size": 10},
        }]
        if both_closed:
            events.append({
                "dealId": "sell-position", "source": "TP", "type": "POSITION",
                "status": "ACCEPTED", "details": {"level": 97.5, "direction": "BUY", "size": 10},
            })
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: (
            [item for item in events if not deal_id or item["dealId"] == deal_id]
        )
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "buy-trigger-ref"
        bot.capital.wait_confirmation.side_effect = lambda reference: (
            {"dealStatus": "ACCEPTED", "dealId": "buy-trigger"}
            if reference == "buy-trigger-ref" else {
                "dealStatus": "ACCEPTED", "dealId": "sell-execution",
                "affectedDeals": [{"dealId": "sell-position", "status": "OPENED"}],
                "level": 99.5, "direction": "SELL",
            }
        )
        return bot

    def test_delayed_second_initial_with_opposite_sl_continues_formed_cycle(self):
        bot = self._pending_second_initial_bot()
        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
        bot.capital.open_position.assert_not_called()
        self.assertEqual(bot.state.phase, "SHORT_ONLY")
        self.assertEqual(bot.state.realized_losses, D("1.5"))
        self.assertEqual(bot.state.long.trigger_id, "buy-trigger")
        self.assertFalse(bot.state.paused)

    def test_delayed_second_initial_both_closed_accounts_sl_before_tp_once(self):
        bot = self._pending_second_initial_bot(both_closed=True)
        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
            self.assertFalse(bot._resume_pending_market())
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.realized_losses, D("1.5"))
        self.assertEqual(bot.state.gross_take_profit, D("2.0"))
        self.assertEqual(bot.state.net_cycle_result, D("0.5"))
        self.assertEqual(bot.state.attempt_result_total, D("5.0"))
        self.assertEqual(bot.state.attempt_history, [])
        self.assertIsNotNone(bot.state.completed_cycle_report)

    def test_tick_reconciles_two_stops_and_nonblocking_pause_then_filter(self):
        bot = self.make_bot()
        object.__setattr__(bot.cfg, "size", D("10"))
        bot.state.active_attempt_id = bot.state.attempt_counter = bot.state.cycle_id = 224
        bot.state.cycle_attempt = 1
        bot.state.long.deal_id = "buy-224"
        bot.state.short.deal_id = "sell-224"
        bot.state.long.current_entry = D("4372.74")
        bot.state.short.current_entry = D("4371.16")
        bot.state.realized_losses = D("10.82")
        bot.state.realized_loss_money = D("108.20")
        bot.state.long.size = bot.state.short.size = D("10")
        bot.capital.positions.return_value = []
        events = [
            {"dealId": "buy-224", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "type": "POSITION", "details": {"level": 4371.22, "size": 10}},
            {"dealId": "sell-224", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "type": "POSITION", "details": {"level": 4373.53, "size": 10}},
        ]
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: events
        with tempfile.TemporaryDirectory() as directory, \
                patch("trader.app.time.sleep"), patch("trader.app.time.time", return_value=1000):
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            object.__setattr__(bot.cfg, "diagnostic_log_file", str(Path(directory) / "log"))
            bot._tick_cycle()
            self.assertEqual(bot.state.phase, "DOUBLE_SL_PAUSE")
            self.assertTrue(bot.state.continuation_managed)
            self.assertEqual(bot.state.continuation_stage, "PAUSE")
            self.assertEqual(bot.state.continuation_pause_until, 1300)
            self.assertEqual(bot.state.realized_losses, D("14.71"))
            self.assertEqual(bot.state.attempt_result_total, D("-147.10"))
            with patch("trader.app.time.time", return_value=1299):
                bot.tick()
            self.assertEqual(bot.state.phase, "DOUBLE_SL_PAUSE")
            with patch("trader.app.time.time", return_value=1301):
                bot.tick()
            self.assertEqual(bot.state.phase, "CONTINUATION_FILTER")
            self.assertEqual(bot.state.continuation_stage, "FILTER")

    def test_continuation_controller_owns_pending_pair_reconciliation(self):
        bot = self._pending_second_initial_bot(both_closed=False)
        bot.state.cycle_id = 254
        bot.state.cycle_attempt = 2
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "FORMING_PAIR"
        bot.continuation = CycleContinuation(bot)
        bot.command("/stop")
        with patch("trader.app.time.sleep"):
            bot.tick()
            bot.tick()
        bot.capital.open_position.assert_not_called()
        self.assertTrue(bot.state.continuation_managed)
        self.assertTrue(bot.state.continuation_stopped_by_user)
        self.assertIn(bot.state.continuation_stage, {"FORMING_PAIR", "ACTIVE"})

    def test_continuation_active_dispatch_uses_second_increase_recovery(self):
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            scenario_sizes=(D("10"),) * 4 + (D("20"),) * 5,
            scenario_stop_distances=(D("1"), D("1"), D("3")) + (D("4"),) * 6,
        )
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4010.50"), D("4010.00"))
        bot.strategy.confirm_initial_fills(D("4010.50"), D("4010.00"))
        for direction in ("BUY", "SELL", "BUY"):
            leg = bot.state.long if direction == "BUY" else bot.state.short
            bot.strategy.stopped(direction, leg.stop, f"stop-{bot.state.scenario}-{direction}")
            bot.strategy.reopened(direction, leg.original_trigger_level,
                                  f"deal-{bot.state.scenario + 1}-{direction}")
        bot.strategy.stopped("SELL", bot.state.short.stop, "stop-sell-4")
        bot.strategy.reopened("SELL", bot.state.short.original_trigger_level,
                              "sell-5", "fill-sell-5")
        bot.strategy.stopped("BUY", bot.state.long.stop, "stop-buy-5")
        bot.state.long.trigger_id = "buy-trigger-6"
        bot.state.short.deal_id = "sell-5"
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "ACTIVE"
        bot.continuation = CycleContinuation(bot)
        bot._apply_protection = Mock(return_value=True)
        bot._ensure_expected_trigger = Mock()
        bot.capital.positions.return_value = [
            {"position": {"dealId": "sell-5", "direction": "SELL", "level": 4010,
                          "size": 20}, "market": {"epic": "GOLD"}},
            {"position": {"dealId": "buy-6", "direction": "BUY", "level": 4010.50,
                          "size": 20, "workingOrderId": "buy-trigger-6"},
             "market": {"epic": "GOLD"}},
        ]

        bot.continuation.handle_active_scenario()

        self.assertEqual(bot.state.scenario, 6)
        self.assertEqual(bot.state.general_recovery / bot.state.long.size, D("6.90"))
        self.assertEqual(bot.state.general_recovery / bot.state.short.size, D("6.90"))
        self.assertEqual(bot.state.long.temporary_recovery, D("0"))
        self.assertEqual(bot.state.short.temporary_recovery, D("0"))

    def test_continuation_preflight_progresses_across_ticks(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        controller = bot.continuation = CycleContinuation(bot)
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []
        bot._start_pair_common = Mock()
        controller.start_pair("closed candle")
        controller.tick()
        controller.tick()
        bot._start_pair_common.assert_not_called()
        controller.tick()
        bot._start_pair_common.assert_called_once_with(
            "closed candle", continuation=True, preflight_done=True
        )
        self.assertEqual(bot.state.continuation_flat_checks, 3)
        self.assertEqual(bot.state.continuation_stage, "FORMING_PAIR")

    def test_fast_continuation_stop_uses_current_scenario_and_carried_recovery(self):
        bot = self.make_bot()
        bot.state.scenario = 5
        bot.state.realized_losses = D("14.71")
        bot.state.cycle_target_profit = D("0.40")
        bot.state.cycle_attempt = 2
        bot.state.continuation_managed = True
        controller = bot.continuation = CycleContinuation(bot)
        bot.strategy.begin_continuation(D("100.50"), D("100.00"))
        bot.state.long.deal_id = "continued-buy"
        bot.state.short.deal_id = "continued-sell"
        bot._apply_protection = Mock(return_value=True)
        bot._create_trigger = Mock()
        controller.handle_fast_second_close(bot.state.short, "SL", D("101.05"))
        self.assertEqual(bot.state.scenario, 5)
        self.assertEqual(bot.state.general_recovery, D("0.215"))
        self.assertEqual(bot.state.long.original_trigger_level, D("100.50"))
        self.assertEqual(bot.state.short.original_trigger_level, D("100.00"))
        bot._create_trigger.assert_called_once_with(bot.state.short)
        self.assertEqual(bot.state.continuation_stage, "ACTIVE")

    def _continuation_tp_bot(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "ACTIVE"
        bot.state.cycle_id = 254
        bot.state.long.deal_id = "buy-winner"
        stopped = bot.strategy.stopped("SELL", D("4011.10"), "sell-stop")
        stopped.trigger_id = "sell-trigger"
        bot.capital.positions.return_value = []
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: [{
            "dealId": "buy-winner", "source": "TP", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 4012.0, "size": "0.1"},
        }]
        bot.continuation = CycleContinuation(bot)
        return bot

    def test_continuation_tp_cancels_trigger_then_returns_to_normal_filter(self):
        bot = self._continuation_tp_bot()
        bot.capital.delete_working_order.return_value = True
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            object.__setattr__(bot.cfg, "diagnostic_log_file", str(Path(directory) / "log"))
            bot.continuation.handle_active_scenario()
        bot.capital.delete_working_order.assert_called_once_with("sell-trigger")
        self.assertFalse(bot.state.continuation_managed)
        self.assertFalse(bot.state.active)
        self.assertTrue(bot.state.armed)
        self.assertEqual(bot.state.phase, "FILTER")
        self.assertTrue(any("завершён по TP" in call.args[0]
                            for call in bot.telegram.send.call_args_list))

    def test_continuation_tp_waits_when_trigger_outcome_is_unknown(self):
        bot = self._continuation_tp_bot()
        bot.capital.delete_working_order.return_value = False
        bot._close_trigger_that_raced_with_tp = Mock(return_value=None)
        bot.continuation.handle_active_scenario()
        self.assertTrue(bot.state.continuation_managed)
        self.assertTrue(bot.state.active)
        self.assertEqual(bot.state.pending_tp_direction, "BUY")
        bot._complete_cycle = Mock()
        bot.continuation.handle_active_scenario()
        bot._complete_cycle.assert_not_called()

    def test_nested_pending_market_scenario_nine_completion_is_not_repeated(self):
        """Reproduce attempt 255: nested fallback completion must stop the outer dispatcher."""
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "ACTIVE"
        bot.state.scenario = 9
        bot.continuation = CycleContinuation(bot)
        completions = []

        def resolve_and_complete():
            # The shared pending-MARKET resolver may dispatch synchronously to the owner.  Model
            # the observable result of that real inner path instead of replacing the outer stage.
            completions.append(bot.state.active_attempt_id)
            bot.state.active = False
            bot.continuation.release()
            return False

        bot._resume_pending_market = Mock(side_effect=resolve_and_complete)
        bot._enter_manual_nine = Mock()

        bot.continuation.handle_active_scenario()

        self.assertEqual(len(completions), 1)
        bot._enter_manual_nine.assert_not_called()
        bot.capital.positions.assert_not_called()

    def test_scenario_nine_completion_is_idempotent_after_cycle_is_inactive(self):
        bot = self.make_bot()
        bot.state.scenario = 9
        bot.state.active = False
        completed = bot.state.completed_cycles

        bot._enter_manual_nine()

        self.assertEqual(bot.state.completed_cycles, completed)
        bot.capital.working_orders.assert_not_called()
        bot.capital.close_position.assert_not_called()

    def test_releasing_continuation_clears_only_transient_owner_metadata(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "ACTIVE"
        bot.state.continuation_pause_until = 12345.0
        bot.state.continuation_flat_checks = 2
        bot.state.continuation_filter_reason = "old filter"
        bot.state.continuation_stopped_by_user = True
        bot.state.paused = True

        bot._get_continuation().release()

        self.assertFalse(bot.state.continuation_managed)
        self.assertEqual(bot.state.continuation_stage, "")
        self.assertEqual(bot.state.continuation_pause_until, 0.0)
        self.assertEqual(bot.state.continuation_flat_checks, 0)
        self.assertEqual(bot.state.continuation_filter_reason, "")
        self.assertFalse(bot.state.continuation_stopped_by_user)
        # /stop is represented by the common pause and must survive owner release.
        self.assertTrue(bot.state.paused)

    def test_preflight_stop_blocks_pair_until_start(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "PREFLIGHT"
        bot.state.continuation_stopped_by_user = True
        bot.continuation = CycleContinuation(bot)
        bot.reconciled = True
        bot._start_pair_common = Mock()
        for _ in range(5):
            bot.continuation.tick()
        bot._start_pair_common.assert_not_called()
        bot.arm_cycle()
        for _ in range(3):
            bot.continuation.tick()
        bot._start_pair_common.assert_called_once()

    def test_forming_pair_retries_pre_submission_preparation_error(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "FORMING_PAIR"
        bot.state.continuation_filter_reason = "filter"
        bot.continuation = CycleContinuation(bot)
        bot._start_pair_common = Mock(side_effect=[CapitalError("quote timeout"), None])
        bot.continuation.tick()
        self.assertEqual(bot.state.continuation_stage, "FORMING_PAIR")
        self.assertFalse(bot.state.initial_submitted_directions)
        bot.continuation.tick()
        self.assertEqual(bot._start_pair_common.call_count, 2)
        for call in bot._start_pair_common.call_args_list:
            self.assertEqual(call.kwargs, {"continuation": True, "preflight_done": True})

    def test_reconciling_trigger_fill_returns_controller_to_active(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.state.continuation_stage = "RECONCILING"
        bot.state.phase = "DOUBLE_SL_RECONCILING"
        bot.continuation = CycleContinuation(bot)
        bot._tick_double_sl_reconciling = Mock(
            side_effect=lambda: setattr(bot.state, "phase", "BOTH_OPEN")
        )
        bot.continuation.tick()
        self.assertEqual(bot.state.continuation_stage, "ACTIVE")
        self.assertTrue(bot.state.continuation_managed)

    def test_market_fallback_follow_up_respects_continuation_owner(self):
        bot = self.make_bot()
        bot.state.continuation_managed = True
        bot.continuation = CycleContinuation(bot)
        bot.continuation.handle_active_scenario = Mock()
        bot._tick_cycle = Mock(side_effect=AssertionError("ordinary owner called"))
        bot._dispatch_owned_cycle()
        bot.continuation.handle_active_scenario.assert_called_once_with()
        bot._tick_cycle.assert_not_called()

    def test_continuation_recovery_uses_losses_target_and_new_spread_once(self):
        bot = self.make_bot()
        bot.state.realized_losses = D("14.71")
        bot.state.cycle_target_profit = D("0.40")
        bot.state.scenario = 8
        bot.state.cycle_attempt = 2
        bot.strategy.begin_continuation(D("4375.20"), D("4375.00"))
        self.assertEqual(bot.state.general_recovery, D("0.060"))
        bot.strategy.confirm_continuation_fills(D("4375.20"), D("4375.00"))
        self.assertEqual(bot.state.general_recovery, D("0.080"))
        self.assertEqual(bot.state.long.original_trigger_level, D("4375.20"))
        self.assertEqual(bot.state.short.original_trigger_level, D("4375.00"))
        self.assertEqual(bot.state.long.take_profit, D("4376.20"))
        self.assertEqual(bot.state.short.take_profit, D("4374.00"))
        self.assertEqual(bot.state.scenario, 8)

    def test_projected_trigger_target_uses_trigger_entry_not_opposite_stop(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"), "sell-stop")
        bot.capital.working_stop.return_value = "trigger-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "trigger-id",
        }
        before = bot.state.recovery
        bot._create_trigger(stopped)
        bot.capital.working_stop.assert_called_once_with(
            "GOLD", "SELL", D("0.1"), D("4010.00"), D("4011.00"), D("4008.30")
        )
        self.assertEqual(bot.state.recovery, before)

    def test_stop_blocks_expired_continuation_pause(self):
        bot = self.make_bot()
        bot.state.phase = "DOUBLE_SL_PAUSE"
        bot.state.continuation_pause_until = 1
        bot.command("/stop")
        with patch("trader.app.time.time", return_value=1000):
            bot.tick()
        self.assertEqual(bot.state.phase, "DOUBLE_SL_PAUSE")
        self.assertTrue(bot.state.continuation_stopped_by_user)
        bot.capital.open_position.assert_not_called()

    def test_delayed_second_initial_rejection_accounts_first_close_and_pauses(self):
        bot = self._pending_second_initial_bot()
        bot.capital.positions.return_value = []
        bot.capital.wait_confirmation.side_effect = None
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "REJECTED", "dealId": "sell-execution", "reason": "rejected",
        }
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: ([{
            "dealId": "buy-position", "source": "SL", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 98.5, "direction": "SELL"},
        }] if not deal_id or deal_id == "buy-position" else [])
        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
            bot.tick()
        self.assertTrue(bot.state.paused)
        self.assertEqual(bot.state.attempt_result_total, D("-15.0"))
        self.assertEqual(bot.state.attempt_history, [])
        bot.capital.open_position.assert_not_called()

    def test_first_initial_leg_is_checked_before_second_entry(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-id"
        bot.capital.position.side_effect = CapitalError(
            'Capital API 404: {"errorCode":"error.not-found.dealId"}'
        )
        with patch("trader.app.time.sleep"):
            present = bot._position_still_open(bot.state.long)
        self.assertFalse(present)
        self.assertEqual(bot.capital.position.call_count, 3)

    def test_filter_waits_for_current_candle_then_enters_at_market(self):
        bot = self.make_bot()
        bot.state.reset()
        bot.state.armed = True
        bot.capital.candle_ranges.return_value = (D("2.5"), D("2.9"))
        bot._start_cycle = Mock()
        bot._tick_filter()
        self.assertTrue(bot.state.waiting_current_candle)
        bot.capital.candle_ranges.return_value = (D("2.5"), D("3.4"))
        bot._tick_filter()
        bot._start_cycle.assert_called_once_with("текущая свеча: 3.4")

    def test_pause_before_entry_disarms_filter_until_start(self):
        bot = self.make_bot()
        bot.state.reset()
        bot.state.armed = True
        bot.reconciled = True
        bot.command("/pause")
        self.assertTrue(bot.state.paused)
        self.assertFalse(bot.state.armed)
        self.assertEqual(bot.state.phase, "PAUSED")

        bot.command("/start")
        self.assertFalse(bot.state.paused)
        self.assertTrue(bot.state.armed)
        self.assertEqual(bot.state.phase, "FILTER")

    def test_early_start_command_reconciles_before_arming(self):
        bot = self.make_bot()
        bot.state.reset()
        bot.reconciled = False
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []

        bot.command("/start")

        self.assertTrue(bot.reconciled)
        self.assertTrue(bot.state.armed)
        self.assertEqual(bot.state.phase, "FILTER")

    def test_start_cannot_override_manual_reconciliation_result(self):
        bot = self.make_bot()
        bot.state.reset()
        bot.state.manual = True
        bot.reconciled = True
        with self.assertRaisesRegex(RuntimeError, "ручном режиме"):
            bot.command("/start")

    def test_expected_command_error_is_reported_without_escaping_loop(self):
        bot = self.make_bot()
        bot.state.reset()
        bot.reconciled = True
        bot.cfg = Settings(dry_run=True)

        bot._process_commands(["/start"])

        message = bot.telegram.send.call_args.args[0]
        self.assertIn("BOT_DRY_RUN=true", message)

    def test_stop_is_pause_alias(self):
        bot = self.make_bot()
        bot.state.reset()
        bot.reconciled = True
        bot.command("/stop")
        self.assertTrue(bot.state.paused)
        self.assertEqual(bot.state.phase, "PAUSED")

    def test_pause_during_cycle_keeps_cycle_active(self):
        bot = self.make_bot()
        bot.reconciled = True
        bot.command("/pause")
        self.assertTrue(bot.state.active)
        self.assertTrue(bot.state.paused)
        self.assertEqual(bot.state.phase, "BOTH_OPEN")

    def test_paused_cycle_finishes_but_does_not_arm_next_cycle(self):
        bot = self.make_bot()
        bot.state.paused = True
        bot.state.short.open = False
        bot.state.short.trigger_id = "order"
        bot.state.phase = "LONG_ONLY"
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []
        bot.capital.activity.return_value = [{
            "dealId": bot.state.long.deal_id, "source": "TP", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 4011.60, "size": 0.1},
        }]
        bot._tick_cycle()
        self.assertFalse(bot.state.active)
        self.assertFalse(bot.state.armed)
        self.assertEqual(bot.state.phase, "PAUSED")
        bot.capital.delete_working_order.assert_called_once_with("order")

    def test_completed_cycle_automatically_returns_to_filter_without_pause(self):
        bot = self.make_bot()
        bot.state.short.open = False
        bot.state.phase = "LONG_ONLY"
        bot.capital.positions.return_value = []
        bot.capital.activity.return_value = [{
            "dealId": bot.state.long.deal_id, "source": "TP", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 4011.60, "size": 0.1},
        }]
        bot._tick_cycle()
        self.assertFalse(bot.state.active)
        self.assertTrue(bot.state.armed)
        self.assertEqual(bot.state.phase, "FILTER")

    def test_normal_tp_waits_across_ticks_when_trigger_404_is_not_yet_resolved(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-winner"
        bot.state.short.open = False
        bot.state.short.trigger_id = "short-trigger"
        bot.state.phase = "LONG_ONLY"
        bot.capital.positions.return_value = []
        bot.capital.activity.return_value = [{
            "dealId": "long-winner", "source": "TP", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": 4011.60, "size": "0.1"},
        }]
        bot.capital.delete_working_order.return_value = False
        bot._close_trigger_that_raced_with_tp = Mock(side_effect=[None, D("0.20")])

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
        self.assertTrue(bot.state.active)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.short.trigger_id, "short-trigger")

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.realized_losses, D("0"))
        self.assertEqual(bot.state.phase, "FILTER")

    def test_transient_empty_positions_snapshot_does_not_enter_manual_mode(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-1"
        bot.state.short.deal_id = "short-1"
        both = [
            {"position": {"dealId": "long-1", "direction": "BUY"},
             "market": {"epic": "GOLD"}},
            {"position": {"dealId": "short-1", "direction": "SELL"},
             "market": {"epic": "GOLD"}},
        ]
        bot.capital.positions.side_effect = [[], both]
        bot._manual = Mock()
        with patch("trader.app.time.sleep"):
            bot._tick_cycle()
        bot._manual.assert_not_called()
        self.assertEqual(bot.state.phase, "BOTH_OPEN")

    def test_both_closes_are_recovered_from_global_activity_index(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-1"
        bot.state.short.deal_id = "short-1"
        bot.capital.positions.return_value = []
        global_events = [
            {"dealId": "long-1", "source": "SL", "type": "POSITION",
             "status": "ACCEPTED", "details": {"level": 4611.23, "size": 0.1}},
            {"dealId": "short-1", "source": "TP", "type": "POSITION",
             "status": "ACCEPTED", "details": {"level": 4610.49, "size": 0.1}},
        ]
        bot.capital.activity.side_effect = lambda deal_id="", **_: (
            global_events if not deal_id else []
        )

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        self.assertFalse(bot.state.active)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.deal_history, [])
        self.assertIsNotNone(bot.state.completed_cycle_report)

    def test_confirmed_stop_waits_beyond_old_sixty_second_cutoff(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-1"
        bot.state.short.deal_id = "short-1"
        bot.capital.positions.return_value = []
        global_events = [
            {"dealId": "long-1", "source": "SL", "type": "POSITION",
             "status": "ACCEPTED", "details": {"level": 4611.23}},
        ]
        bot.capital.activity.side_effect = lambda deal_id="", **_: (
            global_events if not deal_id else []
        )
        bot._missing_exit_since = time.monotonic() - 120
        bot._manual = Mock()

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        bot._manual.assert_not_called()
        self.assertTrue(bot.state.active)
        self.assertEqual(bot.state.phase, "BOTH_OPEN")

    def test_early_initial_stop_is_replayed_instead_of_manual_404(self):
        bot = self.make_bot()
        bot.state.general_recovery = D("0"); bot.state.recovery_events.clear()
        bot.state.long.deal_id = "long-1"
        bot.state.short.deal_id = "short-1"
        bot.strategy.confirm_initial_fills(D("4645.81"), D("4644.88"))
        short_position = [{
            "position": {"dealId": "short-1", "direction": "SELL", "level": 4644.88},
            "market": {"epic": "GOLD"},
        }]
        bot.capital.positions.return_value = short_position
        bot.capital.activity.return_value = [{
            "dealId": "long-1", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
            "details": {"level": 4644.76, "size": 0.1},
        }]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "trigger-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED", "dealId": "trigger-1"},
        ]

        handled = bot._continue_after_early_initial_close()

        self.assertTrue(handled)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.phase, "SHORT_ONLY")
        self.assertFalse(bot.state.long.open)
        self.assertEqual(bot.state.long.trigger_id, "trigger-1")
        self.assertEqual(bot.state.general_recovery, D("0.128"))
        bot.capital.update_position.assert_called_once()
        bot.capital.working_stop.assert_called_once()

    def test_second_initial_leg_stopped_before_position_sync_continues_scenario(self):
        bot = self.make_bot()
        bot.state.general_recovery = D("0"); bot.state.recovery_events.clear()
        bot.state.long.deal_id = "long-1"
        bot.state.long.current_entry = D("4633.17")
        bot.state.long.original_trigger_level = D("4633.17")
        bot.state.short.deal_id = "short-fast-close"
        bot.state.short.current_entry = D("4633.06")
        bot.state.short.original_trigger_level = D("4633.06")
        bot.state.short.open = False
        bot.capital.positions.return_value = [{
            "position": {
                "dealId": "long-1", "direction": "BUY", "level": 4633.17,
            },
            "market": {"epic": "GOLD"},
        }]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "trigger-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED", "dealId": "trigger-1"},
        ]

        with tempfile.NamedTemporaryFile() as state_file:
            bot.cfg = Settings(
                dry_run=False, api_key="key", identifier="id", password="password",
                state_file=state_file.name,
            )
            bot.strategy = Strategy(bot.cfg, bot.state)
            handled = bot._continue_after_second_initial_close(
                bot.state.short, "SL", D("4634.08")
            )

        self.assertTrue(handled)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.phase, "LONG_ONLY")
        self.assertFalse(bot.state.short.open)
        self.assertEqual(bot.state.entry_spread, D("0.11"))
        self.assertEqual(bot.state.general_recovery, D("0.043"))
        self.assertEqual(bot.state.realized_losses, D("1.02"))
        self.assertEqual(bot.state.long.take_profit, D("4634.60"))
        self.assertEqual(bot.state.short.trigger_id, "trigger-1")
        bot.capital.update_position.assert_called_once()
        bot.capital.working_stop.assert_called_once()
        self.assertIn("продолжает сценарий 1", bot.telegram.send.call_args.args[0])

    def test_second_initial_stop_tolerates_transient_missing_survivor(self):
        bot = self.make_bot()
        bot.state.general_recovery = D("0"); bot.state.recovery_events.clear()
        bot.state.long.deal_id = "long-1"
        bot.state.long.current_entry = D("4633.17")
        bot.state.long.original_trigger_level = D("4633.17")
        bot.state.short.deal_id = "short-fast-close"
        bot.state.short.current_entry = D("4633.06")
        bot.state.short.original_trigger_level = D("4633.06")
        bot.state.short.open = False
        survivor = [{
            "position": {
                "dealId": "long-1", "direction": "BUY", "level": 4633.17,
            },
            "market": {"epic": "GOLD"},
        }]
        # The first snapshot is temporarily empty, then Capital publishes the surviving BUY.
        bot.capital.positions.side_effect = [[], survivor]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "trigger-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED", "dealId": "trigger-1"},
        ]

        with tempfile.NamedTemporaryFile() as state_file, patch("trader.app.time.sleep"):
            bot.cfg = Settings(
                dry_run=False, api_key="key", identifier="id", password="password",
                state_file=state_file.name,
            )
            bot.strategy = Strategy(bot.cfg, bot.state)
            handled = bot._continue_after_second_initial_close(
                bot.state.short, "SL", D("4634.08")
            )

        self.assertTrue(handled)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.phase, "LONG_ONLY")
        self.assertEqual(bot.state.general_recovery, D("0.043"))
        self.assertEqual(bot.state.short.trigger_id, "trigger-1")
        self.assertEqual(bot.capital.positions.call_count, 2)

    def test_trigger_fill_followed_by_survivor_stop_is_replayed(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-old"
        bot.state.short.deal_id = "short-old"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        stopped_short = bot.strategy.stopped("SELL", D("4637.05"), "stop-short-old")
        stopped_short.trigger_id = "buy-trigger"
        stopped_short.trigger_reference = "trigger-ref"
        bot.capital.positions.return_value = [{
            "position": {
                "dealId": "short-new",
                "dealReference": "short-new-ref",
                "workingOrderId": "buy-trigger",
                "direction": "SELL",
                "level": 4635.97,
                "createdDateUTC": "2026-09-21T10:00:00Z",
            },
            "market": {"epic": "GOLD"},
        }]
        bot.capital.activity.return_value = [
            {"dealId": "short-new", "source": "USER", "status": "ACCEPTED",
             "type": "POSITION", "dateUTC": "2026-09-21T10:00:00Z",
             "details": {"workingOrderId": "buy-trigger", "direction": "SELL",
                         "level": 4635.97, "size": 0.1}},
            {"dealId": "long-old", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "level": 4635.42, "dateUTC": "2026-09-21T10:00:01Z",
             "details": {"level": 4635.42, "size": 0.1}},
        ]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "next-trigger-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED", "dealId": "next-trigger"},
        ]

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.scenario, 2)
        self.assertEqual(bot.state.phase, "SHORT_ONLY")
        self.assertTrue(bot.state.short.open)
        self.assertEqual(bot.state.short.deal_id, "short-new")
        self.assertFalse(bot.state.long.open)
        self.assertEqual(bot.state.long.trigger_id, "next-trigger")
        bot.capital.update_position.assert_called_once()
        bot.capital.working_stop.assert_called_once()

    def test_trigger_fill_appearing_during_missing_position_retry_is_replayed(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "long-old"
        bot.state.short.deal_id = "short-old"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        stopped_short = bot.strategy.stopped("SELL", D("4637.05"), "stop-short-old")
        stopped_short.trigger_id = "sell-trigger"
        stopped_short.trigger_reference = "trigger-ref"
        trigger_position = [{
            "position": {
                "dealId": "short-new",
                "dealReference": "short-new-ref",
                "workingOrderId": "sell-trigger",
                "direction": "SELL",
                "level": 4635.97,
                "createdDateUTC": "2026-09-21T10:00:00Z",
            },
            "market": {"epic": "GOLD"},
        }]
        # The first snapshot still contains neither side.  Capital.com exposes the position
        # created by the trigger only while _retry_missing_positions is already running.
        bot.capital.positions.side_effect = [[], *([trigger_position] * 10)]
        bot.capital.activity.return_value = [
            {"dealId": "short-new", "source": "USER", "status": "ACCEPTED",
             "type": "POSITION", "dateUTC": "2026-09-21T10:00:00Z",
             "details": {"workingOrderId": "sell-trigger", "direction": "SELL",
                         "level": 4635.97, "size": 0.1}},
            {"dealId": "long-old", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "level": 4635.42, "dateUTC": "2026-09-21T10:00:01Z",
             "details": {"level": 4635.42, "size": 0.1}},
        ]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "next-trigger-ref"
        bot._apply_protection = Mock(return_value=True)
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED", "dealId": "next-trigger"},
        ]

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.scenario, 2)
        self.assertEqual(bot.state.phase, "SHORT_ONLY")
        self.assertEqual(bot.state.short.deal_id, "short-new")
        bot._ensure_expected_trigger()
        self.assertEqual(bot.state.long.trigger_id, "next-trigger")

    def test_fast_positions_path_uses_broker_order_when_sl_precedes_reentry(self):
        bot = self.make_bot()
        bot.state.long.deal_id, bot.state.short.deal_id = "long-old", "short-old"
        bot.state.remember_deal(bot.state.long, 1)
        bot.state.remember_deal(bot.state.short, 1)
        stopped = bot.strategy.stopped("SELL", D("4011.00"), "stop-short-old")
        stopped.trigger_id = "sell-trigger"
        stopped.trigger_reference = "trigger-ref"
        position = {"dealId": "short-new", "workingOrderId": "sell-trigger",
                    "direction": "SELL", "level": "4010.00", "size": "10",
                    "createdDateUTC": "2026-09-21T10:00:02Z"}
        bot.capital.activity.return_value = [
            {"dateUTC": "2026-09-21T10:00:02Z", "dealId": "short-new",
             "source": "USER", "status": "ACCEPTED", "type": "POSITION",
             "details": {"workingOrderId": "sell-trigger", "direction": "SELL",
                         "level": "4010.00"}},
            {"dateUTC": "2026-09-21T10:00:01Z", "dealId": "long-old",
             "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "details": {"level": "4009.30", "size": "0.1"}},
        ]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED", "dealId": "next-trigger"},
        ]
        bot.capital.working_stop.return_value = "next-ref"
        bot.capital.working_orders.return_value = []
        self.assertTrue(bot._recover_trigger_fill_then_stop(
            {"short-new": position}, bot.state.long, stopped
        ))
        closure = next(item for item in bot.state.pending_recovery
                       if item["deal_id"] == "long-old")
        self.assertEqual(closure["scenario_at_close"], 1)
        self.assertFalse(closure["d_accounted"])
        before = (bot.state.general_recovery, bot.state.scenario,
                  len(bot.state.recovery_events))
        bot._detect_trigger_fill({"short-new": position})
        self.assertEqual((bot.state.general_recovery, bot.state.scenario,
                          len(bot.state.recovery_events)), before)

    def test_equal_or_missing_broker_times_do_not_guess_scenario(self):
        for close_time in (None, "2026-09-21T10:00:02Z"):
            bot = self.make_bot()
            bot.state.long.deal_id, bot.state.short.deal_id = "long-old", "short-old"
            stopped = bot.strategy.stopped("SELL", D("4011.00"), "stop-short-old")
            stopped.trigger_id = "sell-trigger"
            position = {"dealId": "short-new", "workingOrderId": "sell-trigger",
                        "direction": "SELL", "level": "4010.00",
                        "createdDateUTC": "2026-09-21T10:00:02Z"}
            event = {"dealId": "long-old", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                     "type": "POSITION", "level": "4009.30"}
            if close_time:
                event["dateUTC"] = close_time
            opening = {"dealId": "short-new", "source": "USER", "status": "ACCEPTED",
                       "type": "POSITION", "dateUTC": "2026-09-21T10:00:02Z",
                       "details": {"workingOrderId": "sell-trigger", "direction": "SELL",
                                   "level": "4010.00"}}
            bot.capital.activity.return_value = [opening, event]
            self.assertTrue(bot._recover_trigger_fill_then_stop(
                {"short-new": position}, bot.state.long, stopped
            ))
            self.assertTrue(bot.state.manual)
            self.assertEqual(bot.state.scenario, 1)

    def test_passed_rejected_trigger_reopens_with_market(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "stop-ref"
        bot.capital.quote.return_value = (D("4009.70"), D("4009.90"))
        bot.capital.open_position.return_value = "market-ref"
        bot.capital.wait_position.return_value = {
            "dealId": "short-2", "direction": "SELL", "level": 4009.68,
        }
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "REJECTED", "reason": "level already crossed"},
            {"dealStatus": "ACCEPTED", "dealId": "short-2", "level": 4009.68},
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED"},
        ]

        bot._create_trigger(stopped)

        self.assertEqual(bot.state.scenario, 2)
        self.assertTrue(bot.state.short.open)
        self.assertEqual(bot.state.short.current_entry, D("4009.68"))
        self.assertEqual(bot.state.short.original_trigger_level, D("4010.00"))
        self.assertEqual(bot.state.general_recovery, D("0.202"))
        bot.capital.open_position.assert_called_once()

    def test_capital_stop_price_rejection_reopens_passed_trigger_with_market(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.validation.stop.price"}'
        )
        bot.capital.quote.return_value = (D("4009.70"), D("4009.90"))
        bot.capital.open_position.return_value = "market-ref"
        bot.capital.wait_position.return_value = {
            "dealId": "short-2", "direction": "SELL", "level": 4009.68,
        }
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED", "dealId": "short-2", "level": 4009.68},
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED"},
        ]

        bot._create_trigger(stopped)

        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.scenario, 2)
        self.assertEqual(bot.state.short.current_entry, D("4009.68"))
        bot.capital.working_stop.assert_called_once()
        bot.capital.open_position.assert_called_once()

    def test_demo_market_fallback_uses_opened_affected_deal_and_actual_position(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "00000000-6135-ee9f"
        stopped = bot.strategy.stopped("SELL", D("4412.55"), "previous-sell-stop")
        stopped.original_trigger_level = D("4411.11")
        stopped.open = False
        confirmation = {
            "dealStatus": "ACCEPTED",
            "dealReference": "o_3a2964aa",
            "dealId": "00000000-6135-eff5",
            "affectedDeals": [{"dealId": "00000000-6135-eff8", "status": "OPENED"}],
            "level": 4410.15,
            "direction": "SELL",
        }
        bot.capital.open_position.return_value = "o_3a2964aa"
        bot.capital.wait_confirmation.side_effect = [
            confirmation,
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED"},
        ]
        bot.capital.wait_position.return_value = {
            "dealId": "00000000-6135-eff8",
            "dealReference": "p_00000000-6135-eff8",
            "workingOrderId": "00000000-6135-eff5",
            "direction": "SELL",
            "level": 4410.15,
        }
        bot._apply_protection = Mock(side_effect=[False, True])
        bot._closing_fill = Mock(return_value=None)
        bot._cycle_positions = Mock(side_effect=[
            {"00000000-6135-ee9f": {"dealId": "00000000-6135-ee9f"}},
            {"00000000-6135-eff8": {
                "dealId": "00000000-6135-eff8", "direction": "SELL", "level": 4410.15,
                "stopLevel": 4411.65, "profitLevel": 4405.14,
            }},
            {"00000000-6135-eff8": {
                "dealId": "00000000-6135-eff8", "direction": "SELL", "level": 4410.15,
                "stopLevel": 4411.65, "profitLevel": 4405.14,
            }},
        ])
        bot._tick_cycle = Mock()

        bot._open_passed_trigger_at_market(
            stopped, D("4406.10"), "error.validation.stop.price"
        )

        self.assertEqual(bot.state.short.deal_id, "00000000-6135-eff8")
        self.assertEqual(bot.state.short.current_entry, D("4410.15"))
        self.assertEqual(bot.state.short.original_trigger_level, D("4411.11"))
        self.assertEqual(
            bot.capital.wait_position.call_args.args[:3],
            ("00000000-6135-eff8", "o_3a2964aa", "SELL"),
        )
        bot._tick_cycle.assert_called_once()
        reports = "\n".join(call.args[0] for call in bot.telegram.send.call_args_list)
        self.assertIn("Confirmation dealId: 00000000-6135-eff5", reports)
        self.assertIn("Фактический Deal ID: 00000000-6135-eff8", reports)
        self.assertIn("Причина STOP-отказа: error.validation.stop.price", reports)

    def test_market_fallback_unknown_post_never_submits_twice(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        bot.capital.open_position.side_effect = CapitalError("write timed out")

        with patch("trader.app.time.sleep"):
            bot._open_passed_trigger_at_market(stopped, D("4007.50"), "level crossed")

        bot.capital.open_position.assert_called_once()
        self.assertFalse(bot.state.manual)
        self.assertEqual(stopped.pending_market_kind, "FALLBACK")
        self.assertTrue(stopped.pending_market_unknown_post)

    def test_outer_trigger_loop_does_not_repeat_market_with_pending_confirmation(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.validation.stop.price"}'
        )
        bot.capital.quote.return_value = (D("4009.70"), D("4009.90"))
        bot.capital.open_position.return_value = "market-ref"
        bot.capital.wait_confirmation.side_effect = CapitalError("confirmation unavailable")

        bot._create_trigger(stopped)
        bot._create_trigger(stopped)

        bot.capital.open_position.assert_called_once()
        bot.capital.working_stop.assert_called_once()
        self.assertEqual(stopped.pending_market_reference, "market-ref")
        self.assertFalse(bot.state.manual)

    def test_outer_trigger_loop_does_not_repeat_market_when_reconciliation_fails(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.validation.stop.price"}'
        )
        bot.capital.quote.return_value = (D("4009.70"), D("4009.90"))
        bot.capital.open_position.side_effect = CapitalError("write timed out")
        bot.capital.positions.side_effect = [
            [], CapitalError("positions unavailable"),
            CapitalError("positions still unavailable"),
        ]

        with patch("trader.app.time.sleep"):
            bot._create_trigger(stopped)
            bot._create_trigger(stopped)

        bot.capital.open_position.assert_called_once()
        self.assertEqual(stopped.pending_market_kind, "FALLBACK")
        self.assertTrue(stopped.pending_market_unknown_post)
        self.assertTrue(bot.state.active)
        self.assertFalse(bot.state.manual)

    def test_market_validation_rejection_clears_only_its_pending_operation(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        before = (bot.state.scenario, bot.state.general_recovery,
                  len(bot.state.recovery_events))
        bot.capital.open_position.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.invalid.takeprofit.maxvalue: 4153.55"}',
            http_status=400,
            error_code="error.invalid.takeprofit.maxvalue: 4153.55",
            outcome="REJECTED",
        )
        bot._dispatch_owned_cycle = Mock()

        bot._open_passed_trigger_at_market(
            stopped, D("4153.59"), "error.validation.stop.price"
        )

        self.assertEqual(stopped.pending_market_kind, "")
        self.assertFalse(stopped.pending_market_unknown_post)
        self.assertEqual(stopped.last_market_outcome, "REJECTED")
        self.assertEqual(stopped.last_market_http_status, 400)
        self.assertEqual(
            stopped.last_market_error_code,
            "error.invalid.takeprofit.maxvalue: 4153.55",
        )
        self.assertEqual(before, (bot.state.scenario, bot.state.general_recovery,
                                  len(bot.state.recovery_events)))
        bot.capital.open_position.assert_called_once()
        bot._dispatch_owned_cycle.assert_called_once()

    def test_legacy_validation_pending_is_resolved_after_reload(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        stopped.pending_market_kind = "FALLBACK"
        stopped.pending_market_unknown_post = True
        stopped.pending_market_reason = (
            'Capital API 400: {"errorCode":"error.invalid.takeprofit.maxvalue: 4153.55"}'
        )
        bot.state.save(bot.cfg.state_file)
        bot.state = CycleState.load(bot.cfg.state_file)
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot._dispatch_owned_cycle = Mock()

        self.assertTrue(bot._resume_pending_market())

        restored = bot.state.short
        self.assertEqual(restored.pending_market_kind, "")
        self.assertEqual(restored.last_market_outcome, "REJECTED")
        bot.capital.open_position.assert_not_called()
        bot._dispatch_owned_cycle.assert_called_once()

    def test_trigger_reentry_uses_new_positions_reference_and_survives_reload(self):
        bot = self.make_bot()
        bot.state.short.deal_id = "old-sell"
        bot.state.short.deal_reference = "old-position-reference"
        stopped = bot.strategy.stopped("SELL", D("4011.10"), "old-stop")
        stopped.trigger_id = "owned-order"
        candidate = {
            "dealId": "new-sell", "dealReference": "new-position-reference",
            "workingOrderId": "owned-order", "direction": "SELL",
            "level": "4009.95", "size": "0.1",
        }
        bot.capital.activity.return_value = [{
            "id": "owned-execution", "dealId": "owned-order", "source": "USER",
            "type": "WORKING_ORDER", "status": "EXECUTED",
            "dateUTC": "2026-09-28T12:03:17.204Z",
        }]
        bot._apply_protection = Mock(return_value=True)

        bot._detect_trigger_fill({"new-sell": candidate})
        bot.state.save(bot.cfg.state_file)
        restored = CycleState.load(bot.cfg.state_file)

        record = next(item for item in restored.deal_history
                      if item["deal_id"] == "new-sell")
        self.assertEqual(restored.short.deal_reference, "new-position-reference")
        self.assertEqual(record["deal_reference"], "new-position-reference")
        old = next(item for item in restored.deal_history
                   if item.get("deal_id") == "old-sell")
        self.assertNotEqual(old.get("deal_reference"), "new-position-reference")

    def test_resetcycle_demo_archives_flat_cycle_and_is_idempotent(self):
        bot = self.make_bot()
        bot.state.cycle_id = bot.state.active_attempt_id = 91
        bot.state.cycle_attempt = 1
        bot.state.completed_cycles = 12
        bot.state.pending_transaction_jobs = [{
            "key": "old-transaction", "cycle_id": 2, "attempt_id": 2,
            "deal_ids": ["old-deal"],
        }]
        bot.state.report_outbox = [{"id": "older-report", "text": "kept"}]
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []

        bot.command("/resetcycle")

        self.assertEqual(bot.state.phase, "PAUSED")
        self.assertTrue(bot.state.paused)
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.completed_cycles, 12)
        self.assertEqual(bot.state.pending_transaction_jobs[0]["key"], "old-transaction")
        self.assertEqual(len(bot.state.report_outbox), 2)
        self.assertTrue(any(item.get("status") == "RESET_BY_USER"
                            for item in bot.state.completed_attempt_summaries))
        reports = len(bot.state.report_outbox)
        bot.command("/resetcycle")
        self.assertEqual(len(bot.state.report_outbox), reports)
        self.assertEqual(bot.state.completed_cycles, 12)

    def test_resetcycle_rejects_real_exposure_api_failure_and_unknown_mutation(self):
        for case in ("real", "position", "order", "api", "unknown"):
            with self.subTest(case=case):
                bot = self.make_bot()
                if case == "real":
                    bot.cfg = Settings(
                        dry_run=False, demo=False, api_key="key",
                        identifier="id", password="password",
                    )
                elif case == "position":
                    bot.capital.positions.return_value = [{
                        "position": {"dealId": "foreign-open", "direction": "BUY"},
                        "market": {"epic": bot.cfg.epic},
                    }]
                    bot.capital.working_orders.return_value = []
                elif case == "order":
                    bot.capital.positions.return_value = []
                    bot.capital.working_orders.return_value = [{
                        "workingOrderData": {"dealId": "owned-order", "epic": bot.cfg.epic}
                    }]
                elif case == "api":
                    bot.capital.positions.side_effect = CapitalError("positions unavailable")
                else:
                    bot.capital.positions.return_value = []
                    bot.capital.working_orders.return_value = []
                    bot.state.short.pending_market_kind = "FALLBACK"
                    bot.state.short.pending_market_unknown_post = True
                before = (bot.state.scenario, bot.state.general_recovery,
                          bot.state.completed_cycles, list(bot.state.deal_history))
                with self.assertRaises(RuntimeError):
                    bot.command("/resetcycle")
                self.assertEqual(
                    before,
                    (bot.state.scenario, bot.state.general_recovery,
                     bot.state.completed_cycles, bot.state.deal_history),
                )

    def test_resetcycle_pending_finalization_resumes_on_startup(self):
        bot = self.make_bot()
        bot.state.cycle_id = bot.state.active_attempt_id = 92
        bot.state.cycle_attempt = 1
        bot.state.pending_finalization = {
            "kind": "RESET_BY_USER", "cycle_id": bot.state.cycle_id,
            "attempt_id": bot.state.active_attempt_id,
        }
        bot.state.paused = True
        bot.state.save(bot.cfg.state_file)
        bot.state = CycleState.load(bot.cfg.state_file)
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []

        bot.reconcile_startup()

        self.assertTrue(bot.reconciled)
        self.assertEqual(bot.state.phase, "PAUSED")
        self.assertFalse(bot.state.pending_finalization)
        self.assertEqual(len([item for item in bot.state.report_outbox
                              if str(item.get("key", "")).startswith("cycle-reset:")]), 1)

    def test_missing_survivor_after_protection_failure_does_not_create_trigger(self):
        bot = self.make_bot()
        bot.state.long.deal_id, bot.state.short.deal_id = "buy-survivor", "sell-stopped"
        bot.capital.positions.return_value = [{
            "position": {"dealId": "buy-survivor", "direction": "BUY", "size": "0.1",
                         "level": "4010.30", "stopLevel": "4009.30",
                         "profitLevel": str(bot.state.long.take_profit)},
            "market": {"epic": bot.cfg.epic},
        }]
        bot.capital.activity.return_value = [{
            "id": "sell-sl", "dateUTC": "2026-09-28T12:04:18.850Z",
            "dealId": "sell-stopped", "source": "SL", "type": "POSITION",
            "status": "ACCEPTED", "details": {"level": "4011.10", "size": "0.1"},
        }]
        bot._apply_protection = Mock(return_value=False)
        bot._create_trigger = Mock()

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        bot._apply_protection.assert_called_once_with(bot.state.long)
        bot._create_trigger.assert_not_called()

    def test_protection_not_found_switches_to_history_without_repeating_put(self):
        bot = self.make_bot()
        leg = bot.state.long
        leg.deal_id = "missing-buy"
        bot.capital.quote.return_value = D("4010.00"), D("4010.20")
        bot.capital.update_position.side_effect = CapitalError(
            'Capital API 404: {"errorCode":"error.not-found.dealId"}',
            http_status=404, error_code="error.not-found.dealId", outcome="REJECTED",
        )
        bot.capital.positions.return_value = []
        bot.capital.activity.return_value = []

        self.assertFalse(bot._apply_protection(leg))
        self.assertFalse(bot._apply_protection(leg))

        bot.capital.update_position.assert_called_once()
        bot.capital.activity.assert_any_call("missing-buy")

    def test_attempt_289_rejection_chain_does_not_leave_false_market_pending(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "buy-4156"
        bot.state.long.current_entry = bot.state.long.original_trigger_level = D("4156.37")
        bot.state.long.stop, bot.state.long.take_profit = D("4155.37"), D("4158.44")
        bot.state.short.deal_id = "sell-4155"
        bot.state.short.current_entry = bot.state.short.original_trigger_level = D("4155.66")
        bot.state.short.stop = D("4156.66")
        bot.state.remember_deal(bot.state.long, 1)
        bot.state.remember_deal(bot.state.short, 1)
        stopped = bot.strategy.stopped("SELL", D("4156.72"), "sell-sl-289")
        bot.capital.quote.return_value = D("4155.20"), D("4155.70")
        bot.capital.positions.return_value = []
        bot.capital.activity.return_value = []  # BUY close is deliberately unknown.
        bot.capital.update_position.side_effect = CapitalError(
            'Capital API 404: {"errorCode":"error.not-found.dealId"}',
            http_status=404, error_code="error.not-found.dealId", outcome="REJECTED",
        )
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.validation.stop.price"}',
            http_status=400, error_code="error.validation.stop.price", outcome="REJECTED",
        )
        bot.capital.open_position.side_effect = CapitalError(
            'Capital API 400: {"errorCode":"error.invalid.takeprofit.maxvalue: 4153.55"}',
            http_status=400,
            error_code="error.invalid.takeprofit.maxvalue: 4153.55",
            outcome="REJECTED",
        )
        bot._dispatch_owned_cycle = Mock()
        before = (bot.state.scenario, bot.state.general_recovery)

        self.assertFalse(bot._apply_protection(bot.state.long))
        bot._create_trigger(stopped)

        self.assertEqual(stopped.pending_market_kind, "")
        self.assertFalse(stopped.pending_market_unknown_post)
        self.assertEqual(stopped.last_market_outcome, "REJECTED")
        self.assertEqual(before, (bot.state.scenario, bot.state.general_recovery))
        bot.capital.open_position.assert_called_once()
        # No synthetic close/fill was invented for the vanished BUY.
        buy_record = next(item for item in bot.state.deal_history
                          if item.get("deal_id") == "buy-4156")
        self.assertIsNone(buy_record.get("close_level"))

    def test_initial_unknown_market_survives_tick_and_state_reload(self):
        bot = self.make_bot()
        bot.capital.open_position.side_effect = CapitalError("write timed out")
        bot.capital.positions.side_effect = [
            [], CapitalError("positions unavailable"),
            CapitalError("positions still unavailable"),
        ]

        with patch("trader.app.time.sleep"):
            error = bot._open_initial_leg(bot.state.long)
            bot._tick_cycle()

        self.assertIn("повторное открытие заблокировано", error)
        bot.capital.open_position.assert_called_once()
        self.assertEqual(bot.state.long.pending_market_kind, "INITIAL")
        restored = CycleState.load(bot.cfg.state_file)
        self.assertEqual(restored.long.pending_market_kind, "INITIAL")
        self.assertTrue(restored.long.pending_market_unknown_post)
        self.assertEqual(restored.long.pending_market_preexisting_ids, [])

    def _pending_market_with_opposite_exit(self, source):
        bot = self.make_bot()
        bot.state.long.deal_id = "buy-old"
        stopped = bot.strategy.stopped("SELL", D("4011.10"), "old-sell-stop")
        stopped.pending_market_kind = "FALLBACK"
        stopped.pending_market_reference = "market-ref"
        stopped.pending_market_reason = "error.validation.stop.price"
        stopped.pending_market_preexisting_ids = ["buy-old"]
        position = {
            "dealId": "sell-new", "dealReference": "p-sell-new",
            "workingOrderId": "execution-id", "direction": "SELL", "level": 4009.68,
            "stopLevel": 4011.0, "profitLevel": 4007.5,
        }
        bot.capital.positions.return_value = [{
            "position": position, "market": {"epic": bot.cfg.epic},
        }]
        bot.capital.wait_position.return_value = position
        bot.capital.wait_confirmation.side_effect = lambda reference: {
            "market-ref": {
                "dealStatus": "ACCEPTED", "dealId": "execution-id",
                "affectedDeals": [{"dealId": "sell-new", "status": "OPENED"}],
                "level": 4009.68,
            },
            "close-sell": {"dealStatus": "ACCEPTED", "dealId": "sell-new",
                           "level": 4009.88},
            "trigger-ref": {"dealStatus": "ACCEPTED", "dealId": "buy-trigger"},
        }.get(reference, {"dealStatus": "ACCEPTED"})
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: [{
            "dealId": "buy-old", "source": source, "type": "POSITION",
            "status": "ACCEPTED", "details": {
                "level": 4009.25 if source == "SL" else 4011.70,
                "size": "0.1",
            },
        }] if not deal_id or deal_id == "buy-old" else []
        bot.capital.update_position.side_effect = lambda deal_id, stop, target: (
            (_ for _ in ()).throw(CapitalError(
                'Capital API 404: {"errorCode":"error.not-found.dealId"}'
            )) if deal_id == "buy-old" else "update-ref"
        )
        bot.capital.quote.return_value = D("4010.0"), D("4010.2")
        bot.capital.working_orders.return_value = []
        bot.capital.working_stop.return_value = "trigger-ref"
        bot.capital.close_position.return_value = "close-sell"
        return bot, stopped

    def test_pending_market_is_resolved_before_opposite_sl(self):
        bot, stopped = self._pending_market_with_opposite_exit("SL")

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        bot.capital.open_position.assert_not_called()
        self.assertEqual(stopped.deal_id, "sell-new")
        self.assertEqual(stopped.pending_market_kind, "")
        self.assertEqual(bot.state.scenario, 2)
        self.assertEqual(bot.state.phase, "SHORT_ONLY")
        self.assertEqual(
            len([key for key in bot.state.processed_events if key.startswith("stop:buy-old")]), 1
        )
        self.assertEqual(bot.state.long.trigger_id, "buy-trigger")

    def test_pending_market_is_resolved_and_closed_before_opposite_tp_completion(self):
        bot, stopped = self._pending_market_with_opposite_exit("TP")

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        bot.capital.open_position.assert_not_called()
        bot.capital.close_position.assert_called_once_with("sell-new")
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.phase, "FILTER")
        self.assertFalse(stopped.open)
        self.assertEqual(stopped.pending_market_kind, "")
        # The fallback position belongs to the TP race, not strategic Recovery losses.
        self.assertEqual(bot.state.realized_losses, D("1.10"))
        self.assertTrue(any("Отдельный signed result race-позиции: -0.020" in call.args[0]
                            for call in bot.telegram.send.call_args_list))

    def test_accepted_market_without_level_is_resolved_without_second_post(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        accepted_without_level = {
            "dealStatus": "ACCEPTED", "dealId": "execution-id",
            "affectedDeals": [{"dealId": "position-id", "status": "OPENED"}],
        }
        bot.capital.open_position.return_value = "market-ref"
        bot.capital.wait_confirmation.return_value = accepted_without_level
        bot.capital.wait_position.side_effect = [
            CapitalError("position delayed"),
            {"dealId": "position-id", "direction": "SELL", "level": 4009.68},
        ]
        bot.capital.activity.return_value = []
        bot._apply_protection = Mock(return_value=True)

        with patch("trader.app.time.sleep"):
            bot._open_passed_trigger_at_market(stopped, D("4007.50"), "level crossed")
            self.assertEqual(stopped.pending_market_reference, "market-ref")
            bot._open_passed_trigger_at_market(stopped, D("4007.50"), "level crossed")

        bot.capital.open_position.assert_called_once()
        self.assertEqual(bot.state.scenario, 2)
        self.assertEqual(stopped.deal_id, "position-id")
        self.assertEqual(stopped.current_entry, D("4009.68"))
        self.assertEqual(stopped.pending_market_reference, "")

    def test_trigger_404_stays_unresolved_until_delayed_execution_appears(self):
        bot = self.make_bot()
        stopped = bot.strategy.stopped("SELL", D("4011.10"))
        stopped.trigger_id = "trigger-sell"
        bot.capital.activity.return_value = []
        bot.capital.positions.return_value = []

        with patch("trader.app.time.sleep"):
            self.assertIsNone(bot._close_trigger_that_raced_with_tp(stopped))

        opened = {
            "dateUTC": "2026-09-08T13:01:00",
            "dealId": "late-sell", "source": "USER", "type": "POSITION",
            "status": "ACCEPTED", "details": {
                "workingOrderId": "trigger-sell", "direction": "SELL", "level": 4010.0,
            },
        }
        executed = {
            "dateUTC": "2026-09-08T13:00:59",
            "dealId": "trigger-sell", "source": "USER", "type": "WORKING_ORDER",
            "status": "EXECUTED", "details": {"direction": "SELL"},
        }
        bot.capital.activity.return_value = [executed, opened]
        bot.capital.positions.return_value = [{
            "position": {
                "dealId": "late-sell", "workingOrderId": "trigger-sell",
                "direction": "SELL", "level": 4010.0, "size": 10,
            },
            "market": {"epic": bot.cfg.epic},
        }]
        bot.capital.close_position.return_value = "close-late"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "late-sell", "level": 4010.2,
        }

        with patch("trader.app.time.sleep"):
            loss = bot._close_trigger_that_raced_with_tp(stopped)

        self.assertEqual(loss, D("-2.0"))
        bot.capital.close_position.assert_called_once_with("late-sell")

    def test_market_position_resolves_from_activity_if_it_closed_before_positions_sync(self):
        bot = self.make_bot()
        bot.capital.wait_position.side_effect = CapitalError("not visible")
        bot.capital.activity.return_value = [{
            "dateUTC": "2026-09-08T13:00:20.414",
            "dealId": "00000000-6135-eff8",
            "source": "USER",
            "type": "POSITION",
            "status": "ACCEPTED",
            "details": {
                "dealReference": "p_00000000-6135-eff8",
                "workingOrderId": "00000000-6135-eff5",
                "direction": "SELL",
                "level": 4410.15,
            },
        }]
        confirmation = {
            "dealId": "00000000-6135-eff5",
            "affectedDeals": [{"dealId": "00000000-6135-eff8", "status": "OPENED"}],
        }

        position = bot._resolve_market_position(
            confirmation, "o_3a2964aa", "SELL", {"old-sell"}
        )

        self.assertEqual(position["dealId"], "00000000-6135-eff8")
        self.assertEqual(position["workingOrderId"], "00000000-6135-eff5")
        self.assertEqual(position["level"], D("4410.15"))

    def test_demo_both_absent_closes_cycle_using_actual_market_position_id(self):
        bot = self.make_bot()
        bot.state.long.deal_id = "00000000-6135-ee9f"
        bot.state.short.deal_id = "00000000-6135-eff8"
        bot.state.long.current_entry = D("4411.91")
        bot.state.long.stop = D("4410.41")
        bot.state.short.current_entry = D("4410.15")
        bot.state.short.stop = D("4411.65")
        bot.state.short.take_profit = D("4405.14")
        bot.state.scenario = 3
        bot.state.scenario_transitions = [
            {"key": "s2", "cycle_id": bot.state.cycle_id, "scenario": 2,
             "deal_id": "sell-s2", "direction": "SELL", "working_order_id": "wo-s2",
             "broker_execution_time": "2026-01-01T00:00:01Z"},
            {"key": "s3", "cycle_id": bot.state.cycle_id, "scenario": 3,
             "deal_id": "sell-s3", "direction": "SELL", "working_order_id": "wo-s3",
             "broker_execution_time": "2026-01-01T00:00:02Z"},
        ]
        bot.state.recovery = D("5.01")
        bot.capital.positions.return_value = []
        bot.capital.activity.side_effect = lambda deal_id="", last_period=86400: [
            {
                "dealId": "00000000-6135-ee9f", "source": "SL", "type": "POSITION",
                "dateUTC": "2026-01-01T00:00:03Z", "status": "ACCEPTED",
                "details": {"level": 4410.34, "direction": "SELL", "size": 0.1},
            },
            {
                "dealId": "00000000-6135-eff8", "source": "TP", "type": "POSITION",
                "dateUTC": "2026-01-01T00:00:04Z", "status": "ACCEPTED",
                "details": {"level": 4406.09, "direction": "BUY", "size": 0.1},
            },
        ] if not deal_id else [item for item in [
            {
                "dealId": "00000000-6135-ee9f", "source": "SL", "type": "POSITION",
                "dateUTC": "2026-01-01T00:00:03Z", "status": "ACCEPTED",
                "details": {"level": 4410.34, "direction": "SELL", "size": 0.1},
            },
            {
                "dealId": "00000000-6135-eff8", "source": "TP", "type": "POSITION",
                "dateUTC": "2026-01-01T00:00:04Z", "status": "ACCEPTED",
                "details": {"level": 4406.09, "direction": "BUY", "size": 0.1},
            },
        ] if item["dealId"] == deal_id]

        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.gross_take_profit, D("4.06"))
        self.assertEqual(bot.state.realized_losses, D("1.57"))
        self.assertEqual(bot.state.net_cycle_result, D("2.49"))

    def test_demo_market_fallback_sl_then_tp_end_to_end(self):
        """Replay historical fills; fixed protection could change a future DEMO outcome."""
        bot = self.make_bot()
        bot.cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            stop_distance=D("1.5"), target_profit=D("0.4"), size=D("10"),
        )
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4411.91"), D("4411.11"))
        bot.state.long.deal_id = "buy-ee9f"
        bot.state.short.deal_id = "old-sell"
        bot.state.scenario = 2
        stopped = bot.strategy.stopped("SELL", D("4412.61"), "old-sell-stop")
        stopped.original_trigger_level = D("4411.11")
        bot.state.recovery = D("3.44")
        # The log already contains two SELL losses before the final MARKET SELL:
        # 15.10 USD + 15.20 USD at size 10 = 3.03 price points.
        bot.state.realized_losses = D("3.03")

        class DemoBroker:
            def __init__(self):
                self.tp_visible = False
                self.sell_stop = D("4412.61")
                self.sell_tp = D("4406.10")
                self.update_calls = []
                self.open_calls = 0
                self.deleted = []
                self.position_reads = 0

            def positions(self):
                self.position_reads += 1
                if self.position_reads == 1:
                    return [{
                        "position": {
                            "dealId": "buy-ee9f", "direction": "BUY", "level": 4411.91,
                        },
                        "market": {"epic": "GOLD"},
                    }]
                if self.tp_visible:
                    return []
                return [{
                    "position": {
                        "dealId": "sell-eff8", "dealReference": "p-sell-eff8",
                        "workingOrderId": "execution-eff5", "direction": "SELL",
                        "level": 4410.15, "stopLevel": self.sell_stop,
                        "profitLevel": self.sell_tp,
                    },
                    "market": {"epic": "GOLD"},
                }]

            def open_position(self, *args, **kwargs):
                self.open_calls += 1
                return "market-ref"

            def wait_confirmation(self, reference):
                if reference == "market-ref":
                    return {
                        "dealStatus": "ACCEPTED", "dealId": "execution-eff5",
                        "affectedDeals": [{"dealId": "sell-eff8", "status": "OPENED"}],
                        "level": 4410.15, "direction": "SELL",
                    }
                if reference == "trigger-ref":
                    return {"dealStatus": "ACCEPTED", "dealId": "buy-trigger"}
                return {"dealStatus": "ACCEPTED"}

            def wait_position(self, deal_id, reference, direction, **kwargs):
                if deal_id != "sell-eff8":
                    raise AssertionError(f"wrong position id: {deal_id}")
                return self.positions()[0]["position"]

            def update_position(self, deal_id, stop, target):
                self.update_calls.append((deal_id, stop, target))
                if deal_id == "buy-ee9f":
                    raise CapitalError('Capital API 404: {"errorCode":"error.not-found.dealId"}')
                if deal_id != "sell-eff8":
                    raise AssertionError(f"wrong protection id: {deal_id}")
                self.sell_stop, self.sell_tp = stop, target
                return f"update-{len(self.update_calls)}"

            def activity(self, deal_id="", last_period=86400):
                events = [{
                    "dealId": "buy-ee9f", "source": "SL", "type": "POSITION",
                    "status": "ACCEPTED", "details": {"level": 4410.34, "size": 10},
                }]
                if self.tp_visible:
                    events.append({
                        "dealId": "sell-eff8", "source": "TP", "type": "POSITION",
                        "status": "ACCEPTED", "details": {"level": 4406.09, "size": 10},
                    })
                return [event for event in events if not deal_id or event["dealId"] == deal_id]

            def working_orders(self):
                return []

            def quote(self, epic):
                return D("4410.60"), D("4411.10")

            def working_stop(self, *args, **kwargs):
                return "trigger-ref"

            def delete_working_order(self, deal_id):
                self.deleted.append(deal_id)
                return True

        broker = DemoBroker()
        bot.capital = broker

        with patch("trader.app.time.sleep"):
            bot._open_passed_trigger_at_market(
                stopped, D("4406.10"), "error.validation.stop.price"
            )

        self.assertEqual(bot.state.short.deal_id, "sell-eff8")
        self.assertEqual(bot.state.scenario, 3)
        self.assertEqual(bot.state.phase, "SHORT_ONLY")
        self.assertEqual(bot.state.realized_losses, D("4.60"))
        self.assertEqual(
            len([key for key in bot.state.processed_events if key.startswith("stop:buy-ee9f")]), 1
        )
        self.assertTrue(any(call[0] == "sell-eff8" for call in broker.update_calls))
        self.assertFalse(any(call[0] == "execution-eff5" for call in broker.update_calls))
        self.assertEqual(broker.open_calls, 1)

        broker.tp_visible = True
        with patch("trader.app.time.sleep"):
            bot._tick_cycle()

        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.gross_take_profit, D("4.06"))
        self.assertEqual(bot.state.realized_losses, D("4.60"))
        self.assertEqual(bot.state.net_cycle_result, D("-0.54"))
        self.assertEqual(bot.state.net_cycle_result * bot.cfg.size, D("-5.40"))
        self.assertEqual(broker.deleted, ["buy-trigger"])
        reports = "\n".join(call.args[0] for call in bot.telegram.send.call_args_list)
        self.assertIn("Фактический Deal ID: sell-eff8", reports)
        self.assertIn("Итог завершённого цикла", reports)

    def test_startup_replays_unambiguous_stop_and_creates_trigger(self):
        bot = self.make_bot()
        bot.reconciled = False
        long_id = bot.state.long.deal_id = "long-1"
        short_id = bot.state.short.deal_id = "short-1"
        bot.capital.positions.return_value = [{
            "position": {"dealId": long_id, "direction": "BUY", "level": 4010.30,
                         "size": 0.1},
            "market": {"epic": "GOLD"},
        }]
        bot.capital.working_orders.return_value = []
        bot.capital.activity.return_value = [{
            "dealId": short_id, "level": 4011.10, "source": "SL", "type": "POSITION", "status": "ACCEPTED",
            "details": {"level": 4011.10, "size": 0.1},
        }]
        bot.capital.update_position.return_value = "update-ref"
        bot.capital.working_stop.return_value = "trigger-ref"
        bot.capital.wait_confirmation.side_effect = [
            {"dealStatus": "ACCEPTED"},
            {"dealStatus": "ACCEPTED", "dealId": "trigger-1"},
        ]

        bot.reconcile_startup()

        self.assertTrue(bot.reconciled)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.phase, "LONG_ONLY")
        self.assertEqual(bot.state.general_recovery, D("0.070"))
        self.assertEqual(bot.state.short.trigger_id, "trigger-1")


    def test_two_confirmed_stops_pause_attempt_once(self):
        bot = self.make_bot()
        object.__setattr__(bot.cfg, "size", D("10"))
        bot.state.active_attempt_id = bot.state.attempt_counter = 224
        bot.state.long.deal_id = "buy-224"
        bot.state.short.deal_id = "sell-224"
        bot.state.long.current_entry = D("4372.74")
        bot.state.short.current_entry = D("4371.16")
        bot.state.long.size = bot.state.short.size = D("10")
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            object.__setattr__(
                bot.cfg, "diagnostic_log_file", str(Path(directory) / "diagnostics.log")
            )
            bot.capital.activity.return_value = [
                {"dateUTC": "2026-09-21T00:00:01Z", "dealId": "buy-224",
                 "source": "SL", "type": "POSITION", "status": "ACCEPTED", "level": 4371.22,
                 "details": {"level": 4371.22, "size": 10}},
                {"dateUTC": "2026-09-21T00:00:02Z", "dealId": "sell-224",
                 "source": "SL", "type": "POSITION", "status": "ACCEPTED", "level": 4373.53,
                 "details": {"level": 4373.53, "size": 10}},
            ]
            with patch("trader.app.end_diagnostic_cycle"):
                bot._begin_double_sl_pause([
                    (bot.state.long, D("4371.22")),
                    (bot.state.short, D("4373.53")),
                ])
                total = bot.state.attempt_result_total
                bot._begin_double_sl_pause([
                    (bot.state.long, D("4371.22")),
                    (bot.state.short, D("4373.53")),
                ])
        self.assertEqual(bot.state.phase, "DOUBLE_SL_PAUSE")
        self.assertTrue(bot.state.active)
        self.assertEqual(total, D("-38.90"))
        self.assertEqual(bot.state.attempt_result_total, total)
        self.assertEqual(len(bot.state.attempt_history), 1)


class DiagnosticHistoryTest(unittest.TestCase):
    def _write(self, handler, text):
        handler.emit(__import__("logging").LogRecord(
            "test", __import__("logging").INFO, __file__, 1, text, (), None
        ))

    def test_more_than_twenty_cycles_are_not_pruned_without_delivery(self):
        with tempfile.TemporaryDirectory() as directory:
            handler = CycleFileHandler(str(Path(directory) / "bot_diagnostics.log"))
            for cycle in range(1, 23):
                handler.begin_cycle(cycle, cycle - 1)
                self._write(handler, f"cycle {cycle}")
                handler.end_cycle(cycle + 1)
            handler.begin_cycle(23, 22)
            names = [item["name"] for item in handler._index["segments"]]
            handler.close()
        self.assertTrue(any("cycle-000000002.log" in name for name in names))
        self.assertTrue(any("cycle-000000003.log" in name for name in names))
        self.assertTrue(any("cycle-000000023.log" in name for name in names))

    def test_long_cycle_is_not_truncated_and_snapshot_can_use_many_parts(self):
        with tempfile.TemporaryDirectory() as directory:
            handler = CycleFileHandler(str(Path(directory) / "bot_diagnostics.log"))
            handler.begin_cycle(7)
            payload = "x" * 700
            self._write(handler, payload)
            parts = handler.snapshot(max_part_bytes=400)
            content = b"".join(Path(path).read_bytes() for path in parts)
            handler.close()
            for path in parts:
                Path(path).unlink(missing_ok=True)
        self.assertGreater(len(parts), 2)
        self.assertIn(payload.encode(), content)

    def test_restart_inside_cycle_retains_prior_segment_and_cycle_number(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "bot_diagnostics.log")
            first = CycleFileHandler(path)
            first.begin_cycle(11)
            self._write(first, "before restart")
            first.close()
            second = CycleFileHandler(path)
            second.begin_cycle(11)
            self._write(second, "after restart")
            parts = second.snapshot(max_part_bytes=10000)
            content = Path(parts[0]).read_text(encoding="utf-8")
            second.close()
            Path(parts[0]).unlink(missing_ok=True)
        self.assertLess(content.index("before restart"), content.index("after restart"))
        self.assertGreaterEqual(content.count("ТОРГОВАЯ ПОПЫТКА 11"), 2)

    def test_runs_without_sendlog_and_stop_marker_are_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "bot_diagnostics.log")
            first = CycleFileHandler(path)
            self._write(first, "run one without sendlog")
            first.close()
            second = CycleFileHandler(path)
            self._write(second, "/stop in same process")
            parts = second.snapshot(max_part_bytes=10000)
            content = b"".join(Path(p).read_bytes() for p in parts).decode()
            second.close()
        self.assertIn("run one without sendlog", content)
        self.assertIn("/stop in same process", content)
        self.assertIn("ЗАПУСК ПРОЦЕССА №1", content)
        self.assertIn("ЗАПУСК ПРОЦЕССА №2", content)

    def test_repeat_sendlog_contains_full_current_run(self):
        with tempfile.TemporaryDirectory() as directory:
            handler = CycleFileHandler(str(Path(directory) / "bot_diagnostics.log"))
            self._write(handler, "begin current")
            first = handler.snapshot(max_part_bytes=10000)
            first_id = handler.pending_snapshots()[-1]["id"]
            for part in handler.pending_snapshots()[-1]["parts"]:
                handler.acknowledge(first_id, part["number"], "delivered")
            self._write(handler, "tail current")
            second = handler.snapshot(max_part_bytes=10000)
            content = b"".join(Path(p).read_bytes() for p in second).decode()
            handler.close()
        self.assertIn("begin current", content)
        self.assertIn("tail current", content)

    def test_partial_failure_keeps_sources_and_delivered_parts(self):
        with tempfile.TemporaryDirectory() as directory:
            handler = CycleFileHandler(str(Path(directory) / "bot_diagnostics.log"))
            self._write(handler, "important diagnostics" * 30)
            handler.snapshot(max_part_bytes=200)
            snapshot = handler.pending_snapshots()[-1]
            handler.acknowledge(snapshot["id"], 1, "delivered")
            handler.acknowledge(snapshot["id"], 2, "failed")
            persisted = json.loads(handler.index_path.read_text())
            source_exists = all((handler.history_dir / r["name"]).exists()
                                for r in snapshot["ranges"])
            handler.close()
        saved = next(item for item in persisted["snapshots"] if item["id"] == snapshot["id"])
        self.assertEqual(saved["parts"][0]["status"], "delivered")
        self.assertEqual(saved["parts"][1]["status"], "failed")
        self.assertTrue(source_exists)

    def test_acknowledged_boundary_preserves_tail_on_next_run(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "bot_diagnostics.log")
            first = CycleFileHandler(path)
            self._write(first, "sent boundary")
            first.snapshot(max_part_bytes=10000)
            snap = first.pending_snapshots()[-1]
            for part in snap["parts"]:
                first.acknowledge(snap["id"], part["number"], "delivered")
            self._write(first, "unsent tail")
            first.close()
            second = CycleFileHandler(path)
            self._write(second, "new run")
            parts = second.snapshot(max_part_bytes=10000)
            content = b"".join(Path(p).read_bytes() for p in parts).decode()
            second.close()
        self.assertNotIn("sent boundary", content)
        self.assertIn("unsent tail", content)
        self.assertIn("new run", content)

    def test_legacy_log_migrates_as_unsent(self):
        with tempfile.TemporaryDirectory() as directory:
            legacy = Path(directory) / "bot_diagnostics.log"
            legacy.write_text("legacy unsent diagnostics", encoding="utf-8")
            handler = CycleFileHandler(str(legacy))
            parts = handler.snapshot(max_part_bytes=10000)
            content = b"".join(Path(p).read_bytes() for p in parts).decode()
            legacy_items = [item for item in handler._index["segments"]
                            if item.get("run_id") == "legacy"]
            handler.close()
        self.assertIn("legacy unsent diagnostics", content)
        self.assertTrue(legacy_items)
        self.assertEqual(legacy_items[0]["delivered_bytes"], 0)

    def test_successful_new_snapshot_supersedes_failed_covered_snapshot(self):
        with tempfile.TemporaryDirectory() as directory:
            handler = CycleFileHandler(str(Path(directory) / "bot_diagnostics.log"))
            self._write(handler, "same covered data")
            handler.snapshot(max_part_bytes=10000)
            old = handler.pending_snapshots()[-1]
            handler.acknowledge(old["id"], 1, "failed")
            handler.snapshot(max_part_bytes=10000)
            new = handler.pending_snapshots()[-1]
            for part in new["parts"]:
                handler.acknowledge(new["id"], part["number"], "delivered")
            old_saved = next(item for item in handler._index["snapshots"]
                             if item["id"] == old["id"])
            handler.close()
        self.assertEqual(old_saved["status"], "superseded")
        self.assertFalse(any(Path(part["path"]).exists() for part in old_saved["parts"]))

    def test_interrupted_legacy_move_is_recovered_without_duplicate_index_entry(self):
        with tempfile.TemporaryDirectory() as directory:
            legacy = Path(directory) / "bot_diagnostics.log"
            history = Path(directory) / "bot_diagnostics.log.history"
            history.mkdir()
            orphan = history / "legacy-bot_diagnostics.log"
            orphan.write_text("moved before index save", encoding="utf-8")
            first = CycleFileHandler(str(legacy)); first.close()
            second = CycleFileHandler(str(legacy))
            records = [item for item in second._index["segments"] if item["name"] == orphan.name]
            parts = second.snapshot(max_part_bytes=10000)
            content = b"".join(Path(path).read_bytes() for path in parts).decode()
            second.close()
        self.assertEqual(len(records), 1)
        self.assertIn("moved before index save", content)

    def test_snapshot_streams_large_source_in_bounded_reads(self):
        with tempfile.TemporaryDirectory() as directory:
            handler = CycleFileHandler(str(Path(directory) / "bot_diagnostics.log"))
            self._write(handler, "x" * (1024 * 1024))
            original_open = Path.open
            reads = []

            class Reader:
                def __init__(self, wrapped): self.wrapped = wrapped
                def __enter__(self): return self
                def __exit__(self, *args): self.wrapped.close()
                def seek(self, *args): return self.wrapped.seek(*args)
                def read(self, size=-1):
                    reads.append(size)
                    return self.wrapped.read(size)

            def monitored(path, mode="r", *args, **kwargs):
                opened = original_open(path, mode, *args, **kwargs)
                return Reader(opened) if mode == "rb" and path.suffix == ".log" else opened

            with patch.object(Path, "open", monitored):
                parts = handler.snapshot(max_part_bytes=300000)
            handler.close()
        self.assertGreater(len(parts), 2)
        self.assertTrue(reads)
        self.assertTrue(all(0 < size <= 256 * 1024 for size in reads))


class CapitalClientTest(unittest.TestCase):
    def test_check_classifies_concrete_validation_rejection_but_not_generic_400(self):
        rejected = Mock(ok=False, status_code=400, content=b"x")
        rejected.text = '{"errorCode":"error.invalid.takeprofit.maxvalue: 4153.55"}'
        rejected.json.return_value = {
            "errorCode": "error.invalid.takeprofit.maxvalue: 4153.55"
        }
        with self.assertRaises(CapitalError) as captured:
            CapitalClient._check(rejected)
        self.assertTrue(captured.exception.rejected)
        self.assertEqual(captured.exception.http_status, 400)
        self.assertEqual(
            captured.exception.error_code,
            "error.invalid.takeprofit.maxvalue: 4153.55",
        )

        ambiguous = Mock(ok=False, status_code=400, content=b"x", text="bad request")
        ambiguous.json.return_value = {"message": "bad request"}
        with self.assertRaises(CapitalError) as captured:
            CapitalClient._check(ambiguous)
        self.assertFalse(captured.exception.rejected)
        self.assertEqual(captured.exception.outcome, "UNKNOWN")

    def test_activity_uses_explicit_one_day_utc_range_without_last_period(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        client.request = Mock(return_value={"activities": []})
        client.activity(
            "deal-old", from_date="2026-09-14T12:00:00", to_date="2026-09-15T12:00:00"
        )
        params = client.request.call_args.kwargs["params"]
        self.assertEqual(params["from"], "2026-09-14T12:00:00")
        self.assertEqual(params["to"], "2026-09-15T12:00:00")
        self.assertEqual(params["dealId"], "deal-old")
        self.assertNotIn("lastPeriod", params)

    def test_activity_rejects_last_period_over_documented_limit(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        with self.assertRaises(ValueError):
            client.activity(last_period=86401)
        with self.assertRaises(ValueError):
            client.activity(
                from_date="2026-09-14T00:00:00", to_date="2026-09-15T00:00:01"
            )

    def test_repeated_activity_responses_log_unique_events_once(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        response = Mock(status_code=200, content=b"yes", text="")
        event = {"dealId": "sell-224", "source": "SL", "details": {"level": 4373.53}}
        response.json.return_value = {"activities": [event]}
        with self.assertLogs("trader.capital", level="INFO") as captured:
            client._log_response(1, response, time.monotonic(), path="/history/activity")
            client._log_response(2, response, time.monotonic(), path="/history/activity")
        joined = "\n".join(captured.output)
        self.assertEqual(joined.count('"dealId":"sell-224"'), 1)
        self.assertIn('"repeated_activities_suppressed":1', joined)

    def test_parallel_session_refresh_is_performed_once(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        response = Mock(ok=True, status_code=200, content=b"{}")
        response.json.return_value = {}
        response.headers = {"CST": "cst", "X-SECURITY-TOKEN": "security"}
        client.http.post = Mock(return_value=response)
        barrier = __import__("threading").Barrier(3)

        def refresh():
            barrier.wait()
            client.login()

        threads = [__import__("threading").Thread(target=refresh) for _ in range(2)]
        for thread in threads:
            thread.start()
        barrier.wait()
        for thread in threads:
            thread.join(1)

        self.assertEqual(client.http.post.call_count, 1)
        self.assertEqual(client.session_generation, 1)

    def test_working_order_cancellation_waits_for_accepted_confirmation(self):
        client = CapitalClient.__new__(CapitalClient)
        client.request = Mock(return_value={"dealReference": "cancel-ref"})
        client.wait_confirmation = Mock(return_value={"dealStatus": "ACCEPTED"})

        self.assertTrue(client.delete_working_order("trigger-1"))

        client.wait_confirmation.assert_called_once_with("cancel-ref")

    def test_delete_missing_working_order_is_idempotent_but_other_errors_raise(self):
        client = CapitalClient.__new__(CapitalClient)
        client.request = Mock(side_effect=CapitalError(
            'Capital API 404: {"errorCode":"error.not-found.dealId"}'
        ))
        self.assertFalse(client.delete_working_order("already-executed"))

        client.request = Mock(side_effect=CapitalError("Capital API 500: unavailable"))
        with self.assertRaises(CapitalError):
            client.delete_working_order("unknown")

    def test_get_retries_transient_transport_failure_without_retrying_mutation(self):
        settings = Settings(api_key="key", identifier="id", password="password")
        client = CapitalClient(settings)
        client.last_login = 10**20
        response = Mock(status_code=200, ok=True, content=b"{}")
        response.json.return_value = {}
        client.http.request = Mock(side_effect=[requests.ReadTimeout("temporary"), response])
        with patch("trader.capital.time.sleep"):
            self.assertEqual(client.request("GET", "/positions"), {})
        self.assertEqual(client.http.request.call_count, 2)

        client.http.request = Mock(side_effect=requests.ReadTimeout("unknown mutation result"))
        with self.assertRaises(CapitalError):
            client.request("POST", "/positions", json={})
        self.assertEqual(client.http.request.call_count, 1)

    def test_initial_position_can_use_fill_relative_protection_distances(self):
        client = CapitalClient.__new__(CapitalClient)
        client.request = Mock(return_value={"dealReference": "ref"})

        reference = client.open_position(
            "GOLD", "BUY", D("0.1"),
            stop_distance=D("1"), profit_distance=D("1.3"),
        )

        self.assertEqual(reference, "ref")
        body = client.request.call_args.kwargs["json"]
        self.assertEqual(body["stopDistance"], 1.0)
        self.assertEqual(body["profitDistance"], 1.3)
        self.assertNotIn("stopLevel", body)
        self.assertNotIn("profitLevel", body)

    def test_three_minute_candles_are_aggregated_from_minute_bars(self):
        client = CapitalClient.__new__(CapitalClient)
        client.request = Mock(return_value={"prices": [
            self.candle("2026-08-21T10:00:00", "10", "9"),
            self.candle("2026-08-21T10:01:00", "12", "10"),
            self.candle("2026-08-21T10:02:00", "11", "8"),
            self.candle("2026-08-21T10:03:00", "14", "12"),
            self.candle("2026-08-21T10:04:00", "15", "13"),
        ]})
        closed, current = client.candle_ranges("GOLD", 3)
        self.assertEqual(closed, D("4"))
        self.assertEqual(current, D("3"))
        self.assertEqual(client.request.call_args.kwargs["params"]["resolution"], "MINUTE")

    def test_wait_position_resolves_permanent_id_from_affected_deal(self):
        client = CapitalClient.__new__(CapitalClient)
        client.positions = Mock(return_value=[{
            "position": {"dealId": "permanent", "dealReference": "ref", "direction": "BUY", "level": 10}
        }])
        position = client.wait_position("permanent", "ref", "BUY")
        self.assertEqual(position["dealId"], "permanent")

    def test_wait_position_does_not_bind_stale_same_direction_position(self):
        client = CapitalClient.__new__(CapitalClient)
        client.positions = Mock(side_effect=[
            [{"position": {"dealId": "old", "direction": "BUY", "level": 9}}],
            [{"position": {"dealId": "old", "direction": "BUY", "level": 9}},
             {"position": {"dealId": "new", "direction": "BUY", "level": 10}}],
        ])
        with patch("trader.capital.time.sleep"):
            position = client.wait_position("confirmation-id", "new-ref", "BUY",
                                            excluded_ids={"old"})
        self.assertEqual(position["dealId"], "new")

    def test_wait_position_direction_fallback_is_scoped_to_epic(self):
        client = CapitalClient.__new__(CapitalClient)
        client.positions = Mock(return_value=[
            {"position": {"dealId": "oil", "direction": "BUY", "level": 80},
             "market": {"epic": "OIL"}},
            {"position": {"dealId": "gold", "direction": "BUY", "level": 4620},
             "market": {"epic": "GOLD"}},
        ])
        position = client.wait_position("pending", "ref", "BUY", epic="GOLD")
        self.assertEqual(position["dealId"], "gold")

    def test_update_position_retries_eventual_not_found(self):
        client = CapitalClient.__new__(CapitalClient)
        client.request = Mock(side_effect=[
            CapitalError('Capital API 404: {"errorCode":"error.not-found.dealId"}'),
            {"dealReference": "updated"},
        ])
        with patch("trader.capital.time.sleep"):
            reference = client.update_position("deal", D("9"), D("11"))
        self.assertEqual(reference, "updated")
        self.assertEqual(client.request.call_count, 2)

    @staticmethod
    def candle(timestamp, high, low):
        return {"snapshotTimeUTC": timestamp, "highPrice": {"bid": high}, "lowPrice": {"bid": low}}


class BrokerInfrastructureTest(unittest.TestCase):
    def test_long_report_is_split_into_ordered_numbered_messages(self):
        telegram = Telegram("token", "123")
        with patch.object(telegram, "send", return_value=True) as send:
            self.assertTrue(telegram.send_report("A\n" * 30, limit=20))
        parts = [call.args[0] for call in send.call_args_list]
        self.assertGreater(len(parts), 1)
        self.assertTrue(parts[0].startswith("Часть 1/"))
        self.assertTrue(parts[-1].startswith(f"Часть {len(parts)}/{len(parts)}"))

    def test_close_wait_retries_deal_and_global_activity(self):
        bot = Bot.__new__(Bot)
        bot.state = CycleState()
        leg = Leg("SELL", D("4010"), D("4010"), deal_id="sell-1", open=True)
        leg.size = D("0.1")
        bot.capital = Mock()
        bot.capital.activity.side_effect = [
            [], [], [], [],
            [{
                "dateUTC": "2026-08-27T12:00:01",
                "dealId": "sell-1", "source": "TP", "type": "POSITION",
                "status": "ACCEPTED", "details": {"level": 4008.7, "size": "0.1"},
            }],
        ]

        with patch("trader.app.time.sleep"):
            fill = bot._wait_closing_fill(leg, "TP", attempts=4, delay=0)

        self.assertEqual(fill, D("4008.7"))
        self.assertEqual(bot.capital.activity.call_args_list[-1].args, ())
        self.assertEqual(bot.state.deal_history[-1]["close_source"], "TP")

    def test_position_protection_readback_404_is_deferred(self):
        bot = Bot.__new__(Bot)
        bot.capital = Mock()
        bot.capital.position.side_effect = CapitalError(
            'Capital API 404: {"errorCode":"error.not-found.dealId"}'
        )

        actual = bot._wait_position_protection("gone", D("9"), D("11"))

        self.assertEqual(actual, (None, None))

    def test_transport_error_on_protection_is_resolved_by_readback(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings()
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4010.30"), D("4010.00"))
        leg = bot.state.long
        leg.deal_id = "long"
        bot.capital = Mock()
        bot.capital.update_position.side_effect = CapitalError(
            "Capital transport error PUT /positions/long: timeout"
        )
        bot._cycle_positions = Mock(return_value={
            "long": {"dealId": "long", "stopLevel": leg.stop,
                     "profitLevel": leg.take_profit},
        })
        bot.telegram = Mock()

        self.assertTrue(bot._apply_protection(leg))
        self.assertIn("повторным чтением", bot.telegram.send.call_args.args[0])

    def test_rejected_close_activity_is_not_treated_as_fill(self):
        activity = [{
            "dateUTC": "2026-08-25T14:00:00", "dealId": "deal",
            "source": "SL", "type": "POSITION", "status": "REJECTED",
            "details": {"level": 4009.2},
        }]
        self.assertIsNone(find_close_event(activity, "deal", "SL"))

    def test_missing_deal_during_protection_is_deferred_to_event_replay(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings()
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4010.30"), D("4010.00"))
        bot.state.long.deal_id = "closed-between-snapshot-and-put"
        bot.capital = Mock()
        bot.capital.update_position.side_effect = CapitalError(
            'Capital API 404: {"errorCode":"error.not-found.dealId"}'
        )
        bot.telegram = Mock()

        self.assertFalse(bot._apply_protection(bot.state.long))
        bot.telegram.send.assert_not_called()

    def test_closed_trigger_position_is_recovered_from_global_activity(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings()
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4622.63"), D("4622.02"))
        bot.state.long.deal_id, bot.state.short.deal_id = "old-buy", "old-sell"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        stopped = bot.strategy.stopped("BUY", D("4621.61"), "initial-buy-stop")
        stopped.trigger_id = "trigger-buy"
        survivor = bot.state.short
        activity = [
            {"dateUTC": "2026-08-25T13:34:09", "dealId": "new-buy",
             "source": "USER", "type": "POSITION", "status": "ACCEPTED",
             "details": {"workingOrderId": "trigger-buy", "direction": "BUY",
                         "level": 4622.63, "size": 0.1}},
            {"dateUTC": "2026-08-25T13:34:10", "dealId": survivor.deal_id,
             "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "details": {"direction": "BUY", "level": 4623.07, "size": 0.1}},
            {"dateUTC": "2026-08-25T13:34:12", "dealId": "new-buy",
             "source": "TP", "type": "POSITION", "status": "ACCEPTED",
             "details": {"direction": "SELL", "level": 4624.95, "size": 0.1}},
        ]
        bot.capital = Mock()
        bot.capital.activity.return_value = activity
        bot.telegram = Mock()
        bot._complete_cycle = Mock()

        self.assertTrue(bot._recover_trigger_round_trip_from_activity(survivor, stopped))
        self.assertEqual(bot.state.scenario, 2)
        bot._complete_cycle.assert_called_once_with("BUY", D("4624.95"))
        bot.capital.activity.assert_called_once_with()

    def test_survivor_tp_trigger_race_is_resolved_by_api_without_manual_mode(self):
        bot = Bot.__new__(Bot)
        bot.state = CycleState()
        bot.cfg = Settings()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4550.20"), D("4549.52"))
        stopped = bot.strategy.stopped("BUY", D("4548.64"), "initial-buy-stop")
        stopped.trigger_id = "trigger-buy"
        survivor = bot.state.short
        bot.capital = Mock()
        bot.capital.activity.return_value = [
            {"dateUTC": "2026-08-28T15:39:18", "dealId": "reopened-buy",
             "source": "USER", "type": "POSITION", "status": "ACCEPTED",
             "details": {"workingOrderId": "trigger-buy", "direction": "BUY",
                         "level": 4550.26}},
            {"dateUTC": "2026-08-28T15:39:19", "dealId": "reopened-buy",
             "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "details": {"level": 4548.64}},
            {"dateUTC": "2026-08-28T15:39:38", "dealId": survivor.deal_id,
             "source": "TP", "type": "POSITION", "status": "ACCEPTED",
             "details": {"level": 4547.56}},
        ]
        bot._close_trigger_that_raced_with_tp = Mock(return_value=D("1.62"))
        bot._complete_cycle = Mock()
        bot.telegram = Mock()

        with tempfile.NamedTemporaryFile() as state_file:
            bot.cfg = Settings(state_file=state_file.name)
            handled = bot._recover_trigger_round_trip_from_activity(survivor, stopped)

        self.assertTrue(handled)
        self.assertFalse(bot.state.manual)
        self.assertEqual(bot.state.realized_losses, D("1.56"))
        bot._close_trigger_that_raced_with_tp.assert_called_once_with(stopped)
        bot._complete_cycle.assert_called_once_with("SELL", D("4547.56"))
        self.assertIn("проверены через Capital.com API", bot.telegram.send.call_args.args[0])

    def test_two_fast_stops_create_trigger_for_the_first_stopped_survivor(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings()
        bot.state = CycleState()
        bot.strategy = Strategy(bot.cfg, bot.state)
        bot.strategy.begin(D("4622.63"), D("4622.02"))
        bot.state.long.deal_id, bot.state.short.deal_id = "old-buy", "old-sell"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        original_stopped = bot.strategy.stopped("BUY", D("4621.61"), "initial-buy-stop")
        original_stopped.trigger_id = "trigger-buy"
        old_survivor = bot.state.short
        bot.capital = Mock()
        bot.capital.activity.return_value = [
            {"dateUTC": "2026-08-25T13:34:09", "dealId": "reopened-buy",
             "source": "USER", "type": "POSITION", "status": "ACCEPTED",
             "details": {"workingOrderId": "trigger-buy", "direction": "BUY",
                         "level": 4622.67, "size": 0.1}},
            {"dateUTC": "2026-08-25T13:34:10", "dealId": "old-sell",
             "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "details": {"direction": "BUY", "level": 4623.07, "size": 0.1}},
            {"dateUTC": "2026-08-25T13:34:12", "dealId": "reopened-buy",
             "source": "SL", "type": "POSITION", "status": "ACCEPTED",
             "details": {"direction": "SELL", "level": 4621.62, "size": 0.1}},
        ]
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []
        bot.telegram = Mock()
        bot._create_trigger = Mock()

        self.assertTrue(
            bot._recover_trigger_round_trip_from_activity(old_survivor, original_stopped)
        )
        self.assertEqual(bot.state.phase, "DOUBLE_SL_PAUSE")
        self.assertFalse(bot.state.long.open)
        self.assertFalse(bot.state.short.open)
        bot._create_trigger.assert_not_called()

    def test_nested_activity_is_normalized_and_sorted(self):
        items = [{
            "dateUTC": "2026-08-22T10:01:00Z", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
            "type": "POSITION",
            "details": {"dealId": "deal-1", "closeLevel": "4009.20", "direction": "BUY"},
        }, {
            "dateUTC": "2026-08-22T10:00:00Z", "source": "USER", "status": "ACCEPTED",
            "details": {"dealId": "deal-1", "level": "4010.30", "direction": "BUY"},
        }]
        events = normalize_events(items)
        self.assertEqual(events[0].source, "USER")
        close = find_close_event(items, "deal-1", "SL")
        self.assertEqual(close.level, D("4009.20"))
        self.assertTrue(close.is_stop)

    def test_execution_helpers_are_directional(self):
        self.assertTrue(trigger_level_passed("SELL", D("10"), D("9.9"), D("10.1")))
        self.assertFalse(trigger_level_passed("BUY", D("10.2"), D("9.9"), D("10.1")))
        self.assertTrue(is_crossed_level_rejection("error.invalid.level: already crossed"))
        self.assertTrue(is_crossed_level_rejection("error.validation.stop.price"))
        self.assertFalse(is_crossed_level_rejection("insufficient funds"))

    def test_remote_snapshot_accepts_position_linked_to_trigger(self):
        snapshot = RemoteSnapshot({
            "new-deal": {"dealId": "new-deal", "workingOrderId": "trigger-1"},
            "foreign": {"dealId": "foreign"},
        }, {})
        self.assertEqual(
            snapshot.unknown_position_ids(set(), {"trigger-1"}), {"foreign"}
        )

    def test_pnl_report_uses_broker_values(self):
        text = pnl_text(
            CycleState(scenario=3, recovery=D("3.00")),
            [{"position": {"upl": "2.50", "currency": "USD"}}],
            [{"profitAndLoss": "-1.20", "currency": "USD"}],
        )
        self.assertIn("Закрытый P&L за период истории: -1.20 USD", text)
        self.assertIn("Суммарно: 1.30 USD", text)

    def test_pnl_report_accepts_capital_transaction_size_as_money(self):
        text = pnl_text(
            CycleState(), [],
            [{"transactionType": "TRADE", "size": "-0.09", "currency": "USD"},
             {"transactionType": "TRADE", "size": "0.14", "currency": "USD"}],
        )
        self.assertIn("Закрытый P&L за период истории: 0.05 USD", text)

    def test_completed_cycle_report_includes_losses_gross_and_net(self):
        state = CycleState(
            scenario=2, realized_losses=D("2.05"), gross_take_profit=D("2.35"),
            net_cycle_result=D("0.30"),
        )
        text = cycle_result_text(state, "SELL", D("4668.99"), D("0.1"))
        self.assertIn("Валовая прибыль TP: 2.35 пункта", text)
        self.assertIn("Общие убытки закрытых сторон: 2.05 пункта", text)
        self.assertIn("Итог цикла: 0.30 пункта", text)
        self.assertIn("итог 0.030", text)

    def test_removed_settrigger_command_does_not_create_working_stop(self):
        bot = EntryRetryTest().make_bot()
        bot.state.manual = True
        bot.state.long.open = False
        bot.capital.working_stop.return_value = "manual-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "manual-order",
        }
        before = (bot.state.scenario, bot.state.general_recovery,
                  bot.state.long.deal_id, bot.state.short.deal_id)
        bot.command("/settrigger long 4020.50")
        self.assertEqual((bot.state.scenario, bot.state.general_recovery,
                          bot.state.long.deal_id, bot.state.short.deal_id), before)
        bot.capital.working_stop.assert_not_called()

    def test_removed_settrigger_is_unknown_after_completed_cycle(self):
        bot = EntryRetryTest().make_bot()
        bot.state.active = False
        bot.state.long.open = False
        bot.command("/settrigger long 4020.50")
        bot.capital.working_stop.assert_not_called()

    def test_removed_recover_command_does_not_mutate_trading_state(self):
        bot = EntryRetryTest().make_bot()
        bot.state.manual = True
        bot.state.paused = True
        before = (bot.state.manual, bot.state.paused, bot.state.scenario,
                  bot.state.long.deal_id, bot.state.short.deal_id,
                  bot.state.general_recovery)
        bot.command("/recover")
        self.assertEqual((bot.state.manual, bot.state.paused, bot.state.scenario,
                          bot.state.long.deal_id, bot.state.short.deal_id,
                          bot.state.general_recovery), before)
        bot.capital.update_position.assert_not_called()

    def test_automode_clears_stale_manual_cycle_when_broker_is_empty(self):
        bot = EntryRetryTest().make_bot()
        bot.state.manual = True
        bot.state.paused = True
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []

        bot.command("/automode")

        self.assertFalse(bot.state.manual)
        self.assertFalse(bot.state.active)
        self.assertTrue(bot.state.paused)
        self.assertEqual(bot.state.phase, "PAUSED")

    def test_automode_refuses_to_ignore_existing_position(self):
        bot = EntryRetryTest().make_bot()
        bot.state.manual = True
        bot.capital.positions.return_value = [{
            "position": {"dealId": "buy", "direction": "BUY"}, "market": {"epic": "GOLD"},
        }]
        bot.capital.working_orders.return_value = []
        with self.assertRaisesRegex(RuntimeError, "Нельзя выйти"):
            bot.command("/automode")

    def test_startup_clears_manual_state_when_broker_has_nothing(self):
        bot = EntryRetryTest().make_bot()
        bot.state.manual = True
        bot.reconciled = False
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []

        bot.reconcile_startup()

        self.assertTrue(bot.reconciled)
        self.assertFalse(bot.state.manual)
        self.assertFalse(bot.state.active)
        self.assertEqual(bot.state.phase, "PAUSED")


class StreamingQuoteTest(unittest.TestCase):
    def test_directional_levels_wake_only_when_reached(self):
        stream = QuoteStream("GOLD", lambda: ("cst", "token"))
        stream.watch([
            PriceWatch("SL", "BUY", D("99")),
            PriceWatch("TP", "BUY", D("105")),
            PriceWatch("TRIGGER", "SELL", D("98")),
        ])

        stream._message(json.dumps({
            "destination": "quote",
            "payload": {"epic": "GOLD", "bid": 100, "ofr": 100.2, "timestamp": 1},
        }))
        self.assertFalse(stream.wait(0))

        stream._message(json.dumps({
            "destination": "quote",
            "payload": {"epic": "GOLD", "bid": 97.9, "ofr": 98.1, "timestamp": 2},
        }))
        self.assertTrue(stream.wait(0))
        self.assertEqual(stream.latest().bid, D("97.9"))

    def test_quotes_never_wake_for_other_epics_or_malformed_messages(self):
        stream = QuoteStream("GOLD", lambda: ("cst", "token"))
        stream.watch([PriceWatch("TP", "SELL", D("100"))])
        stream._message("not-json")
        stream._message(json.dumps({
            "destination": "quote",
            "payload": {"epic": "SILVER", "bid": 90, "ofr": 90.2, "timestamp": 1},
        }))
        self.assertFalse(stream.wait(0))
        self.assertIsNone(stream.latest())

    def test_out_of_order_quote_cannot_generate_a_false_crossing_after_reconnect(self):
        stream = QuoteStream("GOLD", lambda: ("cst", "token"))
        stream.watch([PriceWatch("SL", "BUY", D("99"))])
        stream._message(json.dumps({
            "destination": "quote", "status": "OK",
            "payload": {"epic": "GOLD", "bid": 100, "ofr": 100.2, "timestamp": 20},
        }))
        stream._message(json.dumps({
            "destination": "quote", "status": "OK",
            "payload": {"epic": "GOLD", "bid": 98, "ofr": 98.2, "timestamp": 10},
        }))

        self.assertFalse(stream.wait(0))
        self.assertEqual(stream.latest().bid, D("100"))

    def test_rejected_stream_message_forces_reconnect(self):
        stream = QuoteStream("GOLD", lambda: ("cst", "token"))
        with self.assertRaises(ConnectionError):
            stream._message(json.dumps({
                "destination": "marketData.subscribe", "status": "ERROR", "payload": {},
            }))

    def test_disconnect_reconnects_and_resubscribes_with_current_tokens(self):
        connections = []
        tokens = [("cst-1", "security-1", 1), ("cst-2", "security-2", 2)]
        token_calls = 0

        def current_tokens():
            nonlocal token_calls
            value = tokens[min(token_calls, 1)]
            token_calls += 1
            return value

        class Connection:
            def __init__(self, disconnect):
                self.disconnect = disconnect
                self.sent = []

            def send(self, message):
                self.sent.append(json.loads(message))

            def settimeout(self, timeout):
                self.timeout = timeout

            def recv(self):
                if self.disconnect:
                    self.disconnect = False
                    raise ConnectionError("network lost")
                subscription = self.sent[0]
                return json.dumps({
                    "status": "OK", "destination": "marketData.subscribe",
                    "correlationId": subscription["correlationId"],
                    "payload": {"subscriptions": {"GOLD": "PROCESSED"}},
                })

            def close(self):
                pass

        def factory(url, timeout):
            connection = Connection(disconnect=not connections)
            connections.append(connection)
            return connection

        stream = QuoteStream(
            "GOLD", current_tokens,
            connection_factory=factory, reconnect_initial=0.01
        )
        stream.start()
        deadline = time.monotonic() + 1
        while len(connections) < 2 and time.monotonic() < deadline:
            time.sleep(0.01)
        stream.stop()

        self.assertGreaterEqual(len(connections), 2)
        self.assertEqual(connections[0].sent[0]["destination"], "marketData.subscribe")
        self.assertEqual(connections[0].sent[0]["cst"], "cst-1")
        self.assertEqual(connections[1].sent[0]["cst"], "cst-2")
        self.assertNotIn("cst-1", str(connections[1].sent[0]))

    def test_subscription_requires_processed_acknowledgement(self):
        stream = QuoteStream("GOLD", lambda: ("cst", "token", 1))
        connection = Mock()
        connection.recv.return_value = json.dumps({
            "status": "OK", "destination": "marketData.subscribe", "correlationId": "sub-1",
            "payload": {"subscriptions": {"GOLD": "REJECTED"}},
        })
        with self.assertRaisesRegex(ConnectionError, "not processed"):
            stream._await_subscription(connection, "sub-1")

    def test_missing_quote_timestamp_is_ignored(self):
        stream = QuoteStream("GOLD", lambda: ("cst", "token"))
        stream._message(json.dumps({
            "destination": "quote", "payload": {"epic": "GOLD", "bid": 100, "ofr": 101},
        }))
        self.assertIsNone(stream.latest())

    def test_bot_watches_protected_positions_and_pending_triggers(self):
        bot = Bot.__new__(Bot)
        bot.state = CycleState(active=True)
        bot.state.long = Leg("BUY", D("100"), D("101"), stop=D("99"), take_profit=D("105"))
        bot.state.short = Leg(
            "SELL", D("100"), D("100"), open=False, trigger_id="order-1"
        )

        watches = bot._price_watches()

        self.assertEqual(set(watches), {
            PriceWatch("SL", "BUY", D("99")),
            PriceWatch("TP", "BUY", D("105")),
            PriceWatch("TRIGGER", "SELL", D("100")),
        })

    def test_stream_signal_triggers_rest_confirmation_while_quiet_quotes_do_not(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings(websocket_rest_fallback_seconds=10)
        bot.state = CycleState(active=True)
        bot.quotes = Mock()
        bot.quotes.latest.return_value = object()
        bot._tick_cycle = Mock()
        bot._last_cycle_rest_check = time.monotonic()
        bot._stream_signal = False

        bot.tick()
        bot._tick_cycle.assert_not_called()

        bot._stream_signal = True
        bot.tick()
        bot._tick_cycle.assert_called_once()

    def test_stale_stream_preserves_rest_polling_fallback(self):
        bot = Bot.__new__(Bot)
        bot.cfg = Settings(websocket_rest_fallback_seconds=10)
        bot.state = CycleState(active=True)
        bot.quotes = Mock()
        bot.quotes.latest.return_value = None
        bot._tick_cycle = Mock()
        bot._last_cycle_rest_check = time.monotonic()
        bot._stream_signal = False

        bot.tick()

        bot._tick_cycle.assert_called_once()


class DetailedNotificationRegressionTest(unittest.TestCase):
    def settings(self):
        return Settings(
            scenario_sizes=(D("10"), D("10")) + (D("20"),) * 7,
            scenario_stop_distances=(D("1"), D("2"), D("3")) + (D("4"),) * 6,
        )

    def test_cycle_273_first_and_second_increase_arithmetic(self):
        state = CycleState(general_recovery=D("102"))
        leg = Leg("SELL", D("4000"), D("3999.9"), size=D("20"), stop_distance=D("4"))
        state.short = leg
        text = leg_details(leg, general_recovery=state.general_recovery)
        self.assertIn("recovery_distance=5.1", text)

    def test_double_sl_attempt_uses_actual_sizes_ten_and_twenty(self):
        bot = EntryRetryTest().make_bot()
        bot.state.active_attempt_id = bot.state.attempt_counter = 501
        bot.state.cycle_id, bot.state.cycle_attempt = 50, 2
        buy, sell = bot.state.long, bot.state.short
        buy.deal_id, buy.current_entry, buy.stop, buy.size = "buy", D("100"), D("99"), D("10")
        sell.deal_id, sell.current_entry, sell.stop, sell.size = "sell", D("100"), D("103"), D("20")
        with tempfile.TemporaryDirectory() as directory, patch("trader.app.time.time", return_value=1000):
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            object.__setattr__(bot.cfg, "diagnostic_log_file", str(Path(directory) / "diag.log"))
            bot.capital.activity.return_value = [
                {"dateUTC": "2026-09-21T00:00:01Z", "dealId": "buy",
                 "source": "SL", "type": "POSITION", "status": "ACCEPTED", "level": 99,
                 "details": {"level": 99, "size": 10}},
                {"dateUTC": "2026-09-21T00:00:02Z", "dealId": "sell",
                 "source": "SL", "type": "POSITION", "status": "ACCEPTED", "level": 103,
                 "details": {"level": 103, "size": 20}},
            ]
            bot._begin_double_sl_pause([(buy, D("99")), (sell, D("103"))])
            first_total = bot.state.attempt_result_total
            bot._begin_double_sl_pause([(buy, D("99")), (sell, D("103"))])
        self.assertEqual(first_total, D("-70"))
        self.assertEqual(bot.state.attempt_result_total, D("-70"))
        self.assertEqual(bot.state.realized_loss_money, D("70"))
        report = bot.telegram.send.call_args.args[0]
        self.assertIn("результат закрытия -10", report)
        self.assertIn("результат закрытия -60", report)
        self.assertIn("результат попытки: -70", report)
        self.assertIn("накопленные убытки цикла: 70", report)

    def test_cycle_274_repeated_large_side_then_alignment(self):
        settings = self.settings(); state = CycleState(); strategy = Strategy(settings, state)
        strategy.begin(D("4300.5"), D("4300")); strategy.confirm_initial_fills(D("4300.5"), D("4300"))
        for direction in ("SELL", "SELL", "SELL", "BUY", "BUY"):
            leg = state.short if direction == "SELL" else state.long
            strategy.stopped(direction, leg.stop, f"stop-{state.scenario}-{direction}")
            strategy.reopened(direction, leg.original_trigger_level, f"deal-{state.scenario + 1}", f"open-{state.scenario + 1}")
        self.assertEqual(state.scenario, 6)

    def test_protection_details_use_individual_recovery_and_sources(self):
        leg = Leg("BUY", D("4285.14"), D("4285.14"), deal_id="buy", size=D("20"), stop_distance=D("1"))
        text = leg_details(leg, general_recovery=D("102"))
        self.assertIn("recovery_distance=5.1", text)
        self.assertNotIn("temporary:", text)

    def test_malformed_positions_never_confirms_expected_protection(self):
        bot = EntryRetryTest().make_bot()
        bot.capital.position.side_effect = None
        bot.capital.position.return_value = {
            "position": {"dealId": "buy", "stopLevel": "unparseable", "profitLevel": "999"}
        }
        with patch("trader.app.time.sleep"):
            actual = bot._wait_position_protection("buy", D("99"), D("102"), attempts=2)
        self.assertEqual(actual, (None, None))

    def test_failed_readback_retries_get_without_second_put(self):
        bot = EntryRetryTest().make_bot()
        leg = bot.state.long
        leg.deal_id, leg.stop, leg.take_profit = "buy", D("99"), D("102")
        bot.capital.update_position.return_value = "put-ref"
        bot.capital.wait_confirmation.return_value = {"dealStatus": "ACCEPTED"}
        bot.capital.position.side_effect = None
        bot.capital.position.return_value = {
            "position": {"dealId": "buy", "stopLevel": "bad", "profitLevel": "102"}}
        with tempfile.TemporaryDirectory() as directory, patch("trader.app.time.sleep"):
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            self.assertFalse(bot._apply_protection(leg))
            self.assertFalse(bot._apply_protection(leg))
        bot.capital.update_position.assert_called_once_with("buy", D("99"), D("102"))
        self.assertIn("НЕ ПОДТВЕРЖДЕНО", leg.protection_readback)

    def test_confirmation_and_readback_are_distinct_revisions(self):
        leg = Leg("BUY", D("100"), D("100"), deal_id="buy", stop=D("99"),
                  take_profit=D("103"), confirmed_stop=D("99"),
                  confirmed_take_profit=D("102"), protection_sent_stop=D("99"),
                  protection_sent_take_profit=D("103"), confirmation_stop=D("99"),
                  confirmation_take_profit=D("103"), protection_confirmation="ACCEPTED",
                  protection_readback="ожидается")
        text = leg_details(leg)
        self.assertIn("расчётные SL/TP=99 / 103", text)
        self.assertIn("принятые SL/TP=99 / 103", text)
        self.assertIn("последние сохранённые read-back SL/TP", text)
        self.assertIn("повторное чтение /positions=ожидается", text)

    def test_nonclose_deal_history_falls_back_to_global_and_uses_old_range(self):
        client = Mock()
        client.activity.side_effect = [
            [{"dealId": "buy-old", "source": "USER", "status": "ACCEPTED",
              "type": "POSITION", "level": 100}],
            [{"dealId": "buy-old", "source": "TP", "type": "POSITION", "status": "ACCEPTED",
              "type": "POSITION", "level": 105}],
        ]
        started = time.time() - 3 * 86400
        result = NotificationHistoryWorker._resolve(client, {
            "waiting": {"deal_id": "buy-old"}, "search_from_epoch": started,
            "search_to_epoch": started + 86400,
        })
        self.assertEqual({key: result[key] for key in ("source", "fill")},
                         {"source": "TP", "fill": "105"})
        first = client.activity.call_args_list[0]
        self.assertIn("from_date", first.kwargs)
        self.assertIn("to_date", first.kwargs)
        self.assertNotIn("last_period", first.kwargs)
        start_value = datetime.fromisoformat(first.kwargs["from_date"]).replace(tzinfo=timezone.utc)
        end_value = datetime.fromisoformat(first.kwargs["to_date"]).replace(tzinfo=timezone.utc)
        self.assertLessEqual((end_value - start_value).total_seconds(), 86400)

    def test_specific_sl_returns_without_global_request(self):
        client = Mock()
        client.activity.return_value = [{
            "dealId": "wanted", "source": "SL", "type": "POSITION", "status": "ACCEPTED", "level": 99,
        }]
        result = NotificationHistoryWorker._resolve(client, {
            "waiting": {"deal_id": "wanted"}, "search_from_epoch": 1000,
            "search_to_epoch": 2000,
        })
        self.assertEqual({key: result[key] for key in ("source", "fill")},
                         {"source": "SL", "fill": "99"})
        client.activity.assert_called_once()
        self.assertEqual(client.activity.call_args.args[0], "wanted")

    def test_specific_tp_returns_even_if_global_would_fail(self):
        client = Mock()

        def activity(deal_id="", **kwargs):
            if not deal_id:
                raise CapitalError("global unavailable")
            return [{"dealId": "wanted", "source": "TP", "type": "POSITION", "status": "ACCEPTED",
                     "level": 103}]

        client.activity.side_effect = activity
        result = NotificationHistoryWorker._resolve(client, {
            "waiting": {"deal_id": "wanted"}, "search_from_epoch": 1000,
            "search_to_epoch": 2000,
        })
        self.assertEqual({key: result[key] for key in ("source", "fill")},
                         {"source": "TP", "fill": "103"})
        self.assertEqual(client.activity.call_count, 1)

    def test_foreign_deal_close_is_not_accepted(self):
        client = Mock()
        client.activity.return_value = [{
            "dealId": "foreign", "source": "SL", "type": "POSITION", "status": "ACCEPTED", "level": 99,
        }]
        result = NotificationHistoryWorker._resolve(client, {
            "waiting": {"deal_id": "wanted"}, "search_from_epoch": 1000,
            "search_to_epoch": 2000,
        })
        self.assertIsNone(result)
        self.assertEqual(client.activity.call_count, 2)

    def test_legacy_job_without_dates_uses_frozen_last_day_and_finds_recent_sl(self):
        now = datetime(2026, 9, 17, 12, 0, tzinfo=timezone.utc).timestamp()
        event_time = now - 60
        calls = []

        class FilteringClient:
            def activity(self, deal_id="", **kwargs):
                calls.append((deal_id, kwargs))
                start = datetime.fromisoformat(kwargs["from_date"]).replace(tzinfo=timezone.utc).timestamp()
                end = datetime.fromisoformat(kwargs["to_date"]).replace(tzinfo=timezone.utc).timestamp()
                if deal_id == "legacy" and start <= event_time <= end:
                    return [{"dealId": "legacy", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                             "level": 98, "dateUTC": "2026-09-17T11:59:00"}]
                return []

        job = {"waiting": {"deal_id": "legacy"}}
        with patch("trader.notifications.time.time", return_value=now):
            result = NotificationHistoryWorker._resolve(FilteringClient(), job)
        self.assertEqual({key: result[key] for key in ("source", "fill")},
                         {"source": "SL", "fill": "98"})
        self.assertEqual(job["search_from_epoch"], now - 86400)
        self.assertEqual(job["search_to_epoch"], now)
        self.assertTrue(job["history_range_uncertain"])
        self.assertEqual(len(calls), 1)

    def test_legacy_job_migration_survives_load_save_and_preserves_known_bounds(self):
        now = datetime(2026, 9, 17, 12, 0, tzinfo=timezone.utc).timestamp()
        legacy = {"key": "legacy", "waiting": {"deal_id": "old"}, "closed": {}}
        known = {"key": "known", "waiting": {"deal_id": "dated"},
                 "search_from_epoch": 1234.0, "search_to_epoch": 5678.0,
                 "search_range_source": "saved_attempt"}
        state = CycleState(pending_notification_jobs=[legacy, known])
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            state.save(path)
            loaded = CycleState.load(path)
            self.assertTrue(migrate_notification_jobs(
                loaded.pending_notification_jobs, now=now
            ))
            loaded.save(path)
            restored = CycleState.load(path)
        job = restored.pending_notification_jobs[0]
        self.assertEqual(job["search_from_epoch"], now - 86400)
        self.assertEqual(job["search_to_epoch"], now)
        self.assertEqual(job["search_range_source"], "legacy_fallback_last_24h")
        self.assertFalse(migrate_notification_jobs([job], now=now + 9999))
        self.assertEqual(job["search_from_epoch"], now - 86400)
        known_restored = restored.pending_notification_jobs[1]
        self.assertEqual(known_restored["search_from_epoch"], 1234.0)
        self.assertEqual(known_restored["search_to_epoch"], 5678.0)

    def test_legacy_job_uses_trustworthy_snapshot_timestamp_not_migration_time(self):
        event_time = datetime(2026, 9, 10, 8, 30, tzinfo=timezone.utc).timestamp()
        migration_time = datetime(2026, 9, 17, 12, 0, tzinfo=timezone.utc).timestamp()
        job = {
            "waiting": {"deal_id": "old"},
            "closed": {"deal_id": "known", "dateUTC": "2026-09-10T08:30:00Z"},
        }
        self.assertTrue(migrate_notification_jobs([job], now=migration_time))
        self.assertEqual(job["search_from_epoch"], event_time - 3600)
        self.assertEqual(job["search_to_epoch"], event_time + 3600)
        self.assertEqual(job["search_range_source"], "attempt_snapshot")
        self.assertFalse(job["history_range_uncertain"])

    def test_broker_utc_timestamps_are_timezone_independent(self):
        expected = datetime(2026, 9, 10, 8, 30, tzinfo=timezone.utc).timestamp()
        representations = (
            ("dateUTC", "2026-09-10T08:30:00"),
            ("createdDateUTC", "2026-09-10T08:30:00"),
            ("dateUTC", "2026-09-10T08:30:00Z"),
            ("dateUTC", "2026-09-10T13:30:00+05:00"),
        )
        original_tz = os.environ.get("TZ")
        try:
            for process_tz in ("UTC", "Etc/GMT-5"):
                os.environ["TZ"] = process_tz
                time.tzset()
                for field, value in representations:
                    job = {"waiting": {"deal_id": "old"}, "closed": {field: value}}
                    self.assertTrue(migrate_notification_jobs([job], now=expected + 86400))
                    self.assertEqual(job["search_from_epoch"], expected - 3600)
                    self.assertEqual(job["search_to_epoch"], expected + 3600)
        finally:
            if original_tz is None:
                os.environ.pop("TZ", None)
            else:
                os.environ["TZ"] = original_tz
            time.tzset()

    def test_numeric_epoch_is_timezone_independent_but_generic_naive_time_is_uncertain(self):
        expected = datetime(2026, 9, 10, 8, 30, tzinfo=timezone.utc).timestamp()
        original_tz = os.environ.get("TZ")
        try:
            os.environ["TZ"] = "Etc/GMT-5"
            time.tzset()
            numeric = {"waiting": {"deal_id": "old"}, "event_epoch": expected}
            self.assertTrue(migrate_notification_jobs([numeric], now=expected + 86400))
            self.assertEqual(numeric["search_from_epoch"], expected - 3600)
            generic = {
                "waiting": {"deal_id": "old", "timestamp": "2026-09-10T08:30:00"}
            }
            migration_time = expected + 7 * 86400
            self.assertTrue(migrate_notification_jobs([generic], now=migration_time))
            self.assertEqual(generic["search_range_source"], "legacy_fallback_last_24h")
            self.assertTrue(generic["history_range_uncertain"])
            self.assertEqual(generic["search_from_epoch"], migration_time - 86400)
        finally:
            if original_tz is None:
                os.environ.pop("TZ", None)
            else:
                os.environ["TZ"] = original_tz
            time.tzset()

    def test_repair_old_local_timezone_migration_and_find_close_after_restart(self):
        event_epoch = datetime(2026, 9, 10, 8, 30, tzinfo=timezone.utc).timestamp()
        wrong_start = datetime(2026, 9, 10, 2, 30, tzinfo=timezone.utc).timestamp()
        wrong_end = datetime(2026, 9, 10, 4, 30, tzinfo=timezone.utc).timestamp()
        original = {
            "key": "old-migrated", "cycle_id": 270,
            "waiting": {"deal_id": "buy-270", "size": "10"},
            "closed": {"deal_id": "sell-270", "dateUTC": "2026-09-10T08:30:00"},
            "search_from_epoch": wrong_start, "search_to_epoch": wrong_end,
            "search_range_source": "attempt_snapshot", "history_range_uncertain": False,
        }
        state = CycleState(pending_notification_jobs=[original])
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            state.save(path)
            loaded = CycleState.load(path)
            self.assertTrue(migrate_notification_jobs(loaded.pending_notification_jobs))
            loaded.save(path)
            restored = CycleState.load(path)
        repaired = restored.pending_notification_jobs[0]
        self.assertEqual(repaired["search_from_epoch"], event_epoch - 3600)
        self.assertEqual(repaired["search_to_epoch"], event_epoch + 3600)
        self.assertEqual(repaired["search_time_version"], 2)
        self.assertEqual(repaired["cycle_id"], 270)
        self.assertEqual(repaired["waiting"]["deal_id"], "buy-270")
        self.assertFalse(migrate_notification_jobs([repaired]))

        class FilteringClient:
            def activity(self, deal_id="", **kwargs):
                start = datetime.fromisoformat(kwargs["from_date"]).replace(tzinfo=timezone.utc).timestamp()
                end = datetime.fromisoformat(kwargs["to_date"]).replace(tzinfo=timezone.utc).timestamp()
                if deal_id == "buy-270" and start <= event_epoch <= end:
                    return [{"dealId": "buy-270", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                             "level": 98, "dateUTC": "2026-09-10T08:30:00"}]
                return []

        with patch("trader.notifications.time.time", return_value=event_epoch + 86400):
            result = NotificationHistoryWorker._resolve(FilteringClient(), repaired)
            self.assertEqual({key: result[key] for key in ("source", "fill")},
                             {"source": "SL", "fill": "98"})

    def test_unverifiable_old_attempt_snapshot_range_is_marked_uncertain_not_shifted(self):
        job = {
            "waiting": {"deal_id": "old"}, "search_from_epoch": 1000,
            "search_to_epoch": 2000, "search_range_source": "attempt_snapshot",
        }
        self.assertTrue(migrate_notification_jobs([job], now=9999))
        self.assertEqual((job["search_from_epoch"], job["search_to_epoch"]), (1000, 2000))
        self.assertEqual(job["search_range_source"], "attempt_snapshot_unverified")
        self.assertTrue(job["history_range_uncertain"])
        self.assertFalse(migrate_notification_jobs([job], now=19999))

    def test_uncertain_range_stays_pending_and_late_publication_is_found(self):
        now = datetime(2026, 9, 17, 12, 0, tzinfo=timezone.utc).timestamp()
        events = []

        class Client:
            def activity(self, deal_id="", **kwargs):
                return list(events)

        job = {"waiting": {"deal_id": "late"}}
        with patch("trader.notifications.time.time", return_value=now):
            self.assertIsNone(NotificationHistoryWorker._resolve(Client(), job))
            frozen = (job["search_from_epoch"], job["search_to_epoch"])
            events.append({"dealId": "late", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                           "level": 97})
            result = NotificationHistoryWorker._resolve(Client(), job)
            self.assertEqual({key: result[key] for key in ("source", "fill")},
                             {"source": "SL", "fill": "97"})
        self.assertEqual((job["search_from_epoch"], job["search_to_epoch"]), frozen)

    def test_history_api_error_does_not_invent_a_result(self):
        client = Mock()
        client.activity.side_effect = CapitalError("history unavailable")
        job = {"waiting": {"deal_id": "late"}}
        with patch("trader.notifications.time.time", return_value=100000):
            with self.assertRaises(CapitalError):
                NotificationHistoryWorker._resolve(client, job)
        self.assertTrue(job["history_range_uncertain"])

    def test_old_history_job_splits_saved_range_into_one_day_windows(self):
        calls = []

        class HistoryClient:
            def activity(self, deal_id="", last_period=86400, *, from_date="", to_date=""):
                calls.append((deal_id, from_date, to_date, last_period))
                if len(calls) == 6:
                    return [{"dealId": "old-deal", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                             "type": "POSITION", "level": 97}]
                return []

        started = time.time() - 5 * 86400
        result = NotificationHistoryWorker._resolve(HistoryClient(), {
            "waiting": {"deal_id": "old-deal"}, "search_from_epoch": started,
            "search_to_epoch": started + 3 * 86400,
        })
        self.assertEqual({key: result[key] for key in ("source", "fill")},
                         {"source": "SL", "fill": "97"})
        self.assertEqual(len(calls), 6)
        for _, start_text, end_text, _ in calls:
            start_value = datetime.fromisoformat(start_text).replace(tzinfo=timezone.utc)
            end_value = datetime.fromisoformat(end_text).replace(tzinfo=timezone.utc)
            self.assertLessEqual((end_value - start_value).total_seconds(), 86400)

    def test_late_tp_report_uses_historical_tp_and_current_state(self):
        bot = EntryRetryTest().make_bot()
        bot.state.phase, bot.state.active, bot.state.manual = "BOTH_OPEN", True, False
        first = {"direction": "SELL", "deal_id": "s", "entry": "100", "size": "10",
                 "stop": "101", "take_profit": "98", "source": "SL", "fill": "101"}
        second = {"direction": "BUY", "deal_id": "b", "entry": "100", "size": "10",
                  "stop": "99", "take_profit": "102", "source": "TP", "fill": "102.1"}
        text = bot._initial_pair_report_text(first, second, final=True, meta={
            "cycle_id": 270, "cycle_attempt": 1,
            "original_decision": "MANUAL: исходная пара не сформирована",
        })
        self.assertIn("исторический TP=102", text)
        self.assertIn("slippage=0.1", text)
        self.assertIn("причина=TP", text)
        self.assertIn("текущее состояние бота: phase=BOTH_OPEN, active=True, manual=False", text)

    def test_cycle_completion_and_report_are_one_state_commit(self):
        bot = EntryRetryTest().make_bot()
        bot.state.active_attempt_id = 73
        bot.state.cycle_id = 73
        bot.state.long.deal_id = "winner"
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            bot._complete_cycle("BUY", D("4012"))
            restored = CycleState.load(bot.cfg.state_file)
        self.assertFalse(restored.active)
        self.assertEqual(restored.completed_cycles, 1)
        self.assertTrue(any(item["key"].startswith("cycle-complete:73")
                            for item in restored.report_outbox))

    def test_delivery_ack_is_saved_immediately(self):
        bot = Bot.__new__(Bot)
        bot.telegram = Telegram("token", "chat")
        bot.notification_worker = None
        bot._queued_report_parts = {("1:r", 1)}
        bot._queued_log_parts = set()
        bot.state = CycleState(report_outbox=[{"id": "1:r", "key": "r", "parts": [
            {"number": 1, "text": "done", "status": "pending"}]}])
        with tempfile.TemporaryDirectory() as directory:
            bot.cfg = Settings(state_file=str(Path(directory) / "state.json"),
                               diagnostic_log_file=str(Path(directory) / "diag.log"))
            bot.telegram._delivery_acks.append(
                {"report_id": "1:r", "part": 1, "status": "delivered"})
            bot._tick_notifications()
            restored = CycleState.load(bot.cfg.state_file)
        self.assertEqual(restored.report_outbox, [])

    def test_closed_leg_levels_are_labelled_historical(self):
        leg = Leg("SELL", D("100"), D("99"), deal_id="closed", open=False,
                  size=D("20"), stop_distance=D("3"), recovery=D("3"),
                  stop=D("102"), take_profit=D("93"))
        text = leg_details(leg)
        self.assertIn("исторические последние SL/TP", text)
        self.assertIn("не являются расчётом от нового Recovery", text)

    def test_cycle_result_lists_weighted_deals_and_trigger_fate(self):
        state = CycleState(gross_take_profit=D("25.71"), realized_losses=D("0"),
                           realized_loss_money=D("424.70"), net_cycle_money=D("89.50"))
        state.long = Leg("BUY", D("4300"), D("4300"), size=D("20"))
        state.attempt_deal_ids = ["winner"] + [f"loss-{i}" for i in range(8)]
        state.deal_history = [
            {"deal_id": "winner", "direction": "BUY", "entry": "4295.15",
             "close_level": "4320.86", "close_source": "TP", "size": "20"},
        ] + [
            {"deal_id": f"loss-{index}", "direction": "SELL", "entry": "4300",
             "close_level": str(D("4300") + loss / size), "close_source": "SL",
             "size": str(size)}
            for index, (loss, size) in enumerate(zip(
                map(D, ("10.60", "10.00", "60.00", "20.30", "81.40", "80.40", "81.20", "80.80")),
                map(D, ("10", "10", "20", "10", "20", "20", "20", "20")),
            ))
        ]
        state.last_trigger_resolution = "workingOrderId=trigger: DELETE confirmation ACCEPTED."
        text = cycle_result_text(state, "BUY", D("4320.86"), D("10"))
        self.assertIn("dealId=winner", text)
        self.assertIn("причина=TP", text)
        self.assertIn("(4320.86 − 4295.15) × 20=514.20", text)
        self.assertIn("убытки 424.70; итог 89.50", text)
        self.assertIn("workingOrderId=trigger", text)
        self.assertEqual(text.count("причина=SL"), 8)

    def test_cycle_273_result_is_summed_from_every_deal(self):
        state = CycleState(gross_take_profit=D("22.10"))
        state.long = Leg("BUY", D("100"), D("100"), size=D("10"))
        state.attempt_deal_ids = ["winner", "loss-a", "loss-b"]
        state.deal_history = [
            {"deal_id": "winner", "direction": "BUY", "entry": "100",
             "close_level": "122.10", "close_source": "TP", "size": "10"},
            {"deal_id": "loss-a", "direction": "SELL", "entry": "100",
             "close_level": "105", "close_source": "SL", "size": "10"},
            {"deal_id": "loss-b", "direction": "BUY", "entry": "100",
             "close_level": "94.83", "close_source": "SL", "size": "10"},
        ]
        text = cycle_result_text(state, "BUY", D("122.10"), D("10"))
        self.assertIn("прибыль 221.00; убытки 101.70; итог 119.30", text)

    def test_continuation_cycle_result_keeps_prior_attempt_losses(self):
        state = CycleState(cycle_id=77, gross_take_profit=D("5"),
                           realized_loss_money=D("30"), net_cycle_money=D("20"))
        state.long = Leg("BUY", D("100"), D("100"), size=D("10"))
        state.deal_history = [
            {"deal_id": "current-loss", "cycle_id": 77, "direction": "SELL",
             "entry": "100", "close_level": "101", "close_source": "SL", "size": "10"},
            {"deal_id": "winner", "cycle_id": 77, "direction": "BUY",
             "entry": "100", "close_level": "105", "close_source": "TP", "size": "10"},
        ]
        state.attempt_history = [
            {"cycle_id": 77, "cycle_attempt": 1, "status": "DOUBLE_SL_CONTINUATION",
             "result": "-20"},
            {"cycle_id": 77, "cycle_attempt": 2, "status": "COMPLETED_CYCLE",
             "result": "20"},
        ]
        text = cycle_result_text(state, "BUY", D("105"), D("10"))
        self.assertIn("прибыль 50; убытки 30; итог 20", text)
        self.assertIn("НЕПОЛНАЯ; денежный итог взят из полного сохранённого агрегата", text)
        self.assertIn("попытка 1: DOUBLE_SL_CONTINUATION = -20", text)

    def test_completion_has_one_durable_full_result(self):
        bot = EntryRetryTest().make_bot()
        bot.telegram = Telegram("token", "chat")
        bot._queued_report_parts = set()
        bot.state.active_attempt_id = bot.state.cycle_id = 88
        bot.state.long.deal_id = "winner"
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            bot._complete_cycle("BUY", D("4012"))
            bot._send_report(
                "✅ wrapper\n" + cycle_result_text(bot.state, "BUY", D("4012"), bot.cfg.size)
            )
        full = [item for item in bot.state.report_outbox
                if any("Итог завершённого цикла" in part["text"] for part in item["parts"])]
        self.assertEqual(len(full), 1)

    def test_positions_match_updates_readback_without_put(self):
        bot = EntryRetryTest().make_bot()
        leg = bot.state.long
        leg.deal_id, leg.stop, leg.take_profit = "buy", D("99"), D("103")
        leg.protection_sent_stop, leg.protection_sent_take_profit = D("99"), D("103")
        leg.protection_readback = "НЕ ПОДТВЕРЖДЕНО"
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            self.assertTrue(bot._protection_matches(
                {"dealId": "buy", "stopLevel": "99", "profitLevel": "103"}, leg
            ))
        self.assertEqual(leg.confirmed_stop, D("99"))
        self.assertEqual(leg.confirmed_take_profit, D("103"))
        self.assertEqual(leg.protection_readback, "ПОДТВЕРЖДЕНО")
        bot.capital.update_position.assert_not_called()

    def test_legacy_legs_keep_individual_size_and_stop_distance(self):
        raw = {
            "active": True, "scenario": 3, "phase": "BOTH_OPEN",
            "long": {"direction": "BUY", "original_trigger_level": "100",
                     "current_entry": "101", "deal_id": "buy", "recovery": "7",
                     "temporary_stop_compensation": "0", "temporary_spread_compensation": "0",
                     "temporary_slippage_compensation": "0"},
            "short": {"direction": "SELL", "original_trigger_level": "100",
                      "current_entry": "100", "deal_id": "sell", "size": "10",
                      "stop_distance": "1", "recovery": "7",
                      "temporary_stop_compensation": "0", "temporary_spread_compensation": "0",
                      "temporary_slippage_compensation": "0"},
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            path.write_text(json.dumps(raw), encoding="utf-8")
            state = CycleState.load(str(path))
            bot = EntryRetryTest().make_bot(); bot.state = state
            object.__setattr__(bot.cfg, "state_file", str(path))
            bot._migrate_legacy_legs({
                "buy": {"dealId": "buy", "size": "20", "stopLevel": "98"},
                "sell": {"dealId": "sell", "size": "10", "stopLevel": "101"},
            })
            restored = CycleState.load(str(path))
        self.assertEqual(restored.long.size, D("20"))
        self.assertEqual(restored.long.stop_distance, D("3"))
        self.assertEqual(restored.short.size, D("10"))
        self.assertEqual(restored.short.stop_distance, D("1"))
        self.assertEqual(restored.long.original_trigger_level, D("100"))
        self.assertEqual(restored.long.current_entry, D("101"))

    def test_legacy_leg_with_unknown_recovery_is_durably_blocked(self):
        raw = {"active": True, "scenario": 3, "phase": "BOTH_OPEN",
               "long": {"direction": "BUY", "original_trigger_level": "100",
                        "current_entry": "101", "deal_id": "buy"}}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"; path.write_text(json.dumps(raw), encoding="utf-8")
            bot = EntryRetryTest().make_bot(); bot.state = CycleState.load(str(path))
            object.__setattr__(bot.cfg, "state_file", str(path))
            with self.assertRaisesRegex(RuntimeError, "старое состояние"):
                bot._migrate_legacy_legs(
                    {"buy": {"dealId": "buy", "size": "20", "stopLevel": "98"}}
                )
            restored = CycleState.load(str(path))
        self.assertIn("recovery", restored.long.legacy_missing_fields)
        self.assertNotIn("size", restored.long.legacy_missing_fields)
        self.assertNotIn("stop_distance", restored.long.legacy_missing_fields)

    def test_second_initial_confirmation_announces_protection_not_another_open(self):
        bot = EntryRetryTest().make_bot()
        bot.state.long.deal_id = "buy"
        bot.capital.open_position.return_value = "sell-ref"
        bot.capital.wait_confirmation.return_value = {
            "dealStatus": "ACCEPTED", "dealId": "sell", "level": 99,
        }
        bot.capital.wait_position.return_value = {
            "dealId": "sell", "direction": "SELL", "level": 99,
        }
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            self.assertIsNone(bot._open_initial_leg(bot.state.short))
        text = bot.telegram.send.call_args.args[0]
        self.assertIn("установить и проверить точные SL/TP обеих сторон", text)
        self.assertNotIn("открыть вторую сторону", text)

    def test_history_worker_resolves_late_close_without_trading_mutation(self):
        client = Mock()
        client.activity.return_value = [{
            "dealId": "buy-270", "source": "SL", "type": "POSITION", "status": "ACCEPTED",
            "type": "POSITION", "details": {"level": 4285.04},
        }]
        job = {"waiting": {"deal_id": "buy-270"}}
        result = NotificationHistoryWorker._resolve(client, job)
        self.assertEqual({key: result[key] for key in ("source", "fill")},
                         {"source": "SL", "fill": "4285.04"})
        client.open_position.assert_not_called()
        client.update_position.assert_not_called()

    def test_notification_jobs_and_outbox_survive_restart(self):
        state = CycleState()
        state.pending_notification_jobs = [{
            "key": "initial", "waiting": {"deal_id": "buy"}, "closed": {},
        }]
        state.report_outbox = [{
            "id": "1:report", "key": "report", "parts": [
                {"number": 1, "text": "one", "status": "delivered"},
                {"number": 2, "text": "two", "status": "pending"},
                {"number": 3, "text": "retry next process", "status": "failed"},
            ],
        }]
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            state.save(path)
            loaded = CycleState.load(path)
        self.assertEqual(loaded.pending_notification_jobs[0]["key"], "initial")
        self.assertEqual(loaded.report_outbox[0]["parts"][0]["status"], "delivered")
        self.assertEqual(loaded.report_outbox[0]["parts"][1]["status"], "pending")
        self.assertEqual(loaded.report_outbox[0]["parts"][2]["status"], "pending")

    def test_late_manual_result_uses_saved_snapshot_after_legs_change(self):
        bot = EntryRetryTest().make_bot()
        bot.state.cycle_id = 270
        bot.state.long = Leg("BUY", D("999"), D("999"), deal_id="new-cycle")
        bot.state.pending_notification_jobs = [{
            "key": "initial-270", "cycle_id": 270, "cycle_attempt": 1, "scenario": 1,
            "closed": {"direction": "SELL", "deal_id": "sell-270", "entry": "4285.12",
                       "size": "10", "stop": "4286.12", "source": "SL", "fill": "4286.14"},
            "waiting": {"direction": "BUY", "deal_id": "buy-270", "entry": "4286.07",
                        "size": "10", "stop": "4285.07", "source": "", "fill": None},
        }]
        worker = Mock()
        worker.results.return_value = [{
            "key": "initial-270", "result": {"source": "SL", "fill": "4285.04"},
        }]
        bot.notification_worker = worker
        with tempfile.TemporaryDirectory() as directory:
            object.__setattr__(bot.cfg, "state_file", str(Path(directory) / "state.json"))
            bot._tick_notifications()
        text = bot.telegram.send.call_args.args[0]
        self.assertIn("Цикл №270", text)
        self.assertIn("dealId=buy-270", text)
        self.assertIn("-20.50", text)
        self.assertNotIn("new-cycle", text)
        self.assertEqual(bot.state.pending_notification_jobs, [])

    def test_restart_queues_only_unconfirmed_report_parts(self):
        bot = Bot.__new__(Bot)
        bot.telegram = Telegram("token", "chat")
        bot.state = CycleState(report_outbox=[{
            "id": "7:result", "key": "result", "parts": [
                {"number": 1, "text": "already sent", "status": "delivered"},
                {"number": 2, "text": "resume me", "status": "pending"},
            ],
        }])
        bot._queued_report_parts = set()
        bot._queue_pending_reports()
        self.assertEqual(len(bot.telegram._messages), 1)
        self.assertEqual(bot.telegram._messages[0].part, 2)
        self.assertEqual(bot.telegram._messages[0].value, "resume me")

    def test_stable_report_parts_and_delivery_ack(self):
        parts = split_report("A\n" * 4000, limit=1000)
        self.assertGreater(len(parts), 1)
        self.assertTrue(parts[0].startswith(f"Часть 1/{len(parts)}"))
        telegram = Telegram("token", "chat")
        telegram.send_report_part(parts[0], "report-1", 1, len(parts))
        item = telegram._messages[0]
        telegram._ack(item, "delivered")
        self.assertEqual(telegram.delivery_acks(), [{
            "report_id": "report-1", "part": 1, "status": "delivered",
        }])


class PydroidConfigTest(unittest.TestCase):
    def test_document_success_stays_inflight_until_ack_is_persisted(self):
        telegram = Telegram("token", "123")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "part.log"; path.write_text("data", encoding="utf-8")
            self.assertTrue(telegram.send_document_part(str(path), "snap", 1, 1))
            item = telegram._documents[0]
            telegram._report_document_part(item, delivered=True)
            self.assertIn(("snap", 1), telegram.queued_document_parts())
            self.assertTrue(telegram.send_document_part(str(path), "snap", 1, 1))
            self.assertEqual(len(telegram._documents), 1)
            telegram.confirm_document_ack("snap", 1)
            self.assertNotIn(("snap", 1), telegram.queued_document_parts())

    def test_restored_document_group_keeps_delivered_part_and_completes_once(self):
        telegram = Telegram("token", "123")
        telegram.restore_document_group("snap", 2, [1])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "part-2.log"; path.write_text("two", encoding="utf-8")
            telegram.send_document_part(str(path), "snap", 2, 2)
            item = telegram._documents[0]
            telegram._report_document_part(item, delivered=True)
            acks = telegram.document_acks()
            telegram._report_document_part(item, delivered=True)
        self.assertEqual(acks, [{"snapshot_id": "snap", "part": 2, "status": "delivered"}])
        self.assertNotIn("snap", telegram._document_groups)

    def test_main_owner_emits_one_completion_after_persisting_document_ack(self):
        bot = Bot.__new__(Bot)
        bot.telegram = Telegram("token", "123")
        bot.notification_worker = None
        bot.state = CycleState()
        bot._queued_report_parts = set(); bot._queued_log_parts = {("snap", 2)}
        bot._send_report = Mock()
        bot.cfg = Settings(diagnostic_log_file="unused.log", state_file="unused-state.json")
        bot.telegram._document_acks.append(
            {"snapshot_id": "snap", "part": 2, "status": "delivered"}
        )
        with patch("trader.app.acknowledge_diagnostic_snapshot", return_value=True), \
                patch("trader.app.pending_diagnostic_snapshots", return_value=[]):
            bot._tick_notifications()
            bot._tick_notifications()
        bot._send_report.assert_called_once_with(
            "✅ /sendlog полностью доставлен: снимок snap", key="sendlog-complete:snap"
        )

    def test_missing_document_file_reports_failure_without_killing_worker(self):
        telegram = Telegram("token", "123")
        response = Mock()
        delivered = __import__("threading").Event()

        def post(url, **kwargs):
            if url.endswith("/sendMessage"):
                delivered.set()
            return response

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "part.log"; path.write_text("data", encoding="utf-8")
            telegram.send_document_part(str(path), "missing", 1, 1)
            path.unlink()
            with patch("trader.telegram.requests.get", side_effect=requests.ReadTimeout("offline")), \
                    patch("trader.telegram.requests.post", side_effect=post):
                telegram.start()
                telegram.send("worker still alive")
                self.assertTrue(delivered.wait(1))
                deadline = time.monotonic() + 1
                acks = []
                while not acks and time.monotonic() < deadline:
                    acks = telegram.document_acks()
                    time.sleep(0.01)
                telegram.stop()
        self.assertEqual(acks[0]["status"], "failed")

    def test_invalid_safety_boolean_is_rejected(self):
        with patch.dict(os.environ, {"CAPITAL_DEMO": "treu"}, clear=True):
            with self.assertRaises(ValueError):
                Settings.from_env()

    def test_nonpositive_entry_range_is_rejected(self):
        with patch.dict(os.environ, {"ENTRY_CANDLE_RANGE": "0"}, clear=True):
            with self.assertRaises(ValueError):
                Settings.from_env()

    def test_json_config_is_loaded_without_environment_exports(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "bot_config.json"
            config.write_text(json.dumps({
                "CAPITAL_DEMO": True,
                "BOT_DRY_RUN": False,
                "CAPITAL_API_KEY": "demo-key",
                "CAPITAL_IDENTIFIER": "demo-user",
                "CAPITAL_PASSWORD": "demo-password",
                "POSITION_SIZE": "0.2",
                "ENTRY_CANDLE_MINUTES": 3,
            }), encoding="utf-8")
            with patch.dict(os.environ, {"BOT_CONFIG_FILE": str(config)}, clear=True):
                settings = Settings.from_env()
        self.assertTrue(settings.demo)
        self.assertFalse(settings.dry_run)
        self.assertEqual(settings.size, D("0.2"))
        self.assertEqual(settings.candle_minutes, 3)

    def test_environment_overrides_json_config(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "bot_config.json"
            config.write_text(json.dumps({"POSITION_SIZE": "0.2"}), encoding="utf-8")
            with patch.dict(os.environ, {
                "BOT_CONFIG_FILE": str(config), "POSITION_SIZE": "0.3",
            }, clear=True):
                settings = Settings.from_env()
        self.assertEqual(settings.size, D("0.3"))

    def test_standalone_installer_extracts_and_preserves_local_state(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive = root / "project.zip"
            with ZipFile(archive, "w") as bundle:
                bundle.writestr("AI-IMPULS-TRAIDER-work/main.py", "print('new')")
                bundle.writestr("AI-IMPULS-TRAIDER-work/bot_config.example.json", "{}")
                bundle.writestr("AI-IMPULS-TRAIDER-work/requirements.txt", "requests\n")
                bundle.writestr("AI-IMPULS-TRAIDER-work/trader/app.py", "NEW = True\n")
            source = safe_extract(archive, root / "unpacked")
            target = root / "installed"
            target.mkdir()
            (target / "bot_config.json").write_text('{"secret":"keep"}', encoding="utf-8")
            (target / "bot_state.json").write_text('{"scenario":4}', encoding="utf-8")
            (target / "bot_diagnostics.log").write_text("legacy log", encoding="utf-8")
            history = target / "bot_diagnostics.log.history"
            history.mkdir()
            (history / "index.json").write_text('{"next_segment":7}', encoding="utf-8")

            copy_project(source, target)
            created = create_config(target)

            self.assertFalse(created)
            self.assertEqual((target / "bot_config.json").read_text(), '{"secret":"keep"}')
            self.assertEqual((target / "bot_state.json").read_text(), '{"scenario":4}')
            self.assertEqual((target / "bot_diagnostics.log").read_text(), "legacy log")
            self.assertEqual((history / "index.json").read_text(), '{"next_segment":7}')
            self.assertEqual((target / "trader/app.py").read_text(), "NEW = True\n")

    def test_telegram_queue_calls_never_perform_network_io(self):
        telegram = Telegram("token", "123")
        with patch("trader.telegram.requests.get") as get, patch("trader.telegram.requests.post") as post:
            telegram.send("ready", show_menu=True)
            telegram.send_document(__file__)
            telegram.install_commands()
            self.assertEqual(telegram.commands(), [])
        get.assert_not_called()
        post.assert_not_called()
        self.assertEqual(telegram.pending_reports, 3)

    def test_telegram_sender_timeout_cannot_block_trading_thread(self):
        telegram = Telegram("token", "123")
        entered = __import__("threading").Event()
        release = __import__("threading").Event()
        response = Mock()

        def slow_post(*args, **kwargs):
            entered.set()
            release.wait(1)
            return response

        with patch("trader.telegram.requests.get", side_effect=requests.ReadTimeout("offline")), \
                patch("trader.telegram.requests.post", side_effect=slow_post):
            telegram.start()
            started = time.monotonic()
            self.assertTrue(telegram.send("important"))
            self.assertLess(time.monotonic() - started, 0.05)
            self.assertTrue(entered.wait(0.5))
            self.assertEqual(telegram.commands(), [])
            release.set()
            deadline = time.monotonic() + 1
            while telegram.pending_reports and time.monotonic() < deadline:
                time.sleep(0.01)
            telegram.stop()
        self.assertEqual(telegram.pending_reports, 0)

    def test_telegram_poll_worker_discards_old_then_queues_new_command(self):
        telegram = Telegram("token", "123")
        old = Mock()
        old.json.return_value = {"result": [{"update_id": 77, "message": {
            "chat": {"id": 123}, "text": "/old"}}]}
        new = Mock()
        new.json.return_value = {"result": [{"update_id": 78, "message": {
            "chat": {"id": 123}, "text": "/status"}}]}
        empty = Mock()
        empty.json.return_value = {"result": []}
        with patch("trader.telegram.requests.get", side_effect=[old, new, empty, empty, empty]), \
                patch("trader.telegram.requests.post", return_value=Mock()):
            telegram.start()
            deadline = time.monotonic() + 1
            commands = []
            while not commands and time.monotonic() < deadline:
                commands = telegram.commands()
                time.sleep(0.01)
            telegram.stop()
        self.assertEqual(commands, ["/status"])
        self.assertEqual(telegram.offset, 79)

    def test_slow_failed_document_does_not_block_normal_message(self):
        telegram = Telegram("secret-token", "123")
        upload_started = __import__("threading").Event()
        release_upload = __import__("threading").Event()
        message_delivered = __import__("threading").Event()
        response = Mock()

        def post(url, **kwargs):
            if url.endswith("/sendDocument"):
                upload_started.set()
                release_upload.wait(1)
                raise requests.Timeout(f"write timeout {url}")
            if url.endswith("/sendMessage"):
                message_delivered.set()
            return response

        with tempfile.TemporaryDirectory() as directory:
            log = Path(directory) / "bot_diagnostics.log"
            log.write_text("quote event\n" * 10000, encoding="utf-8")
            with patch("trader.telegram.requests.get", side_effect=requests.ReadTimeout("offline")), \
                    patch("trader.telegram.requests.post", side_effect=post), \
                    patch.object(telegram, "_failure_policy", return_value=(True, 0)):
                telegram.start()
                telegram.send_document(str(log), compress=True)
                self.assertTrue(upload_started.wait(1))
                telegram.send("ordinary report")
                self.assertTrue(message_delivered.wait(0.5))
                release_upload.set()
                deadline = time.monotonic() + 1
                while telegram.pending_reports and time.monotonic() < deadline:
                    time.sleep(0.01)
                telegram.stop()
        self.assertEqual(telegram.pending_reports, 0)

    def test_compressed_document_recovers_after_transient_write_timeout(self):
        telegram = Telegram("token", "123")
        attempts = 0
        uploads = []
        timeouts = []
        response = Mock()

        def post(url, **kwargs):
            nonlocal attempts
            if url.endswith("/sendDocument"):
                attempts += 1
                document = kwargs["files"]["document"]
                uploads.append((Path(document.name).suffix, Path(document.name).stat().st_size))
                timeouts.append(kwargs["timeout"])
                if attempts == 1:
                    raise requests.Timeout("temporary upload failure")
            return response

        with tempfile.TemporaryDirectory() as directory:
            log = Path(directory) / "bot_diagnostics.log"
            log.write_text("same diagnostic line\n" * 50000, encoding="utf-8")
            original_size = log.stat().st_size
            with patch("trader.telegram.requests.get", side_effect=requests.ReadTimeout("offline")), \
                    patch("trader.telegram.requests.post", side_effect=post), \
                    patch.object(telegram, "_failure_policy", return_value=(False, 0.01)):
                telegram.start()
                telegram.send_document(str(log), compress=True)
                deadline = time.monotonic() + 2
                while (attempts < 2 or telegram.pending_reports) and time.monotonic() < deadline:
                    time.sleep(0.01)
                telegram.stop()
            leftovers = list(Path(directory).glob("telegram-*.gz"))
        self.assertEqual(attempts, 2)
        self.assertTrue(all(size < original_size for _, size in uploads))
        self.assertEqual(timeouts, [180, 180])
        self.assertEqual(leftovers, [])

    def test_two_part_snapshot_retries_only_failed_part(self):
        telegram = Telegram("token", "123")
        response = Mock()
        attempts = {}
        messages = []

        def post(url, **kwargs):
            if url.endswith("/sendDocument"):
                name = Path(kwargs["files"]["document"].name).name
                attempts[name] = attempts.get(name, 0) + 1
                if "part-2" in name and attempts[name] == 1:
                    raise requests.Timeout("second part delayed")
            elif url.endswith("/sendMessage"):
                messages.append(kwargs["json"]["text"])
            return response

        with tempfile.TemporaryDirectory() as directory:
            paths = []
            for number in (1, 2):
                path = Path(directory) / f"history-part-{number}-of-2.log"
                path.write_text(f"part {number}\n", encoding="utf-8")
                paths.append(str(path))
            with patch("trader.telegram.requests.get", side_effect=requests.ReadTimeout("offline")), \
                    patch("trader.telegram.requests.post", side_effect=post), \
                    patch.object(telegram, "_failure_policy", return_value=(False, 0.01)):
                telegram.start()
                telegram.send_log_snapshot(lambda: paths)
                deadline = time.monotonic() + 2
                while (telegram.pending_reports or sum(attempts.values()) < 3) \
                        and time.monotonic() < deadline:
                    time.sleep(0.01)
                telegram.stop()

        self.assertEqual(attempts["history-part-1-of-2.log"], 1)
        self.assertEqual(attempts["history-part-2-of-2.log"], 2)
        self.assertEqual(
            sorted((ack["part"], ack["status"]) for ack in telegram.document_acks()),
            [(1, "delivered"), (2, "delivered")],
        )

    def test_one_part_snapshot_is_uploaded_as_plain_log(self):
        telegram = Telegram("token", "123")
        response = Mock()
        uploaded = []

        def post(url, **kwargs):
            if url.endswith("/sendDocument"):
                document = Path(kwargs["files"]["document"].name)
                uploaded.append((document.suffix, document.read_bytes()))
            return response

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "history-part-1-of-1.log"
            path.write_text("plain diagnostics\n", encoding="utf-8")
            with patch("trader.telegram.requests.get", side_effect=requests.ReadTimeout("offline")), \
                    patch("trader.telegram.requests.post", side_effect=post):
                telegram.start()
                telegram.send_log_snapshot(lambda: [str(path)])
                deadline = time.monotonic() + 1
                while telegram.pending_reports and time.monotonic() < deadline:
                    time.sleep(0.01)
                telegram.stop()

        self.assertEqual(uploaded, [(".log", b"plain diagnostics\n")])

    def test_telegram_failure_policy_honours_retry_after_and_stops_bad_requests(self):
        telegram = Telegram("token", "123")
        limited_response = Mock(status_code=429, headers={})
        limited_response.json.return_value = {"parameters": {"retry_after": 17}}
        limited = requests.HTTPError("rate limited", response=limited_response)
        self.assertEqual(telegram._failure_policy(limited, 1, document=True), (False, 17))
        self.assertEqual(telegram._failure_policy(limited, 5, document=True), (False, 17))

        bad_response = Mock(status_code=400, headers={})
        bad = requests.HTTPError("bad document", response=bad_response)
        self.assertEqual(telegram._failure_policy(bad, 1, document=True)[0], True)
        self.assertFalse(telegram._failure_policy(requests.Timeout(), 5, document=True)[0])

        header_response = Mock(status_code=429, headers={"Retry-After": "23"})
        header_response.json.return_value = {"parameters": {}}
        header_limited = requests.HTTPError("rate limited", response=header_response)
        self.assertEqual(
            telegram._failure_policy(header_limited, 1, document=True), (False, 23)
        )

    def test_telegram_error_diagnostics_redact_bot_token(self):
        telegram = Telegram("very-secret-token", "123")
        error = requests.RequestException(
            "https://api.telegram.org/botvery-secret-token/sendDocument failed"
        )
        safe = telegram._safe_error(error)
        self.assertNotIn("very-secret-token", safe)
        self.assertIn("<redacted>", safe)


if __name__ == "__main__":
    unittest.main()

class GeneralRecoveryModelTest(unittest.TestCase):
    def settings(self, *, sizes=None, stops=None, target="0.30"):
        return Settings(
            size=D("10"), stop_distance=D("1"), target_profit=D(target),
            scenario_sizes=sizes or (D("10"),) * 9,
            scenario_stop_distances=stops or tuple(map(D, ("1", "1.5", "2", "4", "4", "4", "4", "4", "4"))),
        )

    def begin(self, cfg=None):
        state = CycleState(cycle_id=1, cycle_attempt=1)
        strategy = Strategy(cfg or self.settings(), state)
        strategy.begin(D("4000.50"), D("4000.00"))
        strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
        return strategy, state

    def test_s1_sl_trigger_sl_trigger_sequence(self):
        strategy, state = self.begin()
        self.assertEqual((state.general_recovery, state.target_value), (D("8"), D("3")))
        strategy.stopped("BUY", D("3999.40"), "buy-sl-1")
        self.assertEqual(state.general_recovery, D("9"))
        self.assertEqual(D(state.pending_recovery[-1]["pending_d_value"]), D("10"))
        self.assertEqual(state.short.take_profit, D("3998.10"))
        strategy.reopened("BUY", D("4000.60"), "buy-2", "buy-open-2")
        self.assertEqual(state.general_recovery, D("20"))
        self.assertEqual(state.scenario, 2)
        self.assertEqual((state.long.stop_distance, state.short.stop_distance), (D("1.5"), D("1.5")))
        strategy.stopped("SELL", D("4001.60"), "sell-sl-2")
        self.assertEqual(state.general_recovery, D("36"))
        strategy.reopened("SELL", D("3999.90"), "sell-3", "sell-open-3")
        self.assertEqual(state.general_recovery, D("37"))
        self.assertEqual((state.long.take_profit, state.short.take_profit),
                         (D("4004.30"), D("3996.20")))

    def test_volume_change_keeps_money_and_uses_new_size_for_trigger_slippage(self):
        cfg = self.settings(sizes=(D("10"), D("20")) + (D("20"),) * 7,
                            stops=(D("4"),) * 9, target="0")
        strategy, state = self.begin(cfg)
        state.general_recovery = state.recovery = D("59")
        strategy._targets_from_entries()
        strategy.stopped("SELL", D("4004.10"), "sell-sl")
        self.assertEqual(state.general_recovery, D("60"))
        self.assertEqual(D(state.pending_recovery[-1]["pending_d_value"]), D("40"))
        strategy.reopened("SELL", D("3999.90"), "sell-2", "sell-open")
        self.assertEqual(state.general_recovery, D("102"))
        self.assertEqual(state.general_recovery / state.long.size, D("10.2"))
        self.assertEqual(state.general_recovery / state.short.size, D("5.1"))
        self.assertEqual((state.long.size, state.short.size), (D("10"), D("20")))
        self.assertEqual((state.long.take_profit, state.short.take_profit),
                         (D("4010.70"), D("3994.80")))

    def test_same_side_can_reopen_repeatedly(self):
        cfg = self.settings(sizes=(D("10"), D("20")) + (D("20"),) * 7,
                            stops=(D("3"),) * 9, target="0")
        strategy, state = self.begin(cfg)
        state.general_recovery = state.recovery = D("60")
        strategy._targets_from_entries()
        strategy.stopped("SELL", D("4003.10"), "sell-sl-a")
        self.assertEqual(state.general_recovery, D("61"))
        strategy.reopened("SELL", D("3999.90"), "sell-b", "sell-open-b")
        self.assertEqual(state.general_recovery, D("93"))
        strategy.stopped("SELL", D("4003.00"), "sell-sl-b")
        strategy.reopened("SELL", D("3999.80"), "sell-c", "sell-open-c")
        self.assertEqual(state.scenario, 3)
        self.assertEqual(state.long.size, D("10"))
        self.assertEqual(state.short.size, D("20"))

    def test_projected_reopen_is_pure_and_excludes_unknown_future_slippage(self):
        strategy, state = self.begin()
        strategy.stopped("BUY", D("3999.40"), "buy-sl")
        before = (state.general_recovery, state.scenario, list(state.recovery_events))
        size, distance, projected = strategy.projected_reopen("BUY")
        self.assertEqual((size, distance, projected), (D("10"), D("1.5"), D("0.4")))
        self.assertEqual((state.general_recovery, state.scenario, state.recovery_events), before)

    def test_double_sl_transfers_each_pending_d_once_and_continuation_spread_once(self):
        strategy, state = self.begin(self.settings(stops=(D("4"),) * 9, target="0"))
        state.general_recovery = state.recovery = D("59")
        strategy._targets_from_entries()
        strategy.stopped("BUY", D("3996.40"), "buy-sl")
        strategy.stopped("SELL", D("4004.20"), "sell-sl")
        self.assertEqual(state.general_recovery, D("62"))
        self.assertEqual(strategy.account_double_sl_pending(), D("80"))
        self.assertEqual(state.general_recovery, D("142"))
        self.assertEqual(strategy.account_double_sl_pending(), D("0"))
        state.cycle_attempt = 2
        strategy.begin_continuation(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("142"))
        strategy.confirm_continuation_fills(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("147"))

    def test_continuation_spread_uses_actual_pair_size_without_target_again(self):
        cfg = self.settings(sizes=(D("20"),) * 9, stops=(D("4"),) * 9)
        strategy, state = self.begin(cfg)
        state.general_recovery = state.recovery = D("142")
        state.cycle_attempt = 2
        strategy.begin_continuation(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("142"))
        strategy.confirm_continuation_fills(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("152"))
        self.assertEqual(state.target_value, D("6"))
        self.assertEqual((state.long.take_profit, state.short.take_profit),
                         (D("4012.10"), D("3988.40")))

    def test_scenario_eight_to_nine_accounts_pending_and_trigger_only(self):
        strategy, state = self.begin(self.settings(sizes=(D("20"),) * 9, stops=(D("4"),) * 9))
        state.scenario = 8
        state.general_recovery = state.recovery = D("102")
        state.short.open = True
        state.short.stop_distance = D("4")
        state.short.stop = D("4004")
        strategy.stopped("SELL", D("4004"), "sell-sl-8")
        self.assertEqual(state.general_recovery, D("182"))
        strategy.reopened("SELL", D("3999.90"), "sell-9", "sell-open-9")
        self.assertEqual(state.general_recovery, D("184"))
        self.assertEqual((state.scenario, state.phase), (9, "SCENARIO_9_CLOSING"))

    def test_restart_preserves_pending_and_idempotent_reopen(self):
        strategy, state = self.begin()
        strategy.stopped("BUY", D("3999.40"), "buy-sl")
        with tempfile.NamedTemporaryFile() as file:
            state.save(file.name)
            restored = CycleState.load(file.name)
        restored_strategy = Strategy(strategy.cfg, restored)
        restored_strategy.reopened("BUY", D("4000.60"), "buy-2", "open-2")
        restored_strategy.reopened("BUY", D("4000.60"), "buy-2", "open-2")
        self.assertEqual(restored.general_recovery, D("20"))
        self.assertEqual(restored.scenario, 2)

    def test_zero_general_recovery_valid_but_zero_size_rejected(self):
        state = CycleState(general_recovery=D("0"), recovery_model_version=3)
        strategy = Strategy(self.settings(), state)
        state.long = Leg("BUY", D("1"), D("1"), size=D("0"), stop_distance=D("1"))
        state.short = Leg("SELL", D("1"), D("1"), size=D("10"), stop_distance=D("1"))
        with self.assertRaisesRegex(RuntimeError, "size"):
            strategy.refresh_targets()

    def test_profit_override_fixes_target_value_once(self):
        strategy, state = self.begin()
        state.reset()
        state.profit_override = D("0.40")
        state.profit_override_remaining = 200
        strategy.begin(D("4000.50"), D("4000.00"))
        strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
        self.assertEqual((state.cycle_target_profit, state.target_value), (D("0.40"), D("4")))
        state.cycle_attempt = 2
        strategy.begin_continuation(D("4001"), D("4000"))
        self.assertEqual(state.target_value, D("4"))

    def test_continuation_attempt_result_is_incremental_not_full_cycle_again(self):
        strategy, state = self.begin()
        state.cycle_id = 7
        state.cycle_attempt = 2
        state.active_attempt_id = 2
        state.attempt_history = [{"attempt_id": 1, "cycle_id": 7, "cycle_attempt": 1,
                                  "status": "DOUBLE_SL_CONTINUATION", "result": "-20"}]
        state.attempt_result_total = D("-20")
        state.realized_loss_money = D("30")
        state.cycle_attempt_start_loss_money = D("20")
        state.long.current_entry = D("100")
        state.long.size = D("10")
        bot = Bot.__new__(Bot)
        bot.state, bot.strategy, bot.cfg = state, strategy, strategy.cfg
        bot.continuation = Mock()
        bot.continuation.release = Mock()
        bot._store_report = Mock()
        bot._send_report = Mock()
        with tempfile.NamedTemporaryFile() as file:
            bot.cfg = Settings(
                state_file=file.name, size=D("10"), stop_distance=D("1"),
                scenario_sizes=(D("10"),) * 9, scenario_stop_distances=(D("1"),) * 9,
            )
            strategy.cfg = bot.cfg
            bot._complete_cycle("BUY", D("105"))
        self.assertEqual(state.net_cycle_money, D("20"))
        self.assertEqual(state.attempt_history, [])
        self.assertIsNotNone(state.completed_cycle_report)
        self.assertEqual(state.attempt_result_total, D("20"))

    def test_legacy_active_state_is_blocked_without_guessing(self):
        state = CycleState(active=True, recovery_model_version=1, recovery=D("9.5"))
        bot = Bot.__new__(Bot)
        bot.state = state
        with tempfile.NamedTemporaryFile() as file:
            bot.cfg = Settings(
                state_file=file.name, size=D("10"), stop_distance=D("1"),
                scenario_sizes=(D("10"),) * 9, scenario_stop_distances=(D("1"),) * 9,
            )
            bot.strategy = Strategy(bot.cfg, state)
            with self.assertRaisesRegex(RuntimeError, "прежнюю Recovery"):
                bot._migrate_recovery_model()
            restored = CycleState.load(file.name)
        self.assertTrue(restored.manual)
        self.assertEqual(restored.recovery, D("9.5"))
        self.assertEqual(restored.recovery_model_version, 1)

class GeneralRecoveryIntegrationFixTest(unittest.TestCase):
    def cfg(self, sizes=None, stops=None):
        return Settings(
            size=D("10"), target_profit=D("0.30"), stop_distance=D("1"),
            scenario_sizes=sizes or (D("10"),) * 9,
            scenario_stop_distances=stops or (D("1"), D("3")) + (D("4"),) * 7,
        )

    def active(self, cfg=None):
        state = CycleState(cycle_id=90, cycle_attempt=1)
        strategy = Strategy(cfg or self.cfg(), state)
        strategy.begin(D("4000.50"), D("4000.00"))
        strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
        return strategy, state

    def test_begin_continuation_and_unformed_attempts_do_not_add_projected_spread(self):
        strategy, state = self.active()
        state.general_recovery = D("142")
        state.cycle_attempt = 2
        strategy.begin_continuation(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("142"))
        state.long.current_entry = D("4000.55")  # only BUY confirmed
        state.long.entry_confirmation = "positions"
        self.assertEqual(state.general_recovery, D("142"))
        state.cycle_attempt = 3
        strategy.begin_continuation(D("4010.50"), D("4010.00"))
        self.assertEqual(state.general_recovery, D("142"))

    def test_continuation_actual_pair_adds_spread_once(self):
        strategy, state = self.active(self.cfg(sizes=(D("20"),) * 9))
        state.general_recovery = D("142")
        state.cycle_attempt = 2
        strategy.begin_continuation(D("3999"), D("3998"))
        state.long.size = state.short.size = D("20")
        strategy.confirm_continuation_fills(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("152"))
        strategy.confirm_continuation_fills(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, D("152"))
        event = next(item for item in state.recovery_events
                     if item["key"] == "continuation-pair:90:2")
        self.assertEqual((event["spread_distance"], event["size"], event["amount"]),
                         ("0.50", "20", "10.00"))

    def test_initial_pair_uses_broker_actual_size(self):
        strategy = Strategy(self.cfg(), CycleState(cycle_id=1, cycle_attempt=1))
        strategy.begin(D("4000.50"), D("4000.00"))
        strategy.state.long.size = strategy.state.short.size = D("12")
        strategy.state.long.size_confirmation = strategy.state.short.size_confirmation = "positions"
        strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
        state = strategy.state
        self.assertEqual((state.initial_position_size, state.target_value,
                          state.general_recovery), (D("12"), D("3.60"), D("9.60")))

    def test_unequal_pair_sizes_are_safe_and_do_not_change_general_recovery(self):
        strategy, state = self.active()
        before = state.general_recovery
        state.cycle_attempt = 2
        strategy.begin_continuation(D("4000.50"), D("4000.00"))
        state.long.size, state.short.size = D("20"), D("19")
        with self.assertRaisesRegex(RuntimeError, "sizes differ"):
            strategy.confirm_continuation_fills(D("4000.50"), D("4000.00"))
        self.assertEqual(state.general_recovery, before)
        self.assertFalse(any(item["key"] == "continuation-pair:90:2"
                             for item in state.recovery_events))

    def _protection_race(self, direction, new_confirmed):
        strategy, state = self.active()
        closed = state.short if direction == "SELL" else state.long
        survivor = state.long if direction == "SELL" else state.short
        closed.deal_id = direction.lower()
        survivor.deal_id = "survivor"
        old_stop = closed.current_entry + D("1") if direction == "SELL" else closed.current_entry - D("1")
        closed.confirmed_stop = old_stop
        closed.confirmed_stop_distance = D("1")
        closed.protection_readback = "ПОДТВЕРЖДЕНО"
        # Trigger on the other side advances desired D for both legs to 3.
        strategy.stopped(survivor.direction, survivor.stop, "other-stop")
        strategy.reopened(survivor.direction, survivor.original_trigger_level,
                          "other-new", "other-open")
        self.assertEqual(closed.stop_distance, D("3"))
        desired_stop = closed.stop
        closed.protection_sent_stop = desired_stop
        closed.protection_readback = "ожидается"
        closed.protection_confirmation = "ACCEPTED" if new_confirmed else "ожидается"
        closed.confirmation_stop = desired_stop if new_confirmed else None
        fill = desired_stop if new_confirmed else old_stop
        strategy.stopped(direction, fill, f"{direction}-race-stop")
        return state.pending_recovery[-1]

    def test_sell_old_confirmed_d_wins_race_against_unconfirmed_desired_d(self):
        pending = self._protection_race("SELL", False)
        self.assertEqual((pending["stop_distance"], pending["desired_stop_distance"],
                          pending["pending_d_value"], pending["stop_source"]),
                         ("1.00", "3", "10.00", "positions_readback"))

    def test_buy_old_confirmed_d_wins_race_against_unconfirmed_desired_d(self):
        pending = self._protection_race("BUY", False)
        self.assertEqual((pending["stop_distance"], pending["pending_d_value"]),
                         ("1.00", "10.00"))

    def test_new_confirmation_changes_effective_pending_d_before_sl(self):
        pending = self._protection_race("SELL", True)
        self.assertEqual((pending["stop_distance"], pending["pending_d_value"],
                          pending["stop_source"]),
                         ("3.00", "30.00", "confirmation"))

    def test_reporting_uses_general_not_legacy_leg_recovery(self):
        leg = Leg("SELL", D("4000"), D("4000"), size=D("20"), stop_distance=D("4"),
                  recovery=D("0"))
        text = leg_details(leg, general_recovery=D("102"), scenario=5)
        self.assertIn("recovery_distance=1.1", text)
        self.assertNotIn("recovery_distance=0", text)

    def test_reporting_continuation_does_not_claim_initial_formula(self):
        strategy, state = self.active(self.cfg(sizes=(D("20"),) * 9))
        state.general_recovery = D("142"); state.cycle_attempt = 2
        before = recovery_snapshot(state)
        strategy.begin_continuation(D("4000.5"), D("4000"))
        strategy.confirm_continuation_fills(D("4000.5"), D("4000"))
        text = recovery_change_text(state, before, event="continuation pair", direction="BUY")
        self.assertIn("ДО=142", text); self.assertIn("ПОСЛЕ=152.0", text)
        self.assertNotIn("initial spread", text)

    def test_full_scenario_one_through_eight_and_non_alternating_sequence(self):
        cfg = self.cfg(
            sizes=(D("10"), D("10"), D("10"), D("10"), D("20"), D("20"), D("20"), D("20"), D("20")),
            stops=(D("1"), D("1.5"), D("2"), D("3"), D("4"), D("4"), D("4"), D("4"), D("4")),
        )
        strategy, state = self.active(cfg)
        directions = ("SELL", "SELL", "SELL", "BUY", "BUY", "SELL", "BUY")
        for expected_scenario, direction in enumerate(directions, 2):
            leg = state.short if direction == "SELL" else state.long
            survivor = state.long if direction == "SELL" else state.short
            anchor, survivor_entry, before = leg.original_trigger_level, survivor.current_entry, state.general_recovery
            old_size, old_d = leg.size, leg.stop_distance
            sl_fill = leg.stop + (D("0.10") if direction == "SELL" else D("-0.10"))
            strategy.stopped(direction, sl_fill, f"e2e-stop-{expected_scenario}")
            pending = state.pending_recovery[-1]
            self.assertEqual(D(pending["pending_d_value"]), old_size * old_d)
            fill = anchor + (D("-0.10") if direction == "SELL" else D("0.10"))
            strategy.reopened(direction, fill, f"deal-{expected_scenario}", f"e2e-open-{expected_scenario}")
            self.assertEqual(state.scenario, expected_scenario)
            self.assertEqual(leg.original_trigger_level, anchor)
            self.assertEqual(leg.current_entry, fill)
            self.assertEqual(survivor.current_entry, survivor_entry)
            self.assertGreater(state.general_recovery, before)
            self.assertTrue(pending["d_accounted"])
            self.assertEqual(leg.stop_distance, cfg.stop_for(expected_scenario))
            self.assertEqual(survivor.stop_distance, cfg.stop_for(expected_scenario))
            self.assertEqual(leg.take_profit,
                             target_for(direction, fill, leg.stop_distance,
                                        remaining_recovery_distance(
                                            state.general_recovery, leg.size,
                                            leg.stop_distance)))
        self.assertEqual(state.scenario, 8)
        self.assertEqual(directions[:5], ("SELL", "SELL", "SELL", "BUY", "BUY"))

    def test_named_json_is_preserved_after_sqlite_becomes_authoritative(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bot_state.json"
            state = CycleState(general_recovery=D("12")); state.save(str(path))
            self.assertFalse(path.exists())
            self.assertTrue(database_path(path).exists())
            original = b'{"user":"state"}\n'; path.write_bytes(original)
            CycleState(general_recovery=D("99")).save(str(path))
            self.assertEqual(path.read_bytes(), original)
            self.assertEqual(CycleState.load(str(path)).general_recovery, D("99"))


class GeneralRecoveryV3AcceptanceTest(unittest.TestCase):
    SIZES = tuple(map(D, ("10", "10", "10", "10", "20", "20", "20", "20", "20")))
    DISTANCES = tuple(map(D, ("1", "1.5", "2", "3", "4", "4", "4", "4", "4")))
    DIRECTIONS = ("SELL", "SELL", "SELL", "BUY", "BUY", "SELL", "BUY", "SELL")
    SEQUENCE = tuple(map(D, ("8", "9", "20", "36", "37", "58", "59", "90", "92",
                              "174", "176", "217", "219", "301", "303", "385", "387")))
    TP_LEVELS = tuple(map(D, ("4002.40", "4004.10", "4006.30", "3990.90",
                               "3982.50", "4011.45", "3984.85", "4019.85")))
    RESULTS = tuple(map(D, ("8", "9", "10", "11", "13", "15", "17", "19")))

    def cfg(self):
        return Settings(
            size=D("10"), stop_distance=D("1"), target_profit=D("0.30"),
            scenario_sizes=self.SIZES, scenario_stop_distances=self.DISTANCES,
        )

    def begin(self):
        state = CycleState(cycle_id=301, cycle_attempt=1)
        strategy = Strategy(self.cfg(), state)
        strategy.begin(D("4000.50"), D("4000.00"))
        strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
        return strategy, state

    @staticmethod
    def sl_fill(leg):
        return leg.stop + (D("-0.10") if leg.direction == "BUY" else D("0.10"))

    @staticmethod
    def reopen_fill(leg):
        return leg.original_trigger_level + (
            D("0.10") if leg.direction == "BUY" else D("-0.10")
        )

    def test_model_version_three_and_initial_actual_recovery(self):
        strategy, state = self.begin()
        self.assertEqual(strategy.MODEL_VERSION, 3)
        self.assertEqual(state.recovery_model_version, 3)
        self.assertEqual((state.entry_spread, state.target_value, state.general_recovery),
                         (D("0.50"), D("3.00"), D("8.00")))

    def test_full_decimal_sequence_sizes_distances_and_immutable_anchors(self):
        strategy, state = self.begin()
        actual = [state.general_recovery]
        anchors = (state.long.original_trigger_level, state.short.original_trigger_level)
        for next_scenario, direction in enumerate(self.DIRECTIONS, 2):
            leg = state.long if direction == "BUY" else state.short
            survivor = state.short if direction == "BUY" else state.long
            survivor_size, survivor_entry = survivor.size, survivor.current_entry
            strategy.stopped(direction, self.sl_fill(leg), f"v3-sl-{state.scenario}-{direction}")
            actual.append(state.general_recovery)
            closure = state.pending_recovery[-1]
            self.assertEqual(closure["scenario_at_close"], next_scenario - 1)
            self.assertEqual(closure["d_accounted"], next_scenario > 2)
            self.assertFalse(closure["reentry_accounted"])
            strategy.reopened(
                direction, self.reopen_fill(leg), f"v3-deal-{next_scenario}-{direction}",
                f"v3-open-{next_scenario}-{direction}",
            )
            actual.append(state.general_recovery)
            self.assertEqual((state.long.original_trigger_level,
                              state.short.original_trigger_level), anchors)
            self.assertEqual((survivor.size, survivor.current_entry),
                             (survivor_size, survivor_entry))
            self.assertEqual(state.scenario, next_scenario)
        self.assertEqual(tuple(actual), self.SEQUENCE)
        self.assertEqual(state.short.size, D("20"))
        self.assertEqual((state.scenario, state.phase), (9, "SCENARIO_9_CLOSING"))

    def test_independent_tp_branches_and_cycle_results(self):
        import copy
        strategy, state = self.begin()
        for index, direction in enumerate(self.DIRECTIONS):
            leg = state.long if direction == "BUY" else state.short
            strategy.stopped(direction, self.sl_fill(leg), f"branch-sl-{state.scenario}-{direction}")
            survivor = state.short if direction == "BUY" else state.long
            self.assertEqual(survivor.take_profit, self.TP_LEVELS[index])
            branch = copy.deepcopy(state)
            Strategy(self.cfg(), branch).complete(survivor.direction, survivor.take_profit)
            self.assertEqual(branch.net_cycle_money, self.RESULTS[index])
            if index < len(self.DIRECTIONS) - 1:
                strategy.reopened(
                    direction, self.reopen_fill(leg), f"branch-deal-{index}",
                    f"branch-open-{index}",
                )

    def test_mirror_s5_and_s6_branches_keep_thirteen_and_fifteen(self):
        import copy
        for prefix, stopped_direction, expected in (
            (("BUY", "BUY", "BUY", "SELL"), "SELL", D("13")),
            (("BUY", "BUY", "BUY", "SELL", "SELL"), "BUY", D("15")),
        ):
            strategy, state = self.begin()
            for index, direction in enumerate(prefix, 2):
                leg = state.long if direction == "BUY" else state.short
                strategy.stopped(direction, self.sl_fill(leg), f"mirror-sl-{index}")
                strategy.reopened(
                    direction, self.reopen_fill(leg), f"mirror-deal-{index}",
                    f"mirror-open-{index}",
                )
            leg = state.long if stopped_direction == "BUY" else state.short
            strategy.stopped(stopped_direction, self.sl_fill(leg), "mirror-final-sl")
            survivor = state.short if stopped_direction == "BUY" else state.long
            branch = copy.deepcopy(state)
            Strategy(self.cfg(), branch).complete(survivor.direction, survivor.take_profit)
            self.assertEqual(branch.net_cycle_money, expected)
            self.assertEqual(
                abs(survivor.take_profit - survivor.current_entry) * survivor.size,
                max(state.general_recovery, survivor.stop_distance * survivor.size),
            )

    def test_s1_sl_pending_then_reentry_and_tp_before_trigger(self):
        import copy
        strategy, state = self.begin()
        strategy.stopped("SELL", D("4001.10"), "s1-sell-sl")
        closure = state.pending_recovery[-1]
        self.assertEqual(state.general_recovery, D("9"))
        self.assertEqual((D(closure["d_value"]), closure["d_accounted"],
                          closure["reentry_accounted"]), (D("10"), False, False))
        tp_branch = copy.deepcopy(state)
        Strategy(self.cfg(), tp_branch).complete("BUY", tp_branch.long.take_profit)
        self.assertEqual(tp_branch.general_recovery, D("9"))
        self.assertFalse(tp_branch.pending_recovery[-1]["d_accounted"])
        strategy.reopened("SELL", D("3999.90"), "s2-sell", "s1-linked-open")
        self.assertEqual(state.general_recovery, D("20"))
        self.assertTrue(closure["d_accounted"] and closure["reentry_accounted"])

    def test_s2_sl_accounts_distance_now_and_reentry_only_slippage(self):
        strategy, state = self.begin()
        strategy.stopped("SELL", D("4001.10"), "s1-sl")
        strategy.reopened("SELL", D("3999.90"), "s2-sell", "s2-open")
        strategy.stopped("SELL", self.sl_fill(state.short), "s2-sl")
        closure = state.pending_recovery[-1]
        self.assertEqual(state.general_recovery, D("36"))
        self.assertEqual((D(closure["d_value"]), closure["d_accounted"],
                          closure["reentry_accounted"]), (D("15"), True, False))
        events = len(state.recovery_events)
        strategy.reopened("SELL", D("3999.90"), "s3-sell", "s3-open")
        self.assertEqual(state.general_recovery, D("37"))
        self.assertTrue(closure["reentry_accounted"])
        self.assertEqual(len(state.recovery_events), events + 1)

    def test_general_greater_equal_and_less_than_base(self):
        strategy, state = self.begin()
        state.scenario = 5
        state.general_recovery = D("60")
        state.long.size, state.short.size = D("10"), D("20")
        state.long.stop_distance = state.short.stop_distance = D("4")
        before = (state.general_recovery, list(state.recovery_events), state.scenario)
        strategy.refresh_targets()
        self.assertEqual(state.long.take_profit - state.long.current_entry, D("6"))
        self.assertEqual(state.short.current_entry - state.short.take_profit, D("4"))
        self.assertEqual((D("6") * D("10"), D("4") * D("20")), (D("60"), D("80")))
        self.assertEqual((state.general_recovery, state.recovery_events, state.scenario), before)
        state.general_recovery = D("40")
        strategy.refresh_targets()
        self.assertEqual(state.long.take_profit - state.long.current_entry, D("4"))

    def test_projection_is_linked_pure_and_does_not_readd_s2_distance(self):
        strategy, state = self.begin()
        strategy.stopped("SELL", D("4001.10"), "project-s1")
        closure = state.pending_recovery[-1]
        before = (state.general_recovery, list(state.recovery_events), dict(closure), state.scenario)
        size, distance, recovery = strategy.projected_reopen("SELL")
        self.assertEqual((size, distance, recovery), (D("10"), D("1.5"), D("0.4")))
        self.assertEqual((state.general_recovery, state.recovery_events, closure, state.scenario), before)
        strategy.reopened("SELL", D("3999.90"), "project-s2", "project-open")
        strategy.stopped("SELL", D("4001.60"), "project-s2-sl")
        closure = state.pending_recovery[-1]
        before_general = state.general_recovery
        strategy.projected_reopen("SELL")
        self.assertTrue(closure["d_accounted"])
        self.assertEqual(state.general_recovery, before_general)

    def test_duplicate_sl_and_normal_reentries_are_idempotent(self):
        strategy, state = self.begin()
        strategy.stopped("SELL", D("4001.10"), "dup-s1-sl")
        strategy.reopened("SELL", D("3999.90"), "dup-s2", "dup-s1-open")
        strategy.stopped("SELL", D("4001.60"), "dup-s2-sl")
        snapshot = dict(state.pending_recovery[-1])
        before = (state.general_recovery, len(state.recovery_events), state.scenario)
        strategy.stopped("SELL", D("4001.60"), "dup-s2-sl")
        self.assertEqual((state.general_recovery, len(state.recovery_events), state.scenario), before)
        self.assertEqual(state.pending_recovery[-1], snapshot)
        strategy.reopened("SELL", D("3999.90"), "dup-s3", "dup-s2-open")
        after = (state.general_recovery, len(state.recovery_events), state.scenario)
        strategy.reopened("SELL", D("3999.90"), "dup-s3", "dup-s2-open")
        self.assertEqual((state.general_recovery, len(state.recovery_events), state.scenario), after)

    def test_restart_s1_and_s2_pending_reentry_contracts(self):
        strategy, state = self.begin()
        strategy.stopped("SELL", D("4001.10"), "restart-s1")
        with tempfile.NamedTemporaryFile() as file:
            state.save(file.name); restored = CycleState.load(file.name)
        Strategy(self.cfg(), restored).reopened(
            "SELL", D("3999.90"), "restart-s2", "restart-s1-open"
        )
        self.assertEqual(restored.general_recovery, D("20"))
        restored_strategy = Strategy(self.cfg(), restored)
        restored_strategy.stopped("SELL", self.sl_fill(restored.short), "restart-s2-sl")
        self.assertEqual(restored.general_recovery, D("36"))
        with tempfile.NamedTemporaryFile() as file:
            restored.save(file.name); again = CycleState.load(file.name)
        Strategy(self.cfg(), again).reopened(
            "SELL", D("3999.90"), "restart-s3", "restart-s2-open"
        )
        self.assertEqual(again.general_recovery, D("37"))

    def test_mandatory_s2_old_effective_stop_race_is_twenty_to_thirty_one(self):
        strategy, state = self.begin()
        state.scenario = 2
        state.general_recovery = D("20")
        leg = state.long
        leg.confirmed_stop = D("3999.50")
        leg.protection_readback = "ПОДТВЕРЖДЕНО"
        leg.stop_distance = D("1.5")
        leg.stop = D("3999.00")
        strategy.stopped(
            "BUY", D("3999.40"), "old-stop-after-reentry", scenario_at_close=2,
            broker_execution_time="2026-09-21T00:00:02+00:00",
        )
        closure = state.pending_recovery[-1]
        self.assertEqual(state.general_recovery, D("31"))
        self.assertEqual((closure["stop_distance"], closure["d_value"],
                          closure["d_accounted"]), ("1.00", "10.00", True))

    def test_late_s1_closure_projection_restart_reentry_and_duplicate(self):
        strategy, state = self.begin()
        strategy.stopped("SELL", D("4001.10"), "late-sell-s1")
        strategy.reopened("SELL", D("3999.90"), "late-sell-s2", "late-sell-open")
        self.assertEqual(state.general_recovery, D("20"))
        buy = state.long
        buy.confirmed_stop = D("3999.50")
        buy.protection_readback = "ПОДТВЕРЖДЕНО"
        strategy.stopped(
            "BUY", D("3999.40"), "late-buy-s1", scenario_at_close=1,
            broker_execution_time="2026-09-21T00:00:01+00:00",
        )
        closure = state.pending_recovery[-1]
        self.assertEqual(state.general_recovery, D("21"))
        self.assertFalse(closure["d_accounted"] or closure["reentry_accounted"])
        projected_general = state.general_recovery + D(closure["d_value"])
        self.assertEqual(projected_general, D("31"))
        before = (state.general_recovery, dict(closure), len(state.recovery_events), state.scenario)
        strategy.projected_reopen("BUY")
        self.assertEqual((state.general_recovery, closure, len(state.recovery_events), state.scenario), before)
        with tempfile.NamedTemporaryFile() as file:
            state.save(file.name); restored = CycleState.load(file.name)
        restored_strategy = Strategy(self.cfg(), restored)
        restored_strategy.reopened("BUY", D("4000.60"), "late-buy-s3", "late-buy-open")
        self.assertEqual(restored.general_recovery, D("32"))
        after = (restored.general_recovery, len(restored.recovery_events), restored.scenario)
        restored_strategy.reopened("BUY", D("4000.60"), "late-buy-s3", "late-buy-open")
        self.assertEqual((restored.general_recovery, len(restored.recovery_events),
                          restored.scenario), after)

    def test_double_sl_s1_transfers_pending_but_s2_d_is_not_duplicated(self):
        strategy, state = self.begin()
        strategy.stopped("BUY", D("3999.40"), "double-s1-buy")
        strategy.stopped("SELL", D("4001.10"), "double-s1-sell")
        self.assertEqual(strategy.account_double_sl_pending(), D("20"))
        self.assertEqual(strategy.account_double_sl_pending(), D("0"))
        strategy, state = self.begin()
        state.scenario = 2; state.general_recovery = D("20")
        strategy._targets_from_entries()
        strategy.stopped("BUY", self.sl_fill(state.long), "double-s2-buy")
        strategy.stopped("SELL", self.sl_fill(state.short), "double-s2-sell")
        before = state.general_recovery
        self.assertEqual(strategy.account_double_sl_pending(), D("0"))
        self.assertEqual(state.general_recovery, before)
        self.assertTrue(all(not item["reentry_accounted"] for item in state.pending_recovery))

    def test_continuation_pair_is_actual_once_target_unchanged_and_new_anchors(self):
        strategy, state = self.begin()
        state.scenario = 6; state.cycle_attempt = 2; state.general_recovery = D("176")
        target = state.target_value
        strategy.begin_continuation(D("4100.50"), D("4100.00"))
        self.assertEqual(state.general_recovery, D("176"))
        state.long.current_entry = D("4100.55")
        self.assertEqual(state.general_recovery, D("176"))
        strategy.confirm_continuation_fills(D("4100.50"), D("4100.00"))
        self.assertEqual((state.general_recovery, state.target_value), (D("186"), target))
        self.assertEqual((state.long.original_trigger_level, state.short.original_trigger_level),
                         (D("4100.50"), D("4100.00")))
        strategy.confirm_continuation_fills(D("4100.50"), D("4100.00"))
        self.assertEqual(state.general_recovery, D("186"))

    def test_reporting_distances_for_s1_s2_and_s9(self):
        leg = Leg("BUY", D("100"), D("100"), size=D("10"), stop_distance=D("4"))
        self.assertIn("recovery_distance=6", leg_details(
            leg, general_recovery=D("60"), scenario=1
        ))
        self.assertIn("recovery_distance=2", leg_details(
            leg, general_recovery=D("60"), scenario=5
        ))
        self.assertIn("ordinary Recovery TP отсутствует", leg_details(
            leg, general_recovery=D("60"), scenario=9
        ))

    def test_scenario_nine_actual_pnl_is_independent_from_general(self):
        for buy_close, expected in ((D("4000.00"), D("-387")),
                                    (D("4000.10"), D("-385"))):
            general = D("387")
            actual = D("-366")
            actual += (buy_close - D("4000.60")) * D("20")
            actual += (D("3999.90") - D("4000.35")) * D("20")
            self.assertEqual(general, D("387"))
            self.assertEqual(actual, expected)

    def test_inactive_v2_can_start_v3_but_active_v2_is_blocked(self):
        inactive = CycleState(recovery_model_version=2)
        Strategy(self.cfg(), inactive).begin(D("4000.50"), D("4000.00"))
        self.assertEqual(inactive.recovery_model_version, 3)
        active = CycleState(active=True, recovery_model_version=2)
        with tempfile.TemporaryDirectory() as directory:
            bot = Bot.__new__(Bot); bot.state = active; bot.cfg = self.cfg()
            bot.strategy = Strategy(bot.cfg, active)
            bot.cfg = Settings(**{
                **bot.cfg.__dict__, "state_file": str(Path(directory) / "state.json")
            })
            bot.strategy.cfg = bot.cfg
            with self.assertRaisesRegex(RuntimeError, "прежнюю Recovery"):
                bot._migrate_recovery_model()


class BrokerEvidenceRegressionTest(unittest.TestCase):
    @staticmethod
    def recovery_bot(state_path: str):
        cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            state_file=state_path, scenario_sizes=(D("10"),) * 9,
            scenario_stop_distances=(D("1"),) * 9, target_profit=D("0.3"),
        )
        bot = Bot.__new__(Bot); bot.cfg = cfg; bot.capital = Mock(); bot.telegram = Mock()
        bot.state = CycleState(cycle_id=1, cycle_attempt=1, active_attempt_id=1)
        bot.strategy = Strategy(cfg, bot.state); bot.execution_policy = ExecutionPolicy()
        bot._missing_exit_since = None; bot.continuation = CycleContinuation(bot)
        bot.strategy.begin(D("4000.50"), D("4000.00"))
        bot.strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
        bot.state.long.deal_id, bot.state.short.deal_id = "buy-old", "sell-old"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        bot.strategy.stopped("SELL", D("4001.10"), "sell-s1")
        bot.strategy.reopened("SELL", D("3999.90"), "sell-new", "sell-reentry",
                              actual_size=D("10"))
        return bot

    @staticmethod
    def chronology_activity(open_time="2026-09-21T00:00:02.000Z",
                            close_time="2026-09-21T00:00:01.000Z"):
        return [
            {"dateUTC": open_time, "dealId": "sell-new", "source": "USER",
             "type": "POSITION", "status": "ACCEPTED",
             "details": {"workingOrderId": "sell-trigger", "direction": "SELL",
                         "level": 3999.90, "size": 10}},
            {"dateUTC": close_time, "dealId": "buy-old", "source": "SL",
             "type": "POSITION", "status": "ACCEPTED", "level": 3999.40,
             "details": {"level": 3999.40, "size": 10, "stopLevel": 3999.50}},
        ]

    def test_late_normal_tick_preserves_open_scenario_and_case_a_ledger(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.recovery_bot(str(Path(directory) / "state.json"))
            self.assertEqual(bot.state.general_recovery, D("20"))
            activity = self.chronology_activity()
            bot.capital.activity.return_value = activity
            bot.capital.positions.return_value = [{
                "position": {"dealId": "sell-new", "direction": "SELL", "level": 3999.90,
                             "size": 10, "stopLevel": 4000.90, "profitLevel": 3997.80},
                "market": {"epic": "GOLD"},
            }]
            bot._apply_protection = Mock(return_value=True)
            bot._create_trigger = Mock()
            bot._tick_cycle()
            closure = next(item for item in bot.state.pending_recovery
                           if item["deal_id"] == "buy-old")
            self.assertEqual((closure["scenario_at_close"], closure["d_accounted"]), (1, False))
            self.assertEqual(bot.state.general_recovery, D("21"))
            before = (bot.state.general_recovery, dict(closure), bot.state.scenario)
            self.assertEqual(bot.strategy.projected_reopen("BUY"), (D("10"), D("1"), D("2.1")))
            self.assertEqual((bot.state.general_recovery, closure, bot.state.scenario), before)
            bot.state.save(bot.cfg.state_file)
            restored = CycleState.load(bot.cfg.state_file)
            Strategy(bot.cfg, restored).reopened(
                "BUY", D("4000.60"), "buy-new", "buy-reentry", actual_size=D("10")
            )
            self.assertEqual(restored.general_recovery, D("32"))
            Strategy(bot.cfg, restored).reopened(
                "BUY", D("4000.60"), "buy-new", "buy-reentry", actual_size=D("10")
            )
            self.assertEqual(restored.general_recovery, D("32"))

    def test_late_stop_is_identical_in_startup_and_continuation_handlers(self):
        for owner in ("startup", "continuation"):
            with self.subTest(owner=owner), tempfile.TemporaryDirectory() as directory:
                bot = self.recovery_bot(str(Path(directory) / "state.json"))
                activity = self.chronology_activity()
                bot.capital.activity.return_value = activity
                position = {"dealId": "sell-new", "direction": "SELL", "level": 3999.90,
                            "size": 10, "stopLevel": 4000.90, "profitLevel": 3997.80}
                bot.capital.positions.return_value = [
                    {"position": position, "market": {"epic": "GOLD"}}
                ]
                bot._apply_protection = Mock(return_value=True); bot._create_trigger = Mock()
                if owner == "startup":
                    bot._migrate_recovery_model = Mock()
                    bot._recover_active_cycle({"sell-new": position}, [])
                else:
                    bot.state.continuation_managed = True
                    bot.state.continuation_stage = "ACTIVE"
                    bot.continuation.handle_active_scenario()
                closure = next(item for item in bot.state.pending_recovery
                               if item["deal_id"] == "buy-old")
                self.assertEqual((closure["scenario_at_close"], closure["d_accounted"],
                                  bot.state.general_recovery), (1, False, D("21")))

    def test_fast_path_prefers_activity_open_over_later_position_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.recovery_bot(str(Path(directory) / "state.json"))
            # Rewind to the one-sided state immediately before SELL reentry accounting.
            state = CycleState(cycle_id=1, cycle_attempt=1, active_attempt_id=1)
            bot.state = state; bot.strategy = Strategy(bot.cfg, state)
            bot.strategy.begin(D("4000.50"), D("4000.00"))
            bot.strategy.confirm_initial_fills(D("4000.50"), D("4000.00"))
            state.long.deal_id, state.short.deal_id = "buy-old", "sell-old"
            state.remember_deal(state.long, 1); state.remember_deal(state.short, 1)
            stopped = bot.strategy.stopped("SELL", D("4001.10"), "sell-s1")
            stopped.trigger_id = "sell-trigger"
            state.pending_recovery[-1]["trigger_id"] = "sell-trigger"
            bot.capital.activity.return_value = self.chronology_activity(
                "2026-09-21T00:00:02.000Z", "2026-09-21T00:00:02.030Z"
            )
            bot._apply_protection = Mock(return_value=True); bot._create_trigger = Mock()
            candidate = {"dealId": "sell-new", "workingOrderId": "sell-trigger",
                         "direction": "SELL", "level": 3999.90, "size": 10,
                         "createdDateUTC": "2026-09-21T00:00:02.060Z"}
            self.assertTrue(bot._recover_trigger_fill_then_stop(
                {"sell-new": candidate}, state.long, stopped
            ))
            closure = next(item for item in state.pending_recovery
                           if item["deal_id"] == "buy-old")
            self.assertEqual((closure["scenario_at_close"], state.general_recovery), (2, D("31")))

    def test_attempt_281_working_order_execution_proves_reentry_before_sell_sl(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.recovery_bot(str(Path(directory) / "state.json"))
            bot.cfg = Settings(**{**bot.cfg.__dict__,
                                  "scenario_stop_distances": (D("1"),) + (D("2"),) * 8})
            state = CycleState(cycle_id=281, cycle_attempt=1, active_attempt_id=281)
            bot.state = state; bot.strategy = Strategy(bot.cfg, state)
            bot.strategy.begin(D("4340.18"), D("4339.40"))
            bot.strategy.confirm_initial_fills(D("4340.18"), D("4339.40"))
            state.long.deal_id, state.short.deal_id = "buy-old", "sell-old"
            state.remember_deal(state.long, 1); state.remember_deal(state.short, 1)
            stopped = bot.strategy.stopped("BUY", D("4339.08"), "buy-s1")
            stopped.trigger_id = "buy-order"
            state.pending_recovery[-1]["trigger_id"] = "buy-order"
            bot.capital.activity.return_value = [
                {"dateUTC": "2026-09-22T03:31:46.204Z", "dealId": "buy-order",
                 "type": "WORKING_ORDER", "status": "EXECUTED"},
                {"dateUTC": "2026-09-22T03:41:12.182Z", "dealId": "sell-old",
                 "type": "POSITION", "status": "ACCEPTED", "source": "SL",
                 "details": {"level": 4341.40, "size": 10}},
            ]
            candidate = {"dealId": "buy-new", "workingOrderId": "buy-order",
                         "direction": "BUY", "level": 4340.18, "size": 10,
                         "createdDateUTC": "2026-09-22T03:31:46.284Z"}
            bot._apply_protection = Mock(return_value=True); bot._create_trigger = Mock()
            self.assertTrue(bot._recover_trigger_fill_then_stop(
                {"buy-new": candidate}, state.short, stopped
            ))
            closure = next(item for item in state.pending_recovery
                           if item["deal_id"] == "sell-old")
            self.assertEqual((closure["scenario_at_close"], state.general_recovery,
                              state.scenario), (2, D("41.80"), 2))
            self.assertEqual((state.long.deal_id, state.long.current_entry, state.long.size),
                             ("buy-new", D("4340.18"), D("10")))

    def test_automatic_trigger_relinks_closure_and_fill_once(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.recovery_bot(str(Path(directory) / "state.json"))
            leg = bot.state.long
            # Use the unresolved BUY closure made by an explicit late S1 stop.
            bot.strategy.stopped("BUY", D("3999.40"), "buy-late", scenario_at_close=1)
            leg.trigger_id = "automatic-order"
            bot.state.pending_recovery[-1]["trigger_id"] = "automatic-order"
            closure = bot.state.pending_recovery[-1]
            self.assertEqual((leg.trigger_id, closure["trigger_id"]),
                             ("automatic-order", "automatic-order"))
            bot._apply_protection = Mock(return_value=True)
            candidate = {"dealId": "buy-new", "workingOrderId": "automatic-order",
                         "direction": "BUY", "level": 4000.60, "size": 10}
            before = bot.state.scenario
            bot._detect_trigger_fill({"buy-new": candidate})
            self.assertEqual((bot.state.scenario, leg.deal_id, leg.current_entry, leg.size),
                             (before + 1, "buy-new", D("4000.60"), D("10")))
            general = bot.state.general_recovery
            bot._detect_trigger_fill({"buy-new": candidate})
            self.assertEqual((bot.state.scenario, bot.state.general_recovery),
                             (before + 1, general))

    def test_previous_v3_closures_without_owner_do_not_shadow_continuation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.recovery_bot(path)
            old = {"close_key": "old", "deal_id": "old-buy", "direction": "BUY",
                   "d_value": "10", "pending_d_value": "10", "d_accounted": True,
                   "reentry_accounted": False, "reopen_event_id": ""}
            bot.state.pending_recovery.append(old)
            bot.state.deal_history.append({"deal_id": "old-buy", "cycle_id": 1,
                                           "cycle_attempt": 1, "scenario": 1})
            bot.state.cycle_attempt = 2
            bot.state.long = Leg("BUY", D("4100.5"), D("4100.5"), deal_id="new-buy",
                                 size=D("10"), stop_distance=D("1"), stop=D("4099.5"))
            bot.state.short = Leg("SELL", D("4100"), D("4100"), deal_id="new-sell",
                                  size=D("10"), stop_distance=D("1"), stop=D("4101"))
            bot.state.remember_deal(bot.state.long, bot.state.scenario)
            bot.strategy.stopped("BUY", D("4099.4"), "new-stop")
            bot.state.save(path)
            restored = CycleState.load(path); strategy = Strategy(bot.cfg, restored)
            current = strategy._pending_for("BUY")
            self.assertEqual(current["deal_id"], "new-buy")
            self.assertTrue(old["d_accounted"])

    def test_synthetic_event_identity_is_stable_across_indexes_and_reordering(self):
        first = {"dateUTC": "2026-09-21T10:00:00Z", "dealId": "a", "source": "SL",
                 "status": "ACCEPTED", "type": "POSITION", "details": {"level": 99}}
        second = {"dateUTC": "2026-09-21T10:00:01Z", "dealId": "b", "source": "USER",
                  "status": "ACCEPTED", "type": "POSITION", "details": {"level": 100}}
        self.assertEqual(normalize_event(first, 0).event_id, normalize_event(first, 99).event_id)
        original = {event.deal_id: event.event_id for event in normalize_events([first, second])}
        reordered = {event.deal_id: event.event_id for event in normalize_events([second, first])}
        self.assertEqual(original, reordered)
        self.assertNotEqual(original["a"], original["b"])
        self.assertEqual(normalize_events([second, first]), normalize_events([second, first]))

    @staticmethod
    def response(status, *, headers=None):
        response = Mock(status_code=status, ok=status < 400, content=b"{}", text="unauthorized")
        response.json.return_value = {}
        response.headers = headers or {}
        return response

    def test_explicit_401_refreshes_generation_and_retries_once(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        client.last_login = 10**20
        unauthorized = self.response(401)
        success = self.response(200)
        login = self.response(200, headers={"CST": "new-cst", "X-SECURITY-TOKEN": "new-sec"})
        client.http.request = Mock(side_effect=[unauthorized, success])
        client.http.post = Mock(return_value=login)
        self.assertEqual(client.request("PUT", "/positions/deal", json={}), {})
        self.assertEqual(client.http.request.call_count, 2)
        self.assertEqual(client.http.post.call_count, 1)
        self.assertEqual(client.session_generation, 1)
        self.assertEqual(client.streaming_tokens(), ("new-cst", "new-sec", 1))

    def test_second_401_is_an_error_without_another_retry(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        client.last_login = 10**20
        login = self.response(200, headers={"CST": "new-cst", "X-SECURITY-TOKEN": "new-sec"})
        client.http.request = Mock(side_effect=[self.response(401), self.response(401)])
        client.http.post = Mock(return_value=login)
        with self.assertRaises(CapitalError):
            client.request("POST", "/positions", json={})
        self.assertEqual(client.http.request.call_count, 2)
        self.assertEqual(client.http.post.call_count, 1)

    def test_401_retry_timeout_has_no_third_send_and_refresh_failure_stops(self):
        for second in (requests.ReadTimeout("retry unknown"),):
            client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
            client.last_login = 10**20
            client.http.request = Mock(side_effect=[self.response(401), second])
            client.http.post = Mock(return_value=self.response(200, headers={
                "CST": "new", "X-SECURITY-TOKEN": "new-sec",
            }))
            with self.assertRaises(CapitalError):
                client.request("DELETE", "/positions/deal")
            self.assertEqual(client.http.request.call_count, 2)
        failed = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        failed.last_login = 10**20
        failed.http.request = Mock(return_value=self.response(401))
        failed.http.post = Mock(return_value=self.response(401))
        with self.assertRaises(CapitalError):
            failed.request("GET", "/positions")
        self.assertEqual(failed.http.request.call_count, 1)

    def test_concurrent_failed_generation_refreshes_only_once(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        login = self.response(200, headers={"CST": "new-cst", "X-SECURITY-TOKEN": "new-sec"})
        client.http.post = Mock(return_value=login)
        barrier = __import__("threading").Barrier(3)
        errors = []
        def refresh():
            try:
                barrier.wait()
                client._refresh_failed_session(0)
            except Exception as exc:  # pragma: no cover - assertion reports the exception
                errors.append(exc)
        threads = [__import__("threading").Thread(target=refresh) for _ in range(2)]
        for thread in threads:
            thread.start()
        barrier.wait()
        for thread in threads:
            thread.join(1)
        self.assertFalse(errors)
        self.assertEqual(client.http.post.call_count, 1)
        self.assertEqual(client.session_generation, 1)

    def test_request_generation_is_bound_to_actual_token_headers(self):
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        client.last_login = 10**20
        client.http.headers.update({"CST": "old-cst", "X-SECURITY-TOKEN": "old-sec"})
        sent = []
        def request(method, url, **kwargs):
            sent.append(dict(kwargs["headers"]))
            if len(sent) == 1:
                # Another worker refreshes after this request was prepared/sent.
                client.http.headers.update({"CST": "new-cst", "X-SECURITY-TOKEN": "new-sec"})
                client.session_generation = 1
                return self.response(401)
            return self.response(200)
        client.http.request = Mock(side_effect=request)
        client.http.post = Mock()
        self.assertEqual(client.request("DELETE", "/positions/deal"), {})
        self.assertEqual(sent, [
            {"CST": "old-cst", "X-SECURITY-TOKEN": "old-sec"},
            {"CST": "new-cst", "X-SECURITY-TOKEN": "new-sec"},
        ])
        client.http.post.assert_not_called()

    def test_two_full_concurrent_401_requests_share_one_refresh(self):
        threading = __import__("threading")
        client = CapitalClient(Settings(api_key="key", identifier="id", password="password"))
        client.last_login = 10**20
        client.http.headers.update({"CST": "old-cst", "X-SECURITY-TOKEN": "old-sec"})
        barrier = threading.Barrier(2); local = threading.local(); sent = []
        lock = threading.Lock()
        def request(method, url, **kwargs):
            count = getattr(local, "count", 0); local.count = count + 1
            with lock:
                sent.append((count, dict(kwargs["headers"])))
            if count == 0:
                barrier.wait()
                return self.response(401)
            return self.response(200)
        client.http.request = Mock(side_effect=request)
        client.http.post = Mock(return_value=self.response(200, headers={
            "CST": "new-cst", "X-SECURITY-TOKEN": "new-sec",
        }))
        errors = []
        def run(method):
            try:
                client.request(method, "/positions", json={} if method != "GET" else None)
            except Exception as exc:
                errors.append(exc)
        threads = [threading.Thread(target=run, args=(method,))
                   for method in ("GET", "DELETE")]
        for thread in threads: thread.start()
        for thread in threads: thread.join(2)
        self.assertFalse(errors)
        self.assertEqual(client.http.post.call_count, 1)
        self.assertEqual(sum(1 for count, _ in sent if count == 0), 2)
        self.assertTrue(all(headers["CST"] == ("old-cst" if count == 0 else "new-cst")
                            for count, headers in sent))

    def test_pending_closure_requires_unambiguous_broker_linkage(self):
        state = CycleState(active=True, scenario=1, cycle_id=7, cycle_attempt=2)
        state.pending_recovery = [
            {"close_key": "old", "direction": "BUY", "deal_id": "old", "d_value": "10",
             "pending_d_value": "10", "d_accounted": False, "reentry_accounted": False,
             "trigger_id": "trigger-old", "cycle_id": 7, "cycle_attempt": 1},
            {"close_key": "a", "direction": "BUY", "deal_id": "a", "d_value": "10",
             "pending_d_value": "10", "d_accounted": False, "reentry_accounted": False,
             "trigger_id": "trigger-a", "cycle_id": 7, "cycle_attempt": 2},
            {"close_key": "b", "direction": "BUY", "deal_id": "b", "d_value": "20",
             "pending_d_value": "20", "d_accounted": False, "reentry_accounted": False,
             "trigger_id": "trigger-b", "cycle_id": 7, "cycle_attempt": 2},
        ]
        strategy = Strategy(Settings(scenario_sizes=(D("10"),) * 9,
                                     scenario_stop_distances=(D("1"),) * 9), state)
        with self.assertRaisesRegex(RuntimeError, "Ambiguous"):
            strategy._pending_for("BUY")
        self.assertEqual(strategy._pending_for("BUY", working_order_id="trigger-a")["close_key"], "a")
        with self.assertRaisesRegex(RuntimeError, "No broker-linked"):
            strategy._pending_for("BUY", working_order_id="new-deal-without-link")

    def test_attempt_279_actual_result_uses_production_ledger_once(self):
        state = CycleState(general_recovery=D("468.30"), net_cycle_result=D("-26.83"),
                           pending_actual_attempt_id=279,
                           pending_actual_deal_ids=[f"sl-{i}" for i in range(8)] + ["buy9", "sell9"])
        values = [
            ("BUY", "4352.43", "4351.38", "10"),
            ("SELL", "4351.91", "4353.91", "10"),
            ("SELL", "4351.89", "4354.90", "20"),
            ("BUY", "4352.43", "4348.43", "10"),
            ("SELL", "4351.88", "4355.92", "20"),
            ("BUY", "4352.45", "4348.41", "20"),
            ("SELL", "4351.87", "4355.89", "20"),
            ("BUY", "4352.51", "4348.41", "20"),
            ("BUY", "4352.50", "4351.30", "20"),
            ("SELL", "4351.90", "4351.87", "20"),
        ]
        state.deal_history = [
            {"deal_id": deal_id, "direction": direction, "entry": entry,
             "close_level": close, "size": size}
            for deal_id, (direction, entry, close, size) in zip(state.pending_actual_deal_ids, values)
        ]
        state.attempt_history = [{"attempt_id": 279}]
        bot = Bot.__new__(Bot); bot.state = state
        bot.cfg = Settings(scenario_sizes=(D("10"), D("10"), *(D("20"),) * 7))
        bot.capital = Mock()
        with tempfile.TemporaryDirectory() as directory:
            bot.cfg = Settings(**{**bot.cfg.__dict__,
                                  "state_file": str(Path(directory) / "state.json")})
            self.assertTrue(bot._refresh_actual_attempt_result())
            self.assertEqual(state.attempt_history[0]["actual_result"], "-478.10")
            self.assertEqual(state.attempt_result_total, D("-478.10"))
            self.assertEqual((state.general_recovery, state.net_cycle_result),
                             (D("468.30"), D("-26.83")))
            self.assertTrue(bot._refresh_actual_attempt_result())
            self.assertEqual(state.attempt_result_total, D("-478.10"))

    def test_actual_result_cases_minus_387_and_minus_385_do_not_change_general(self):
        for buy_close, expected in (("4000.00", D("-387")),
                                    ("4000.10", D("-385"))):
            state = CycleState(
                general_recovery=D("387"), pending_actual_attempt_id=8,
                pending_actual_deal_ids=["previous", "buy", "sell"],
                deal_history=[
                    {"deal_id": "previous", "direction": "BUY", "entry": "4000",
                     "close_level": "3981.70", "size": "20"},
                    {"deal_id": "buy", "direction": "BUY", "entry": "4000.60",
                     "close_level": buy_close, "size": "20"},
                    {"deal_id": "sell", "direction": "SELL", "entry": "3999.90",
                     "close_level": "4000.35", "size": "20"},
                ],
                attempt_history=[{"attempt_id": 8}],
            )
            bot = Bot.__new__(Bot); bot.state = state; bot.capital = Mock()
            bot.cfg = Settings(scenario_sizes=(D("20"),) * 9)
            with tempfile.TemporaryDirectory() as directory:
                bot.cfg = Settings(**{**bot.cfg.__dict__,
                                      "state_file": str(Path(directory) / "state.json")})
                self.assertTrue(bot._refresh_actual_attempt_result())
            self.assertEqual(D(state.attempt_history[0]["actual_result"]), expected)
            self.assertEqual(state.general_recovery, D("387"))

    def test_broker_transaction_pnl_requires_exact_links_and_currency(self):
        linked = [
            {"transactionId": "t1", "dealId": "deal", "type": "TRADE",
             "amount": "-24", "currency": "USD"},
            {"transactionId": "foreign", "dealId": "other", "type": "TRADE",
             "amount": "999", "currency": "USD"},
        ]
        result = broker_attempt_pnl(linked + [linked[0]], {"deal"})
        self.assertEqual((result["status"], result["amount"], result["currency"]),
                         ("COMPLETE_SNAPSHOT", D("-24"), "USD"))
        ambiguous = broker_attempt_pnl(linked + [{
            "transactionId": "fee", "dealId": "deal", "type": "TRADE_COMMISSION",
            "amount": "-1", "currency": "USD",
        }], {"deal"})
        self.assertEqual(ambiguous["status"], "AMBIGUOUS")
        self.assertIsNone(broker_attempt_pnl([{
            "transactionId": "time-only", "type": "SWAP", "amount": "-1", "currency": "USD",
        }], {"deal"})["amount"])

    def test_transaction_snapshot_requires_every_expected_deal_and_finite_money(self):
        partial = broker_attempt_pnl([{
            "transactionId": "one", "dealId": "old-buy", "type": "TRADE",
            "amount": "-24", "currency": "USD",
        }], {"old-buy", "old-sell"})
        self.assertEqual((partial["status"], partial["amount"]), ("PARTIAL", None))
        complete = broker_attempt_pnl([
            {"transactionId": "one", "dealId": "old-buy", "type": "TRADE",
             "amount": "-24", "currency": "USD"},
            {"transactionId": "two", "dealId": "old-sell", "type": "TRADE",
             "amount": "-10", "currency": "USD"},
        ], {"old-buy", "old-sell"})
        self.assertEqual((complete["status"], complete["amount"]),
                         ("COMPLETE_SNAPSHOT", D("-34")))
        for invalid in ("invalid", "NaN", "Infinity", "-Infinity"):
            result = broker_attempt_pnl([{
                "transactionId": invalid, "dealId": "old-buy", "type": "TRADE",
                "amount": invalid, "currency": "USD",
            }], {"old-buy"})
            self.assertEqual((result["status"], result["amount"]), ("UNAVAILABLE", None))
        zero = broker_attempt_pnl([{
            "transactionId": "zero", "dealId": "old-buy", "type": "TRADE",
            "amount": "0", "currency": "USD",
        }], {"old-buy"})
        self.assertEqual((zero["status"], zero["amount"]),
                         ("COMPLETE_SNAPSHOT", D("0")))

    def test_transaction_worker_uses_owned_snapshot_and_all_documented_types(self):
        client = Mock()
        client.transactions.return_value = [
            {"transactionId": "a", "dealId": "attempt-one", "type": "TRADE",
             "amount": "-34", "currency": "USD"},
            {"transactionId": "foreign", "dealId": "attempt-two", "type": "TRADE",
             "amount": "3", "currency": "USD"},
        ]
        with patch("trader.notifications.time.time", return_value=200000):
            result = TransactionHistoryWorker._resolve(client, {
                "deal_ids": ["attempt-one"], "search_from_epoch": 100000,
            })
        self.assertEqual((result["status"], result["amount"]),
                         ("COMPLETE_SNAPSHOT", D("-34")))
        self.assertTrue(all(call.kwargs["all_types"] for call in client.transactions.call_args_list))
        self.assertTrue(all("from_date" in call.kwargs and "to_date" in call.kwargs
                            for call in client.transactions.call_args_list))

    def test_transaction_fingerprint_is_order_independent_and_content_complete(self):
        base = {"status": "COMPLETE_SNAPSHOT", "amount": D("-24.0"), "currency": "usd",
                "components": [
                    {"id": "a", "deal_id": "d1", "type": "TRADE",
                     "amount": "-23.00", "currency": "USD"},
                    {"id": "b", "deal_id": "d1", "type": "SWAP",
                     "amount": "-1", "currency": "USD"},
                ]}
        expected = transaction_result_fingerprint(base)
        reordered = {**base, "amount": "-24.000",
                     "components": list(reversed(base["components"]))}
        self.assertEqual(expected, transaction_result_fingerprint(reordered))
        for field, value in (("deal_id", "d2"), ("type", "CORRECTION"),
                             ("amount", "-2"), ("currency", "EUR")):
            changed = {**base, "components": [dict(item) for item in base["components"]]}
            changed["components"][0][field] = value
            self.assertNotEqual(expected, transaction_result_fingerprint(changed))

    def test_transaction_jobs_are_durably_scheduled_and_backed_off(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = Bot.__new__(Bot); bot.cfg = Settings(state_file=str(Path(directory) / "s.json"))
            bot.state = CycleState(pending_transaction_jobs=[{
                "key": "one", "attempt_id": 1, "deal_ids": ["d"],
                "search_from_epoch": 1, "next_check_at": 0,
            }])
            bot.notification_worker = None; bot.telegram = Mock(); bot._queue_pending_reports = Mock()
            bot.transaction_worker = Mock(); bot.transaction_worker.results.return_value = []
            bot._tick_notifications(now=100)
            bot._tick_notifications(now=101)
            # The real worker de-duplicates in-flight keys; scheduling does not create a later
            # request after a completed snapshot until its explicit interval.
            bot.transaction_worker.results.return_value = [{"key": "one", "result": {
                "status": "COMPLETE_SNAPSHOT", "amount": D("0"), "currency": "USD",
                "components": [], "observed_to_epoch": 101,
            }}]
            bot._tick_notifications(now=101)
            bot.transaction_worker.reset_mock(); bot.transaction_worker.results.return_value = []
            bot._tick_notifications(now=102)
            bot.transaction_worker.submit.assert_not_called()
            self.assertEqual(bot.state.pending_transaction_jobs[0]["next_check_at"], 3701)
            bot.transaction_worker.results.return_value = [{"key": "one", "error": "temporary"}]
            bot._tick_notifications(now=3701)
            self.assertEqual(bot.state.pending_transaction_jobs[0]["next_check_at"], 3706)

    def test_tick_never_performs_transaction_network_io(self):
        bot = Bot.__new__(Bot); bot.state = CycleState(); bot.capital = Mock()
        bot.state.broker_transaction_status = "PENDING"
        bot.state.pending_transaction_jobs = [{"key": "old", "deal_ids": ["old"]}]
        bot.tick()
        bot.capital.transactions.assert_not_called()

    def test_main_owner_applies_two_transaction_jobs_to_their_attempts_once(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = Bot.__new__(Bot)
            bot.cfg = Settings(state_file=str(Path(directory) / "state.json"))
            bot.state = CycleState(
                attempt_history=[{"attempt_id": 1}, {"attempt_id": 2}],
                pending_transaction_jobs=[
                    {"key": "one", "attempt_id": 1, "deal_ids": ["old"],
                     "search_from_epoch": 1},
                    {"key": "two", "attempt_id": 2, "deal_ids": ["new"],
                     "search_from_epoch": 2},
                ],
            )
            bot.notification_worker = None
            bot.transaction_worker = Mock()
            bot.transaction_worker.results.return_value = [
                {"key": "one", "result": {"status": "COMPLETE_SNAPSHOT",
                 "amount": D("-34"), "currency": "USD", "components": [],
                 "observed_to_epoch": 3}},
                {"key": "two", "result": {"status": "COMPLETE_SNAPSHOT",
                 "amount": D("3"), "currency": "USD", "components": [],
                 "observed_to_epoch": 4}},
            ]
            bot.telegram = Mock(); bot._queue_pending_reports = Mock()
            bot._tick_notifications()
            self.assertEqual(
                [item["broker_transaction_pnl"] for item in bot.state.attempt_history],
                ["-34", "3"],
            )
            bot.transaction_worker.submit.assert_not_called()
            # Replaying the same worker result does not create another accounting entry.
            snapshot = json.dumps(bot.state.attempt_history, sort_keys=True)
            bot._tick_notifications()
            self.assertEqual(json.dumps(bot.state.attempt_history, sort_keys=True), snapshot)


class Attempt285ProductionRegressionTest(unittest.TestCase):
    def make_bot(self, path, stopped_direction="BUY"):
        cfg = Settings(
            dry_run=False, api_key="key", identifier="id", password="password",
            state_file=str(path), scenario_sizes=(D("10"),) * 9,
            scenario_stop_distances=(D("1"), D("2"), *(D("3"),) * 7),
            target_profit=D("0.30"),
        )
        bot = Bot.__new__(Bot); bot.cfg = cfg; bot.capital = Mock(); bot.telegram = Mock()
        bot.state = CycleState(cycle_id=285, cycle_attempt=1, active_attempt_id=285)
        bot.strategy = Strategy(cfg, bot.state); bot.continuation = CycleContinuation(bot)
        bot.execution_policy = ExecutionPolicy(); bot._missing_exit_since = None
        bot.strategy.begin(D("4279.94"), D("4279.37"))
        bot.strategy.confirm_initial_fills(D("4279.94"), D("4279.37"))
        bot.state.long.deal_id, bot.state.short.deal_id = "buy-old", "sell-old"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        closed = bot.state.long if stopped_direction == "BUY" else bot.state.short
        fill = D("4278.81") if stopped_direction == "BUY" else D("4280.50")
        bot.strategy.stopped(stopped_direction, fill, f"{stopped_direction}-s1")
        closed.trigger_id = f"{stopped_direction.lower()}-order"
        bot.state.cycle_trigger_ids.append(closed.trigger_id)
        bot.state.pending_recovery[-1]["trigger_id"] = closed.trigger_id
        return bot

    @staticmethod
    def wrapper(data):
        return {"position": data, "market": {"epic": "GOLD"}}

    def test_normal_dispatcher_reentry_then_late_sl_uses_working_order_clock_after_restart(self):
        for restart in (False, True):
            with self.subTest(restart=restart), tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "state.json"
                bot = self.make_bot(path)
                execution = {
                    "dateUTC": "2026-09-23T17:33:57.928Z", "dealId": "buy-order",
                    "source": "USER", "type": "WORKING_ORDER", "status": "EXECUTED",
                    "details": {"direction": "BUY", "size": 10, "level": 4279.94},
                }
                buy = {"dealId": "buy-new", "workingOrderId": "buy-order",
                       "direction": "BUY", "level": 4280.07, "size": 10,
                       "stopLevel": 4278.07, "profitLevel": 4282.20,
                       "createdDateUTC": "2026-09-23T17:33:58.012Z"}
                sell = {"dealId": "sell-old", "direction": "SELL", "level": 4279.37,
                        "size": 10, "stopLevel": 4281.37, "profitLevel": 4277.24}
                bot.capital.activity.return_value = [execution]
                bot._apply_protection = Mock(return_value=True)
                bot._detect_trigger_fill({"buy-new": buy, "sell-old": sell})
                self.assertEqual((bot.state.scenario, bot.state.general_recovery), (2, D("21.30")))
                opened = next(item for item in bot.state.deal_history
                              if item.get("deal_id") == "buy-new")
                self.assertEqual((opened["trigger_id"], opened["broker_open_execution_time"]),
                                 ("buy-order", "2026-09-23T17:33:57.928000+00:00"))
                bot.state.save(str(path))
                if restart:
                    state = CycleState.load(str(path))
                    bot.state = state; bot.strategy = Strategy(bot.cfg, state)
                    bot.continuation = CycleContinuation(bot)
                sell_sl = {
                    "dateUTC": "2026-09-23T17:34:37.146Z", "dealId": "sell-old",
                    "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                    "details": {"direction": "BUY", "level": 4281.43, "size": 10,
                                "stopLevel": 4281.37, "profitLevel": 4277.24},
                }
                reads = {"sell-old": 0}
                def activity(deal_id="", **_kwargs):
                    if deal_id == "sell-old":
                        reads["sell-old"] += 1
                        return [] if reads["sell-old"] == 1 else [sell_sl]
                    return [execution, sell_sl]
                bot.capital.activity.side_effect = activity
                bot.capital.positions.return_value = [self.wrapper(buy)]
                bot.capital.working_stop.return_value = "sell-trigger-ref"
                bot.capital.working_orders.return_value = []
                bot.capital.wait_confirmation.return_value = {
                    "dealStatus": "ACCEPTED", "dealId": "sell-trigger"
                }
                bot._apply_protection = Mock(return_value=True)
                with patch("trader.app.time.sleep"):
                    bot._tick_cycle()
                self.assertFalse(bot.state.manual)
                self.assertEqual((bot.state.scenario, bot.state.general_recovery), (2, D("41.90")))
                self.assertEqual((bot.state.long.deal_id, bot.state.long.current_entry,
                                  bot.state.long.size, bot.state.long.take_profit),
                                 ("buy-new", D("4280.07"), D("10"), D("4284.26")))
                self.assertEqual((bot.state.short.trigger_id,
                                  bot.state.short.original_trigger_level),
                                 ("sell-trigger", D("4279.37")))
                mutations = bot.capital.working_stop.call_count
                bot._tick_cycle()
                self.assertEqual((bot.state.general_recovery, bot.state.scenario,
                                  bot.capital.working_stop.call_count),
                                 (D("41.90"), 2, mutations))

    def test_mirror_late_sl_after_reentry_is_accounted_once(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(Path(directory) / "s.json", "SELL")
            execution = {"dateUTC": "2026-09-23T10:00:00Z", "dealId": "sell-order",
                         "source": "USER", "type": "WORKING_ORDER", "status": "EXECUTED"}
            sell_new = {"dealId": "sell-new", "workingOrderId": "sell-order",
                        "direction": "SELL", "level": 4279.20, "size": 10}
            bot.capital.activity.return_value = [execution]
            bot._apply_protection = Mock(return_value=True)
            bot._detect_trigger_fill({"sell-new": sell_new})
            buy_sl = {"dateUTC": "2026-09-23T10:00:10Z", "dealId": "buy-old",
                      "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                      "details": {"direction": "SELL", "level": 4277.80, "size": 10,
                                  "stopLevel": 4277.94}}
            bot.capital.activity.return_value = [execution, buy_sl]
            event = find_close_event([buy_sl], "buy-old", "SL")
            before = bot.state.general_recovery
            self.assertIsNotNone(bot._apply_confirmed_stop_event(bot.state.long, event,
                                                                 [execution, buy_sl]))
            after = bot.state.general_recovery
            self.assertGreater(after, before)
            stop_key = next(key for key in bot.state.processed_events
                            if key.startswith("stop:buy-old:"))
            self.assertIs(bot.strategy.stopped("BUY", D("4277.80"), stop_key), bot.state.long)
            self.assertEqual(bot.state.general_recovery, after)

    def test_confirmed_close_evidence_survives_empty_history_and_records_range(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(Path(directory) / "s.json")
            event_payload = {
                "dateUTC": "2026-09-23T17:34:37.146Z", "dealId": "sell-old",
                "source": "SL", "type": "POSITION", "status": "ACCEPTED",
                "details": {"level": 4281.43, "size": 10, "stopLevel": 4281.37},
            }
            bot.capital.activity.side_effect = [[event_payload], []]
            self.assertEqual(bot._closing_fill(bot.state.short, "SL"), D("4281.43"))
            self.assertEqual(bot._closing_fill(bot.state.short, "SL"), D("4281.43"))
            record = next(item for item in bot.state.deal_history
                          if item.get("deal_id") == "sell-old")
            self.assertEqual(record["protection_range"]["range_assessment"], "SL")
            self.assertEqual(record["close_execution_time"],
                             "2026-09-23T17:34:37.146000+00:00")

    def test_protection_range_is_diagnostic_only(self):
        base = {"dateUTC": "2026-01-01T00:00:00Z", "dealId": "owned",
                "source": "USER", "type": "POSITION", "status": "ACCEPTED",
                "details": {"direction": "SELL", "level": 100.5}}
        event = normalize_event(base)
        result = protection_range_diagnostic(
            event, confirmed_stop=D("99.50"), confirmed_take_profit=D("100.00")
        )
        self.assertEqual((result["range_assessment"], result["authoritative_source"]),
                         ("TP", "USER"))
        for direction, source, fill, expected in (
            ("BUY", "SL", "99.50", "SL"), ("SELL", "SL", "100.50", "SL"),
            ("BUY", "TP", "101.50", "TP"), ("SELL", "TP", "98.50", "TP"),
        ):
            payload = {**base, "source": source,
                       "details": {"direction": direction, "level": fill}}
            diagnostic = protection_range_diagnostic(
                normalize_event(payload),
                confirmed_stop=D(fill) + (D("0.50") if source == "SL" else D("10")),
                confirmed_take_profit=D(fill) - (D("0.50") if source == "TP" else D("10")),
            )
            self.assertEqual(diagnostic["range_assessment"], expected)
        outside = protection_range_diagnostic(
            normalize_event({**base, "source": "SL", "details": {"level": 102}}),
            confirmed_stop=D("100"), confirmed_take_profit=None,
        )
        self.assertEqual(outside["range_assessment"], "NONE")


class DurableMutationAndTransactionRegressionTest(unittest.TestCase):
    def one_sided_bot(self, path):
        cfg = Settings(dry_run=False, api_key="k", identifier="i", password="p",
                       state_file=str(path), scenario_sizes=(D("10"),) * 9,
                       scenario_stop_distances=(D("1"),) * 9)
        bot = Bot.__new__(Bot); bot.cfg = cfg; bot.telegram = Mock(); bot.capital = Mock()
        bot.state = CycleState(active=True, scenario=1, phase="LONG_ONLY", cycle_id=1,
                               cycle_attempt=1, active_attempt_id=1)
        bot.state.long = Leg("BUY", D("100"), D("100"), deal_id="survivor", size=D("10"),
                             stop_distance=D("1"), stop=D("99"), take_profit=D("102"))
        bot.state.short = Leg("SELL", D("99.5"), D("99.5"), deal_id="closed", open=False,
                              size=D("10"), stop_distance=D("1"), trigger_id="old-order",
                              trigger_reference="old-ref")
        bot.state.pending_recovery = [{"close_key": "close", "deal_id": "closed",
            "direction": "SELL", "d_value": "10", "pending_d_value": "10",
            "d_accounted": False, "reentry_accounted": False, "trigger_id": "old-order",
            "cycle_id": 1, "cycle_attempt": 1, "original_trigger_anchor": "99.5"}]
        bot.state.cycle_trigger_ids = ["old-order"]
        bot.strategy = Strategy(cfg, bot.state); bot.continuation = CycleContinuation(bot)
        bot.execution_policy = ExecutionPolicy(); bot._missing_exit_since = None
        return bot

    def test_removed_settrigger_never_starts_a_replacement_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"; bot = self.one_sided_bot(path)
            before = bot.state.to_dict() if hasattr(bot.state, "to_dict") else None
            bot.command("/settrigger short 99.4")
            self.assertEqual(bot.state.short.trigger_id, "old-order")
            bot.capital.delete_working_order.assert_not_called()
            bot.capital.working_stop.assert_not_called()

    def test_cancel_unknown_keeps_binding_then_suppresses_automatic_recreation(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.one_sided_bot(Path(directory) / "state.json")
            bot.capital.delete_working_order.return_value = False
            with self.assertRaisesRegex(RuntimeError, "ещё не подтверждён"):
                bot._manual_command("/canceltrigger", ["short"])
            self.assertEqual(bot.state.short.trigger_id, "old-order")
            bot.capital.positions.return_value = [{"position": {"dealId": "survivor",
                "direction": "BUY", "level": 100, "size": 10},
                "market": {"epic": "GOLD"}}]
            bot.capital.activity.return_value = [{
                "dateUTC": "2026-01-01T00:00:00Z", "dealId": "old-order",
                "type": "WORKING_ORDER", "status": "CANCELLED",
            }]
            bot._resume_pending_trigger_cancel()
            self.assertEqual(bot.state.short.trigger_id, "")
            self.assertTrue(bot.state.short.trigger_recreation_suppressed)
            bot._ensure_expected_trigger()
            bot.capital.working_stop.assert_not_called()

    def test_unknown_trigger_cancellation_does_not_stop_survivor_protection(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.one_sided_bot(Path(directory) / "state.json")
            bot.state.short.pending_trigger_action = "cancel"
            bot.state.short.pending_trigger_cancel_unknown = True
            survivor = {"dealId": "survivor", "direction": "BUY", "level": 100,
                        "size": 10, "stopLevel": 98, "profitLevel": 103}
            bot.capital.positions.return_value = [{"position": survivor,
                                                   "market": {"epic": "GOLD"}}]
            bot.capital.activity.return_value = []
            bot._protection_matches = Mock(return_value=False)
            bot._apply_protection = Mock(return_value=True)
            bot._tick_cycle()
            bot._apply_protection.assert_called_with(bot.state.long)
            self.assertEqual(bot.state.short.trigger_id, "old-order")
            bot.capital.working_stop.assert_not_called()

    def test_trigger_tp_race_uses_actual_size_in_real_caller(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.one_sided_bot(Path(directory) / "state.json")
            bot.state.short.size = D("10")
            bot.capital.delete_working_order.return_value = False
            opened = {"dateUTC": "2026-01-01T00:00:01Z", "dealId": "race",
                      "source": "USER", "type": "POSITION", "status": "ACCEPTED",
                      "details": {"workingOrderId": "old-order", "direction": "SELL",
                                  "level": 100, "size": 7}}
            bot.capital.activity.return_value = [opened]
            bot.capital.positions.return_value = [{"position": {"dealId": "race",
                "workingOrderId": "old-order", "direction": "SELL", "level": 100,
                "size": 7}, "market": {"epic": "GOLD"}}]
            bot.capital.close_position.return_value = "close-ref"
            bot.capital.wait_confirmation.return_value = {
                "dealStatus": "ACCEPTED", "dealId": "race", "level": 101,
            }
            bot._cancel_pending_trigger_for_completion(bot.state.long)
            self.assertEqual((bot.state.short.size, bot.state.realized_losses,
                              bot.state.realized_loss_money), (D("7"), D("0"), D("0")))
            self.assertEqual(bot.state.trigger_race_results[-1]["signed_result"], "-7")
            record = next(item for item in bot.state.deal_history
                          if item.get("deal_id") == "race")
            self.assertEqual(record["size"], "7")

    def test_real_transaction_payload_and_incomplete_fee_only(self):
        payload = {"reference": "139712570466515", "transactionType": "TRADE",
                   "size": "-11.2", "currency": "USD", "dealId": "buy-284",
                   "status": "PROCESSED", "dateUtc": "2026-09-23T17:25:00.744"}
        result = broker_attempt_pnl([payload], {"buy-284"})
        self.assertEqual((result["status"], result["amount"], result["currency"]),
                         ("COMPLETE_SNAPSHOT", D("-11.2"), "USD"))
        fee_only = broker_attempt_pnl([{
            "transactionId": "fee", "dealId": "buy-284", "type": "SWAP",
            "amount": "-1", "currency": "USD", "status": "PROCESSED",
        }], {"buy-284"})
        self.assertEqual((fee_only["status"], fee_only["amount"]), ("PARTIAL", None))
        shared = broker_attempt_pnl([payload, {**payload, "dealId": "sell-285",
            "size": "-20.6"}], {"buy-284", "sell-285"})
        self.assertEqual(shared["status"], "COMPLETE_SNAPSHOT")
        self.assertEqual(len(shared["components"]), 2)

    def test_real_transaction_payload_flows_from_worker_to_main_owner(self):
        with tempfile.TemporaryDirectory() as directory:
            payload = {"reference": "139712570466515", "transactionType": "TRADE",
                       "size": "-11.2", "currency": "USD", "dealId": "buy-284",
                       "status": "PROCESSED", "dateUtc": "2026-09-23T17:25:00.744"}
            client = Mock(); client.transactions.return_value = [payload]
            with patch("trader.notifications.time.time", return_value=200):
                result = TransactionHistoryWorker._resolve(client, {
                    "deal_ids": ["buy-284"], "search_from_epoch": 100,
                })
            bot = Bot.__new__(Bot); bot.cfg = Settings(
                state_file=str(Path(directory) / "state.json")
            )
            bot.state = CycleState(attempt_history=[{"attempt_id": 284}],
                pending_transaction_jobs=[{"key": "tx", "attempt_id": 284,
                    "deal_ids": ["buy-284"], "search_from_epoch": 100,
                    "next_check_at": 0}])
            bot.notification_worker = None; bot.telegram = Mock()
            bot._queue_pending_reports = Mock(); bot.transaction_worker = Mock()
            bot.transaction_worker.results.return_value = [{"key": "tx", "result": result}]
            bot._tick_notifications(now=201)
            attempt = bot.state.attempt_history[0]
            self.assertEqual((attempt["broker_transaction_status"],
                              attempt["broker_transaction_pnl"],
                              attempt["broker_transaction_currency"]),
                             ("COMPLETE_SNAPSHOT", "-11.2", "USD"))

    def test_identical_snapshot_advances_watermark_without_reaccounting(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = Bot.__new__(Bot); bot.cfg = Settings(state_file=str(Path(directory) / "s.json"))
            result = {"status": "COMPLETE_SNAPSHOT", "amount": D("-11.2"),
                      "currency": "USD", "components": [], "observed_to_epoch": 20}
            fingerprint = transaction_result_fingerprint(result)
            bot.state = CycleState(attempt_history=[{"attempt_id": 1,
                "broker_transaction_pnl": "-11.2"}], pending_transaction_jobs=[{
                "key": "one", "attempt_id": 1, "deal_ids": ["d"],
                "search_from_epoch": 1, "observed_to_epoch": 10,
                "result_fingerprint": fingerprint, "next_check_at": 0,
            }])
            bot.notification_worker = None; bot.telegram = Mock()
            bot._queue_pending_reports = Mock(); bot.transaction_worker = Mock()
            bot.transaction_worker.results.return_value = [{"key": "one", "result": result}]
            before = json.dumps(bot.state.attempt_history, sort_keys=True)
            bot._tick_notifications(now=20)
            self.assertEqual(bot.state.pending_transaction_jobs[0]["observed_to_epoch"], 20)
            self.assertEqual(json.dumps(bot.state.attempt_history, sort_keys=True), before)

    def test_worker_key_remains_busy_until_main_acknowledges(self):
        worker = TransactionHistoryWorker(Settings(), client_factory=lambda _cfg: Mock())
        worker._resolve = Mock(return_value={"status": "PENDING", "amount": None,
                                             "currency": "", "components": [],
                                             "observed_to_epoch": 1})
        worker.start()
        try:
            job = {"key": "race", "deal_ids": ["d"], "search_from_epoch": 0}
            worker.submit(job)
            deadline = time.time() + 2
            completed = []
            while time.time() < deadline and not completed:
                completed = worker.results()
                time.sleep(0.001)
            self.assertTrue(completed)
            worker.submit(job)
            time.sleep(0.01)
            self.assertEqual(worker.results(), [])
            worker.acknowledge("race")
            worker.submit(job)
            deadline = time.time() + 2
            while time.time() < deadline and not worker.results():
                time.sleep(0.001)
            self.assertGreaterEqual(worker._resolve.call_count, 2)
        finally:
            worker.stop()


class Attempt286UnifiedLedgerRegressionTest(unittest.TestCase):
    def make_bot(self, path: str) -> Bot:
        cfg = Settings(
            dry_run=False, api_key="k", identifier="i", password="p", state_file=path,
            diagnostic_log_file=str(Path(path).with_name("diagnostic.log")),
            target_profit=D("0.30"), scenario_sizes=(D("10"), D("10"), D("20"))
            + (D("20"),) * 6,
            scenario_stop_distances=(D("1"), D("2"), D("3")) + (D("3"),) * 6,
        )
        bot = Bot.__new__(Bot); bot.cfg = cfg; bot.capital = Mock(); bot.telegram = Mock()
        bot.state = CycleState(cycle_id=286, cycle_attempt=1, active_attempt_id=286)
        bot.strategy = Strategy(cfg, bot.state); bot.execution_policy = ExecutionPolicy()
        bot.continuation = CycleContinuation(bot); bot._missing_exit_since = None
        bot.strategy.begin(D("4290.72"), D("4290.36"))
        bot.strategy.confirm_initial_fills(D("4290.72"), D("4290.36"))
        bot.state.long.deal_id, bot.state.short.deal_id = "buy-1", "sell-1"
        bot.state.remember_deal(bot.state.long, 1); bot.state.remember_deal(bot.state.short, 1)
        bot._apply_protection = Mock(return_value=True)
        return bot

    @staticmethod
    def stop_event(deal_id: str, direction: str, fill: str, stop: str,
                   size: str, stamp: str):
        return normalize_event({
            "dateUTC": stamp, "dealId": deal_id, "source": "SL",
            "type": "POSITION", "status": "ACCEPTED",
            "details": {"direction": direction, "level": fill,
                        "stopLevel": stop, "size": size},
        })

    def reopen(self, bot: Bot, leg: Leg, order: str, deal: str, fill: str,
               size: str, stamp: str) -> None:
        leg.trigger_id = order
        next(item for item in bot.state.pending_recovery
             if item["deal_id"] == leg.deal_id)["trigger_id"] = order
        bot.capital.activity.return_value = [{
            "dateUTC": stamp, "dealId": order, "type": "WORKING_ORDER",
            "status": "EXECUTED",
        }]
        bot._detect_trigger_fill({deal: {
            "dealId": deal, "workingOrderId": order, "direction": leg.direction,
            "level": fill, "size": size,
        }})

    def test_two_same_side_reentries_then_original_buy_stop_is_scenario_three(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            self.assertEqual(bot.state.general_recovery, D("6.60"))

            sell = bot._apply_confirmed_stop_event(
                bot.state.short,
                self.stop_event("sell-1", "SELL", "4291.43", "4291.36", "10",
                                "2026-09-24T17:26:00Z"), [],
            )
            self.assertIsNotNone(sell)
            self.assertEqual(bot.state.general_recovery, D("7.30"))
            self.reopen(bot, sell, "sell-order-2", "sell-2", "4290.32", "10",
                        "2026-09-24T17:26:10Z")
            self.assertEqual((bot.state.scenario, bot.state.general_recovery), (2, D("17.70")))

            sell = bot._apply_confirmed_stop_event(
                bot.state.short,
                self.stop_event("sell-2", "SELL", "4292.34", "4292.32", "10",
                                "2026-09-24T17:27:00Z"), [],
            )
            self.assertIsNotNone(sell)
            self.assertEqual(bot.state.general_recovery, D("37.90"))
            self.reopen(bot, sell, "sell-order-3", "sell-3", "4290.34", "20",
                        "2026-09-24T17:27:20Z")
            self.assertEqual((bot.state.scenario, bot.state.general_recovery), (3, D("38.30")))

            # The restart is between the second reentry and the separately observed BUY SL.
            bot.state.save(path); restored = CycleState.load(path)
            bot.state = restored; bot.strategy = Strategy(bot.cfg, restored)
            buy_close = self.stop_event(
                "buy-1", "BUY", "4287.72", "4287.72", "10",
                "2026-09-24T17:28:48.036Z",
            )
            self.assertIsNotNone(bot._apply_confirmed_stop_event(restored.long, buy_close, []))
            self.assertEqual((restored.scenario, restored.general_recovery), (3, D("68.30")))
            self.assertEqual((restored.short.deal_id, restored.short.current_entry,
                              restored.short.size, restored.short.take_profit),
                             ("sell-3", D("4290.34"), D("20"), D("4286.925")))
            opened_buy = next(item for item in restored.deal_history
                              if item["deal_id"] == "buy-1")
            self.assertEqual((opened_buy["scenario"], opened_buy["scenario_at_close"]), (1, 3))
            self.assertEqual([item["scenario"] for item in restored.scenario_transitions], [2, 3])

    def test_saved_historical_stop_wins_over_current_leg_levels(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            leg = bot.state.long
            leg.current_entry = D("100"); leg.size = D("10")
            leg.stop = leg.confirmed_stop = D("98"); leg.take_profit = D("104")
            bot.state.general_recovery = D("8")
            event = self.stop_event("buy-1", "BUY", "98.9", "99", "10",
                                    "2026-01-01T00:00:01Z")
            self.assertEqual(bot._remember_close_event(leg, event, scenario_at_close=1), "NEW")
            bot.state.save(path); restored = CycleState.load(path)
            bot.state = restored; bot.strategy = Strategy(bot.cfg, restored)
            saved = bot._saved_close_event(restored.long, "SL")
            self.assertIsNotNone(saved)
            self.assertIsNotNone(bot._apply_confirmed_stop_event(restored.long, saved, []))
            pending = restored.pending_recovery[-1]
            self.assertEqual((restored.general_recovery, pending["pending_d_value"],
                              pending["confirmed_stop"]), (D("9"), "10", "99"))

    def test_synthetic_late_sell_tp_completes_attempt_286_once_with_actual_result(self):
        """The TP time is synthetic: the supplied DEMO log ends while SELL20 is open."""
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.state.scenario = 3; bot.state.general_recovery = D("68.30")
            bot.state.long.open = False; bot.state.long.deal_id = "buy-1"
            bot.state.short.deal_id = "sell-3"; bot.state.short.current_entry = D("4290.34")
            bot.state.short.size = D("20"); bot.state.short.take_profit = D("4286.925")
            bot.state.short.confirmed_take_profit = D("4287.34")
            bot.state.phase = "SHORT_ONLY"
            bot.state.realized_losses = D("6.09")
            bot.state.realized_loss_money = D("60.90")
            bot.state.deal_history = [
                {"cycle_id": 286, "deal_id": "sell-1", "direction": "SELL",
                 "entry": "4290.36", "size": "10", "close_level": "4291.43",
                 "close_source": "SL"},
                {"cycle_id": 286, "deal_id": "sell-2", "direction": "SELL",
                 "entry": "4290.32", "size": "10", "close_level": "4292.34",
                 "close_source": "SL"},
                {"cycle_id": 286, "deal_id": "buy-1", "direction": "BUY",
                 "entry": "4290.72", "size": "10", "close_level": "4287.72",
                 "close_source": "SL"},
                {"cycle_id": 286, "deal_id": "sell-3", "direction": "SELL",
                 "entry": "4290.34", "size": "20", "close_level": None,
                 "close_source": ""},
            ]
            bot.state.attempt_deal_ids = ["sell-1", "sell-2", "buy-1", "sell-3"]
            tp = {"dateUTC": "2026-09-24T17:30:00Z", "dealId": "sell-3",
                  "source": "TP", "type": "POSITION", "status": "ACCEPTED",
                  "details": {"direction": "BUY", "level": 4287.25,
                              "profitLevel": 4287.34, "size": 20}}
            bot.capital.positions.return_value = []
            bot.capital.activity.side_effect = lambda deal_id="", **_: [tp]
            bot.capital.working_orders.return_value = []
            bot._apply_protection = Mock()
            bot._create_trigger = Mock()
            with patch("trader.app.time.sleep"):
                bot._tick_cycle()
            self.assertFalse(bot.state.active)
            self.assertEqual((bot.state.net_cycle_money, bot.state.completed_cycles),
                             (D("0.90"), 1))
            self.assertEqual((bot.state.deal_history, bot.state.attempt_history), ([], []))
            bot._apply_protection.assert_not_called()
            bot._create_trigger.assert_not_called()
            bot._tick_cycle()
            self.assertEqual(bot.state.completed_cycles, 1)

    def test_conflicting_full_close_is_rejected_before_accounting(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.state.long.current_entry = D("100"); bot.state.long.size = D("10")
            bot.state.long.stop = bot.state.long.confirmed_stop = D("99")
            bot.state.general_recovery = D("8")
            first = self.stop_event("buy-1", "BUY", "98.9", "99", "10",
                                    "2026-01-01T00:00:01Z")
            second = self.stop_event("buy-1", "BUY", "98.8", "99", "10",
                                     "2026-01-01T00:00:01Z")
            self.assertEqual(bot._remember_close_event(bot.state.long, first,
                                                       scenario_at_close=1), "NEW")
            before = bot.state.general_recovery
            bot._manual = Mock()
            self.assertIsNone(bot._apply_confirmed_stop_event(bot.state.long, second, []))
            self.assertEqual(bot.state.general_recovery, before)
            bot._manual.assert_called_once()

    def test_partial_stop_keeps_remainder_open_and_uses_actual_size(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            leg = bot.state.long; leg.current_entry = D("100"); leg.size = D("10")
            leg.stop = leg.confirmed_stop = D("99")
            bot.state.general_recovery = D("8")
            partial = self.stop_event("buy-1", "BUY", "98.9", "99", "7",
                                      "2026-01-01T00:00:01Z")
            self.assertIsNotNone(bot._apply_confirmed_stop_event(leg, partial, []))
            self.assertTrue(leg.open)
            self.assertEqual((leg.size, bot.state.general_recovery,
                              bot.state.realized_loss_money), (D("3"), D("8.7"), D("7.7")))
            self.assertEqual(bot.state.pending_recovery[-1]["pending_d_value"], "7")
            final = self.stop_event("buy-1", "BUY", "98.8", "99", "3",
                                    "2026-01-01T00:00:02Z")
            self.assertIsNotNone(bot._apply_confirmed_stop_event(leg, final, []))
            self.assertFalse(leg.open)
            self.assertEqual(len(bot.state.pending_recovery), 1)
            self.assertEqual((bot.state.pending_recovery[0]["size"],
                              bot.state.pending_recovery[0]["pending_d_value"]), ("10", "10"))

    def test_equivalent_transaction_amount_spellings_are_one_record(self):
        base = {"reference": "tx", "transactionType": "TRADE", "currency": "USD",
                "dealId": "deal", "status": "PROCESSED"}
        result = broker_attempt_pnl([{**base, "size": "-11.2"},
                                     {**base, "size": "-11.20"}], {"deal"})
        self.assertEqual((result["status"], result["amount"], len(result["components"])),
                         ("COMPLETE_SNAPSHOT", D("-11.2"), 1))

    def test_completion_logs_then_clears_cycle_ledger_and_jobs(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            bot.state.pending_transaction_jobs = [{
                "key": "old-job", "cycle_id": 286, "generation": 0,
            }]
            bot.state.attempt_history = [{"attempt_id": 286, "cycle_id": 286,
                                          "status": "OPEN"}]
            bot._store_report = Mock(return_value=None)
            bot._get_continuation = Mock(return_value=Mock(release=Mock()))
            with self.assertLogs("trader.app", level="INFO") as captured:
                bot._complete_cycle("BUY", D("4291.72"))
            archived = "\n".join(captured.output)
            self.assertIn("CYCLE_LEDGER_FINAL", archived)
            self.assertIn('"deal_history"', archived)
            self.assertEqual((bot.state.deal_history, bot.state.attempt_history,
                              len(bot.state.pending_transaction_jobs)), ([], [], 1))
            self.assertEqual(bot.state.completed_cycles, 1)
            bot.notification_worker = None; bot.transaction_worker = Mock()
            bot.transaction_worker.results.return_value = []
            bot._queue_pending_reports = Mock()
            bot._tick_notifications(now=1)
            bot.transaction_worker.submit.assert_called_once()
            restored = CycleState.load(path)
            self.assertEqual((restored.deal_history, restored.attempt_history,
                              len(restored.pending_transaction_jobs)), ([], [], 1))

    def test_late_removed_transaction_job_result_cannot_change_new_cycle(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.notification_worker = None; bot.telegram = Mock()
            bot._queue_pending_reports = Mock()
            bot.transaction_worker = TransactionHistoryWorker(
                bot.cfg, client_factory=lambda _cfg: Mock()
            )
            bot.transaction_worker.results = Mock(return_value=[{
                "key": "transactions:old", "result": {
                    "status": "COMPLETE_SNAPSHOT", "amount": D("999"),
                    "currency": "USD", "components": [], "observed_to_epoch": 10,
                },
            }])
            bot.transaction_worker.acknowledge = Mock()
            before = (bot.state.general_recovery, bot.state.attempt_result_total)
            bot._tick_notifications(now=10)
            self.assertEqual((bot.state.general_recovery,
                              bot.state.attempt_result_total), before)
            bot.transaction_worker.acknowledge.assert_called_once_with("transactions:old")

    def test_stale_transaction_generation_cannot_apply_to_current_cycle(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.state.transaction_generation = 2
            bot.state.pending_transaction_jobs = [{
                "key": "stale", "cycle_id": 286, "generation": 1,
                "attempt_id": 286, "next_check_at": 0,
            }]
            bot.notification_worker = None; bot.telegram = Mock()
            bot._queue_pending_reports = Mock()
            bot.transaction_worker = TransactionHistoryWorker(
                bot.cfg, client_factory=lambda _cfg: Mock()
            )
            bot.transaction_worker.results = Mock(return_value=[{
                "key": "stale", "result": {"status": "COMPLETE_SNAPSHOT",
                    "amount": D("999"), "currency": "USD", "components": [],
                    "observed_to_epoch": 10},
            }])
            bot.transaction_worker.acknowledge = Mock()
            bot._tick_notifications(now=10)
            self.assertEqual(bot.state.broker_transaction_pnl, None)
            self.assertNotIn("amount", bot.state.pending_transaction_jobs[0])
            bot.transaction_worker.acknowledge.assert_called_once_with("stale")

    def test_valid_completed_cycle_transaction_job_updates_summary_not_new_cycle(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.state.cycle_id = 287; bot.state.general_recovery = D("6.6")
            bot.state.completed_attempt_summaries = [{"cycle_id": 286, "attempt_id": 286}]
            bot.state.pending_transaction_jobs = [{"key": "old-valid", "cycle_id": 286,
                "attempt_id": 286, "deal_ids": ["old"], "search_from_epoch": 1,
                "generation": bot.state.transaction_generation, "next_check_at": 0}]
            bot.notification_worker = None; bot.telegram = Mock(); bot._queue_pending_reports = Mock()
            bot.transaction_worker = Mock()
            bot.transaction_worker.results.return_value = [{"key": "old-valid", "result": {
                "status": "COMPLETE_SNAPSHOT", "amount": D("-11.2"), "currency": "USD",
                "components": [], "observed_to_epoch": 10}}]
            before = (bot.state.general_recovery, bot.state.scenario,
                      bot.state.long.deal_id, bot.state.short.deal_id)
            bot._tick_notifications(now=10)
            self.assertEqual((bot.state.general_recovery, bot.state.scenario,
                              bot.state.long.deal_id, bot.state.short.deal_id), before)
            summary = bot.state.completed_attempt_summaries[0]
            self.assertEqual((summary["broker_transaction_status"],
                              summary["broker_transaction_pnl"]),
                             ("COMPLETE_SNAPSHOT", "-11.2"))

    def test_trigger_create_confirmation_timeout_never_reposts_and_survives_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            stopped = bot.strategy.stopped("SELL", D("4291.43"), "sell-stop")
            bot.capital.working_orders.return_value = []
            bot.capital.working_stop.return_value = "trigger-ref"
            bot.capital.wait_confirmation.side_effect = CapitalError("confirmation delayed")
            bot.capital.quote.return_value = (D("4300"), D("4300.1"))
            bot._create_trigger(stopped)
            bot._create_trigger(stopped)
            self.assertEqual(bot.capital.working_stop.call_count, 1)
            self.assertEqual(stopped.pending_trigger_create_reference, "trigger-ref")

            restored = CycleState.load(path)
            bot.state = restored; bot.strategy = Strategy(bot.cfg, restored)
            bot.capital.wait_confirmation.side_effect = None
            bot.capital.wait_confirmation.return_value = {
                "dealStatus": "ACCEPTED", "dealId": "trigger-order",
            }
            bot._create_trigger(restored.short)
            self.assertEqual(restored.short.trigger_id, "trigger-order")
            self.assertFalse(restored.short.pending_trigger_create)
            self.assertEqual(bot.capital.working_stop.call_count, 1)

    def test_trigger_post_timeout_blocks_repost_until_owned_order_is_visible(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            stopped = bot.strategy.stopped("SELL", D("4291.43"), "sell-stop")
            bot.capital.working_orders.return_value = []
            bot.capital.working_stop.side_effect = CapitalError("transport timeout")
            bot.capital.quote.return_value = (D("4300"), D("4300.1"))
            bot._create_trigger(stopped); bot._create_trigger(stopped)
            self.assertEqual(bot.capital.working_stop.call_count, 1)
            self.assertTrue(stopped.pending_trigger_create_unknown_post)
            bot.capital.working_orders.return_value = [{"workingOrderData": {
                "dealId": "delayed-order", "epic": bot.cfg.epic, "direction": "SELL",
                "orderLevel": 4290.36, "orderSize": 10,
            }}]
            bot._create_trigger(stopped)
            self.assertEqual(stopped.trigger_id, "")
            self.assertTrue(stopped.pending_trigger_create_unknown_post)
            self.assertEqual(bot.capital.working_stop.call_count, 1)
            self.assertEqual(bot.capital.working_stop.call_count, 1)

    def test_unknown_tp_market_delete_is_resolved_from_owned_user_close_once(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            bot.state.short.open = False; bot.state.short.trigger_id = "owned-trigger"
            bot.state.phase = "LONG_ONLY"
            bot.capital.close_position.side_effect = CapitalError("response lost")
            bot._close_reached_take_profit(bot.state.long)
            self.assertEqual(bot.capital.close_position.call_count, 1)
            self.assertTrue(bot.state.pending_close_unknown_delete)
            event = {"dateUTC": "2026-01-01T00:00:01Z", "dealId": "buy-1",
                     "source": "USER", "type": "POSITION", "status": "ACCEPTED",
                     "details": {"direction": "SELL", "level": 4292, "size": 10}}
            bot.capital.positions.return_value = []
            bot.capital.activity.side_effect = lambda *args, **kwargs: [event]
            bot.capital.delete_working_order.return_value = True
            bot._tick_cycle()
            self.assertFalse(bot.state.active)
            self.assertEqual(bot.capital.close_position.call_count, 1)
            self.assertEqual(bot.state.pending_close_direction, "")

    def test_visible_partial_stop_uses_each_execution_identity_and_actual_size(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.state.general_recovery = D("8")
            leg = bot.state.long; leg.current_entry = D("100"); leg.size = D("10")
            leg.stop = leg.confirmed_stop = D("99")
            bot.state.short.current_entry = D("99.5"); bot.state.short.size = D("10")
            first = {"id": "partial-7", "dateUTC": "2026-01-01T00:00:01Z",
                     "dealId": "buy-1", "source": "SL", "type": "POSITION",
                     "status": "ACCEPTED", "details": {"level": 98.9,
                     "stopLevel": 99, "size": 7, "direction": "SELL"}}
            bot.capital.positions.return_value = [
                {"position": {"dealId": "buy-1", "direction": "BUY", "level": 100,
                              "size": 3}, "market": {"epic": bot.cfg.epic}},
                {"position": {"dealId": "sell-1", "direction": "SELL", "level": 99.5,
                              "size": 10}, "market": {"epic": bot.cfg.epic}},
            ]
            bot.capital.activity.return_value = [first]
            bot._tick_cycle()
            self.assertEqual((leg.size, bot.state.general_recovery,
                              bot.state.realized_loss_money), (D("3"), D("8.7"), D("7.7")))
            final = {"id": "partial-3", "dateUTC": "2026-01-01T00:00:02Z",
                     "dealId": "buy-1", "source": "SL", "type": "POSITION",
                     "status": "ACCEPTED", "details": {"level": 98.8,
                     "stopLevel": 99, "size": 3, "direction": "SELL"}}
            bot.capital.positions.return_value = [
                {"position": {"dealId": "sell-1", "direction": "SELL", "level": 99.5,
                              "size": 10}, "market": {"epic": bot.cfg.epic}},
            ]
            bot.capital.activity.return_value = [final, first]
            bot._apply_protection = Mock(return_value=True); bot._create_trigger = Mock()
            with patch("trader.app.time.sleep"):
                bot._tick_cycle()
            self.assertEqual((bot.state.general_recovery, bot.state.realized_loss_money),
                             (D("9.3"), D("11.3")))
            self.assertEqual(bot.state.pending_recovery[0]["pending_d_value"], "10")
            before = (bot.state.general_recovery, bot.state.realized_loss_money)
            bot._tick_cycle()
            self.assertEqual((bot.state.general_recovery, bot.state.realized_loss_money), before)

    def test_close_event_requires_position_accepted_and_rejects_conflict(self):
        base = {"dealId": "d", "source": "SL", "details": {"level": 99, "size": 1}}
        self.assertIsNone(find_close_event([{**base, "type": "POSITION",
                                             "status": "UNKNOWN"}], "d", "SL"))
        self.assertIsNone(find_close_event([{**base, "type": "WORKING_ORDER",
                                             "status": "ACCEPTED"}], "d", "SL"))
        self.assertIsNone(find_close_event([{**base, "type": "POSITION"}], "d", "SL"))
        accepted = find_close_event([{**base, "type": "POSITION",
                                      "status": "ACCEPTED"}], "d", "SL")
        self.assertIsNotNone(accepted)

    def test_global_close_fallback_persists_full_evidence_across_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            event = {"id": "global-sl", "dateUTC": "2026-01-01T00:00:01Z",
                     "dealId": "buy-1", "source": "SL", "type": "POSITION",
                     "status": "ACCEPTED", "details": {"level": 4289.6,
                     "stopLevel": 4289.72, "profitLevel": 4292, "size": 10}}
            bot.capital.activity.side_effect = lambda deal_id="", **kwargs: ([] if deal_id else [event])
            with patch("trader.app.time.sleep"):
                self.assertEqual(bot._wait_closing_fill(bot.state.long, attempts=4), D("4289.6"))
            bot.state.save(path)
            restored = CycleState.load(path)
            record = next(item for item in restored.deal_history if item["deal_id"] == "buy-1")
            self.assertEqual((record["close_event_id"], record["close_size"],
                              record["close_execution_time"], record["effective_stop"]),
                             ("global-sl", "10", "2026-01-01T00:00:01+00:00", "4289.72"))
            bot.state = restored; bot.strategy = Strategy(bot.cfg, restored)
            bot.capital.activity.return_value = []
            bot.capital.activity.side_effect = None
            saved = bot._saved_close_event(restored.long, "SL")
            self.assertEqual((saved.event_id, saved.size, saved.timestamp.isoformat()),
                             ("global-sl", D("10"), "2026-01-01T00:00:01+00:00"))

    def test_actual_attempt_result_sums_partial_prices_instead_of_last_fill(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json"))
            bot.state.pending_actual_attempt_id = 286
            bot.state.pending_actual_deal_ids = ["buy-1"]
            bot.state.attempt_history = [{"attempt_id": 286, "cycle_id": 286}]
            record = next(item for item in bot.state.deal_history if item["deal_id"] == "buy-1")
            record.update({"entry": "100", "size": "10", "close_level": "98.8",
                           "close_source": "SL", "partial_closes": [{
                               "event_id": "part-7", "source": "SL", "fill": "98.9",
                               "size": "7", "execution_time": "2026-01-01T00:00:01+00:00"}]})
            self.assertTrue(bot._refresh_actual_attempt_result())
            self.assertEqual(bot.state.attempt_history[0]["actual_result"], "-11.3")

    def test_scenario_nine_finalization_resumes_after_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.make_bot(path)
            bot.state.active = False; bot.state.completed_cycles = 1
            bot.state.scenario = 9; bot.state.phase = "COMPLETED"
            bot.state.scenario_nine_long_fill = D("90")
            bot.state.scenario_nine_short_fill = D("110")
            bot.state.pending_finalization = {"kind": "SCENARIO_9", "attempt_id": 286,
                "long_fill": "90", "short_fill": "110", "paused": False}
            bot.state.save(path)
            restored = CycleState.load(path)
            bot.state = restored; bot.strategy = Strategy(bot.cfg, restored)
            bot.capital.positions.return_value = []
            bot.capital.working_orders.return_value = []
            bot.reconcile_startup()
            self.assertEqual((restored.phase, restored.armed), ("FILTER", True))
            self.assertFalse(restored.pending_finalization)
            self.assertEqual(len(restored.report_outbox), 1)
            bot.reconcile_startup()
            self.assertEqual((restored.completed_cycles, len(restored.report_outbox)), (1, 1))


class ScenarioNineCleanupRegressionTest(unittest.TestCase):
    def test_two_scenario_nine_finalizations_do_not_reuse_close_operations(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = Bot.__new__(Bot)
            bot.cfg = Settings(dry_run=False, api_key="key", identifier="id", password="pw",
                               state_file=path,
                               diagnostic_log_file=str(Path(directory) / "diagnostic.log"))
            bot.telegram = Mock(); bot.capital = Mock()
            bot.state = CycleState(); bot.strategy = Strategy(bot.cfg, bot.state)
            for cycle_id in (71, 72):
                bot.state.cycle_id = cycle_id
                bot.state.completed_cycles = cycle_id - 70
                bot.state.active = False
                bot.state.scenario = 9
                bot.state.scenario_nine_close_operations = {
                    "BUY": {"operation_id": f"old-buy-{cycle_id}", "cycle_id": cycle_id,
                            "attempt_id": cycle_id, "deal_id": f"buy-{cycle_id}"},
                    "SELL": {"operation_id": f"old-sell-{cycle_id}", "cycle_id": cycle_id,
                             "attempt_id": cycle_id, "deal_id": f"sell-{cycle_id}"},
                }
                bot.state.pending_finalization = {
                    "kind": "SCENARIO_9", "attempt_id": 0,
                    "long_fill": "99", "short_fill": "101", "paused": False,
                    "deal_ids": [],
                }
                bot._resume_scenario_nine_finalization()
                self.assertEqual(bot.state.scenario_nine_close_operations, {})
                self.assertEqual((bot.state.phase, bot.state.armed), ("FILTER", True))
                bot.strategy.begin(D("100.2"), D("100"))
                self.assertEqual(bot.state.scenario, 1)
                self.assertEqual(bot.state.scenario_nine_close_operations, {})


class SuccessfulCycleBroker:
    """Stateful Capital fake for full-volume, immediately successful production paths."""

    def __init__(self, epic="GOLD"):
        self.epic = epic; self.positions_by_id = {}; self.orders = {}; self.events = []
        self.confirmations = {}; self.sequence = 0; self.mutations = []
        self.executions = []
        self.deal_journal = {}
        self.bid, self.ask = D("100"), D("100.2")

    def _id(self, prefix):
        self.sequence += 1
        return f"{prefix}-{self.sequence}"

    def _time(self):
        minute, second = divmod(self.sequence, 60)
        return f"2026-09-20T10:{minute:02d}:{second:02d}.000Z"

    def positions(self):
        return [{"position": dict(item), "market": {"epic": self.epic}}
                for item in self.positions_by_id.values()]

    def position(self, deal_id):
        return {"position": dict(self.positions_by_id[deal_id])}

    def working_orders(self):
        return [{"workingOrderData": dict(item), "marketData": {"epic": self.epic}}
                for item in self.orders.values()]

    def quote(self, epic):
        return self.bid, self.ask

    def candle_ranges(self, epic, minutes):
        return D("0"), D("0")

    def open_position(self, epic, direction, size, **kwargs):
        reference = self._id("market-ref"); deal_id = self._id(direction.lower())
        level = self.ask if direction == "BUY" else self.bid
        position = {"dealId": deal_id, "dealReference": reference,
                    "direction": direction, "level": level, "size": size,
                    "stopLevel": level - D("1") if direction == "BUY" else level + D("1")}
        self.positions_by_id[deal_id] = position
        self.deal_journal[deal_id] = {
            "deal_id": deal_id, "direction": direction, "entry": level,
            "size": D(str(size)), "close": None, "source": "",
        }
        self.confirmations[reference] = {
            "dealStatus": "ACCEPTED", "dealId": deal_id, "level": level, "size": size,
            "affectedDeals": [{"dealId": deal_id, "status": "OPENED"}],
        }
        self.mutations.append(("POST_POSITION", deal_id))
        return reference

    def wait_confirmation(self, reference, attempts=10):
        return self.confirmations[reference]

    def wait_position(self, deal_id, reference, direction, **kwargs):
        return dict(self.positions_by_id[deal_id])

    def update_position(self, deal_id, stop, target):
        reference = self._id("put-ref")
        position = self.positions_by_id[deal_id]
        position["stopLevel"], position["profitLevel"] = stop, target
        self.confirmations[reference] = {"dealStatus": "ACCEPTED", "dealId": deal_id}
        self.mutations.append(("PUT", deal_id, stop, target))
        return reference

    def working_stop(self, epic, direction, size, level, stop, target):
        reference = self._id("stop-ref"); order_id = self._id("order")
        self.orders[order_id] = {"dealId": order_id, "dealReference": reference,
            "epic": epic, "direction": direction, "orderLevel": level, "orderSize": size,
            "stopLevel": stop, "profitLevel": target}
        self.confirmations[reference] = {"dealStatus": "ACCEPTED", "dealId": order_id}
        self.mutations.append(("POST_STOP", order_id))
        return reference

    def delete_working_order(self, order_id):
        self.orders.pop(order_id, None); self.mutations.append(("DELETE_STOP", order_id))
        return True

    def close_position(self, deal_id):
        position = self.positions_by_id[deal_id]
        # Successful controlled closes use a deterministic fill distinct from entry while
        # retaining the exact permanent deal identity in confirmation and activity.
        fill = position["level"] + (D("0.2") if position["direction"] == "BUY" else D("-0.2"))
        self.emit_close(deal_id, "USER", fill)
        reference = self._id("close-ref")
        self.confirmations[reference] = {
            "dealStatus": "ACCEPTED", "dealId": deal_id, "level": fill,
            "affectedDeals": [{"dealId": deal_id, "status": "CLOSED"}],
        }
        self.mutations.append(("DELETE_POSITION", deal_id, reference))
        return reference

    def activity(self, deal_id="", last_period=86400):
        return [item for item in self.events if not deal_id or item.get("dealId") == deal_id]

    def login(self, **kwargs):
        return None

    def emit_close(self, deal_id, source, fill):
        position = self.positions_by_id.pop(deal_id)
        event_id = self._id("close")
        event = {"id": event_id, "dateUTC": self._time(), "dealId": deal_id,
            "source": source, "type": "POSITION", "status": "ACCEPTED",
            "direction": "SELL" if position["direction"] == "BUY" else "BUY",
            "details": {"level": fill, "size": position["size"],
                        "stopLevel": position.get("stopLevel"),
                        "profitLevel": position.get("profitLevel")}}
        self.events.append(event)
        points = (fill - position["level"] if position["direction"] == "BUY"
                  else position["level"] - fill)
        self.executions.append(points * D(str(position["size"])))
        self.deal_journal[deal_id].update({"close": fill, "source": source})
        return event

    def execute_order(self, order_id, fill):
        order = self.orders.pop(order_id); deal_id = self._id(order["direction"].lower())
        self.events.append({"id": self._id("wo-exec"), "dateUTC": self._time(),
                            "dealId": order_id, "source": "USER",
                            "type": "WORKING_ORDER", "status": "EXECUTED"})
        position = {"dealId": deal_id, "dealReference": order["dealReference"],
                    "workingOrderId": order_id, "direction": order["direction"],
                    "level": fill, "size": order["orderSize"],
                    "stopLevel": order["stopLevel"], "profitLevel": order["profitLevel"]}
        self.positions_by_id[deal_id] = position
        self.deal_journal[deal_id] = {
            "deal_id": deal_id, "direction": order["direction"], "entry": fill,
            "size": D(str(order["orderSize"])), "close": None, "source": "",
            "working_order_id": order_id,
        }
        self.events.append({"id": self._id("open"), "dateUTC": self._time(),
            "dealId": deal_id, "workingOrderId": order_id, "source": "USER",
            "type": "POSITION", "status": "ACCEPTED", "direction": order["direction"],
            "details": {"level": fill, "size": order["orderSize"]}})
        return position


class SuccessfulCycleEndToEndTest(unittest.TestCase):
    def make_bot(self, path, *, sizes=None):
        cfg = Settings(dry_run=False, api_key="key", identifier="id", password="pw",
                       state_file=path, diagnostic_log_file=path + ".log",
                       scenario_sizes=sizes or (D("10"),) * 9,
                       scenario_stop_distances=tuple(D(str(i)) for i in range(1, 10)),
                       target_profit=D("0.3"))
        bot = Bot.__new__(Bot); bot.cfg = cfg; bot.state = CycleState()
        bot.strategy = Strategy(cfg, bot.state); bot.capital = SuccessfulCycleBroker(cfg.epic)
        bot.telegram = Mock(); bot.execution_policy = ExecutionPolicy(); bot._flat_checks = 0
        return bot

    def emit_double_sl(self, bot, broker):
        broker.emit_close(bot.state.long.deal_id, "SL", bot.state.long.stop - D("0.1"))
        broker.emit_close(bot.state.short.deal_id, "SL", bot.state.short.stop + D("0.1"))
        bot.tick()
        self.assertEqual(bot.state.continuation_stage, "PAUSE")
        self.assertTrue(bot.state.continuation_managed)
        self.assertFalse(broker.positions_by_id)
        self.assertFalse(broker.orders)

    def resume_continuation_pair(self, bot, broker):
        broker.candle_ranges = lambda epic, minutes: (D("0"), D("4"))
        pause_until = bot.state.continuation_pause_until
        with patch("trader.app.time.time", return_value=pause_until + 1):
            bot.tick()
        self.assertEqual(bot.state.continuation_stage, "FILTER")
        bot.tick()
        self.assertEqual(bot.state.continuation_stage, "PREFLIGHT")
        posts_before = len([item for item in broker.mutations if item[0] == "POST_POSITION"])
        bot.tick(); self.assertEqual(bot.state.continuation_flat_checks, 1)
        bot.tick(); self.assertEqual(bot.state.continuation_flat_checks, 2)
        self.assertEqual(len([item for item in broker.mutations
                              if item[0] == "POST_POSITION"]), posts_before)
        bot.tick()
        self.assertEqual(bot.state.continuation_stage, "ACTIVE")
        self.assertEqual(len([item for item in broker.mutations
                              if item[0] == "POST_POSITION"]), posts_before + 2)
        return bot.state.active_attempt_id

    def test_full_volume_tp_matrix_s1_to_s8_both_winners_and_reentry_orders(self):
        sizes = (D("10"),) + (D("20"),) * 8
        cases = ((scenario, winner, pattern)
                 for scenario in range(1, 9)
                 for winner in ("BUY", "SELL")
                 for pattern in ("same", "alternating"))
        for scenario, winner_direction, pattern in cases:
            with self.subTest(scenario=scenario, winner=winner_direction, pattern=pattern), \
                    tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json"), sizes=sizes)
                broker = bot.capital
                bot._start_pair_common("successful candle", continuation=False,
                                       preflight_done=True)
                first_cycle_id = bot.state.cycle_id
                immutable_anchors = {
                    "BUY": bot.state.long.original_trigger_level,
                    "SELL": bot.state.short.original_trigger_level,
                }
                expected_general = D("5.0")  # 0.2 spread*10 + 0.3 target*10
                stop_direction = "SELL" if winner_direction == "BUY" else "BUY"
                for current in range(1, scenario):
                    leg = bot.state.short if stop_direction == "SELL" else bot.state.long
                    closed_size = leg.size
                    effective_distance = abs(leg.current_entry - leg.confirmed_stop)
                    stop_fill = leg.stop + (D("0.1") if stop_direction == "SELL" else D("-0.1"))
                    broker.emit_close(leg.deal_id, "SL", stop_fill)
                    bot._tick_cycle()
                    expected_general += D("0.1") * closed_size
                    if current >= 2:
                        expected_general += effective_distance * closed_size
                    order_id = leg.trigger_id
                    trigger_fill = leg.original_trigger_level + (
                        D("0.05") if stop_direction == "BUY" else D("-0.05")
                    )
                    broker.execute_order(order_id, trigger_fill)
                    bot._tick_cycle()
                    if current == 1:
                        expected_general += effective_distance * closed_size
                    expected_general += D("0.05") * sizes[current]
                    self.assertEqual(bot.state.scenario, current + 1)
                    if pattern == "alternating":
                        stop_direction = "BUY" if stop_direction == "SELL" else "SELL"

                winner = bot.state.long if winner_direction == "BUY" else bot.state.short
                loser = bot.state.short if winner_direction == "BUY" else bot.state.long
                winner_identity = (winner.deal_id, winner.current_entry, winner.size)
                loser_size = loser.size
                loser_effective_distance = abs(loser.current_entry - loser.confirmed_stop)
                loser_fill = loser.stop + (
                    D("0.1") if loser.direction == "SELL" else D("-0.1")
                )
                broker.emit_close(loser.deal_id, "SL", loser_fill)
                bot._tick_cycle()
                expected_general += D("0.1") * loser_size
                if scenario >= 2:
                    expected_general += loser_effective_distance * loser_size
                scenario_distance = D(str(scenario))
                if scenario == 1:
                    recovery_distance = expected_general / winner.size
                else:
                    base = scenario_distance * winner.size
                    recovery_distance = max(D("0"), expected_general - base) / winner.size
                total_distance = scenario_distance + recovery_distance
                expected_tp = (winner.current_entry + total_distance
                               if winner.direction == "BUY"
                               else winner.current_entry - total_distance)
                self.assertEqual(winner.take_profit, expected_tp)
                winner_puts = [item for item in broker.mutations
                               if item[0] == "PUT" and item[1] == winner.deal_id]
                self.assertTrue(winner_puts)
                self.assertEqual(winner_puts[-1][3], expected_tp)
                self.assertEqual(broker.positions_by_id[winner.deal_id]["profitLevel"], expected_tp)
                self.assertEqual((winner.deal_id, winner.current_entry, winner.size), winner_identity)
                trigger_id = loser.trigger_id
                self.assertEqual(loser.original_trigger_level,
                                 immutable_anchors[loser.direction])
                tp_fill = expected_tp
                broker.emit_close(winner.deal_id, "TP", tp_fill)
                expected_actual = sum(
                    ((item["close"] - item["entry"]) * item["size"]
                     if item["direction"] == "BUY"
                     else (item["entry"] - item["close"]) * item["size"])
                    for item in broker.deal_journal.values() if item["close"] is not None
                )
                mutations_before_completion = len(broker.mutations)
                bot._tick_cycle()

                self.assertEqual(bot.state.scenario, scenario)
                self.assertEqual(bot.state.general_recovery, expected_general)
                self.assertEqual(bot.state.completed_cycles, 1)
                self.assertEqual(bot.state.phase, "FILTER")
                self.assertNotIn(trigger_id, broker.orders)
                self.assertIn(("DELETE_STOP", trigger_id), broker.mutations)
                summary = next(item for item in bot.state.completed_attempt_summaries
                               if item.get("status") == "COMPLETED_CYCLE")
                self.assertEqual(D(summary["result"]), expected_actual)
                self.assertFalse(any(item[0] in {"POST_STOP", "POST_POSITION", "PUT"}
                                     for item in broker.mutations[mutations_before_completion:]))
                before = (bot.state.general_recovery, bot.state.completed_cycles,
                          len(bot.state.report_outbox), len(broker.mutations))
                bot.tick()
                self.assertEqual(before, (bot.state.general_recovery, bot.state.completed_cycles,
                                          len(bot.state.report_outbox), len(broker.mutations)))

                # Exercise the real candle filter and all three flat preflight reads before the
                # next logical cycle creates a fresh initial pair.
                broker.candle_ranges = lambda epic, minutes: (D("0"), D("4"))
                for _ in range(4):
                    bot.tick()
                self.assertTrue(bot.state.active)
                self.assertEqual(bot.state.scenario, 1)
                self.assertNotEqual(bot.state.cycle_id, first_cycle_id)

    def test_s8_trigger_then_survivor_sl_and_reopened_tp_uses_terminal_s9_both_mirrors(self):
        for final_direction, owner in (("SELL", "normal"), ("BUY", "normal"),
                                       ("SELL", "continuation"), ("BUY", "continuation")):
            with self.subTest(final_direction=final_direction, owner=owner), \
                    tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
                bot._start_pair_common("successful candle", continuation=False, preflight_done=True)
                self.assertEqual(bot.state.scenario, 1)
                # Seven full SL -> owned Trigger -> actual fill transitions produce S2..S8.
                direction = "SELL" if final_direction == "SELL" else "BUY"
                expected_prior_losses = D("0")
                for expected in range(2, 9):
                    leg = bot.state.short if direction == "SELL" else bot.state.long
                    stop_fill = leg.stop + (D("0.1") if direction == "SELL" else D("-0.1"))
                    expected_prior_losses += (
                        stop_fill - leg.current_entry if direction == "SELL"
                        else leg.current_entry - stop_fill
                    )
                    broker.emit_close(leg.deal_id, "SL", stop_fill)
                    bot._tick_cycle()
                    order_id = leg.trigger_id
                    anchor = leg.original_trigger_level
                    fill = anchor + (D("0.05") if direction == "BUY" else D("-0.05"))
                    broker.execute_order(order_id, fill)
                    bot._tick_cycle()
                    self.assertEqual(bot.state.scenario, expected)
                    direction = "BUY" if direction == "SELL" else "SELL"

                # At S8 close the requested side, create and execute its S9 Trigger, then publish
                # survivor SL and reopened TP before the next successful positions snapshot.
                reopened = bot.state.short if final_direction == "SELL" else bot.state.long
                survivor = bot.state.long if final_direction == "SELL" else bot.state.short
                first_fill = reopened.stop + (D("0.1") if final_direction == "SELL" else D("-0.1"))
                expected_prior_losses += (
                    first_fill - reopened.current_entry if reopened.direction == "SELL"
                    else reopened.current_entry - first_fill
                )
                broker.emit_close(reopened.deal_id, "SL", first_fill)
                bot._tick_cycle()
                order_id = reopened.trigger_id
                new_position = broker.execute_order(order_id, reopened.original_trigger_level)
                survivor_fill = survivor.stop + (D("-0.1") if survivor.direction == "BUY" else D("0.1"))
                expected_prior_losses += (
                    survivor.current_entry - survivor_fill if survivor.direction == "BUY"
                    else survivor_fill - survivor.current_entry
                )
                survivor_event = broker.emit_close(survivor.deal_id, "SL", survivor_fill)
                tp_fill = new_position["profitLevel"]
                tp_event = broker.emit_close(new_position["dealId"], "TP", tp_fill)
                mutation_count = len(broker.mutations)
                expected_deal_ids = set(bot.state.attempt_deal_ids) | {new_position["dealId"]}
                expected_actual_pnl = sum(broker.executions, D("0"))
                with patch("trader.app.LOG.info") as info_log:
                    if owner == "continuation":
                        bot.state.continuation_managed = True
                        bot.state.continuation_stage = "ACTIVE"
                        bot.continuation = CycleContinuation(bot)
                        bot.continuation.handle_active_scenario()
                    else:
                        bot._tick_cycle()
                archive_call = next(call for call in info_log.call_args_list
                                    if call.args and call.args[0] == "CYCLE_LEDGER_FINAL %s")
                archived = json.loads(archive_call.args[1])
                sources = {item["deal_id"]: item.get("close_source")
                           for item in archived["deal_history"]}
                self.assertEqual(sources[survivor_event["dealId"]], "SL")
                self.assertEqual(sources[tp_event["dealId"]], "TP")

                self.assertEqual(bot.state.scenario, 9)
                self.assertFalse(bot.state.active)
                self.assertEqual(bot.state.phase, "FILTER")
                self.assertEqual(bot.state.completed_cycles, 1)
                self.assertEqual(bot.state.active_attempt_id, 0)
                self.assertFalse(bot.state.continuation_managed)
                self.assertEqual(len(bot.state.pending_transaction_jobs), 1)
                self.assertEqual(set(bot.state.pending_transaction_jobs[0]["deal_ids"]),
                                 expected_deal_ids)
                summary = next(item for item in bot.state.completed_attempt_summaries
                               if item.get("status") == "COMPLETED_SCENARIO_9")
                self.assertEqual(D(summary["actual_result"]), expected_actual_pnl)
                self.assertEqual(
                    bot.state.net_cycle_result,
                    -(expected_prior_losses + abs(survivor_fill - tp_fill)),
                )
                self.assertIn(str(survivor_fill), bot.state.completed_cycle_report)
                self.assertIn(str(tp_fill), bot.state.completed_cycle_report)
                self.assertFalse(any(item[0] in {"PUT", "POST_STOP"}
                                     for item in broker.mutations[mutation_count:]))
                # S9 finalization archived the precise broker sources before clearing the ledger.
                self.assertEqual(survivor_event["source"], "SL")
                self.assertEqual(tp_event["source"], "TP")
                before = (bot.state.completed_cycles, len(bot.state.report_outbox),
                          len(bot.state.pending_transaction_jobs), len(broker.mutations))
                bot.tick()
                self.assertEqual(before, (bot.state.completed_cycles, len(bot.state.report_outbox),
                                          len(bot.state.pending_transaction_jobs),
                                          len(broker.mutations)))

    def test_real_double_sl_continuation_filter_preflight_reentry_and_tp_both_mirrors(self):
        for stopped_direction in ("BUY", "SELL"):
            with self.subTest(stopped_direction=stopped_direction), \
                    tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
                bot._start_pair_common("initial filter", continuation=False, preflight_done=True)
                cycle_id = bot.state.cycle_id
                initial_target_component = bot.cfg.target_profit * D("10")
                initial_general = bot.state.general_recovery
                initial_attempt = bot.state.active_attempt_id

                # Both authoritative SL executions arrive between two polls. The normal owner
                # must account them and hand the same logical cycle to CycleContinuation.
                broker.emit_close(bot.state.long.deal_id, "SL", bot.state.long.stop - D("0.1"))
                broker.emit_close(bot.state.short.deal_id, "SL", bot.state.short.stop + D("0.1"))
                bot._tick_cycle()
                self.assertEqual(bot.state.continuation_stage, "PAUSE")
                self.assertTrue(bot.state.continuation_managed)
                general_after_double_sl = bot.state.general_recovery
                pending_once = sum(D(item.get("value", "0")) for item in bot.state.recovery_events
                                   if item.get("component") == "DOUBLE_SL_PENDING_D")

                # A controlled clock releases the non-blocking five-minute pause. The real
                # candle-filter and exactly three consecutive flat preflight reads follow.
                broker.candle_ranges = lambda epic, minutes: (D("0"), D("4"))
                pause_until = bot.state.continuation_pause_until
                with patch("trader.app.time.time", return_value=pause_until + 1):
                    bot.tick()
                self.assertEqual(bot.state.continuation_stage, "FILTER")
                bot.tick()
                self.assertEqual(bot.state.continuation_stage, "PREFLIGHT")
                posts_before = len([item for item in broker.mutations
                                    if item[0] == "POST_POSITION"])
                bot.tick(); self.assertEqual(bot.state.continuation_flat_checks, 1)
                bot.tick(); self.assertEqual(bot.state.continuation_flat_checks, 2)
                self.assertEqual(len([item for item in broker.mutations
                                      if item[0] == "POST_POSITION"]), posts_before)
                bot.tick()
                self.assertEqual(bot.state.continuation_stage, "ACTIVE")
                self.assertEqual(len([item for item in broker.mutations
                                      if item[0] == "POST_POSITION"]), posts_before + 2)
                self.assertEqual(bot.state.cycle_id, cycle_id)
                self.assertNotEqual(bot.state.active_attempt_id, initial_attempt)
                continuation_attempt = bot.state.active_attempt_id
                # Continuation adds only its actual spread (0.2*10), never initial target again.
                self.assertEqual(bot.state.general_recovery,
                                 general_after_double_sl + D("2"))
                self.assertNotEqual(initial_target_component, D("0"))
                self.assertEqual(
                    sum(D(item.get("value", "0")) for item in bot.state.recovery_events
                        if item.get("component") == "DOUBLE_SL_PENDING_D"), pending_once,
                )

                stopped = bot.state.long if stopped_direction == "BUY" else bot.state.short
                survivor = bot.state.short if stopped_direction == "BUY" else bot.state.long
                broker.emit_close(stopped.deal_id, "SL", stopped.stop + (
                    D("-0.1") if stopped.direction == "BUY" else D("0.1")))
                bot.tick()
                order_id = stopped.trigger_id
                broker.execute_order(order_id, stopped.original_trigger_level + (
                    D("0.05") if stopped.direction == "BUY" else D("-0.05")))
                bot.tick()
                self.assertEqual(bot.state.scenario, 2)
                if stopped_direction == "SELL":
                    bot.command("/stop")
                    self.assertTrue(bot.state.continuation_stopped_by_user)
                reopened = bot.state.long if stopped_direction == "BUY" else bot.state.short
                broker.emit_close(reopened.deal_id, "SL", reopened.stop + (
                    D("-0.1") if reopened.direction == "BUY" else D("0.1")))
                bot.tick()
                trigger_id = reopened.trigger_id
                broker.emit_close(survivor.deal_id, "TP", survivor.take_profit)
                bot.tick()

                self.assertEqual(bot.state.completed_cycles, 1)
                self.assertEqual(bot.state.phase,
                                 "PAUSED" if stopped_direction == "SELL" else "FILTER")
                self.assertFalse(bot.state.continuation_managed)
                self.assertEqual(bot.state.active_attempt_id, 0)
                self.assertNotIn(trigger_id, broker.orders)
                self.assertTrue(any(item.get("attempt_id") == continuation_attempt
                                    for item in bot.state.completed_attempt_summaries))

    def test_stop_command_keeps_active_cycle_managed_and_finishes_paused(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
            bot._start_pair_common("initial filter", continuation=False, preflight_done=True)
            bot.command("/stop")
            self.assertTrue(bot.state.paused)
            broker.emit_close(bot.state.long.deal_id, "SL", bot.state.long.stop - D("0.1"))
            bot._tick_cycle()
            broker.emit_close(bot.state.short.deal_id, "TP", bot.state.short.take_profit)
            bot._tick_cycle()
            self.assertEqual(bot.state.phase, "PAUSED")
            post_count = len([item for item in broker.mutations if item[0] == "POST_POSITION"])
            for _ in range(4):
                bot.tick()
            self.assertEqual(len([item for item in broker.mutations
                                  if item[0] == "POST_POSITION"]), post_count)

    def test_sl_then_opposite_tp_between_polls_completes_without_recovery_trigger(self):
        for winner_direction in ("BUY", "SELL"):
            with self.subTest(winner=winner_direction), tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
                bot._start_pair_common("initial filter", continuation=False, preflight_done=True)
                winner = bot.state.long if winner_direction == "BUY" else bot.state.short
                loser = bot.state.short if winner_direction == "BUY" else bot.state.long
                broker.emit_close(loser.deal_id, "SL", loser.stop + (
                    D("-0.1") if loser.direction == "BUY" else D("0.1")))
                broker.emit_close(winner.deal_id, "TP", winner.take_profit)
                stop_posts = len([item for item in broker.mutations if item[0] == "POST_STOP"])
                bot._tick_cycle()
                self.assertEqual(bot.state.completed_cycles, 1)
                self.assertEqual(bot.state.phase, "FILTER")
                self.assertEqual(len([item for item in broker.mutations
                                      if item[0] == "POST_STOP"]), stop_posts)
                self.assertFalse(broker.positions_by_id)
                self.assertFalse(broker.orders)

    def test_two_complete_s1_to_s9_controlled_close_cycles_use_fresh_ownership(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
            cycle_ids = []; cycle_deal_sets = []
            for cycle_number in (1, 2):
                journal_before = set(broker.deal_journal)
                if cycle_number == 1:
                    bot._start_pair_common("initial filter", continuation=False,
                                           preflight_done=True)
                else:
                    broker.candle_ranges = lambda epic, minutes: (D("0"), D("4"))
                    for expected_flat_checks in (1, 2, 3):
                        posts_before = len([item for item in broker.mutations
                                            if item[0] == "POST_POSITION"])
                        bot.tick()
                        if expected_flat_checks < 3:
                            self.assertEqual(len([item for item in broker.mutations
                                                  if item[0] == "POST_POSITION"]), posts_before)
                    self.assertTrue(bot.state.active)
                    self.assertEqual(bot.state.scenario, 1)
                cycle_ids.append(bot.state.cycle_id)
                for transition in range(1, 9):
                    direction = "BUY" if transition % 2 else "SELL"
                    leg = bot.state.long if direction == "BUY" else bot.state.short
                    broker.emit_close(leg.deal_id, "SL", leg.stop + (
                        D("-0.1") if direction == "BUY" else D("0.1")))
                    bot._tick_cycle()
                    order_id = leg.trigger_id
                    broker.execute_order(order_id, leg.original_trigger_level + (
                        D("0.05") if direction == "BUY" else D("-0.05")))
                    bot._tick_cycle()
                    if transition < 8:
                        self.assertEqual(bot.state.scenario, transition + 1)

                self.assertEqual(bot.state.scenario, 9)
                self.assertFalse(bot.state.active)
                self.assertEqual(bot.state.phase, "FILTER")
                self.assertEqual(bot.state.completed_cycles, cycle_number)
                self.assertEqual(bot.state.scenario_nine_close_operations, {})
                self.assertFalse(broker.positions_by_id)
                self.assertFalse(broker.orders)
                cycle_deals = set(broker.deal_journal) - journal_before
                cycle_deal_sets.append(cycle_deals)
                job = next(item for item in bot.state.pending_transaction_jobs
                           if item["cycle_id"] == cycle_ids[-1])
                self.assertEqual(set(job["deal_ids"]), cycle_deals)
                mutation_count = len(broker.mutations)
                bot.tick()
                self.assertEqual(len(broker.mutations), mutation_count)

            self.assertNotEqual(cycle_ids[0], cycle_ids[1])
            self.assertTrue(cycle_deal_sets[0].isdisjoint(cycle_deal_sets[1]))
            self.assertEqual(len(bot.state.pending_transaction_jobs), 2)

    def test_full_continuation_path_reaches_scenario_nine_and_finalizes_both_mirrors(self):
        for first_direction in ("BUY", "SELL"):
            with self.subTest(first_direction=first_direction), \
                    tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
                bot._start_pair_common("initial filter", continuation=False, preflight_done=True)
                cycle_id = bot.state.cycle_id
                initial_ids = set(broker.deal_journal)
                self.emit_double_sl(bot, broker)
                general_after_double = bot.state.general_recovery
                attempt_id = self.resume_continuation_pair(bot, broker)
                self.assertEqual(bot.state.cycle_id, cycle_id)
                self.assertEqual(bot.state.general_recovery, general_after_double + D("2"))
                expected_general = general_after_double + D("2")
                direction = first_direction
                for scenario in range(1, 9):
                    leg = bot.state.long if direction == "BUY" else bot.state.short
                    size = leg.size
                    distance = abs(leg.current_entry - leg.confirmed_stop)
                    broker.emit_close(leg.deal_id, "SL", leg.stop + (
                        D("-0.1") if direction == "BUY" else D("0.1")))
                    bot.tick()
                    expected_general += D("0.1") * size
                    if scenario >= 2:
                        expected_general += distance * size
                    broker.execute_order(leg.trigger_id, leg.original_trigger_level + (
                        D("0.05") if direction == "BUY" else D("-0.05")))
                    bot.tick()
                    if scenario == 1:
                        expected_general += distance * size
                    expected_general += D("0.05") * bot.cfg.size_for(scenario + 1)
                    direction = "SELL" if direction == "BUY" else "BUY"

                continuation_deals = set(broker.deal_journal) - initial_ids
                self.assertEqual(bot.state.scenario, 9)
                self.assertEqual(bot.state.general_recovery, expected_general)
                self.assertEqual(bot.state.completed_cycles, 1)
                self.assertFalse(bot.state.active)
                self.assertEqual(bot.state.phase, "FILTER")
                self.assertFalse(bot.state.continuation_managed)
                self.assertEqual(bot.state.active_attempt_id, 0)
                self.assertFalse(broker.positions_by_id)
                self.assertFalse(broker.orders)
                self.assertTrue(all(item["size"] == D("10")
                                    and item["close"] is not None
                                    for deal_id, item in broker.deal_journal.items()
                                    if deal_id in continuation_deals))
                jobs = [item for item in bot.state.pending_transaction_jobs
                        if item["attempt_id"] == attempt_id]
                self.assertEqual(len(jobs), 1)
                self.assertEqual(set(jobs[0]["deal_ids"]), continuation_deals)
                before = (bot.state.completed_cycles, len(bot.state.report_outbox),
                          len(broker.mutations))
                bot.tick()
                self.assertEqual(before, (bot.state.completed_cycles,
                                          len(bot.state.report_outbox),
                                          len(broker.mutations)))

    def test_second_double_sl_creates_third_attempt_in_same_cycle_both_mirrors(self):
        for finishing_winner in ("BUY", "SELL"):
            with self.subTest(finishing_winner=finishing_winner), \
                    tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json")); broker = bot.capital
                bot._start_pair_common("initial filter", continuation=False, preflight_done=True)
                cycle_id = bot.state.cycle_id
                initial_target_events = [item for item in bot.state.recovery_events
                                         if item["kind"] == "INITIAL_SPREAD_AND_TARGET"]
                self.emit_double_sl(bot, broker)
                attempt_two = self.resume_continuation_pair(bot, broker)
                attempt_two_ids = {bot.state.long.deal_id, bot.state.short.deal_id}
                attempt_two_anchors = (bot.state.long.original_trigger_level,
                                       bot.state.short.original_trigger_level)
                general_attempt_two = bot.state.general_recovery

                self.emit_double_sl(bot, broker)
                general_after_second_double = bot.state.general_recovery
                broker.bid, broker.ask = D("101"), D("101.2")
                attempt_three = self.resume_continuation_pair(bot, broker)
                attempt_three_ids = {bot.state.long.deal_id, bot.state.short.deal_id}
                attempt_three_anchors = (bot.state.long.original_trigger_level,
                                         bot.state.short.original_trigger_level)

                self.assertEqual(bot.state.cycle_id, cycle_id)
                self.assertNotEqual(attempt_two, attempt_three)
                self.assertTrue(attempt_two_ids.isdisjoint(attempt_three_ids))
                self.assertNotEqual(attempt_two_anchors, attempt_three_anchors)
                self.assertEqual(bot.state.general_recovery,
                                 general_after_second_double + D("2"))
                self.assertEqual(general_attempt_two + D("22"),
                                 general_after_second_double)
                self.assertEqual(len([item for item in bot.state.recovery_events
                                      if item["kind"] == "CONTINUATION_SPREAD"]), 2)
                self.assertEqual([item for item in bot.state.recovery_events
                                  if item["kind"] == "INITIAL_SPREAD_AND_TARGET"],
                                 initial_target_events)
                recovery_keys = [item["key"] for item in bot.state.recovery_events]
                self.assertEqual(len(recovery_keys), len(set(recovery_keys)))
                self.assertFalse(broker.orders)

                winner = bot.state.long if finishing_winner == "BUY" else bot.state.short
                loser = bot.state.short if finishing_winner == "BUY" else bot.state.long
                broker.emit_close(loser.deal_id, "SL", loser.stop + (
                    D("-0.1") if loser.direction == "BUY" else D("0.1")))
                broker.emit_close(winner.deal_id, "TP", winner.take_profit)
                bot.tick()
                self.assertEqual(bot.state.completed_cycles, 1)
                self.assertFalse(bot.state.continuation_managed)
                self.assertEqual(bot.state.phase, "FILTER")

    def test_s4_to_s5_size_change_uses_each_leg_size_and_does_not_scale_general(self):
        sizes = (D("10"), D("10"), D("10"), D("10"), D("20"),
                 D("20"), D("20"), D("20"), D("20"))
        for reopened_direction in ("BUY", "SELL"):
            with self.subTest(reopened_direction=reopened_direction), \
                    tempfile.TemporaryDirectory() as directory:
                bot = self.make_bot(str(Path(directory) / "state.json"), sizes=sizes)
                broker = bot.capital
                bot._start_pair_common("initial filter", continuation=False, preflight_done=True)
                expected_general = D("5")
                immutable_anchor = (bot.state.long.original_trigger_level
                                    if reopened_direction == "BUY"
                                    else bot.state.short.original_trigger_level)
                for scenario in range(1, 5):
                    leg = bot.state.long if reopened_direction == "BUY" else bot.state.short
                    old_deal_id = leg.deal_id
                    distance = abs(leg.current_entry - leg.confirmed_stop)
                    broker.emit_close(old_deal_id, "SL", leg.stop + (
                        D("-0.1") if reopened_direction == "BUY" else D("0.1")))
                    bot._tick_cycle()
                    expected_general += D("1")
                    if scenario >= 2:
                        expected_general += distance * D("10")
                    mutations_before_reentry = len(broker.mutations)
                    broker.execute_order(leg.trigger_id, immutable_anchor + (
                        D("0.05") if reopened_direction == "BUY" else D("-0.05")))
                    bot._tick_cycle()
                    if scenario == 1:
                        expected_general += distance * D("10")
                    expected_general += D("0.5") if scenario < 4 else D("1")
                    self.assertEqual(bot.state.general_recovery, expected_general)
                    if scenario == 4:
                        reopened = bot.state.long if reopened_direction == "BUY" else bot.state.short
                        survivor = bot.state.short if reopened_direction == "BUY" else bot.state.long
                        self.assertEqual(reopened.size, D("20"))
                        self.assertEqual(survivor.size, D("10"))
                        self.assertNotEqual(reopened.deal_id, old_deal_id)
                        self.assertEqual(reopened.original_trigger_level, immutable_anchor)
                        for current in (reopened, survivor):
                            distance_s5 = D("5")
                            remaining = max(
                                D("0"), expected_general - distance_s5 * current.size
                            ) / current.size
                            expected_tp = current.current_entry + distance_s5 + remaining \
                                if current.direction == "BUY" else \
                                current.current_entry - distance_s5 - remaining
                            self.assertEqual(current.take_profit, expected_tp)
                            puts = [item for item in broker.mutations
                                    if item[0] == "PUT" and item[1] == current.deal_id]
                            self.assertEqual(puts[-1][3], expected_tp)
                            self.assertEqual(
                                broker.positions_by_id[current.deal_id]["profitLevel"], expected_tp
                            )
                        before = (bot.state.general_recovery, bot.state.scenario,
                                  len(bot.state.recovery_events), len(broker.mutations))
                        bot._tick_cycle()
                        self.assertEqual(before, (bot.state.general_recovery, bot.state.scenario,
                                                  len(bot.state.recovery_events),
                                                  len(broker.mutations)))
                        broker.emit_close(survivor.deal_id, "SL", survivor.stop + (
                            D("-0.1") if survivor.direction == "BUY" else D("0.1")))
                        broker.emit_close(reopened.deal_id, "TP", reopened.take_profit)
                        expected_actual = sum(
                            ((item["close"] - item["entry"]) * item["size"]
                             if item["direction"] == "BUY"
                             else (item["entry"] - item["close"]) * item["size"])
                            for item in broker.deal_journal.values()
                            if item["close"] is not None
                        )
                        bot._tick_cycle()
                        summary = next(item for item in bot.state.completed_attempt_summaries
                                       if item.get("status") == "COMPLETED_CYCLE")
                        self.assertEqual(D(summary["result"]), expected_actual)


class AttemptFinancialAccountingRegressionTest(unittest.TestCase):
    def make_bot(self, path: str, *, mirror: bool = False) -> tuple[Bot, Leg, Leg]:
        bot = Bot.__new__(Bot)
        bot.cfg = Settings(
            dry_run=False, demo=True, api_key="key", identifier="id", password="password",
            size=D("10"), state_file=path, diagnostic_log_file=str(Path(path).with_suffix(".log")),
        )
        bot.capital = Mock()
        bot.capital.positions.return_value = []
        bot.capital.working_orders.return_value = []
        bot.telegram = Mock()
        bot.notification_worker = None
        bot.transaction_worker = None
        bot._queued_report_parts = set()
        bot._queued_log_parts = set()
        bot.state = CycleState(active=True, scenario=1, phase="BOTH_OPEN")
        bot.state.cycle_id = bot.state.active_attempt_id = bot.state.diagnostic_cycle_number = 291
        bot.state.cycle_attempt = 1
        bot.state.attempt_counter = 291
        buy = Leg("BUY", D("4147.32"), D("4147.32"), deal_id="buy-291",
                  deal_reference="buy-ref", size=D("10"), stop_distance=D("1"),
                  stop=D("4146.32"))
        sell = Leg("SELL", D("4145.78"), D("4145.78"), deal_id="sell-291",
                   deal_reference="sell-ref", size=D("10"), stop_distance=D("1"),
                   stop=D("4146.78"))
        bot.state.long, bot.state.short = buy, sell
        bot.strategy = Strategy(bot.cfg, bot.state)
        first, waiting = (buy, sell) if mirror else (sell, buy)
        first_fill = D("4146.23") if mirror else D("4146.80")
        first_event = normalize_event({
            "id": "buy-close" if mirror else "sell-close",
            "dateUTC": "2026-09-29T07:39:37.901Z" if mirror else "2026-09-29T07:39:38.605Z",
            "dealId": first.deal_id, "source": "SL", "type": "POSITION",
            "status": "ACCEPTED", "details": {
                "level": str(first_fill), "size": 10, "direction": (
                    "SELL" if first.direction == "BUY" else "BUY"
                ), "stopLevel": str(first.stop),
            },
        })
        bot._remember_close_event(first, first_event, scenario_at_close=1)
        bot._schedule_initial_pair_report(first, "SL", first_fill, waiting)
        bot.state.manual = True
        bot.state.phase = "MANUAL"
        bot.state.save(path)
        return bot, first, waiting

    @staticmethod
    def result_for(leg: Leg) -> dict:
        buy = leg.direction == "BUY"
        return {
            "deal_id": leg.deal_id, "event_id": "buy-close" if buy else "sell-close",
            "source": "SL", "type": "POSITION", "status": "ACCEPTED",
            "fill": "4146.23" if buy else "4146.80", "size": "10",
            "execution_time": (
                "2026-09-29T07:39:37.901+00:00" if buy
                else "2026-09-29T07:39:38.605+00:00"
            ),
        }

    def apply_worker_result(self, bot: Bot, waiting: Leg, *, repeat: bool = False) -> None:
        worker = Mock(spec=NotificationHistoryWorker)
        completed = {"key": bot.state.pending_notification_jobs[0]["key"],
                     "result": self.result_for(waiting)}
        worker.results.return_value = [completed]
        bot.notification_worker = worker
        bot._tick_notifications()
        if repeat:
            worker.results.return_value = [completed]
            bot._tick_notifications()

    def test_delayed_initial_double_sl_is_accounted_once_and_survives_cleanup_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot, _, waiting = self.make_bot(path)
            general_before = bot.state.general_recovery
            bot.state = CycleState.load(path)
            bot.strategy = Strategy(bot.cfg, bot.state)
            waiting = bot.state.long
            self.apply_worker_result(bot, waiting, repeat=True)

            self.assertEqual(bot.state.attempt_result_total, D("-21.10"))
            summary = bot.state.completed_attempt_summaries[0]
            self.assertEqual((summary["cycle_id"], summary["attempt_id"],
                              summary["cycle_attempt"]), (291, 291, 1))
            self.assertEqual(summary["actual_result_status"], "CONFIRMED")
            self.assertEqual({item["deal_id"] for item in summary["closes"]},
                             {"buy-291", "sell-291"})
            self.assertEqual(sum((D(item["result"]) for item in summary["closes"]), D("0")),
                             D("-21.10"))
            self.assertEqual(bot.state.general_recovery, general_before)
            self.assertEqual(len(bot.state.deal_history), 2)
            self.assertIn("сохранён в attempt_result_total", bot.telegram.send.call_args.args[0])

            # A delivered report disappears independently of the financial summary.
            bot.state.report_outbox = [{"id": "delayed", "key": "delayed", "parts": [
                {"number": 1, "text": "-21.10", "status": "pending"},
            ]}]
            telegram = Mock(spec=Telegram)
            telegram.delivery_acks.return_value = [
                {"report_id": "delayed", "part": 1, "status": "delivered"}
            ]
            telegram.document_acks.return_value = []
            bot.telegram = telegram
            bot.notification_worker = None
            bot._tick_notifications()
            self.assertEqual(bot.state.report_outbox, [])
            self.assertEqual(bot.state.completed_attempt_summaries[0]["result"], "-21.10")

            bot.telegram = Mock()
            bot._exit_manual_mode()
            self.assertEqual(bot.state.deal_history, [])
            self.assertEqual(bot.state.attempt_result_total, D("-21.10"))
            self.assertEqual(bot.state.completed_attempt_summaries[0]["result"], "-21.10")
            bot.strategy.begin(D("4200.5"), D("4200"))
            self.assertEqual(bot.state.general_recovery, D("0"))
            bot.state.save(path)
            restored = CycleState.load(path)
            self.assertEqual(restored.attempt_result_total, D("-21.10"))
            self.assertEqual(restored.completed_attempt_summaries[0]["result"], "-21.10")

    def test_mirrored_order_and_late_result_use_original_snapshot_not_new_legs(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot, _, waiting = self.make_bot(path, mirror=True)
            job = bot.state.pending_notification_jobs[0]
            bot.state.cycle_id = 292
            bot.state.active_attempt_id = 292
            bot.state.long = Leg("BUY", D("5000"), D("5000"), deal_id="new-buy", size=D("20"))
            bot.state.short = Leg("SELL", D("4999"), D("4999"), deal_id="new-sell", size=D("20"))
            self.assertTrue(bot._apply_delayed_initial_pair_result(job, self.result_for(waiting)))
            self.assertEqual(bot.state.attempt_result_total, D("-21.10"))
            summary = bot.state.completed_attempt_summaries[0]
            self.assertEqual(summary["cycle_id"], 291)
            self.assertNotIn("new-buy", {item["deal_id"] for item in summary["closes"]})
            self.assertEqual(bot.state.long.deal_id, "new-buy")

    def test_incomplete_or_conflicting_delayed_evidence_stays_pending(self):
        with tempfile.TemporaryDirectory() as directory:
            bot, _, waiting = self.make_bot(str(Path(directory) / "state.json"))
            job = bot.state.pending_notification_jobs[0]
            incomplete = self.result_for(waiting); incomplete["size"] = None
            self.assertFalse(bot._apply_delayed_initial_pair_result(job, incomplete))
            conflicting = self.result_for(waiting); conflicting["deal_id"] = "foreign"
            self.assertFalse(bot._apply_delayed_initial_pair_result(job, conflicting))
            self.assertEqual(bot.state.attempt_result_total, D("0"))
            self.assertEqual(bot.state.completed_attempt_summaries, [])
            self.assertEqual(len(bot.state.pending_notification_jobs), 1)

    def double_sl_bot(self, path: str) -> Bot:
        bot = self.make_bot(path)[0]
        bot.state.pending_notification_jobs.clear()
        bot.state.manual = False
        bot.state.long.current_entry, bot.state.short.current_entry = D("100"), D("99.5")
        bot.state.long.deal_id, bot.state.short.deal_id = "buy", "sell"
        bot.state.long.size = bot.state.short.size = D("10")
        bot.state.long.stop, bot.state.short.stop = D("99"), D("100.5")
        bot.state.deal_history.clear()
        bot.state.attempt_result_total = D("0")
        bot.state.realized_loss_money = D("0")
        bot.state.realized_losses = D("0")
        events = [
            normalize_event({"id": "buy-sl", "dateUTC": "2026-09-28T12:04:18Z",
                             "dealId": "buy", "source": "SL", "type": "POSITION",
                             "status": "ACCEPTED", "details": {"level": 99, "size": 10,
                                                                    "stopLevel": 99}}),
            normalize_event({"id": "sell-sl", "dateUTC": "2026-09-28T12:04:20Z",
                             "dealId": "sell", "source": "SL", "type": "POSITION",
                             "status": "ACCEPTED", "details": {"level": 100.6, "size": 10,
                                                                    "stopLevel": 100.5}}),
        ]
        raw = [event.raw for event in events]
        bot.capital.activity.return_value = raw
        bot._apply_confirmed_stop_event(bot.state.long, events[0], raw)
        bot._apply_confirmed_stop_event(bot.state.short, events[1], raw)
        return bot

    def test_sequential_double_sl_summary_uses_complete_owned_ledger(self):
        with tempfile.TemporaryDirectory() as directory:
            bot = self.double_sl_bot(str(Path(directory) / "state.json"))
            with patch("trader.app.time.time", return_value=1000):
                bot._begin_double_sl_pause([(bot.state.short, D("100.6"))])
            summary = bot.state.attempt_history[0]
            self.assertEqual(summary["result"], "-21.0")
            self.assertEqual({item["event_id"] for item in summary["closes"]},
                             {"buy-sl", "sell-sl"})
            self.assertEqual(bot.state.attempt_result_total, D("-21.0"))

    def test_legacy_single_close_summary_is_enriched_without_reaccounting_or_cross_attempt(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = self.double_sl_bot(path)
            bot.state.attempt_history = [{
                "attempt_id": 291, "cycle_id": 291, "cycle_attempt": 1,
                "status": "DOUBLE_SL_CONTINUATION", "result": "-21.0", "scenario": 1,
                "closes": [{"deal_id": "buy", "direction": "BUY", "fill": "99",
                            "result": "-10"}],
            }]
            bot.state.attempt_result_total = D("-21")
            bot.state.deal_history.append({
                "deal_id": "foreign", "direction": "BUY", "entry": "10", "size": "10",
                "cycle_id": 291, "cycle_attempt": 2, "attempt_id": 292,
                "close_source": "SL", "close_level": "9", "close_size": "10",
                "close_event_id": "foreign-sl", "close_event_type": "POSITION",
                "close_event_status": "ACCEPTED", "close_execution_time": "2026-09-28T12:05:00+00:00",
            })
            bot.state.save(path)
            bot.state = CycleState.load(path); bot.strategy = Strategy(bot.cfg, bot.state)
            before = bot.state.attempt_result_total
            bot._enrich_attempt_summaries_from_ledger()
            summary = bot.state.attempt_history[0]
            self.assertEqual(bot.state.attempt_result_total, before)
            self.assertEqual({item["deal_id"] for item in summary["closes"]}, {"buy", "sell"})

            bot.state.pending_finalization = {"kind": "RESET_BY_USER", "cycle_id": 291,
                                              "attempt_id": 291}
            bot.state.active = True
            with self.assertLogs("trader.app", level="INFO") as captured:
                bot._resume_cycle_reset()
            archive = next(line for line in captured.output if "CYCLE_LEDGER_RESET" in line)
            self.assertIn('"deal_id": "sell"', archive)
            self.assertEqual(bot.state.attempt_result_total, before)


class SQLiteStateStoreRegressionTest(unittest.TestCase):
    def initialize_bot_without_network(self, cfg):
        capital = Mock(); capital.streaming_tokens = Mock()
        with patch("trader.app.CapitalClient", return_value=capital), \
                patch("trader.app.QuoteStream", return_value=Mock()), \
                patch("trader.app.Telegram", return_value=Mock()), \
                patch("trader.app.NotificationHistoryWorker", return_value=Mock()), \
                patch("trader.app.TransactionHistoryWorker", return_value=Mock()):
            return Bot(cfg)

    def test_bot_initialization_ignores_unsupported_flock_and_legacy_lock_file(self):
        with tempfile.TemporaryDirectory() as directory:
            state_path = str(Path(directory) / "state.json")
            cfg = Settings(
                dry_run=True, state_file=state_path,
                diagnostic_log_file=str(Path(directory) / "diagnostic.log"),
            )
            saved = CycleState(
                active=True, scenario=4, cycle_id=17, cycle_attempt=2,
                active_attempt_id=18, general_recovery=D("42.75"),
                deal_history=[{"deal_id": "deal-17", "direction": "BUY",
                               "entry": "100", "size": "10"}],
                pending_transaction_jobs=[{"key": "tx-17", "deal_ids": ["deal-17"]}],
                scenario_nine_close_operations={
                    "BUY": {"operation_id": "pending-close", "deal_id": "deal-17"}
                },
            )
            saved.save(state_path)
            legacy_lock = Path(str(database_path(state_path)) + ".lock")
            legacy_lock.write_text("left by an older release", encoding="utf-8")
            unsupported_flock = Mock(side_effect=OSError(38, "Function not implemented"))
            fake_fcntl = types.SimpleNamespace(
                flock=unsupported_flock, LOCK_EX=2, LOCK_NB=4,
            )

            with patch.dict(sys.modules, {"fcntl": fake_fcntl}):
                first = self.initialize_bot_without_network(cfg)
                second = self.initialize_bot_without_network(cfg)

            unsupported_flock.assert_not_called()
            self.assertFalse(hasattr(first, "_state_writer_lock"))
            self.assertFalse(hasattr(second, "_state_writer_lock"))
            for bot in (first, second):
                self.assertEqual(bot.state.scenario, 4)
                self.assertEqual(bot.state.general_recovery, D("42.75"))
                self.assertEqual(bot.state.deal_history[0]["deal_id"], "deal-17")
                self.assertEqual(bot.state.pending_transaction_jobs[0]["key"], "tx-17")
                self.assertEqual(
                    bot.state.scenario_nine_close_operations["BUY"]["operation_id"],
                    "pending-close",
                )
            self.assertTrue(legacy_lock.exists())

    def test_actual_result_accepts_partial_execution_ledger_not_last_fill_times_full_size(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = Bot.__new__(Bot)
            bot.cfg = Settings(dry_run=False, api_key="key", identifier="id", password="pw",
                               state_file=path)
            bot.state = CycleState(
                pending_actual_attempt_id=44,
                pending_actual_deal_ids=["buy-partial"],
                attempt_history=[{"attempt_id": 44, "status": "PENDING"}],
                deal_history=[{"deal_id": "buy-partial", "direction": "BUY",
                               "entry": "100", "size": "10", "close_level": None}],
            )
            bot.capital = Mock()
            bot.capital.activity.return_value = [
                {"id": "execution-a", "dealId": "buy-partial", "source": "SL",
                 "type": "POSITION", "status": "ACCEPTED",
                 "dateUTC": "2026-09-01T10:00:00Z",
                 "details": {"level": "98.90", "size": "7"}},
                {"id": "execution-a", "dealId": "buy-partial", "source": "SL",
                 "type": "POSITION", "status": "ACCEPTED",
                 "dateUTC": "2026-09-01T10:00:00Z",
                 "details": {"level": "98.9", "size": "7.0"}},
                {"id": "execution-b", "dealId": "buy-partial", "source": "SL",
                 "type": "POSITION", "status": "ACCEPTED",
                 "dateUTC": "2026-09-01T10:00:01Z",
                 "details": {"level": "98.80", "size": "3"}},
            ]
            self.assertTrue(bot._refresh_actual_attempt_result())
            self.assertEqual(bot.state.attempt_history[0]["actual_result"], "-11.30")
            self.assertEqual(len(bot.state.deal_history[0]["partial_closes"]), 1)
            restored = CycleState.load(path)
            self.assertEqual(restored.attempt_result_total, D("-11.30"))

    def test_scenario_nine_unknown_deletes_are_not_repeated_after_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            state = CycleState(active=True, scenario=9, phase="SCENARIO_9_CLOSING",
                               active_attempt_id=51, cycle_id=50,
                               scenario_nine_triggers_verified=True)
            state.long = Leg("BUY", D("100"), D("100"), size=D("10"),
                             deal_id="buy", open=True)
            state.short = Leg("SELL", D("99"), D("99"), size=D("10"),
                              deal_id="sell", open=True)
            state.long.stop = state.long.take_profit = None
            state.short.stop = state.short.take_profit = None
            state.scenario_nine_close_operations = {
                direction: {"operation_id": f"s9:{direction}", "cycle_id": 50,
                            "attempt_id": 51, "deal_id": deal_id,
                            "direction": direction, "state": "MAY_HAVE_SENT", "reference": ""}
                for direction, deal_id in (("BUY", "buy"), ("SELL", "sell"))
            }
            state.save(path)
            bot = Bot.__new__(Bot); bot.cfg = Settings(
                dry_run=False, api_key="key", identifier="id", password="pw", state_file=path)
            bot.state = CycleState.load(path); bot.strategy = Strategy(bot.cfg, bot.state)
            bot.capital = Mock(); bot.telegram = Mock()
            bot.capital.positions.return_value = [
                {"position": {"dealId": "buy", "direction": "BUY"},
                 "market": {"epic": bot.cfg.epic}},
                {"position": {"dealId": "sell", "direction": "SELL"},
                 "market": {"epic": bot.cfg.epic}},
            ]
            bot.capital.activity.return_value = []
            bot._enter_manual_nine()
            bot.capital.close_position.assert_not_called()
            self.assertEqual(set(bot.state.scenario_nine_close_operations), {"BUY", "SELL"})

    def test_initial_pair_aborts_after_reference_commit_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            bot = Bot.__new__(Bot)
            bot.cfg = Settings(dry_run=False, api_key="key", identifier="id", password="pw",
                               state_file=path,
                               diagnostic_log_file=str(Path(directory) / "diagnostic.log"))
            bot.state = CycleState(); bot.state.save(path)
            bot.strategy = Strategy(bot.cfg, bot.state)
            bot.capital = Mock()
            bot.capital.quote.return_value = (D("100"), D("100.2"))
            bot.capital.open_position.return_value = "buy-reference"
            bot.capital.positions.return_value = []
            bot.telegram = Mock(); bot.execution_policy = ExecutionPolicy()
            bot._flat_checks = 0
            original_save = StateStore.save

            def fail_reference_commit(store, payload, **kwargs):
                long = payload.get("long") or {}
                if long.get("pending_market_reference") == "buy-reference":
                    return original_save(store, payload, fault=lambda stage: (
                        (_ for _ in ()).throw(RuntimeError("reference commit fault"))
                        if stage == "before_commit" else None
                    ), **kwargs)
                return original_save(store, payload, **kwargs)

            with patch.object(StateStore, "save", new=fail_reference_commit):
                with self.assertRaisesRegex(StorageFailure, "reference commit fault"):
                    bot._start_pair_common("test", continuation=False, preflight_done=True)
            self.assertEqual(bot.capital.open_position.call_count, 1)
            self.assertEqual(bot.capital.open_position.call_args.args[1], "BUY")
            committed = CycleState.load(path)
            self.assertTrue(committed.long.pending_market_unknown_post)
            self.assertEqual(committed.long.pending_market_reference, "")

    def test_corrupt_legacy_state_blocks_empty_database_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            legacy = Path(directory) / "bot_state.json"
            original = b'{"active":'
            legacy.write_bytes(original)
            with self.assertRaisesRegex(StorageFailure, "cannot be migrated"):
                CycleState.load(str(legacy))
            self.assertEqual(legacy.read_bytes(), original)
            with sqlite3.connect(database_path(legacy)) as db:
                self.assertIsNone(db.execute(
                    "SELECT payload FROM state_snapshot WHERE singleton=1"
                ).fetchone())

    def test_json_migration_is_transactional_one_time_and_preserves_source(self):
        with tempfile.TemporaryDirectory() as directory:
            legacy = Path(directory) / "bot_state.json"
            payload = {
                "active": True, "scenario": 3, "cycle_id": 7, "cycle_attempt": 2,
                "general_recovery": "68.30", "processed_events": ["execution-1"],
                "pending_transaction_jobs": [{"key": "tx", "deal_ids": ["deal-1"]}],
                "report_outbox": [{"id": "report", "parts": []}],
                "deal_history": [{"deal_id": "deal-1", "partial_closes": [{
                    "event_id": "part-1", "source": "SL", "fill": "98.9", "size": "7"}]}],
            }
            original = json.dumps(payload).encode(); legacy.write_bytes(original)
            migrated = CycleState.load(str(legacy))
            self.assertEqual((migrated.scenario, migrated.general_recovery), (3, D("68.30")))
            self.assertEqual(legacy.read_bytes(), original)
            self.assertTrue(database_path(legacy).exists())
            legacy.write_text(json.dumps({"scenario": 9}), encoding="utf-8")
            self.assertEqual(CycleState.load(str(legacy)).scenario, 3)
            with sqlite3.connect(database_path(legacy)) as db:
                self.assertEqual(db.execute(
                    "SELECT value FROM metadata WHERE key='schema_version'"
                ).fetchone()[0], "1")
                self.assertEqual(db.execute("SELECT COUNT(*) FROM broker_executions").fetchone()[0], 1)

    def test_failed_sqlite_commit_rolls_back_disk_and_in_memory_state(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            state = CycleState(general_recovery=D("8")); state.save(path)
            state.general_recovery = D("99")
            original_save = StateStore.save

            def fail_before_commit(store, payload, **kwargs):
                return original_save(store, payload, fault=lambda stage: (
                    (_ for _ in ()).throw(RuntimeError("fault"))
                    if stage == "before_commit" else None
                ), **kwargs)

            with patch.object(StateStore, "save", new=fail_before_commit):
                with self.assertRaisesRegex(StorageFailure, "fault"):
                    state.save(path)
            self.assertEqual(state.general_recovery, D("8"))
            self.assertEqual(CycleState.load(path).general_recovery, D("8"))

    def test_online_backup_is_consistent(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "state.json")
            CycleState(general_recovery=D("12.34")).save(path)
            backup = Path(directory) / "snapshot.sqlite3"
            StateStore(path).backup(backup)
            with sqlite3.connect(backup) as db:
                raw = json.loads(db.execute(
                    "SELECT payload FROM state_snapshot WHERE singleton=1"
                ).fetchone()[0])
            self.assertEqual(raw["general_recovery"], "12.34")

    def test_scenario_nine_owners_receive_independent_deal_id_snapshots(self):
        deal_ids = ["a", "b"]
        state = CycleState(pending_actual_deal_ids=list(deal_ids), pending_finalization={
            "kind": "SCENARIO_9", "deal_ids": list(deal_ids),
        }, pending_transaction_jobs=[{"key": "tx", "deal_ids": list(deal_ids)}])
        state.pending_actual_deal_ids.clear()
        self.assertEqual(state.pending_finalization["deal_ids"], deal_ids)
        self.assertEqual(state.pending_transaction_jobs[0]["deal_ids"], deal_ids)

    def test_installer_preserves_sqlite_database_wal_shm_and_backups(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source"; target = Path(directory) / "target"
            source.mkdir(); target.mkdir()
            (source / "main.py").write_text("new", encoding="utf-8")
            for name in ("bot_state.sqlite3", "bot_state.sqlite3-wal",
                         "bot_state.sqlite3-shm", "bot_state.sqlite3.backup-1"):
                (source / name).write_text("new", encoding="utf-8")
                (target / name).write_text("runtime", encoding="utf-8")
            copy_project(source, target)
            for name in ("bot_state.sqlite3", "bot_state.sqlite3-wal",
                         "bot_state.sqlite3-shm", "bot_state.sqlite3.backup-1"):
                self.assertEqual((target / name).read_text(), "runtime")

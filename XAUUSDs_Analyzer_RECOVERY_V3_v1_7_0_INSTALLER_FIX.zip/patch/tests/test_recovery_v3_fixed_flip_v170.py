"""RECOVERY V3 fixed nominal anchors, no trailing or partial TP. PAPER ONLY."""
import time
import pytest
from fastapi.testclient import TestClient
from analyzer.engine import PaperEngine, Settings, Tick
import analyzer.server as server


def q(m,s,b,spread=.23):
    return Tick((m*60+s)*1000,round(b,8),round(b+spread,8))


def config(**overrides):
    data=dict(recovery_enabled=True,recovery_variant='fixed_flip',volume_lots=.03,
              recovery_v3_initial_lots=.03,recovery_v3_work_lots=.03,
              recovery_v3_stop_gap=1.50, recovery_v3_initial_tp_distance=.25)
    data.update(overrides)
    return Settings(**data)


def first_buy(**settings):
    e=PaperEngine(config(**settings))
    e.on_tick(q(0,0,3999.50));e.start();e.on_tick(q(0,50,4000.00))
    e.on_tick(q(1,0,4000.00))
    assert e.pending and e.pending.side=='BUY' and e.pending.level==pytest.approx(4001.)
    e.on_tick(q(1,1,4000.77))  # ASK=4001
    assert e.position and e.position.entry==pytest.approx(4001)
    return e


def first_sell(**settings):
    e=PaperEngine(config(**settings))
    e.on_tick(q(0,0,4000.50));e.start();e.on_tick(q(0,50,4000.00))
    e.on_tick(q(1,0,4000.00))
    assert e.pending and e.pending.side=='SELL' and e.pending.level==pytest.approx(3999.)
    e.on_tick(q(1,1,3999.))
    assert e.position and e.position.side=='SELL'
    return e


def first_flip():
    e=first_buy()
    e.on_tick(q(1,2,3999.50))
    assert e.recovery and e.recovery.active
    return e


def test_v3_fixed_gap_initial_tp_sl_and_follow_candles():
    e=first_buy()
    assert e.position.sl==pytest.approx(3999.50)
    assert e.position.tp==pytest.approx(4001.25)
    assert e._position_lots(e.position)==.03
    assert e.settings.recovery_v3_stop_gap==1.5


def test_initial_tp_returns_to_new_closed_m1():
    e=first_buy();e.on_tick(q(1,2,4001.25))
    assert e.recovery is None and e.position is None
    assert e.trades[-1]['result']=='TP'
    assert e.pending is None
    e.on_tick(q(1,40,4001.60));e.on_tick(q(2,0,4001.60))
    assert e.pending is not None


def test_first_sl_auto_flips_on_same_tick_and_nominal_anchors_stay_fixed():
    e=first_flip();r=e.recovery
    assert r.variant=='fixed_flip' and not r.stepped_mode
    assert (r.buy_anchor,r.sell_anchor)==pytest.approx((4001,3999.50))
    assert (r.original_buy_anchor,r.original_sell_anchor)==pytest.approx((4001,3999.50))
    assert r.active.side=='SELL' and r.active.entry==pytest.approx(3999.50)
    assert r.active.stop==pytest.approx(4001.00)
    assert r.active.tp==pytest.approx(3998.00)
    assert r.active.trail_step_index==-1
    assert len(r.pending_stops)==1 and r.pending_stops[0]['side']=='BUY'
    assert r.partial_tps==0


def test_slippage_changes_realized_pnl_not_stored_entry_levels():
    e=first_buy()
    e.on_tick(q(1,2,3999.40))  # crossed nominal SL by .10
    r=e.recovery
    assert r.original_sl_exit==pytest.approx(3999.40)
    assert r.sell_anchor==pytest.approx(3999.50)
    assert r.buy_anchor==pytest.approx(4001.00)
    assert r.active.entry==pytest.approx(3999.40)
    assert r.active.stop==pytest.approx(4001.00)
    assert r.realized_weighted_points==pytest.approx(-1.60*.03)
    assert r.active.tp==pytest.approx(3997.80)
    e.on_tick(q(1,3,4000.90)) # Ask=4001.13 SL SELL at 4001, BUY entry 4001.13
    assert r.active.side=='BUY'
    assert r.active.entry==pytest.approx(4001.13)
    assert r.active.stop==pytest.approx(3999.50)
    assert r.buy_anchor==pytest.approx(4001.00)
    assert r.sell_anchor==pytest.approx(3999.50)
    assert r.reentries==1
    e.on_tick(q(1,4,3999.40))
    assert r.active.side=='SELL' and r.active.entry==pytest.approx(3999.40)
    assert r.active.stop==pytest.approx(4001)
    assert r.buy_anchor==pytest.approx(4001)
    assert r.sell_anchor==pytest.approx(3999.50)


def test_recovery_target_recovers_losses_only_not_original_025_profit():
    e=first_flip()
    r=e.recovery
    assert r.active.tp==pytest.approx(3998.)
    e.on_tick(q(1,3,3997.77))  # Ask 3998.00 => TP at exact recovery target
    assert e.recovery is None
    assert e.trades[-1]['result']=='RECOVERED'
    assert e.trades[-1]['recovery_variant']=='fixed_flip'
    assert e.trades[-1]['pnl_weighted_points_lots']==pytest.approx(0)
    assert e.summary()['recovered']==1
    e.on_tick(q(1,50,3997.8));e.on_tick(q(2,0,3997.8))
    assert e.pending is not None


def test_sell_initial_stop_opens_buy_at_fixed_other_side():
    e=first_sell()
    assert e.position.sl==pytest.approx(4000.50)
    e.on_tick(q(1,2,4000.30))  # Ask 4000.53 >= stop
    r=e.recovery
    assert (r.sell_anchor,r.buy_anchor)==pytest.approx((3999.,4000.50))
    assert r.active and r.active.side=='BUY'
    assert r.active.entry==pytest.approx(4000.53)
    assert r.active.stop==pytest.approx(3999.)
    assert r.active.tp>4001.50


def test_stop_never_trails_and_no_partial_tp_when_price_moves_but_not_target():
    e=first_flip();r=e.recovery;leg=r.active
    original_stop=leg.stop
    e.on_tick(q(1,3,3999.00));e.on_tick(q(1,4,3998.50))
    assert r.active is leg
    assert leg.stop==original_stop
    assert leg.next_take_index==0 and leg.trail_step_index==-1
    assert r.partial_tps==0 and e.recovery_partial_tps==0
    assert not any(a['type']=='recovery_partial_tp' for a in r.actions)


def test_snapshot_roundtrip_keeps_nominal_refs_and_pending_opposite():
    e=first_flip();e.on_tick(q(1,3,4000.90))
    restored=PaperEngine.from_snapshot(e.to_snapshot())
    assert restored.recovery.variant=='fixed_flip'
    assert (restored.recovery.buy_anchor,restored.recovery.sell_anchor)==pytest.approx((4001,3999.5))
    assert restored.recovery.active.side=='BUY'
    assert restored.recovery.active.entry==pytest.approx(4001.13)
    restored.on_tick(q(1,4,3999.45))
    assert restored.recovery.active.side=='SELL'
    assert restored.recovery.buy_anchor==pytest.approx(4001)


def test_v3_manual_move_changes_nominal_band_but_slippage_never_does():
    e=first_flip();r=e.recovery
    e.move_trigger('recovery',4001.25,'BUY')
    assert r.buy_anchor==pytest.approx(4001.25)
    assert r.sell_anchor==pytest.approx(3999.75)
    assert r.active.stop==pytest.approx(4001.25)
    assert r.active.tp==pytest.approx(3998.)
    assert r.pending_stops[0]['level']==pytest.approx(4001.25)
    e.on_tick(q(1,3,4001.10))
    assert r.active.side=='BUY'
    assert r.active.entry==pytest.approx(4001.33)
    assert r.sell_anchor==pytest.approx(3999.75)


def test_v3_manual_partial_close_recalculates_tp_and_keeps_stop_fixed():
    e=first_flip();r=e.recovery
    e.manual_close('recovery',.01)
    assert r.active.lots==pytest.approx(.02)
    assert r.active.stop==pytest.approx(4001)
    assert r.active.tp<3998.0  # more debt / smaller remaining lots
    assert r.buy_anchor==pytest.approx(4001)


def test_settings_v1_v2_untouched_and_v3_lot_guard():
    with pytest.raises(ValueError,match='V3'):
        Settings(recovery_enabled=True,recovery_variant='fixed_flip',volume_lots=.05)
    assert Settings().recovery_variant=='classic'
    assert Settings(recovery_enabled=True,recovery_variant='extreme',volume_lots=.03).recovery_v2_support_sl_distance==1.0
    assert Settings(recovery_enabled=False,recovery_variant='fixed_flip').volume_lots==.10


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD','secure-random-v3-paper-test-password')
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as c:
        yield c


def test_v3_configuration_is_selectable_through_api(client):
    auth=('admin','secure-random-v3-paper-test-password')
    payload=dict(trigger_distance=1,tp_distance=.25,sl_distance=3,volume_lots=.03,
                 recovery_enabled=True,recovery_variant='fixed_flip',
                 recovery_v3_initial_lots=.03,recovery_v3_work_lots=.05,
                 recovery_v3_trigger_distance=.8,recovery_v3_initial_tp_distance=.2,
                 recovery_v3_stop_gap=1.5)
    res=client.post('/api/settings',json=payload,auth=auth)
    assert res.status_code==200,res.text
    s=res.json()['settings']
    assert s['recovery_variant']=='fixed_flip'
    assert s['recovery_v3_stop_gap']==1.5
    assert s['recovery_v3_work_lots']==.05
    assert s['recovery_v2_support_sl_distance']==1.0


def test_v3_backtest_grid_selects_locked_single_sl_and_no_trailing_multiplier(client):
    auth=('admin','secure-random-v3-paper-test-password')
    request=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1.0],tps=[.25],
                 sls=[1.5,2.0],volume_lots=.03,recovery_enabled=True,
                 recovery_variant='fixed_flip',recovery_v3_work_lots=.03,
                 recovery_trail_offsets=[.7,.9],
                 recovery_v2_reentry_offsets=[.5,1.],recovery_v2_trail_steps=[.1,.2])
    res=client.post('/api/backtests',json=request,auth=auth)
    assert res.status_code==200,res.text
    job_id=res.json()['id'];deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        job=client.get('/api/backtests/'+job_id,auth=auth).json()
        if job['status'] in ('completed','failed'):break
        time.sleep(.075)
    assert job['status']=='completed',job.get('error')
    variants=client.get('/api/backtests/'+job_id+'/variants',auth=auth).json()
    assert len(variants)==2
    assert {x['config']['recovery_v3_stop_gap'] for x in variants}=={1.5,2.0}
    assert all(x['config']['recovery_v3_work_lots']==.03 for x in variants)


def test_v3_ui_separate_tab_and_settings(client):
    page=client.get('/',auth=('admin','secure-random-v3-paper-test-password')).text
    assert 'data-recovery-mode="fixed_flip"' in page
    assert 'class="recovery-settings recovery-v3-settings hidden"' in page
    assert 'name="recovery_v3_stop_gap"' in page
    assert 'name="recovery_v3_work_lots"' in page
    assert '/assets/app.js?v=1.7.0' in page
    assert 'Нет трейлинга, нет частичных закрытий' in page


def test_extreme_spread_overlap_does_not_fabricate_reverse_fill():
    e=first_buy()
    # Bid below saved SELL and Ask above saved BUY on the same tick.
    e.on_tick(q(1,2,3999.40,spread=2.10))
    r=e.recovery
    assert r and r.active is None
    assert len(r.pending_stops)==1 and not r.pending_stops[0]['armed']
    assert any(x['type']=='v3_spread_overlap' for x in r.actions)
    assert (r.buy_anchor,r.sell_anchor)==pytest.approx((4001.0,3999.50))
    e.on_tick(q(1,3,4000.30))
    assert r.pending_stops[0]['armed']
    assert r.active is None
    e.on_tick(q(1,4,3999.40))
    assert r.active and r.active.side=='SELL'

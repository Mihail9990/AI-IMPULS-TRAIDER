"""Two independent V2 stop distances: first fixed TP leg vs later trailing legs."""
import time
import pytest
from fastapi.testclient import TestClient

from analyzer.engine import PaperEngine, Settings, Tick
import analyzer.server as server


def q(minute, second, bid, spread=.23):
    return Tick((minute * 60 + second) * 1000, bid, round(bid + spread, 8))


def buy_first(initial_sl, support_sl):
    e = PaperEngine(Settings(recovery_enabled=True, recovery_variant='extreme',
                             volume_lots=.03, recovery_v2_initial_lots=.03,
                             recovery_v2_initial_sl_distance=initial_sl,
                             recovery_v2_support_sl_distance=support_sl))
    e.on_tick(q(0, 0, 3999.5));e.start()
    e.on_tick(q(0, 50, 4000));e.on_tick(q(1, 0, 4000))
    e.on_tick(q(1, 1, 4000.77))
    assert e.position and e.position.side == 'BUY'
    return e


def test_first_stop_1_50_but_recovery_stop_0_70_and_trails_independently():
    e = buy_first(1.50, .70)
    assert e.position.tp == pytest.approx(4001.25)
    assert e.position.sl == pytest.approx(3999.50)
    e.on_tick(q(1, 2, 3999.50))
    assert e.recovery and not e.recovery.active
    assert e.recovery.pending_stops[0]['level'] == pytest.approx(3999.50)
    e.on_tick(q(1, 3, 3999.30))
    p = e.recovery.active
    assert p and p.side == 'SELL'
    assert p.entry == pytest.approx(3999.30)
    assert p.stop == pytest.approx(4000.00)   # 3999.30 + .70 (not 1.50)
    assert p.tp == pytest.approx(3997.80)   # recover 1.50 only, no extra .25
    e.on_tick(q(1, 4, 3998.85))  # Ask 3999.08, 0.22 favorable, two steps
    assert p.stop == pytest.approx(3999.80)
    assert e.settings.recovery_v2_initial_sl_distance == pytest.approx(1.50)
    assert e.settings.recovery_v2_support_sl_distance == pytest.approx(.70)


def test_first_stop_0_65_and_recovery_stop_1_80_mirror_sell():
    e=PaperEngine(Settings(recovery_enabled=True, recovery_variant='extreme',
                           volume_lots=.03,recovery_v2_initial_lots=.03,
                           recovery_v2_initial_sl_distance=.65,
                           recovery_v2_support_sl_distance=1.80))
    e.on_tick(q(0, 0, 4000.5));e.start()
    e.on_tick(q(0, 40, 4000.0));e.on_tick(q(1, 0, 4000.0))
    e.on_tick(q(1, 1, 3998.99))
    assert e.position.side == 'SELL'
    assert e.position.sl == pytest.approx(3999.64)
    e.on_tick(q(1, 2, 3999.50))  # ask=3999.73, crosses initial SL
    r=e.recovery
    assert r is not None and r.active is None
    assert r.pending_stops[0]['side']=='BUY'
    assert r.pending_stops[0]['level']==pytest.approx(3999.73)
    e.on_tick(q(1, 3, 3999.60))  # ask=3999.83, BUY STOP execution
    p=e.recovery.active
    assert p is not None and p.side=='BUY'
    assert p.entry==pytest.approx(3999.83)
    assert p.stop==pytest.approx(3998.03)  # not initial .65


def test_saved_snapshot_preserves_both_stop_parameters_without_coupling():
    e=buy_first(1.70, .55)
    restored=PaperEngine.from_snapshot(e.to_snapshot())
    assert restored.settings.recovery_v2_initial_sl_distance == pytest.approx(1.70)
    assert restored.settings.recovery_v2_support_sl_distance == pytest.approx(.55)
    restored.on_tick(q(1, 2, 3999.30))
    assert restored.recovery is not None
    restored.on_tick(q(1, 3, 3999.00))
    assert restored.recovery.active.stop == pytest.approx(3999.55)


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD', 'random-password-for-v2-independent-sl')
    monkeypatch.setenv('WEB_USERNAME', 'admin')
    monkeypatch.setenv('DATA_SOURCE', 'demo')
    monkeypatch.setenv('DATA_DIR', str(tmp_path))
    with TestClient(server.app) as c:
        yield c


def test_backtest_v2_independent_support_grid_overrides_legacy_generic(client):
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1.0],
                 tps=[.25],sls=[1.20,1.50],volume_lots=.03,
                 recovery_enabled=True,recovery_variant='extreme',
                 recovery_trail_offsets=[2.50],
                 recovery_v2_support_sl_distances=[.70,.90],
                 recovery_v2_reentry_offsets=[.50],recovery_v2_trail_steps=[.10])
    res=client.post('/api/backtests',json=payload,auth=('admin','random-password-for-v2-independent-sl'))
    assert res.status_code==200,res.text
    job_id=res.json()['id'];deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        job=client.get('/api/backtests/'+job_id,auth=('admin','random-password-for-v2-independent-sl')).json()
        if job['status'] in ('completed','failed'):
            break
        time.sleep(.08)
    assert job['status']=='completed',job.get('error')
    variants=client.get(f'/api/backtests/{job_id}/variants',auth=('admin','random-password-for-v2-independent-sl')).json()
    assert len(variants)==4
    assert {x['config']['recovery_v2_initial_sl_distance'] for x in variants}=={1.20,1.50}
    assert {x['config']['recovery_v2_support_sl_distance'] for x in variants}=={.70,.90}
    assert {x['config']['sl_distance'] for x in variants}=={1.20,1.50}
    assert not any(x['config']['recovery_v2_support_sl_distance']==2.50 for x in variants)


def test_v2_settings_two_stops_have_clear_labels_and_distinct_keys(client):
    html=client.get('/',auth=('admin','random-password-for-v2-independent-sl')).text
    assert 'SL только первой позиции с TP 0.25' in html
    assert 'Начальный SL каждой позиции RECOVERY (сразу с трейлингом)' in html
    assert 'name="recovery_v2_initial_sl_distance"' in html
    assert 'name="recovery_v2_support_sl_distance"' in html
    assert 'name="recovery_v2_support_sl_distances"' in html
    assert '/assets/app.js?v=1.7.0' in html


def test_v2_backtest_rejects_invalid_independent_sl_support_grid(client):
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1],
                 tps=[.25],sls=[1],volume_lots=.03,recovery_enabled=True,
                 recovery_variant='extreme',recovery_v2_support_sl_distances=[0])
    res=client.post('/api/backtests',json=payload,auth=('admin','random-password-for-v2-independent-sl'))
    assert res.status_code==400


def test_classic_mode_sl_settings_not_changed_by_v2_split():
    e=PaperEngine(Settings(recovery_enabled=True,recovery_variant='classic',volume_lots=.01,
                           sl_distance=3.,recovery_trail_start_offset=1.0,
                           recovery_v2_initial_sl_distance=.5,
                           recovery_v2_support_sl_distance=.7))
    e.on_tick(q(0, 0, 3999.5));e.start()
    e.on_tick(q(0, 50, 4000));e.on_tick(q(1, 0, 4000));e.on_tick(q(1, 1, 4000.77))
    assert e.position.sl==pytest.approx(3998)

@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_RECOVERY_V3_v1_7_0.ps1"
if errorlevel 1 (
  echo ERROR: The update was not completed. Existing analyzer files were preserved or rolled back.
)
echo.
pause

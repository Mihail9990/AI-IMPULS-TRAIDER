﻿param([string]$TargetDirectory='')
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$files=@(
  'analyzer\engine.py',
  'analyzer\backtest.py',
  'analyzer\live.py',
  'analyzer\server.py',
  'web\app.js',
  'web\index.html',
  'web\terminal.css',
  'tests\test_recovery_v3_fixed_flip_v170.py',
  'tests\test_recovery_v2_api_v160.py',
  'tests\test_recovery_v2_separate_sl_v161.py',
  'tests\test_reset_statistics_v141.py',
  'tools\precheck_v170.py'
)
function Main {
  Write-Host 'XAUUSD.s Strategy Analyzer - RECOVERY V3 v1.7.0 (installer fix)' -ForegroundColor Cyan
  Write-Host 'Requires INSTALLED v1.6.1. V1 and V2 retained. No real orders or broker calls.'
  Write-Host 'UNCHANGED: .env, passwords, real MT5, SQLite history, tick cache, Caddy and HTTPS.'
  $manifest=Join-Path $here 'SHA256SUMS.txt'
  if(-not (Test-Path -LiteralPath $manifest -PathType Leaf)){throw 'Missing SHA256SUMS.txt'}
  $hashes=@{}
  foreach($line in (Get-Content -LiteralPath $manifest)) {
    if($line -match '^([0-9a-fA-F]{64})\s{2}(.+)$'){$hashes[$matches[2]]=$matches[1].ToLowerInvariant()}
  }
  foreach($rel in $files) {
    $key='patch/'+($rel.Replace('\','/'))
    $src=Join-Path (Join-Path $here 'patch') $rel
    if(-not (Test-Path -LiteralPath $src -PathType Leaf)){throw ('Missing '+$key)}
    if(-not $hashes.ContainsKey($key)){throw ('Missing SHA-256 for '+$key)}
    if((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hashes[$key]) {
      throw ('SHA-256 mismatch: '+$key)
    }
  }
  Write-Host '[OK] All 12 patch file checksums verified.' -ForegroundColor Green

  if(-not $TargetDirectory){
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description='Select installed Analyzer v1.6.1 folder containing start_windows.bat and .env'
    $dialog.ShowNewFolderButton=$false
    if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){
      Write-Host 'Cancelled. Nothing changed.';return
    }
    $TargetDirectory=$dialog.SelectedPath
  }
  $target=[System.IO.Path]::GetFullPath($TargetDirectory)
  foreach($rel in @('start_windows.bat','.env','analyzer\engine.py','analyzer\server.py',
                    'analyzer\live.py','web\index.html','web\app.js')) {
    if(-not (Test-Path -LiteralPath (Join-Path $target $rel) -PathType Leaf)){
      throw ('Wrong installed analyzer directory. Missing '+$rel)
    }
  }
  $oldEngine=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\engine.py'))
  if(-not($oldEngine.Contains('recovery_v2_initial_sl_distance') -and
          $oldEngine.Contains('recovery_v2_support_sl_distance') -and
          $oldEngine.Contains('strategy_manual_open'))) {
    throw 'Installed v1.6.1 is required (or the files do not match a supported Analyzer). No files changed.'
  }
  $envFile=[System.IO.File]::ReadAllText((Join-Path $target '.env'))
  $port=8765
  $m=[regex]::Match($envFile,'(?m)^\s*WEB_PORT\s*=\s*(\d+)')
  if($m.Success){$port=[int]$m.Groups[1].Value}
  if(Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue){
    if(@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue).Count -gt 0){
      throw ('Analyzer still listening on '+$port+'. Close start_windows.bat before update. No files changed.')
    }
  }
  $python=Join-Path $target '.venv\Scripts\python.exe'
  $usePyLauncher=$false
  if(-not (Test-Path -LiteralPath $python -PathType Leaf)){
    $candidate=Get-Command py -ErrorAction SilentlyContinue
    if(-not $candidate){throw 'Python not found for read-only state precheck'}
    $python=$candidate.Source
    $usePyLauncher=$true
  }
  $backup=Join-Path $target ('backup_RECOVERY_V3_v1_7_0_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
  New-Item -ItemType Directory -Path $backup -Force|Out-Null
  $check=Join-Path (Join-Path $here 'patch') 'tools\precheck_v170.py'
  if($usePyLauncher){ & $python -3.13 $check --target $target --backup (Join-Path $backup 'db') }
  else { & $python $check --target $target --backup (Join-Path $backup 'db') }
  if($LASTEXITCODE -ne 0){
    throw 'Active virtual cycle or database preflight failed. Installed files have NOT been modified.'
  }

  $existed=@{}
  try{
    foreach($rel in $files){
      $dest=Join-Path $target $rel
      $existed[$rel]=Test-Path -LiteralPath $dest -PathType Leaf
      if($existed[$rel]){
        $bk=Join-Path $backup $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $bk) -Force|Out-Null
        Copy-Item -LiteralPath $dest -Destination $bk -Force
      }
    }
    foreach($rel in $files){
      $src=Join-Path (Join-Path $here 'patch') $rel
      $dest=Join-Path $target $rel
      New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
      Copy-Item -LiteralPath $src -Destination $dest -Force
      Write-Host ('Updated '+$rel)
    }
  }catch{
    Write-Host 'Copy failed: rolling back replaced source files...' -ForegroundColor Yellow
    foreach($rel in $files){
      $dest=Join-Path $target $rel
      $bk=Join-Path $backup $rel
      if(Test-Path -LiteralPath $bk -PathType Leaf){Copy-Item -LiteralPath $bk -Destination $dest -Force}
      elseif($existed.ContainsKey($rel) -and -not $existed[$rel] -and (Test-Path -LiteralPath $dest -PathType Leaf)){
        Remove-Item -LiteralPath $dest -Force
      }
    }
    throw
  }
  Write-Host '[OK] RECOVERY V3 v1.7.0 installed. Old V1 / V2 logic, histories and settings preserved.' -ForegroundColor Green
  Write-Host ('Backup (including database snapshot if present): '+$backup)
  Write-Host 'Start start_windows.bat. Open the SAME HTTPS address on Android and refresh.'
  Write-Host 'Open Strategy settings, select V3 FIXED SL tab, configure and save BEFORE /start.'
}
try { Main } catch { Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red; exit 1 }

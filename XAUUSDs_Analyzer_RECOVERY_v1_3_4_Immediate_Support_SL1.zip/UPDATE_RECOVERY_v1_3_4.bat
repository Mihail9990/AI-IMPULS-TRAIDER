@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_RECOVERY_v1_3_4.ps1"
set "code=%ERRORLEVEL%"
echo.
if not "%code%"=="0" echo Update was NOT completed. Check the error above.
pause
exit /b %code%

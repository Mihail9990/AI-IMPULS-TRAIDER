﻿param([string]$TargetFolder = '')
$ErrorActionPreference = 'Stop'
try {
  Write-Host 'XAUUSD.s Strategy Analyzer - RECOVERY v1.3.4' -ForegroundColor Cyan
  Write-Host 'Non-destructive update: HISTORY, ticks, .env/password and MT5 are PRESERVED.' -ForegroundColor Green
  $patchDir = Join-Path $PSScriptRoot 'patch'
  $manifestPath = Join-Path $PSScriptRoot 'SHA256SUMS.txt'
  $files = @(
    'analyzer\engine.py', 'analyzer\server.py',
    'analyzer\backtest.py', 'web\app.js', 'web\index.html',
    'tests\test_recovery.py', 'tests\test_web.py',
    'tools\check_v134_upgrade.py', 'RECOVERY_v1_3_4_README_RU.md'
  )
  if (!(Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'Unpack the ENTIRE ZIP first (SHA256SUMS.txt is missing).'
  }
  $manifest = @{}
  foreach ($line in (Get-Content -LiteralPath $manifestPath -Encoding UTF8)) {
    if ($line -match '^([a-fA-F0-9]{64})\s+(.+)$') {
      $manifest[$matches[2].Trim()] = $matches[1].ToLowerInvariant()
    }
  }
  foreach ($rel in $files) {
    $src = Join-Path $patchDir $rel
    $key = $rel.Replace('\','/')
    if (!(Test-Path -LiteralPath $src -PathType Leaf)) {throw "Missing patch file: $rel"}
    if (!$manifest.ContainsKey($key)) {throw "Missing SHA256 for: $key"}
    $hash = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $manifest[$key]) {throw "SHA256 mismatch for: $rel"}
  }
  Write-Host '[OK] All patch checksums verified.' -ForegroundColor Green
  if ([string]::IsNullOrWhiteSpace($TargetFolder)) {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Select the INSTALLED XAUUSDs analyzer folder containing start_windows.bat'
    $dlg.ShowNewFolderButton = $false
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
      throw 'Cancelled by user; nothing changed.'
    }
    $TargetFolder = $dlg.SelectedPath
  }
  $TargetFolder = (Resolve-Path -LiteralPath $TargetFolder).Path
  if (!(Test-Path -LiteralPath (Join-Path $TargetFolder 'start_windows.bat')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder '.env')) -or
      !(Test-Path -LiteralPath (Join-Path $TargetFolder 'analyzer\engine.py'))) {
    throw 'Wrong installation folder. Choose the folder with start_windows.bat and .env.'
  }
  $port = 8765
  foreach ($line in (Get-Content -LiteralPath (Join-Path $TargetFolder '.env') -Encoding UTF8)) {
    if ($line -match '^WEB_PORT\s*=\s*(\d+)\s*$') {$port = [int]$matches[1]}
  }
  $listeners = @(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
  if ($listeners.Count -gt 0) {throw "Analyzer port $port is open. Stop start_windows.bat FIRST. Do not close MT5."}
  $py = Join-Path $TargetFolder '.venv\Scripts\python.exe'
  if (!(Test-Path -LiteralPath $py -PathType Leaf)) {throw 'Existing .venv Python not found.'}
  & $py (Join-Path $patchDir 'tools\check_v134_upgrade.py') --target $TargetFolder
  if ($LASTEXITCODE -ne 0) {throw 'Preflight failed. No files have been changed.'}
  $backupDir = Join-Path $TargetFolder ('backup_recovery_v1_3_4_CODE_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  $replaced = New-Object System.Collections.ArrayList
  foreach ($rel in $files) {
    $old = Join-Path $TargetFolder $rel
    if (Test-Path -LiteralPath $old) {
      $dst = Join-Path $backupDir $rel
      New-Item -ItemType Directory -Path (Split-Path -Path $dst -Parent) -Force | Out-Null
      Copy-Item -LiteralPath $old -Destination $dst -Force
    }
  }
  try {
    foreach ($rel in $files) {
      $old = Join-Path $TargetFolder $rel
      $src = Join-Path $patchDir $rel
      New-Item -ItemType Directory -Path (Split-Path -Path $old -Parent) -Force | Out-Null
      [void]$replaced.Add($rel)
      Copy-Item -LiteralPath $src -Destination $old -Force
      Write-Host "  Updated $rel"
    }
    & $py -m compileall -q (Join-Path $TargetFolder 'analyzer')
    if ($LASTEXITCODE -ne 0) {throw 'Python compilation failed.'}
    Push-Location $TargetFolder
    try {
      & $py -c 'import analyzer.engine'
      if ($LASTEXITCODE -ne 0) {throw 'Python engine import failed.'}
      Write-Host '[OK] Python module imports cleanly.' -ForegroundColor Green
    } finally { Pop-Location }
  } catch {
    Write-Host 'Patch failed, restoring previous source files.' -ForegroundColor Yellow
    foreach ($rel in $replaced) {
      $saved = Join-Path $backupDir $rel
      $old = Join-Path $TargetFolder $rel
      if (Test-Path -LiteralPath $saved) {
        Copy-Item -LiteralPath $saved -Destination $old -Force -ErrorAction SilentlyContinue
      } else {
        Remove-Item -LiteralPath $old -Force -ErrorAction SilentlyContinue
      }
    }
    throw
  }
  Write-Host ''
  Write-Host '[OK] RECOVERY v1.3.4 installed. NO RESULTS WERE CLEARED.' -ForegroundColor Green
  Write-Host "Source backup: $backupDir"
  Write-Host 'Restart start_windows.bat and press Ctrl+F5 in the VPS browser.'
  exit 0
} catch {
  Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
  exit 1
}

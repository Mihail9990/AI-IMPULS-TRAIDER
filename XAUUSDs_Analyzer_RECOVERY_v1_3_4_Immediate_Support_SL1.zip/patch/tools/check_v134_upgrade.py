"""Non-destructive preflight for a v1.3.1/v1.3.2/v1.3.3 -> v1.3.4 source-only patch.

Stdlib only. Never modifies the SQLite DB or any .env file. An active
RECOVERY session cannot be migrated safely because upgrades must not change the execution rules mid-cycle.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3
import sys


def env_file_values(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name,value=line.split('=',1)
        result[name.strip()]=value.strip().strip('"').strip("'")
    return result


def ensure_safe(target: Path) -> int:
    target=target.resolve()
    if not all((target/f).is_file() for f in ('start_windows.bat','.env','analyzer/engine.py')):
        raise RuntimeError('Select the INSTALLED analyzer folder, not the new ZIP folder.')
    src=(target/'analyzer/engine.py').read_text(encoding='utf-8')
    required=('recovery_first_fill','recovery_fixed_tp','stepped_mode')
    if any(x not in src for x in required):
        raise RuntimeError('This patch requires RECOVERY v1.3.1, v1.3.2 or v1.3.3. Install v1.3.1 first.')
    env=env_file_values(target/'.env')
    source=(env.get('DATA_SOURCE','mt5') or 'mt5').lower()
    symbol=env.get('MT5_SYMBOL','XAUUSD.s') if source=='mt5' else 'SYNTHETIC-DEMO'
    safe_name=''.join(x for x in symbol if x.isalnum() or x in '._-')
    data_root=Path(env.get('DATA_DIR','') or str(target/'data'))
    if not data_root.is_absolute():
        data_root=target/data_root
    db=data_root/f'{source}_{safe_name}'/'analyzer.sqlite3'
    if not db.is_file():
        print('OK: no saved live RECOVERY state exists at the normal database path.')
        return 0
    connection=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True,timeout=5)
    try:
        row=connection.execute("SELECT value FROM state WHERE key='live_snapshot'").fetchone()
    finally:
        connection.close()
    if row:
        snapshot=json.loads(row[0])
        if snapshot.get('recovery') is not None:
            raise RuntimeError(
                'An unfinished RECOVERY cycle is saved in the database. '
                'Resume the OLD version and finish the virtual cycle, or '
                'manually stop it using the analyzer control. '
                'Then shut down the analyzer cleanly and retry. '
                'NO history was deleted.'
            )
    print('OK: no unfinished RECOVERY cycle. Existing results and .env remain intact.')
    return 0


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--target',type=Path,required=True)
    args=parser.parse_args()
    try:
        sys.exit(ensure_safe(args.target))
    except Exception as exc:
        print('PRECHECK FAILED:',str(exc),file=sys.stderr)
        sys.exit(2)

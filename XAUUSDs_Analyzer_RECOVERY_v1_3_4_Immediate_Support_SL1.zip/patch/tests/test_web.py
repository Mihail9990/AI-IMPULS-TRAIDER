from fastapi.testclient import TestClient
from analyzer.server import app
import pytest


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD','test-access-password')
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(app) as cli:
        yield cli


def auth():return ('admin','test-access-password')


def test_auth_required(client):
    assert client.get('/api/status').status_code==401
    assert client.get('/',auth=auth()).status_code==200
    assert 'XAUUSD.s Strategy Analyzer' in client.get('/').text or client.get('/').status_code==401


def test_demo_session_and_setting(client):
    r=client.get('/api/status',auth=auth())
    assert r.status_code==200
    assert r.json()['source']=='demo'
    assert client.post('/api/control/start',auth=auth()).json()['mode']=='running'
    p={'trigger_distance':1.5,'tp_distance':.25,'sl_distance':3,'volume_lots':.1,'commission_per_lot_roundtrip':0}
    assert client.post('/api/settings',json=p,auth=auth()).status_code==200
    assert client.post('/api/control/force_stop',auth=auth()).status_code==200


def test_backtest_validation(client):
    payload={'start_date':'2050-01-01','end_date':'2050-01-02','distances':[1], 'tps':[.25], 'sls':[3]}
    assert client.post('/api/backtests',json=payload,auth=auth()).status_code==400
    assert client.get('/api/backtests',auth=auth()).status_code==200


def test_demo_chart_and_same_origin_protection(client):
    candles=client.get('/api/chart',auth=auth())
    assert candles.status_code==200 and len(candles.json())>100
    assert client.post('/api/control/start',auth=auth(),headers={'Origin':'https://attacker.example'}).status_code==403


def test_historical_grid_runs_with_holdout_replay_and_regimes(client):
    import time
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',
                 distances=[.5,1],tps=[.25],sls=[3])
    create=client.post('/api/backtests',json=payload,auth=auth())
    assert create.status_code==200,create.text
    run_id=create.json()['id']
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        job=client.get(f'/api/backtests/{run_id}',auth=auth()).json()
        if job['status'] in ('completed','failed'):break
        time.sleep(.08)
    assert job['status']=='completed',job['error']
    variants=client.get(f'/api/backtests/{run_id}/variants',auth=auth()).json()
    assert len(variants)==2
    for v in variants:
        assert 'train' in v['summary'] and 'holdout' in v['summary']
        assert v['summary']['train']['trades']+v['summary']['holdout']['trades']<=v['summary']['trades']
    regimes=client.get(f'/api/backtests/{run_id}/regimes',auth=auth())
    assert regimes.status_code==200 and isinstance(regimes.json(),list)
    for variant in variants:
        trades=client.get(f"/api/variants/{variant['id']}/trades",auth=auth()).json()
        if trades:
            replay=client.get(f"/api/replay/{trades[0]['db_id']}",auth=auth())
            assert replay.status_code==200
            assert replay.json()['source']=='demo'
            assert len(replay.json()['candles'])>0
            break
    else:
        pytest.fail('Expected a closed virtual trade in synthetic history')


def test_recovery_settings_api_and_historical_variants(client):
    p={'trigger_distance':1,'tp_distance':.25,'sl_distance':3,
       'volume_lots':.01,'commission_per_lot_roundtrip':0,
       'recovery_enabled':True,'recovery_core_lots':.01,
       'recovery_reentry_lots':.12,'recovery_hedge_lots':.13,
       'recovery_trail_activation':0,'recovery_trail_start_offset':1.00,
       'recovery_trail_step':.10,'recovery_partial_lots':.03}
    updated=client.post('/api/settings',json=p,auth=auth())
    assert updated.status_code==200,updated.text
    status=client.get('/api/status',auth=auth()).json()
    assert status['settings']['recovery_enabled'] is True
    assert status['settings']['recovery_trail_activation'] == 0
    assert status['settings']['recovery_trail_start_offset'] == 1.0
    assert status['recovery'] is None
    bad=dict(p,volume_lots=.1)
    assert client.post('/api/settings',json=bad,auth=auth()).status_code==409
    assert 'recovery' in client.get('/',auth=auth()).text.lower()
    run=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1],
             tps=[.25],sls=[3],volume_lots=.01,recovery_enabled=True,
             recovery_trail_offsets=[1.00,1.50])
    created=client.post('/api/backtests',json=run,auth=auth())
    assert created.status_code==200,created.text
    run_id=created.json()['id']
    import time
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        job=client.get(f'/api/backtests/{run_id}',auth=auth()).json()
        if job['status'] in ('completed','failed'):
            break
        time.sleep(.08)
    assert job['status']=='completed',job['error']
    variants=client.get(f'/api/backtests/{run_id}/variants',auth=auth()).json()
    assert len(variants)==2
    assert {v['config']['recovery_trail_start_offset'] for v in variants} == {1.0,1.5}
    for v in variants:
        assert v['config']['recovery_enabled'] is True
        summary=v['summary']
        assert 'recovered' in summary and 'unresolved_recovery' in summary
        assert 'max_equity_drawdown_points' in summary
        assert 'equity_points' in summary['train']
        assert 'equity_delta_points' in summary['holdout']
    exported=client.get(f'/api/backtests/{run_id}/export.csv',auth=auth())
    assert exported.status_code==200 and 'unresolved_recovery' in exported.text

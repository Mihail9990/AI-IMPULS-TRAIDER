#!/usr/bin/env python3
"""Read-only MT5 market-data analyzer with local HTTP UI. No trade API calls."""
import argparse, copy, hashlib, hmac, ipaddress, json, logging, os, secrets, sys, threading, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from analyzer.core import GROUPS,IDS
from analyzer.engine import analyze

ROOT=Path(__file__).resolve().parent
CONFIG_PATH=ROOT/'settings.json'
KEY_PATH=ROOT/'access_key.txt'
WEB=ROOT/'web'
LOG=logging.getLogger('xau')
TIMEFRAMES={'M1':'TIMEFRAME_M1','M5':'TIMEFRAME_M5','M15':'TIMEFRAME_M15','M30':'TIMEFRAME_M30','H1':'TIMEFRAME_H1','H4':'TIMEFRAME_H4'}
DEFAULTS={'symbol':'XAUUSD.S','timeframe':'M1','windows':{'small':60,'medium':180,'large':600},
          'enabled':{gid:True for gid in IDS},'terminal_path':'','refresh_seconds':2}


def atomic_json(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)


def validate(raw):
    if not isinstance(raw,dict): raise ValueError('Настройки должны быть объектом.')
    config=copy.deepcopy(DEFAULTS)
    symbol=raw.get('symbol',config['symbol']); tf=raw.get('timeframe',config['timeframe'])
    if not isinstance(symbol,str) or not 1<=len(symbol.strip())<=40 or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-#' for c in symbol.strip()): raise ValueError('Некорректное имя инструмента.')
    if tf not in TIMEFRAMES: raise ValueError('Недопустимый таймфрейм.')
    config['symbol']=symbol.strip(); config['timeframe']=tf
    path=raw.get('terminal_path','')
    if not isinstance(path,str) or len(path)>500 or '\x00' in path: raise ValueError('Некорректный путь к терминалу.')
    config['terminal_path']=path.strip()
    w=raw.get('windows',{}); en=raw.get('enabled',{})
    if not isinstance(w,dict) or not isinstance(en,dict): raise ValueError('Некорректные настройки диапазонов или разделов.')
    for k in config['windows']:
        n=w.get(k,config['windows'][k])
        if type(n) is not int or not 30<=n<=3000: raise ValueError('Диапазон каждого масштаба должен быть от 30 до 3000 свечей.')
        config['windows'][k]=n
    if not config['windows']['small']<config['windows']['medium']<config['windows']['large']:
        raise ValueError('Диапазоны должны возрастать: младший < средний < большой.')
    for k in IDS:
        val=en.get(k,True)
        if type(val) is not bool: raise ValueError('Переключатели должны быть true/false.')
        config['enabled'][k]=val
    rs=raw.get('refresh_seconds',2)
    if type(rs) is not int or not 1<=rs<=30: raise ValueError('Обновление от 1 до 30 секунд.')
    config['refresh_seconds']=rs
    return config


def load_config():
    if not CONFIG_PATH.exists(): return copy.deepcopy(DEFAULTS)
    try: return validate(json.loads(CONFIG_PATH.read_text(encoding='utf-8')))
    except Exception as exc: LOG.warning('Настройки не прочитаны: %s',exc); return copy.deepcopy(DEFAULTS)


def auth_key():
    if KEY_PATH.exists():
        key=KEY_PATH.read_text(encoding='utf-8').strip()
        if len(key)>=24: return key
        raise ValueError('access_key.txt должен содержать не менее 24 символов. Удалите файл для создания нового ключа.')
    key=secrets.token_urlsafe(24)
    fd=os.open(str(KEY_PATH),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w',encoding='utf-8') as f: f.write(key+'\n')
    return key


class Market:
    def __init__(self):
        self.lock=threading.RLock(); self.config=load_config(); self.generation=0; self.stop=threading.Event()
        self.snapshot={'connected':False,'message':'Ожидание MT5…','bars':[],'analysis':None,'tick':None,'updated':None}
        self.cache_key=None; self.cache=None
    def update_config(self,obj):
        with self.lock:
            if isinstance(obj,dict) and 'patch' in obj:
                patch=obj['patch']
                if not isinstance(patch,dict) or any(k not in DEFAULTS for k in patch): raise ValueError('Недопустимое изменение настроек.')
                base=copy.deepcopy(self.config)
                for k,v in patch.items():
                    if k in ('enabled','windows'):
                        if not isinstance(v,dict) or any(key not in base[k] for key in v): raise ValueError('Неизвестный параметр.')
                        base[k].update(v)
                    else: base[k]=v
                conf=validate(base)
            else: conf=validate(obj)
            atomic_json(CONFIG_PATH,conf)
            self.config=conf; self.generation+=1
    def get_config(self):
        with self.lock:return copy.deepcopy(self.config)
    def get_config_generation(self):
        with self.lock:return copy.deepcopy(self.config), self.generation
    def get_snapshot(self):
        with self.lock:
            data=copy.deepcopy(self.snapshot)
            data['config']=copy.deepcopy(self.config)
            data['config_generation']=self.generation
            return data
    def set_error(self,message):
        with self.lock:
            self.snapshot['connected']=False; self.snapshot['message']=message; self.snapshot['updated']=int(time.time())
    def run(self):
        try: import MetaTrader5 as mt5
        except ImportError:
            self.set_error('Модуль MetaTrader5 не установлен или система не Windows. Запустите установку на VPS.')
            return
        initialized=False; connected_path=None
        try:
            while not self.stop.is_set():
                cfg,gen=self.get_config_generation()
                try:
                    if initialized and cfg['terminal_path']!=connected_path:
                        mt5.shutdown(); initialized=False
                    if not initialized:
                        kwargs={'timeout':10000}
                        ok=mt5.initialize(cfg['terminal_path'],**kwargs) if cfg['terminal_path'] else mt5.initialize(**kwargs)
                        if not ok: raise RuntimeError('Не удалось подключить MT5: '+str(mt5.last_error()))
                        initialized=True; connected_path=cfg['terminal_path']
                    info=mt5.terminal_info()
                    if info is None or not info.connected: raise RuntimeError('MT5 не подключён к серверу брокера. Проверьте вход в терминале.')
                    symbol=cfg['symbol']
                    if not mt5.symbol_select(symbol,True):
                        available=mt5.symbols_get() or []
                        matches=[x.name for x in available if x.name.casefold()==symbol.casefold()]
                        if len(matches)!=1 or not mt5.symbol_select(matches[0],True):
                            raise RuntimeError('Инструмент '+symbol+' не найден в MT5. Проверьте точное имя в Обзоре рынка.')
                        symbol=matches[0]
                    tf=getattr(mt5,TIMEFRAMES[cfg['timeframe']]); count=max(cfg['windows']['large']+50,350)
                    # Position 1 explicitly excludes the currently forming bar (position 0).
                    rates=mt5.copy_rates_from_pos(symbol,tf,1,count)
                    cur=mt5.copy_rates_from_pos(symbol,tf,0,1)
                    tick=mt5.symbol_info_tick(symbol)
                    if rates is None or len(rates)==0: raise RuntimeError('История свечей недоступна: '+str(mt5.last_error()))
                    def convert(row):
                        return {'time':int(row['time']),'open':float(row['open']),'high':float(row['high']),
                                'low':float(row['low']),'close':float(row['close']),'tick_volume':int(row['tick_volume']),
                                'real_volume':int(row['real_volume'])}
                    closed=sorted([convert(r) for r in rates],key=lambda x:x['time'])
                    current=convert(cur[-1]) if cur is not None and len(cur)>0 else None
                    bars=closed+([current] if current and current['time']>closed[-1]['time'] else [])
                    digest=hashlib.sha256(json.dumps(closed,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                    cache_key=(gen,cfg['symbol'],cfg['timeframe'],digest)
                    if self.cache_key!=cache_key:
                        self.cache=analyze(closed,cfg); self.cache_key=cache_key
                    tk=None
                    if tick:
                        tt=int(tick.time); age=int(time.time())-tt
                        tk={'bid':float(tick.bid),'ask':float(tick.ask),'spread':float(tick.ask-tick.bid),'time':tt,'age_seconds':age,'stale':age>30 or age<-30}
                    state={'connected':True,'message':'Подключено к MT5' if tk and not tk['stale'] else 'Подключено к MT5; последняя котировка устарела или недоступна',
                           'symbol':cfg['symbol'],'actual_symbol':symbol,'timeframe':cfg['timeframe'],'bars':bars,'analysis':self.cache,'tick':tk,'updated':int(time.time()),
                           'history_requested':count,'history_received':len(closed)}
                    with self.lock:
                        if gen==self.generation: self.snapshot=state
                except Exception as exc:
                    LOG.warning('Источник MT5: %s',exc); self.set_error(str(exc)); self.cache_key=None
                    if initialized:
                        try: mt5.shutdown()
                        except Exception: pass
                        initialized=False
                self.stop.wait(cfg['refresh_seconds'])
        finally:
            if initialized: mt5.shutdown()


class Handler(BaseHTTPRequestHandler):
    server_version='XAUAnalyzer/1.0'
    def log_message(self,*args): pass
    def headers_common(self,code,ctype):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff'); self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
    def respond(self,code,obj):
        data=json.dumps(obj,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self.headers_common(code,'application/json; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def cookie_ok(self):
        from http.cookies import SimpleCookie
        try:
            c=SimpleCookie(); c.load(self.headers.get('Cookie','')); candidate=c.get('xau_session')
            return candidate is not None and hmac.compare_digest(candidate.value,self.server.key)
        except Exception: return False
    def same_origin(self):
        origin=self.headers.get('Origin')
        if not origin: return False
        u=urlparse(origin)
        return u.scheme in ('http','https') and u.netloc==self.headers.get('Host')
    def json_body(self):
        if not self.headers.get('Content-Type','').lower().startswith('application/json'): raise ValueError('Ожидается JSON')
        size=int(self.headers.get('Content-Length','0'))
        if not 1<=size<=16000: raise ValueError('Недопустимый размер запроса')
        return json.loads(self.rfile.read(size).decode('utf-8'))
    def do_GET(self):
        path=urlparse(self.path).path
        assets={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}
        if path in assets:
            file=WEB/assets[path]; data=file.read_bytes(); ct='text/html' if path=='/' else 'text/javascript' if path.endswith('.js') else 'text/css'
            self.headers_common(200,ct+'; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if not self.cookie_ok(): self.respond(401,{'error':'Требуется ключ доступа'}); return
        if path=='/api/config': self.respond(200,self.server.market.get_config()); return
        if path=='/api/snapshot': self.respond(200,self.server.market.get_snapshot()); return
        if path=='/api/groups': self.respond(200,{'groups':[{'id':x,'title':y,'coverage':z} for x,y,z in GROUPS]}); return
        self.respond(404,{'error':'Не найдено'})
    def do_POST(self):
        path=urlparse(self.path).path
        if not self.same_origin(): self.respond(403,{'error':'Запрос с другого источника отклонён'}); return
        try: data=self.json_body()
        except Exception: self.respond(400,{'error':'Некорректный запрос'}); return
        if path=='/api/login':
            candidate=data.get('key','') if isinstance(data,dict) else ''
            if not isinstance(candidate,str) or not hmac.compare_digest(candidate,self.server.key):
                time.sleep(.5); self.respond(401,{'error':'Неверный ключ'}); return
            body=b'{"ok":true}'
            self.headers_common(200,'application/json; charset=utf-8'); self.send_header('Set-Cookie','xau_session='+self.server.key+'; HttpOnly; SameSite=Strict; Path=/')
            self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        if not self.cookie_ok(): self.respond(401,{'error':'Требуется ключ доступа'}); return
        if path=='/api/config':
            try: self.server.market.update_config(data)
            except (ValueError,TypeError) as exc: self.respond(400,{'error':str(exc)}); return
            self.respond(200,{'ok':True}); return
        if path=='/api/logout':
            body=b'{"ok":true}'; self.headers_common(200,'application/json; charset=utf-8')
            self.send_header('Set-Cookie','xau_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
            self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        self.respond(404,{'error':'Не найдено'})


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8765); parser.add_argument('--tailscale-ip',default='',help='Только IPv4 адрес Tailscale 100.64.0.0/10'); parser.add_argument('--no-browser',action='store_true'); args=parser.parse_args()
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',handlers=[logging.StreamHandler(),logging.FileHandler(ROOT/'analyzer.log',encoding='utf-8')])
    try: key=auth_key(); market=Market(); server=ThreadingHTTPServer((args.host,args.port),Handler)
    except Exception as exc: print('Ошибка запуска:',exc); return 1
    server.key=key; server.market=market; server.daemon_threads=True
    remote=None
    if args.tailscale_ip:
        try:
            address=ipaddress.IPv4Address(args.tailscale_ip)
            if address not in ipaddress.IPv4Network('100.64.0.0/10'): raise ValueError('Нужен IPv4 Tailscale из диапазона 100.64.0.0/10')
            if args.host!='127.0.0.1': raise ValueError('Для Tailscale оставьте локальный адрес по умолчанию')
            remote=ThreadingHTTPServer((str(address),args.port),Handler); remote.key=key; remote.market=market; remote.daemon_threads=True
            threading.Thread(target=remote.serve_forever,daemon=True).start()
        except Exception as exc:
            server.server_close(); print('Не удалось открыть Tailscale-адрес:',exc); return 1
    worker=threading.Thread(target=market.run,daemon=True); worker.start()
    local=f'http://127.0.0.1:{args.port}'
    print('\nXAU MT5 ANALYZER — режим только чтения')
    print('На этом компьютере:',local); print('Ключ доступа в файле:',KEY_PATH)
    if remote: print(f'На телефоне через Tailscale: http://{args.tailscale_ip}:{args.port}')
    if args.host!='127.0.0.1': print('Сетевой доступ включён. Используйте VPN и ограничьте порт в брандмауэре Windows.')
    if not args.no_browser: threading.Timer(1,lambda:webbrowser.open(local)).start()
    try: server.serve_forever(poll_interval=.5)
    except KeyboardInterrupt: print('\nОстановка...')
    finally:
        market.stop.set(); server.server_close()
        if remote: remote.shutdown(); remote.server_close()
    return 0
if __name__=='__main__': sys.exit(main())

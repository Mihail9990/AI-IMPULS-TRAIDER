@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo First run INSTALL.bat
  pause
  exit /b 1
)
echo Enter the Tailscale IPv4 address of THIS Windows VPS.
echo It normally begins with 100. To find it, open Tailscale on the VPS.
set /p TS_ADDRESS=Tailscale IPv4: 
.venv\Scripts\python.exe app.py --tailscale-ip %TS_ADDRESS%
if errorlevel 1 pause

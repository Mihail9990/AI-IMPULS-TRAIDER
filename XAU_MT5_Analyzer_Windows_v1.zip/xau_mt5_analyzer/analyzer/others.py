"""Deterministic, individually isolated analysis groups on closed bars."""
from .core import signal, pivots, median_range, safe_div, line
import numpy as np


def s(group,name,d='neutral',description='',bars=None,**kwargs):
    return signal(group,name,d,description,at=bars[-1]['time'] if bars else None,**kwargs)


def priceaction(b):
    if len(b)<22: return []
    g='priceaction'; out=[]; a,c=b[-2],b[-1]; rg=c['high']-c['low']; body=abs(c['close']-c['open'])
    def add(n,d='neutral',msg=''): out.append(s(g,n,d,msg,b))
    if c['high']<a['high'] and c['low']>a['low']: add('Внутренний бар','neutral','Последний закрытый бар внутри предыдущего.')
    if c['high']>a['high'] and c['low']<a['low']: add('Внешний бар','up' if c['close']>c['open'] else 'down','Последний закрытый бар перекрывает диапазон предыдущего.')
    if rg>0:
        upper=c['high']-max(c['open'],c['close']); lower=min(c['open'],c['close'])-c['low']
        if lower>=max(2*body,rg*.55): add('Бычий пин-бар','up','Длинная нижняя тень; направление условное.')
        if upper>=max(2*body,rg*.55): add('Медвежий пин-бар','down','Длинная верхняя тень; направление условное.')
    for n in (4,7):
        if rg<=min(x['high']-x['low'] for x in b[-n:-1]): add(f'Узкий диапазон NR{n}','neutral','Минимальный диапазон среди последних свечей.')
    prior=b[-21:-1]; high=max(x['high'] for x in prior); low=min(x['low'] for x in prior)
    if c['high']>high and c['close']<high: add('Ложный пробой максимума','down',f'Выход выше {high:.2f} и закрытие ниже.')
    elif c['close']>high: add('Пробой максимума диапазона','up',f'Закрытие выше {high:.2f}.')
    if c['low']<low and c['close']>low: add('Ложный пробой минимума','up',f'Выход ниже {low:.2f} и закрытие выше.')
    elif c['close']<low: add('Пробой минимума диапазона','down',f'Закрытие ниже {low:.2f}.')
    return out


def harmonic(b):
    if len(b)<40: return []
    g='harmonic'; p=pivots(b,3); out=[]
    if len(p)<4: return out
    recent=p[-5:]
    a,bp,c,d=recent[-4:]; ab=abs(bp['price']-a['price']); cd=abs(d['price']-c['price'])
    if ab>0 and abs(cd/ab-1)<=.15 and len(b)-1-d['i']<=20:
        out.append(s(g,'AB=CD (приближённо)','up' if d['kind']=='L' else 'down',f'CD/AB={cd/ab:.2f}; допуск 15%.',b))
    if len(recent)<5: return out
    x,a,bp,c,d=recent; xa=abs(a['price']-x['price']); bc=abs(c['price']-bp['price'])
    if xa<=0 or bc<=0 or len(b)-1-d['i']>20: return out
    rab=abs(bp['price']-a['price'])/xa; rad=abs(d['price']-a['price'])/xa; rbc=abs(c['price']-bp['price'])/max(abs(bp['price']-a['price']),1e-12); rcd=abs(d['price']-c['price'])/bc
    direction='up' if d['kind']=='L' else 'down'
    candidates=[]
    if abs(rab-.618)<=.08 and abs(rad-.786)<=.08 and .30<=rbc<=.94 and 1.1<=rcd<=1.8: candidates.append('Gartley')
    if .30<=rab<=.58 and abs(rad-.886)<=.08 and .30<=rbc<=.94 and 1.4<=rcd<=2.8: candidates.append('Bat')
    if abs(rab-.786)<=.08 and 1.19<=rad<=1.70 and .30<=rbc<=.94 and 1.3<=rcd<=2.8: candidates.append('Butterfly')
    if .30<=rab<=.70 and abs(rad-1.618)<=.12 and .30<=rbc<=.94 and 2.0<=rcd<=4.2: candidates.append('Crab')
    for name in candidates:
        out.append(s(g,name+' (приближённо)',direction,f'AB/XA={rab:.2f}, AD/XA={rad:.2f}, BC/AB={rbc:.2f}, CD/BC={rcd:.2f}; обязательна ручная проверка.',b))
    return out


def waves(b):
    g='waves'; p=pivots(b,3); out=[]
    if len(p)>=4:
        q=p[-4:]; vals=[z['price'] for z in q]; direction='up' if vals[-1]>vals[0] else 'down'
        if len(b)-q[-1]['i']<=25:
            out.append(s(g,'ABC: три последовательных колебания',direction,'Приближённая геометрия, не подтверждённый волновой подсчёт.',b))
    if len(p)>=6:
        q=p[-6:]; vals=[z['price'] for z in q]; up=vals[-1]>vals[0]
        if (up and vals[3]>vals[1] and vals[5]>vals[3]) or ((not up) and vals[3]<vals[1] and vals[5]<vals[3]):
            out.append(s(g,'Пять движений: возможный импульс','up' if up else 'down','Эвристика по экстремумам, без полного набора правил Эллиотта.',b))
    return out


def structure(b):
    g='structure'; p=pivots(b,3); h=[x for x in p if x['kind']=='H']; l=[x for x in p if x['kind']=='L']; out=[]
    if len(h)>=2 and len(l)>=2:
        hs='HH' if h[-1]['price']>h[-2]['price'] else 'LH'; ls='HL' if l[-1]['price']>l[-2]['price'] else 'LL'
        d='up' if hs=='HH' and ls=='HL' else 'down' if hs=='LH' and ls=='LL' else 'neutral'
        out.append(s(g,f'Структура {hs} / {ls}',d,'Сравнение двух последних подтверждённых максимумов и минимумов.',b))
        close=b[-1]['close']; prev=b[-2]['close']
        if close>h[-1]['price'] and prev<=h[-1]['price']: out.append(s(g,'Пробой последнего максимума','up',f'Закрытие выше {h[-1]["price"]:.2f}.',b))
        if close<l[-1]['price'] and prev>=l[-1]['price']: out.append(s(g,'Пробой последнего минимума','down',f'Закрытие ниже {l[-1]["price"]:.2f}.',b))
    return out


def smc(b):
    if len(b)<23: return []
    g='smc'; out=[]; a,m,c=b[-3:]; high=max(x['high'] for x in b[-21:-1]); low=min(x['low'] for x in b[-21:-1])
    def add(n,d,msg): out.append(s(g,n,d,msg,b))
    if c['low']>a['high']: add('Бычий FVG','up',f'Между {a["high"]:.2f} и {c["low"]:.2f}; правило по трём свечам, не свидетельство отсутствия сделок.')
    if c['high']<a['low']: add('Медвежий FVG','down',f'Между {c["high"]:.2f} и {a["low"]:.2f}; правило по трём свечам.')
    if c['high']>high and c['close']<high: add('Выход за максимум и возврат','down','Эвристика снятия ликвидности: реальное расположение стопов неизвестно.')
    if c['low']<low and c['close']>low: add('Выход за минимум и возврат','up','Эвристика снятия ликвидности: реальное расположение стопов неизвестно.')
    typical=median_range(b[-30:])
    if abs(c['close']-c['open'])>2*typical and c['close']>c['open'] and m['close']<m['open']:
        add('Возможная бычья зона импульса','up',f'Предыдущая свеча {m["low"]:.2f}–{m["high"]:.2f}; не подтверждает наличие ордеров.')
    if abs(c['close']-c['open'])>2*typical and c['close']<c['open'] and m['close']>m['open']:
        add('Возможная медвежья зона импульса','down',f'Предыдущая свеча {m["low"]:.2f}–{m["high"]:.2f}; не подтверждает наличие ордеров.')
    return out


def wyckoff(b):
    if len(b)<60: return []
    g='wyckoff'; out=[]; c=b[-1]; box=b[-41:-1]; hi=max(x['high'] for x in box); lo=min(x['low'] for x in box)
    prior=b[-60]['close']; trend=(box[0]['close']-prior); rg=max(hi-lo,1e-9)
    if c['low']<lo and c['close']>lo: out.append(s(g,'Spring: выход и возврат в диапазон','up',f'Нижняя граница {lo:.2f}; не подтверждает накопление.',b))
    if c['high']>hi and c['close']<hi: out.append(s(g,'Upthrust: выход и возврат в диапазон','down',f'Верхняя граница {hi:.2f}; не подтверждает распределение.',b))
    if lo<=c['close']<=hi:
        label='Диапазон после снижения' if trend<-.2*rg else 'Диапазон после роста' if trend>.2*rg else 'Боковой диапазон'
        out.append(s(g,label,'neutral','Признак диапазона; это не подтверждённая фаза накопления или распределения.',b))
    return out


def gaps(b):
    g='gaps'; out=[]; start=max(1,len(b)-100)
    for i in range(start,len(b)):
        prev,c=b[i-1],b[i]
        if c['low']>prev['high']:
            lo,hi=prev['high'],c['low']; d='up'
        elif c['high']<prev['low']:
            lo,hi=c['high'],prev['low']; d='down'
        else: continue
        later=b[i+1:]; filled=any(x['low']<=lo if d=='up' else x['high']>=hi for x in later)
        out.append(signal(g,'Ценовой разрыв вверх' if d=='up' else 'Ценовой разрыв вниз',d,
                    f'{lo:.2f}–{hi:.2f}; '+('полностью закрыт' if filled else 'полностью не закрыт на доступных свечах'),at=c['time']))
    return out[-6:][::-1]


def volume(b):
    if len(b)<22: return []
    g='volume'; real=any(x.get('real_volume',0)>0 for x in b[-21:]); key='real_volume' if real else 'tick_volume'; title='реальный объём' if real else 'тиковый объём'
    vals=[float(x.get(key,0)) for x in b[-21:]]; med=float(np.median(vals[:-1])); v=vals[-1]; ratio=safe_div(v,med)
    msg=f'{title}: {v:.0f}; медиана 20 предыдущих свечей: {med:.0f}; коэффициент {ratio:.2f}.'
    out=[s(g,'Объём последней закрытой свечи','neutral',msg,b)]
    if med>0 and ratio>=2: out.append(s(g,'Всплеск объёма','neutral','Объём как минимум в 2 раза выше медианы 20 свечей.',b))
    elif med>0 and ratio<=.5: out.append(s(g,'Пониженный объём','neutral','Объём не превышает половины медианы 20 свечей.',b))
    return out


def ema(a,period):
    a=np.asarray(a,dtype=float); out=np.zeros_like(a); out[0]=a[0]; k=2/(period+1)
    for i in range(1,len(a)): out[i]=a[i]*k+out[i-1]*(1-k)
    return out


def indicators(b):
    if len(b)<35: return []
    g='indicators'; out=[]; close=np.array([x['close'] for x in b],float); hi=np.array([x['high'] for x in b],float); lo=np.array([x['low'] for x in b],float)
    def add(name,dir,msg): out.append(s(g,name,dir,msg,b))
    delta=np.diff(close); gain=np.maximum(delta,0); loss=np.maximum(-delta,0)
    # Wilder's smoothing, initial mean of 14 periods.
    ag=float(np.mean(gain[:14])); al=float(np.mean(loss[:14])); rsis=[]
    for i in range(14,len(gain)):
        ag=(ag*13+gain[i])/14; al=(al*13+loss[i])/14
    rsi=50. if ag==0 and al==0 else 100. if al==0 else 100.-100./(1+ag/al)
    tr=np.maximum(hi[1:]-lo[1:],np.maximum(abs(hi[1:]-close[:-1]),abs(lo[1:]-close[:-1])))
    atr=float(np.mean(tr[:14]))
    for x in tr[14:]: atr=(atr*13+x)/14
    add('RSI (14)','neutral',f'{rsi:.1f}; '+('область выше 70' if rsi>70 else 'область ниже 30' if rsi<30 else 'средняя область')+'. Это не сигнал гарантированного разворота.')
    add('ATR (14)','neutral',f'{atr:.3f} ценовых единиц; показатель диапазона, не направления.')
    ma20=float(np.mean(close[-20:])); ma50=float(np.mean(close[-50:])) if len(close)>=50 else None
    add('SMA (20 / 50)','neutral',f'SMA20 {ma20:.2f}; SMA50 {ma50:.2f}.' if ma50 is not None else f'SMA20 {ma20:.2f}; для SMA50 недостаточно свечей.')
    fast=ema(close,12); slow=ema(close,26); macd=fast-slow; sig=ema(macd,9)
    add('MACD (12, 26, 9)','neutral',f'MACD {macd[-1]:.3f}; сигнал {sig[-1]:.3f}.')
    if macd[-2]<=sig[-2] and macd[-1]>sig[-1]: add('MACD: пересечение вверх','up','На закрытых свечах.')
    if macd[-2]>=sig[-2] and macd[-1]<sig[-1]: add('MACD: пересечение вниз','down','На закрытых свечах.')
    if len(close)>=51:
        old20=np.mean(close[-21:-1]); old50=np.mean(close[-51:-1])
        if old20<=old50 and ma20>ma50: add('Скользящие: пересечение вверх','up','SMA20 пересекла SMA50.')
        if old20>=old50 and ma20<ma50: add('Скользящие: пересечение вниз','down','SMA20 пересекла SMA50.')
    sd=float(np.std(close[-20:])); upper=ma20+2*sd; lower=ma20-2*sd
    add('Полосы Боллинджера (20, 2)','neutral',f'Нижняя {lower:.2f}; средняя {ma20:.2f}; верхняя {upper:.2f}.')
    hh=float(np.max(hi[-14:])); ll=float(np.min(lo[-14:])); stoch=100*safe_div(close[-1]-ll,hh-ll)
    add('Стохастик %K (14)','neutral',f'{stoch:.1f}.')
    return out

HANDLERS={'priceaction':priceaction,'harmonic':harmonic,'waves':waves,'structure':structure,'smc':smc,
          'wyckoff':wyckoff,'gaps':gaps,'volume':volume,'indicators':indicators}

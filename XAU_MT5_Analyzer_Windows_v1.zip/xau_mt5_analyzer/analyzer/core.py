"""Reusable functions and the contract for analysis results."""
from __future__ import annotations
import math
import numpy as np

GROUPS = [
 ('reversal','1. Разворотные фигуры','Двойные и тройные вершины/дна, голова и плечи; упрощённые геометрические правила.'),
 ('continuation','2. Продолжение и диапазон','Треугольники, клинья, прямоугольники, каналы и флаги по оценкам границ.'),
 ('candle1','3. Односвечные','Свечные модели TA-Lib и основные ручные проверки.'),
 ('candle2','4. Двухсвечные','Свечные модели TA-Lib и основные ручные проверки.'),
 ('candle3','5. Три и более свечей','Многосвечные модели TA-Lib и базовые модели звёзд.'),
 ('priceaction','6. Price Action','Внутренний/внешний бар, NR4/NR7, ложный пробой и пробой диапазона.'),
 ('harmonic','7. Гармонические','Приближённые AB=CD, Gartley, Bat, Butterfly, Crab по последним подтверждённым экстремумам.'),
 ('waves','8. Волны','Приближённые структуры ABC и пяти движений. Не полный волновой подсчёт Эллиотта.'),
 ('structure','9. Структура','HH/HL, LH/LL, пробой последних подтверждённых экстремумов.'),
 ('smc','10. Ликвидность и SMC','FVG, снятие максимумов/минимумов, приближённые зоны импульса.'),
 ('wyckoff','11. Вайкофф','Приближённые признаки диапазона, spring и upthrust; фазы не устанавливаются достоверно.'),
 ('gaps','12. Гэпы','Разрывы между диапазонами соседних свечей и их последующее закрытие.'),
 ('volume','13. Объём','Тиковый или реальный объём свечей, всплеск и сравнение с медианой. Профиль объёма не рассчитывается.'),
 ('indicators','14. Индикаторы','RSI, ATR, скользящие средние, MACD, полосы Боллинджера и стохастик.'),
]
IDS = [x[0] for x in GROUPS]
SCALES = [('large','Большой','#ac8cff'),('medium','Средний','#38d7c0'),('small','Младший','#ffb15f')]


def signal(group,name, direction='neutral', description='', **kw):
    result={'group':group,'name':name,'direction':direction,'description':description}
    result.update(kw)
    return result


def pivots(bars, depth=3):
    """Extrema become available only after depth later *closed* bars exist."""
    if len(bars)<2*depth+1: return []
    out=[]
    for i in range(depth,len(bars)-depth):
        h=bars[i]['high']; l=bars[i]['low']
        hs=[b['high'] for b in bars[i-depth:i+depth+1]]
        ls=[b['low'] for b in bars[i-depth:i+depth+1]]
        # Ignore ambiguous bars simultaneously making both extrema.
        # Rightmost point wins on a plateau, with a strict move afterwards.
        hi=h==max(hs) and h>max(hs[depth+1:])
        lo=l==min(ls) and l<min(ls[depth+1:])
        if hi == lo: continue
        out.append({'i':i,'time':bars[i]['time'],'price':float(h if hi else l),'kind':'H' if hi else 'L'})
    # Alternate, keeping the more extreme point of adjacent same-kind pivots.
    clean=[]
    for p in out:
        if clean and clean[-1]['kind']==p['kind']:
            if (p['kind']=='H' and p['price']>clean[-1]['price']) or (p['kind']=='L' and p['price']<clean[-1]['price']): clean[-1]=p
        else: clean.append(p)
    return clean


def median_range(bars):
    return float(np.median([b['high']-b['low'] for b in bars])) if bars else 0.


def fmt(x): return f'{x:.2f}'

def line(points, style='solid', role='shape'):
    return {'points':[[int(p[0]),float(p[1])] for p in points], 'style':style,'role':role}


def safe_div(a,b): return a/b if abs(b)>1e-12 else 0.0


def fit(points):
    if len(points)<2: return None
    xs=np.array([p['i'] for p in points],dtype=float); ys=np.array([p['price'] for p in points],dtype=float)
    if np.ptp(xs)<1: return None
    m,c=np.polyfit(xs,ys,1)
    return float(m),float(c)


def at(model,i): return model[0]*i+model[1]

from .core import GROUPS,IDS,SCALES
from . import graphics, candles, others

MINIMUM={g:30 for g in IDS}
MINIMUM.update({'candle1':6,'candle2':6,'candle3':6,'priceaction':22,'harmonic':40,'waves':30,'structure':30,'smc':23,'wyckoff':60,'gaps':2,'volume':22,'indicators':35})


def analyze(closed,config):
    enabled=config['enabled']; results=[]; statuses={}
    for gid,title,coverage in GROUPS:
        statuses[gid]={'id':gid,'title':title,'coverage':coverage,'enabled':bool(enabled.get(gid)),
                       'status':'disabled' if not enabled.get(gid) else ('insufficient' if len(closed)<MINIMUM[gid] else 'ok'), 'count':0}
    # Graph groups can fail independently and never stop the other groups.
    for gid in ('reversal','continuation'):
        if statuses[gid]['status']!='ok': continue
        try:
            for key,_,_ in SCALES:
                n=config['windows'][key]; subset=closed[-n:]
                if len(subset)<30: continue
                results.extend(graphics.graphic(subset,key,rev=(gid=='reversal'),cont=(gid=='continuation')))
        except Exception as exc:
            statuses[gid]['status']='error'; statuses[gid]['error']=f'{type(exc).__name__}: {exc}'
    try:
        cand, candle_engine=candles.scan(closed,enabled)
        for gid,items in cand.items():
            if statuses[gid]['status']=='ok': results.extend(items)
    except Exception as exc:
        candle_engine='Ошибка свечного движка: '+str(exc)
        for gid in ('candle1','candle2','candle3'):
            if statuses[gid]['status']=='ok': statuses[gid]['status']='error'; statuses[gid]['error']=str(exc)
    for gid,handler in others.HANDLERS.items():
        if statuses[gid]['status']!='ok': continue
        try: results.extend(handler(closed))
        except Exception as exc: statuses[gid]['status']='error'; statuses[gid]['error']=f'{type(exc).__name__}: {exc}'
    for x in results: statuses[x['group']]['count']+=1
    return {'groups':[statuses[x] for x in IDS], 'signals':results, 'candle_engine':candle_engine,
            'closed_bars':len(closed),'windows':config['windows'].copy()}

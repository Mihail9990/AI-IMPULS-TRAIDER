"""Closed-candle patterns using TA-Lib with a small, labelled fallback."""
from .core import signal, median_range
import numpy as np

try:
    import talib
except ImportError:
    talib=None

ONE=set('CDLBELTHOLD CDLCLOSINGMARUBOZU CDLDOJI CDLDRAGONFLYDOJI CDLGRAVESTONEDOJI CDLHAMMER CDLHANGINGMAN CDLHIGHWAVE CDLINVERTEDHAMMER CDLLONGLEGGEDDOJI CDLLONGLINE CDLMARUBOZU CDLRICKSHAWMAN CDLSHOOTINGSTAR CDLSHORTLINE CDLSPINNINGTOP CDLTAKURI'.split())
TWO=set('CDLCOUNTERATTACK CDLDARKCLOUDCOVER CDLDOJISTAR CDLENGULFING CDLHARAMI CDLHARAMICROSS CDLHOMINGPIGEON CDLINNECK CDLKICKING CDLKICKINGBYLENGTH CDLMATCHINGLOW CDLONNECK CDLPIERCING CDLSEPARATINGLINES CDLTHRUSTING'.split())
NAMES={
'CDL2CROWS':'Две вороны','CDL3BLACKCROWS':'Три чёрные вороны','CDL3INSIDE':'Три изнутри',
'CDL3LINESTRIKE':'Трёхлинейный удар','CDL3OUTSIDE':'Три снаружи','CDL3STARSINSOUTH':'Три звезды на юге',
'CDL3WHITESOLDIERS':'Три белых солдата','CDLABANDONEDBABY':'Брошенный ребёнок','CDLADVANCEBLOCK':'Блок наступления',
'CDLBELTHOLD':'Захват за пояс','CDLBREAKAWAY':'Отрыв','CDLCLOSINGMARUBOZU':'Марубозу закрытия',
'CDLCONCEALBABYSWALL':'Скрывающаяся ласточка','CDLCOUNTERATTACK':'Встречные линии','CDLDARKCLOUDCOVER':'Завеса из тёмных облаков',
'CDLDOJI':'Доджи','CDLDOJISTAR':'Звезда доджи','CDLDRAGONFLYDOJI':'Доджи-стрекоза','CDLENGULFING':'Поглощение',
'CDLEVENINGDOJISTAR':'Вечерняя звезда доджи','CDLEVENINGSTAR':'Вечерняя звезда','CDLGAPSIDESIDEWHITE':'Соседние белые свечи с гэпом',
'CDLGRAVESTONEDOJI':'Доджи-надгробие','CDLHAMMER':'Молот','CDLHANGINGMAN':'Повешенный','CDLHARAMI':'Харами',
'CDLHARAMICROSS':'Крест харами','CDLHIGHWAVE':'Высокая волна','CDLHIKKAKE':'Хиккаке','CDLHIKKAKEMOD':'Модифицированный хиккаке',
'CDLHOMINGPIGEON':'Возвращающийся голубь','CDLIDENTICAL3CROWS':'Три одинаковые вороны','CDLINNECK':'Линия в шее',
'CDLINVERTEDHAMMER':'Перевёрнутый молот','CDLKICKING':'Пинок','CDLKICKINGBYLENGTH':'Пинок по длине свечи',
'CDLLADDERBOTTOM':'Лестничное дно','CDLLONGLEGGEDDOJI':'Длинноногий доджи','CDLLONGLINE':'Длинная свеча',
'CDLMARUBOZU':'Марубозу','CDLMATCHINGLOW':'Совпадающие минимумы','CDLMATHOLD':'Удержание на татами',
'CDLMORNINGDOJISTAR':'Утренняя звезда доджи','CDLMORNINGSTAR':'Утренняя звезда','CDLONNECK':'Линия на шее',
'CDLPIERCING':'Просвет в облаках','CDLRICKSHAWMAN':'Рикша','CDLRISEFALL3METHODS':'Три метода роста/падения',
'CDLSEPARATINGLINES':'Разделяющиеся линии','CDLSHOOTINGSTAR':'Падающая звезда','CDLSHORTLINE':'Короткая свеча',
'CDLSPINNINGTOP':'Волчок','CDLSTALLEDPATTERN':'Заторможенная модель','CDLSTICKSANDWICH':'Сэндвич',
'CDLTAKURI':'Такури','CDLTASUKIGAP':'Разрыв тасуки','CDLTHRUSTING':'Проникающая линия','CDLTRISTAR':'Три звезды',
'CDLUNIQUE3RIVER':'Уникальные три реки','CDLUPSIDEGAP2CROWS':'Две вороны с гэпом вверх','CDLXSIDEGAP3METHODS':'Гэп с тремя методами'}
NEUTRAL=set('CDLDOJI CDLDOJISTAR CDLDRAGONFLYDOJI CDLGRAVESTONEDOJI CDLHIGHWAVE CDLLONGLEGGEDDOJI CDLRICKSHAWMAN CDLSHORTLINE CDLSPINNINGTOP'.split())


def scan(bars,enabled):
    out={g:[] for g in ['candle1','candle2','candle3','priceaction']}
    if len(bars)<6: return out,'Недостаточно свечей'
    if talib is not None:
        op=np.array([x['open'] for x in bars],dtype='double'); hi=np.array([x['high'] for x in bars],dtype='double')
        lo=np.array([x['low'] for x in bars],dtype='double'); cl=np.array([x['close'] for x in bars],dtype='double')
        for name in talib.get_function_groups().get('Pattern Recognition',[]):
            group='priceaction' if name in ('CDLHIKKAKE','CDLHIKKAKEMOD') else ('candle1' if name in ONE else 'candle2' if name in TWO else 'candle3')
            if not enabled.get(group): continue
            vals=getattr(talib,name)(op,hi,lo,cl)
            for i in range(max(0,len(bars)-3),len(bars)):
                v=int(vals[i])
                if not v: continue
                direction='neutral' if name in NEUTRAL else ('up' if v>0 else 'down')
                out[group].append(signal(group,NAMES.get(name,name),direction,description='По правилам TA-Lib; последняя или две предыдущие закрытые свечи.',at=bars[i]['time'],engine='TA-Lib'))
        engine='TA-Lib: '+str(len(talib.get_function_groups().get('Pattern Recognition',[])))+' алгоритмов; доступные группы включаются отдельно'
    else:
        engine='TA-Lib не установлена: работают только основные свечные проверки. Запустите установку зависимостей.'
        for i in range(max(2,len(bars)-3),len(bars)):
            c=bars[i]; prev=bars[i-1]; size=max(c['high']-c['low'],1e-9)
            body=abs(c['close']-c['open']); upper=c['high']-max(c['open'],c['close']); lower=min(c['open'],c['close'])-c['low']
            direction='up' if c['close']>c['open'] else 'down'
            def add(group,name,d='neutral'):
                if enabled.get(group): out[group].append(signal(group,name,d,'Базовое правило; анализ закрытых свечей.',at=c['time'],engine='Базовый'))
            if body<=.1*size: add('candle1','Доджи')
            if lower>=2*max(body,size*.05) and upper<size*.22: add('candle1','Молот / повешенный', 'neutral')
            if upper>=2*max(body,size*.05) and lower<size*.22: add('candle1','Перевёрнутый молот / падающая звезда','neutral')
            if body>=.85*size: add('candle1','Марубозу',direction)
            if c['close']>c['open'] and prev['close']<prev['open'] and c['open']<=prev['close'] and c['close']>=prev['open']: add('candle2','Бычье поглощение','up')
            if c['close']<c['open'] and prev['close']>prev['open'] and c['open']>=prev['close'] and c['close']<=prev['open']: add('candle2','Медвежье поглощение','down')
            if max(c['open'],c['close'])<max(prev['open'],prev['close']) and min(c['open'],c['close'])>min(prev['open'],prev['close']): add('candle2','Харами')
            first=bars[i-2]; mid=bars[i-1]; midbody=abs(mid['close']-mid['open'])
            if midbody<abs(first['close']-first['open'])*.5 and first['close']<first['open'] and c['close']>c['open'] and c['close']>(first['open']+first['close'])/2: add('candle3','Утренняя звезда (упрощённо)','up')
            if midbody<abs(first['close']-first['open'])*.5 and first['close']>first['open'] and c['close']<c['open'] and c['close']<(first['open']+first['close'])/2: add('candle3','Вечерняя звезда (упрощённо)','down')
    for g in out: out[g]=sorted(out[g],key=lambda x:x.get('at',0),reverse=True)[:24]
    return out,engine

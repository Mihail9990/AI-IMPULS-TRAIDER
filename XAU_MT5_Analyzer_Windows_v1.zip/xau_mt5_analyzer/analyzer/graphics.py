"""Rule-based chart shapes. These are approximate and not forecasts."""
from .core import signal, pivots, median_range, fit, at, line
import numpy as np


def graphic(bars, scale, rev=True, cont=True):
    if len(bars)<30: return []
    depth=max(2,min(8,len(bars)//80+2))
    p=pivots(bars,depth); out=[]
    end=len(bars)-1; now=bars[-1]['close']; t=bars[-1]['time']
    step=max(1, int(bars[-1]['time']-bars[-2]['time']))
    rng=max(median_range(bars),1e-9)
    def emit(group,name,direction,points,levels,status, height):
        # Only reference times from historical candles; projection is a scenario.
        projected=now+(1 if direction=='up' else -1)*height if direction!='neutral' else None
        ls=[line([(x['time'],x['price']) for x in points])]
        for a,b in levels: ls.append(line([(bars[a[0]]['time'],a[1]),(bars[b[0]]['time'],b[1])],role='boundary'))
        if projected is not None:
            ls.append(line([(t,now),(t+step*max(8,min(25,len(bars)//8)),projected)],'dashed','projection'))
        out.append(signal(group,name,direction,description='Геометрическое приближение; пунктир — условный сценарий, не прогноз.',scale=scale,
             status=status,lines=ls,at=t,level=round(levels[-1][1][1],4) if levels else None))

    if rev and len(p)>=3:
        # Examine only recent, confirmed swing points; model may still await neckline.
        for k in range(max(0,len(p)-9),len(p)-2):
            a,b,c=p[k:k+3]
            if end-c['i']>max(12,len(bars)//4): continue
            if a['kind']!=c['kind'] or a['kind']==b['kind']: continue
            height=abs((a['price']+c['price'])/2-b['price'])
            if height<rng*1.5 or abs(a['price']-c['price'])>max(height*.22,rng*.8): continue
            is_top=a['kind']=='H'; target='down' if is_top else 'up'
            level=b['price']; confirmed=now<level if is_top else now>level
            emit('reversal','Двойная вершина' if is_top else 'Двойное дно',target,[a,b,c],
                 [((b['i'],level),(end,level))],'Подтверждена' if confirmed else 'Ожидает пробоя',height)
        if len(p)>=5:
            for k in range(max(0,len(p)-8),len(p)-4):
                a,b,c,d,e=p[k:k+5]
                if end-e['i']>max(12,len(bars)//4): continue
                top=a['kind']=='H'; base=(b['price']+d['price'])/2
                prominence=abs(c['price']-base)
                if prominence<2*rng: continue
                should=(a['price']+e['price'])/2
                shoulders_ok=abs(a['price']-e['price']) <= max(prominence*.30,rng)
                head_ok=(c['price']>max(a['price'],e['price'])+prominence*.10 if top else c['price']<min(a['price'],e['price'])-prominence*.10)
                triple=max(a['price'],c['price'],e['price'])-min(a['price'],c['price'],e['price']) < max(prominence*.20,rng*.8)
                slope=(d['price']-b['price'])/max(1,d['i']-b['i']); neckline=d['price']+slope*(end-d['i'])
                levels=[((b['i'],b['price']),(end,neckline))]
                if shoulders_ok and head_ok:
                    confirmed=now<neckline if top else now>neckline
                    emit('reversal','Голова и плечи' if top else 'Перевёрнутые голова и плечи','down' if top else 'up',[a,b,c,d,e],levels,'Подтверждена' if confirmed else 'Ожидает пробоя',prominence)
                elif triple:
                    confirmed=now<neckline if top else now>neckline
                    emit('reversal','Тройная вершина' if top else 'Тройное дно','down' if top else 'up',[a,b,c,d,e],levels,'Подтверждена' if confirmed else 'Ожидает пробоя',prominence)
    if cont:
        # Fit last 2-4 highs and lows on same scan window.
        recent=[x for x in p if x['i']>=len(bars)//5]
        high=[x for x in recent if x['kind']=='H'][-4:]; low=[x for x in recent if x['kind']=='L'][-4:]
        if len(high)>=2 and len(low)>=2:
            hi=fit(high); lo=fit(low)
            if hi and lo:
                start=max(0,min(high[0]['i'],low[0]['i'])); span=max(1,end-start)
                hu0,ld0=at(hi,start),at(lo,start); hu,ld=at(hi,end),at(lo,end)
                width0=hu0-ld0; width=hu-ld
                if width0>rng and width>rng*.3 and width<width0*2:
                    nh=hi[0]*span/width0; nl=lo[0]*span/width0
                    name=None; direction='neutral'
                    if abs(nh)<.15 and abs(nl)<.15: name='Прямоугольник'
                    elif abs(nh)<.15 and nl>.15: name='Восходящий треугольник'; direction='up'
                    elif nh<-.15 and abs(nl)<.15: name='Нисходящий треугольник'; direction='down'
                    elif nh<-.15 and nl>.15: name='Симметричный треугольник'
                    elif nh>0.10 and nl>0.10 and nl>nh+.08: name='Восходящий клин'; direction='down'
                    elif nh<-.10 and nl<-.10 and nh<nl-.08: name='Нисходящий клин'; direction='up'
                    elif abs(nh-nl)<.22 and nh>.10: name='Восходящий канал'; direction='up'
                    elif abs(nh-nl)<.22 and nh<-.10: name='Нисходящий канал'; direction='down'
                    if name:
                        confirmed = now>hu if direction=='up' else now<ld if direction=='down' else now>hu or now<ld
                        if direction=='neutral' and confirmed: direction='up' if now>hu else 'down'
                        pts=sorted(high[-2:]+low[-2:],key=lambda x:x['i'])
                        emit('continuation',name,direction,pts,[((start,hu0),(end,hu)),((start,ld0),(end,ld))],
                             'Пробой' if confirmed else 'Формируется',width)
                        # Flag = preceding impulse followed by a slanted channel.
                        if 'канал' in name and start>8:
                            prev=bars[max(0,start-min(15,start))]['close']; impulse=bars[start]['close']-prev
                            if abs(impulse)>width0*1.5 and impulse*hi[0]<0:
                                d='up' if impulse>0 else 'down'
                                emit('continuation','Бычий флаг' if d=='up' else 'Медвежий флаг',d,pts,
                                     [((start,hu0),(end,hu)),((start,ld0),(end,ld))],
                                     'Пробой' if (now>hu if d=='up' else now<ld) else 'Формируется',abs(impulse))
    # Keep unique recent results, cap for legibility.
    found=[]; seen=set()
    for s in reversed(out):
        key=(s['name'],s['group'])
        if key not in seen: found.append(s); seen.add(key)
    return found[:8]

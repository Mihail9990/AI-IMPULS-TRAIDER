"""Automated offline checks. The artificial bars are only test fixtures."""
import copy, json, math, sys, tempfile, threading, time, unittest, urllib.request, urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import app
from analyzer.core import IDS, pivots
from analyzer.engine import analyze
from analyzer import others, candles


def artificial(n=650):
    result=[]
    for i in range(n):
        o=4000+.01*i+3*math.sin(i*.18); c=4000+.01*(i+1)+3*math.sin((i+1)*.18)
        result.append({'time':1700000000+i*60,'open':o,'high':max(o,c)+.1,'low':min(o,c)-.1,'close':c,'tick_volume':100+i%21,'real_volume':0})
    return result

class AnalysisTests(unittest.TestCase):
    def setUp(self): self.bars=artificial(); self.cfg=copy.deepcopy(app.DEFAULTS)
    def test_all_fourteen_independent_and_three_chart_windows(self):
        res=analyze(self.bars,self.cfg)
        self.assertEqual([g['id'] for g in res['groups']],IDS)
        self.assertTrue(all(g['status']=='ok' for g in res['groups']),res['groups'])
        graphs=[x for x in res['signals'] if x['group']=='reversal']
        self.assertEqual(set(x['scale'] for x in graphs),{'small','medium','large'})
        self.assertTrue(all(x['lines'] for x in graphs))
        for x in graphs:
            self.assertTrue(any(l['role']=='projection' for l in x['lines']))
    def test_disabling_does_not_stop_other_groups(self):
        before=analyze(self.bars,self.cfg)
        self.cfg['enabled']['reversal']=False; self.cfg['enabled']['candle1']=False
        after=analyze(self.bars,self.cfg)
        status={g['id']:g for g in after['groups']}
        self.assertEqual(status['reversal']['status'],'disabled')
        self.assertEqual(status['candle1']['status'],'disabled')
        self.assertFalse(any(x['group'] in ('reversal','candle1') for x in after['signals']))
        self.assertEqual([x for x in before['signals'] if x['group']=='indicators'],[x for x in after['signals'] if x['group']=='indicators'])
        self.assertEqual(status['continuation']['status'],'ok')
    def test_single_group_exception_is_isolated(self):
        with patch('analyzer.others.volume',side_effect=RuntimeError('bad volume')):
            # The handler registry holds the original callable, so patch the registry itself.
            with patch.dict('analyzer.others.HANDLERS',{'volume':lambda b: (_ for _ in ()).throw(RuntimeError('bad volume'))}):
                res=analyze(self.bars,self.cfg)
        d={g['id']:g for g in res['groups']}
        self.assertEqual(d['volume']['status'],'error'); self.assertEqual(d['indicators']['status'],'ok')
        self.assertTrue(any(x['group']=='indicators' for x in res['signals']))
    def test_confirmed_pivots_do_not_look_past_input(self):
        values=[2,3,8,5,4]
        bars=[{'time':i,'high':v,'low':v-1} for i,v in enumerate(values)]
        self.assertEqual(pivots(bars[:4],2),[])
        self.assertEqual([(p['i'],p['kind']) for p in pivots(bars,2)],[(2,'H')])
    def test_gap_only_closed_when_price_reaches_other_side(self):
        b=artificial(30)
        b[-4].update(high=100,low=99,open=99.2,close=99.5)
        b[-3].update(open=102,high=103,low=101,close=102)
        b[-2].update(open=102,high=103,low=100.5,close=101)
        b[-1].update(open=101,high=102,low=100.1,close=101)
        matches=[s for s in others.gaps(b) if s['at']==b[-3]['time']]
        self.assertEqual(len(matches),1);self.assertIn('полностью не закрыт',matches[0]['description'])
        b[-1]['low']=99.9
        matches=[s for s in others.gaps(b) if s['at']==b[-3]['time']]
        self.assertIn('полностью закрыт',matches[0]['description'])
    def test_talib_patterns_route_to_independent_sections(self):
        class FakeTA:
            def get_function_groups(self):return {'Pattern Recognition':['CDLDOJI','CDLENGULFING','CDLMORNINGSTAR']}
            def values(self,*args):
                v=np.zeros(len(args[0])); v[-1]=100;return v
            CDLDOJI=values
            CDLENGULFING=values
            CDLMORNINGSTAR=values
        self.cfg['enabled']['candle2']=False
        with patch.object(candles,'talib',FakeTA()):
            out,engine=candles.scan(self.bars,self.cfg['enabled'])
        self.assertEqual(out['candle1'][0]['name'],'Доджи')
        self.assertEqual(out['candle1'][0]['direction'],'neutral')
        self.assertEqual(out['candle2'],[])
        self.assertEqual(out['candle3'][0]['name'],'Утренняя звезда')
        self.assertIn('3 алгоритмов',engine)

    def test_config_validation(self):
        cfg=copy.deepcopy(self.cfg);cfg['windows']['small']=200
        with self.assertRaises(ValueError):app.validate(cfg)
        cfg=copy.deepcopy(self.cfg);cfg['symbol']='XAUUSD.s/../../x'
        with self.assertRaises(ValueError):app.validate(cfg)
        cfg=copy.deepcopy(self.cfg);cfg['enabled']['waves']='false'
        with self.assertRaises(ValueError):app.validate(cfg)

class FakeMT5:
    TIMEFRAME_M1=1
    def __init__(self):self.positions=[];self.was_shutdown=False
    def initialize(self,*a,**kw):return True
    def terminal_info(self):return SimpleNamespace(connected=True)
    def symbol_select(self,s,v):return s=='XAUUSD.s' and v
    def symbols_get(self):return [SimpleNamespace(name='XAUUSD.s')]
    def symbol_info_tick(self,s):return SimpleNamespace(time=int(time.time()),bid=4000.1,ask=4000.33)
    def copy_rates_from_pos(self,s,tf,pos,count):
        self.positions.append(pos)
        allbars=artificial(650)
        if pos==0:
            now=allbars[-1].copy();now.update(time=allbars[-1]['time']+60,close=8000,high=8001)
            return [now]
        return allbars
    def shutdown(self):self.was_shutdown=True
    def last_error(self):return (0,'ok')

class SourceTests(unittest.TestCase):
    def test_closed_bar_and_live_bar_are_separate(self):
        fake=FakeMT5();market=app.Market()
        with patch.dict(sys.modules,{'MetaTrader5':fake}):
            t=threading.Thread(target=market.run);t.start()
            deadline=time.time()+5
            while time.time()<deadline and not market.get_snapshot()['connected']: time.sleep(.02)
            market.stop.set();t.join(3)
        snap=market.get_snapshot()
        self.assertTrue(snap['connected'],snap)
        self.assertIn(0,fake.positions);self.assertIn(1,fake.positions)
        self.assertEqual(snap['symbol'],'XAUUSD.S');self.assertEqual(snap['actual_symbol'],'XAUUSD.s')
        self.assertEqual(snap['analysis']['closed_bars'],650)
        self.assertEqual(snap['bars'][-1]['close'],8000)
        sma=[s for s in snap['analysis']['signals'] if s['name']=='SMA (20 / 50)'][0]
        self.assertNotIn('8000',sma['description'])
        self.assertTrue(fake.was_shutdown)

class APITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.old=app.CONFIG_PATH;app.CONFIG_PATH=Path(cls.tmp.name)/'settings.json'
        cls.market=app.Market();cls.server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        cls.server.key='long-random-test-key-1234567890';cls.server.market=cls.market
        cls.port=cls.server.server_address[1];cls.url=f'http://127.0.0.1:{cls.port}'
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join();app.CONFIG_PATH=cls.old;cls.tmp.cleanup()
    def request(self,path,body=None,headers=None):
        req=urllib.request.Request(self.url+path,data=json.dumps(body).encode() if body is not None else None,headers=headers or {})
        try:
            with urllib.request.urlopen(req,timeout=3) as r:return r.status,dict(r.headers),r.read()
        except urllib.error.HTTPError as e:return e.code,dict(e.headers),e.read()
    def test_login_and_change_settings(self):
        code,_,_=self.request('/api/config');self.assertEqual(code,401)
        h={'Content-Type':'application/json','Origin':self.url}
        code,_,_=self.request('/api/login',{'key':'wrong'},h);self.assertEqual(code,401)
        code,_,_=self.request('/api/login',{'key':self.server.key},{'Content-Type':'application/json','Origin':'http://attacker.invalid'});self.assertEqual(code,403)
        code,headers,_=self.request('/api/login',{'key':self.server.key},h);self.assertEqual(code,200)
        cookie=headers['Set-Cookie'].split(';')[0]; auth={'Cookie':cookie}
        code,_,body=self.request('/api/config',headers=auth);self.assertEqual(code,200);cfg=json.loads(body)
        cfg['enabled']['reversal']=False
        code,_,_=self.request('/api/config',cfg,{**h,**auth});self.assertEqual(code,200)
        code,_,body=self.request('/api/config',headers=auth);result=json.loads(body)
        self.assertFalse(result['enabled']['reversal']);self.assertTrue(result['enabled']['volume'])
        code,_,_=self.request('/api/config',cfg,{'Content-Type':'text/plain','Origin':self.url,**auth});self.assertEqual(code,400)
        self.assertTrue(app.CONFIG_PATH.exists())
        # Two devices each modify one setting; the second must not undo the first.
        code,_,_=self.request('/api/config',{'patch':{'enabled':{'volume':False}}},{**h,**auth});self.assertEqual(code,200)
        code,_,_=self.request('/api/config',{'patch':{'enabled':{'waves':False}}},{**h,**auth});self.assertEqual(code,200)
        code,_,body=self.request('/api/snapshot',headers=auth);snapshot=json.loads(body)
        self.assertFalse(snapshot['config']['enabled']['volume'])
        self.assertFalse(snapshot['config']['enabled']['waves'])
        self.assertFalse(snapshot['config']['enabled']['reversal'])

if __name__=='__main__': unittest.main()

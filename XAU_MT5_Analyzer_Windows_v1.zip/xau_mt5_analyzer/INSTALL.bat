@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ========================================
echo     XAU MT5 ANALYZER - INSTALL
echo ========================================
where py >nul 2>&1
if errorlevel 1 (
  echo Python launcher not found. Install 64-bit Python 3.13 from python.org.
  echo During installation enable the Python launcher.
  pause
  exit /b 1
)
py -3.13 -m venv .venv
if errorlevel 1 (
  echo Python 3.13 not found. Trying the default installed Python 3...
  py -3 -m venv .venv
)
if errorlevel 1 (
  echo Cannot create virtual environment. Install 64-bit Python 3.13.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto FAIL
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto FAIL
echo.
echo Installation completed. Start with START_LOCAL.bat
pause
exit /b 0
:FAIL
echo.
echo Installation failed. Check internet and the error messages above.
pause
exit /b 1

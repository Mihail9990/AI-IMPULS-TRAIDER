(() => {
  'use strict';
  const M = window.RecoveryModel, $ = id => document.getElementById(id);
  let key = '', busy = false, timer = null, controller = null, epoch = 0, context = null, lastResult = null, actionBusy = false, pendingAuth = null, loggingOut = false;
  const text = (id, value) => { $(id).textContent = value; };
  const node = (tag, value, cls) => { const e = document.createElement(tag); if (value !== undefined) e.textContent = value; if (cls) e.className = cls; return e; };
  const mode = { real:'Реальный счёт', demo:'Демо-счёт', contest:'Конкурсный счёт', unknown:'Тип счёта не подтверждён' };
  const secureOrigin = () => location.protocol === 'https:' || (location.protocol === 'http:' && ['localhost','127.0.0.1','[::1]'].includes(location.hostname));
  text('origin', location.protocol === 'file:' ? 'Локальный просмотр. Для подключения откройте HTTPS-адрес VPS.' : 'Сервер: ' + location.host);
  function controls() { $('refresh').disabled = !key || busy; $('logout').disabled = loggingOut || (!key && !busy); $('auto').disabled = !key; $('lookup-button').disabled = !key || busy || lastResult?.connectionOnly === true; $('connect').disabled = busy || actionBusy; $('dashboard').setAttribute('aria-busy', String(busy)); $('open-settings').hidden = lastResult!==null; }
  function stopTimer() { clearTimeout(timer); timer = null; }
  function schedule() { stopTimer(); if (key && $('auto').checked && !document.hidden) timer = setTimeout(loadState, 5000); }
  function unavailable(message) { lastResult=null;context=null;window.dispatchEvent(new CustomEvent('recovery-state',{detail:null}));text('message',message); $('dashboard').classList.add('stale'); text('snapshot','Нет свежего снимка MT5. Показанные данные могут быть устаревшими.'); text('executor','Не подтверждено'); }
  function clearData() { context=null;lastResult=null;window.dispatchEvent(new Event('recovery-session-change')); for (const name of ['positions','orders','ranges']) { $(name).replaceChildren(node('p','Данные не подтверждены','empty')); } for (const name of ['positions-count','orders-count','symbol','account']) text(name,'—'); text('executor','Нет данных'); text('snapshot','Нет снимка MT5.'); text('timing',''); $('issues').replaceChildren(); $('settings').replaceChildren(); $('receipt-result').replaceChildren(); }
  function clearSession() { ++epoch; key=''; if(controller)controller.abort(); stopTimer(); busy=false; $('key').value=''; $('key').type='password'; text('reveal','Показать'); $('reveal').setAttribute('aria-pressed','false'); $('auto').checked=false; $('request-id').value=''; clearData(); text('message','Вход не активен.'); text('session-label','Ключ не сохранён'); controls(); }
  async function logout() {
    if(loggingOut)return;loggingOut=true;
    clearSession();busy=true;controls();const turn=epoch;
    // Wait for an already issued login so its late Set-Cookie is revoked too.
    try {
      if(pendingAuth)await pendingAuth.catch(()=>{});
      const latest=await window.RecoverySession.restore();
      await window.RecoverySession.logout(latest);
      if(turn===epoch)text('message','Вы вышли. Сеанс отозван.');
    } catch {if(turn===epoch)text('message','Выход на VPS не подтверждён. Сеанс браузера мог сохраниться до истечения срока.');}
    finally {loggingOut=false;busy=false;controls();}
  }
  async function read(kind, id) {
    if (!secureOrigin()) throw new Error('Для соединения откройте эту панель через HTTPS на вашем VPS.');
    const bytes = new Uint8Array(16); crypto.getRandomValues(bytes); const nonce = [...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');
    const req = M.spec(kind,id,nonce,key); const requestController = new AbortController(); controller=requestController;
    const timeout = setTimeout(()=>requestController.abort(),15000);
    try {
      const response = await fetch(req.path,{...req.options,signal:requestController.signal});
      if (response.status===401 || response.status===403) {clearSession();throw new Error('Доступ отклонён. Введите ключ повторно.');}
      if (!response.ok) throw new Error('VPS вернул ошибку HTTP '+response.status+'. Этот запрос был только чтением.');
      if (!response.headers.get('content-type')?.toLowerCase().includes('application/json')) throw new Error('VPS вернул не JSON. Проверьте адрес панели и настройку прокси.');
      const reader=response.body.getReader(), chunks=[];let size=0;
      while(true){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>1000000){await reader.cancel();throw new Error('Ответ VPS слишком большой.');}chunks.push(part.value);}
      const all=new Uint8Array(size);let offset=0;for(const chunk of chunks){all.set(chunk,offset);offset+=chunk.length;}
      const data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(all));
      return kind==='state'?M.state(data,nonce):M.receipt(data,id);
    } finally {clearTimeout(timeout);if(controller===requestController)controller=null;}
  }
  function fields(container, pairs) {const dl=node('dl');for(const [label,value] of pairs){dl.append(node('dt',label),node('dd',M.text(value)));}container.append(dl);}
  function inventory(name, rows) {
    text(name+'-count',rows===null?'—':String(rows.length));const box=$(name);box.replaceChildren();
    if(rows===null){box.append(node('p','Данные MT5 недоступны.','empty'));return;}
    if(!rows.length){box.append(node('p',name==='positions'?'Нет открытых позиций.':'Нет триггерных ордеров.','empty'));return;}
    for(const r of rows.slice(0,100)){const card=node('article',undefined,'item'),head=node('div',undefined,'item-head');head.append(node('span',M.text(r.side),r.side==='BUY'?'buy':r.side==='SELL'?'sell':''),node('span','№ '+M.text(r.ticket)));card.append(head);fields(card,[['Диапазон',r.range_id],['Объём, лоты',r.volume],[name==='positions'?'Вход':'Цена триггера',r.price],['SL',r.sl],['TP',r.tp]]);if(r.mapping_status!=='verified')card.append(node('p','Принадлежность диапазону не подтверждена.','warning'));box.append(card);}
    if(rows.length>100)box.append(node('p','Показаны первые 100 записей из '+rows.length+'.','small muted'));
  }
  function render(result) {
    lastResult=result;window.dispatchEvent(new CustomEvent('recovery-state',{detail:result}));
    if(result.connectionOnly===true){
      context=null;$('dashboard').classList.remove('stale');text('symbol','—');text('account','Не проверялся');
      text('executor','Торговля выключена');text('snapshot','VPS доступен по HTTPS. MT5 не проверялся.');
      text('timing','');$('issues').replaceChildren();$('settings').replaceChildren();$('receipt-result').replaceChildren();
      inventory('positions',null);inventory('orders',null);$('ranges').replaceChildren(node('p','Диапазоны не проверялись.','empty'));
      text('message','VPS подключён. Торговля выключена.');
      return;
    }
    const w=result.widget;context=w.snapshot.context_id; $('dashboard').classList.toggle('stale',w.snapshot.status!=='fresh');text('account',mode[w.account_trade_mode]);text('symbol',M.text(w.snapshot.symbol));
    text('executor',w.reconciliation_required?'Нужна сверка':w.executor_ready?'Готов':'Не готов');
    text('snapshot',w.snapshot.status==='fresh'?'Снимок MT5: '+M.text(w.snapshot.observed_at):'Снимок MT5 недоступен.');
    text('timing',result.age===null?'':'Возраст снимка: '+result.age+' мс.');
    $('issues').replaceChildren();for(const issue of w.issues.slice(0,30))$('issues').append(node('p',M.text(issue),'warning'));
    inventory('positions',w.positions);inventory('orders',w.orders);$('ranges').replaceChildren();
    if(!w.ranges.length)$('ranges').append(node('p','Диапазоны не настроены.','empty'));
    const lifecycle={active:'Активный',cancelled:'Отменён',manual:'Ручной режим'};
    for(const r of w.ranges.slice(0,10)){const card=node('article',undefined,'item'),head=node('div',undefined,'item-head');head.append(node('span','Диапазон №'+M.text(r.id)),node('span',M.text(r.side),r.side==='BUY'?'buy':r.side==='SELL'?'sell':''));card.append(head);const t=w.totals[r.id];fields(card,[['Первичная цена',r.price],['Начальный объём',r.volume],['Режим',Object.hasOwn(lifecycle,r.lifecycle)?lifecycle[r.lifecycle]:r.lifecycle],['Убытки закрытых позиций',t?.gross_negative_closed_net],['Результат',t?.realized_net],['Полных SL',t?.full_sl_count]]);$('ranges').append(card);}
    $('settings').replaceChildren();for(const [label,value] of [['Исходный SL',w.settings.initial_sl_distance],['После SL поддержки',w.settings.reentry_distance]])$('settings').append(node('dt',label),node('dd',M.text(value)));
    text('message','Подключено.');
  }
  async function loadState() {if(busy||!key)return;stopTimer();busy=true;const turn=epoch;controls();text('message','Обновляю…');try{const result=await read('state');if(turn===epoch)render(result);}catch(e){if(turn===epoch)unavailable(e.name==='AbortError'?'VPS не ответил вовремя.':e instanceof SyntaxError?'Некорректный ответ VPS.':e.message);}finally{if(turn===epoch){busy=false;controls();schedule();}}}
  $('login').addEventListener('submit',async e=>{
    e.preventDefault();if(busy||actionBusy||loggingOut)return;const candidate=$('key').value.trim();
    try{M.spec('state',null,'0'.repeat(32),candidate);}catch(err){text('message',err.message);return;}
    clearSession();busy=true;controls();$('key').value='';const turn=epoch;
    const operation=window.RecoverySession.login(candidate);pendingAuth=operation;
    try{const result=await operation;if(turn===epoch){key=result;text('session-label','Вход сохранён в этом браузере, до 8 часов');}}
    catch(err){if(turn===epoch)text('message',err.message);}finally{if(pendingAuth===operation)pendingAuth=null;if(turn===epoch){busy=false;controls();if(key)loadState();}}
  });
  $('reveal').addEventListener('click',()=>{const show=$('key').type==='password';$('key').type=show?'text':'password';text('reveal',show?'Скрыть':'Показать');$('reveal').setAttribute('aria-pressed',String(show));});
  $('refresh').addEventListener('click',loadState);$('logout').addEventListener('click',logout);$('auto').addEventListener('change',schedule);
  $('lookup').addEventListener('submit',async e=>{e.preventDefault();if(busy||!key||lastResult?.connectionOnly===true)return;const id=$('request-id').value.trim().toLowerCase();if(!M.uuid.test(id)){text('receipt-result','Введите request_id в формате UUID.');return;}busy=true;stopTimer();const turn=epoch;controls();text('receipt-result','Читаю запись…');try{const result=await read('receipt',id);if(turn!==epoch)return;$('receipt-result').replaceChildren(node('p',result.message,'warning'));if(context!==null&&result.context!==context)$('receipt-result').append(node('p','Это запись другого контекста счёта. Обновите состояние.','warning'));const labels={confirmed:'первичная отправка подтверждена',not_dispatched:'не отправлен',rejected:'отклонён'};for(const r of result.outcomes.slice(0,100))$('receipt-result').append(node('p','Диапазон №'+M.text(r.range_id)+': '+(Object.hasOwn(labels,r.status)?labels[r.status]:'статус не подтверждён')));}catch(err){if(turn===epoch)text('receipt-result','Не удалось прочитать запись.');}finally{if(turn===epoch){busy=false;controls();schedule();}}});
  const tabs = Array.from(document.querySelectorAll('[role="tab"][data-tab]'));
  function selectTab(tab, focusTarget = null) {
    for (const item of tabs) {
      const selected = item === tab;
      item.setAttribute('aria-selected', String(selected));
      item.tabIndex = selected ? 0 : -1;
      $(item.getAttribute('aria-controls')).hidden = !selected;
    }
    window.scrollTo(0, 0);
    if (focusTarget) focusTarget.focus({preventScroll: true});
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab, tab));
    tab.addEventListener('keydown', event => {
      const last = tabs.length - 1;
      const move = { ArrowLeft: index === 0 ? last : index - 1,
                     ArrowRight: index === last ? 0 : index + 1, Home: 0, End: last };
      if (!Object.hasOwn(move, event.key) || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      event.preventDefault();
      const target = tabs[move[event.key]];
      selectTab(target, target);
    });
  });
  $('open-settings').addEventListener('click', () => selectTab($('tab-settings'), $('key')));
  window.RecoveryView=Object.freeze({getToken:async()=>key,getState:()=>lastResult,setActionBusy:value=>{actionBusy=value===true;controls();},refresh:loadState});
  window.dispatchEvent(new Event('recovery-ready'));
  document.addEventListener('visibilitychange'  ,()=>{if(document.hidden)stopTimer();else schedule();});window.addEventListener('pagehide',()=>{++epoch;if(controller)controller.abort();stopTimer();key='';clearData();});controls();
  function restoreSession(){
    if(location.protocol!=='https:'||loggingOut)return;clearSession();
    busy=true;controls();const turn=epoch;
    window.RecoverySession.restore().then(session=>{if(turn!==epoch)return;key=session;clearData();text('session-label','Вход восстановлен. Торговые кнопки выключены.');}).catch(()=>{}).finally(()=>{if(turn===epoch){busy=false;controls();if(key)loadState();}});
  }
  window.addEventListener('pageshow',event=>{if(event.persisted)restoreSession();});
  restoreSession();
})();

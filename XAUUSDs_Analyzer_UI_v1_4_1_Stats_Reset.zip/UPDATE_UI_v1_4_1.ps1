# Windows PowerShell 5.1, ASCII-only installer for a web + statistics reset update.
param([string]$TargetDirectory = '')
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Join-Path $here 'SHA256SUMS.txt'
$files = @(
  'web\index.html',
  'web\app.js',
  'web\terminal.css',
  'analyzer\storage.py',
  'analyzer\live.py',
  'analyzer\server.py',
  'tests\test_reset_statistics_v141.py'
)

function Main {
    Write-Host 'XAUUSD.s Strategy Analyzer - UI v1.4.1 & statistics reset' -ForegroundColor Cyan
    Write-Host 'No virtual history or results are cleared by the UPDATE.'
    Write-Host 'The clear statistics button requires separate manual confirmation.'
    if (-not (Test-Path -LiteralPath $manifest)) { throw 'Manifest missing.' }
    $hashes = @{}
    foreach ($line in (Get-Content -LiteralPath $manifest)) {
        if ($line -match '^([0-9a-fA-F]{64})\s{2}(.+)$') { $hashes[$matches[2]] = $matches[1].ToLowerInvariant() }
    }
    foreach ($rel in $files) {
        $key = ('patch/' + ($rel -replace '\\','/'))
        $src = Join-Path (Join-Path $here 'patch') $rel
        if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw ('Missing update file: ' + $key) }
        if (-not $hashes.ContainsKey($key)) { throw ('No SHA256 entry for: ' + $key) }
        $actual = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $hashes[$key]) { throw ('SHA256 MISMATCH: ' + $key) }
    }
    Write-Host '[OK] All update file checksums verified.' -ForegroundColor Green

    if (-not $TargetDirectory) {
        Add-Type -AssemblyName System.Windows.Forms
        $chooser = New-Object System.Windows.Forms.FolderBrowserDialog
        $chooser.Description = 'Select INSTALLED analyzer folder containing start_windows.bat'
        $chooser.ShowNewFolderButton = $false
        $result = $chooser.ShowDialog()
        if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
            Write-Host 'Cancelled. No files changed.'
            return
        }
        $TargetDirectory = $chooser.SelectedPath
    }
    $target = [System.IO.Path]::GetFullPath($TargetDirectory)
    foreach ($relative in @('start_windows.bat','.env','analyzer\engine.py','analyzer\server.py','analyzer\live.py','analyzer\storage.py','web\index.html')) {
        if (-not (Test-Path -LiteralPath (Join-Path $target $relative) -PathType Leaf)) {
            throw ('Not the installed analyzer folder (missing ' + $relative + ').')
        }
    }
    $engineSource = [System.IO.File]::ReadAllText((Join-Path $target 'analyzer\engine.py'))
    if (-not ($engineSource.Contains('recovery_trail_start_offset') -and $engineSource.Contains('best_trigger_quote'))) {
        throw 'Unsupported trading engine version: expected RECOVERY v1.3.4. No files changed.'
    }

    $port = 8765
    $envPath = Join-Path $target '.env'
    $portMatch = [regex]::Match([System.IO.File]::ReadAllText($envPath), '(?m)^\s*WEB_PORT\s*=\s*(\d+)')
    if ($portMatch.Success) { $port = [int]$portMatch.Groups[1].Value }
    if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
        $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
        if ($listeners.Count -gt 0) { throw ('Port ' + $port + ' is listening. Close start_windows.bat before updating.') }
    }

    $backup = Join-Path $target ('backup_ui_v1_4_1_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    $existed = @{}
    try {
        foreach ($rel in $files) {
            $dest = Join-Path $target $rel
            $existed[$rel] = Test-Path -LiteralPath $dest -PathType Leaf
            if ($existed[$rel]) {
                $backupFile = Join-Path $backup $rel
                $backupDir = Split-Path -Parent $backupFile
                New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
                Copy-Item -LiteralPath $dest -Destination $backupFile -Force
            }
        }
        foreach ($rel in $files) {
            $src = Join-Path (Join-Path $here 'patch') $rel
            $dest = Join-Path $target $rel
            $destDir = Split-Path -Parent $dest
            if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            Copy-Item -LiteralPath $src -Destination $dest -Force
            Write-Host ('Updated: ' + $rel)
        }
    } catch {
        Write-Host 'Copy error. Restoring previous files from backup...' -ForegroundColor Yellow
        foreach ($rel in $files) {
            $dest = Join-Path $target $rel
            $backupFile = Join-Path $backup $rel
            if (Test-Path -LiteralPath $backupFile -PathType Leaf) {
                Copy-Item -LiteralPath $backupFile -Destination $dest -Force
            } elseif ($existed.ContainsKey($rel) -and (-not $existed[$rel]) -and (Test-Path -LiteralPath $dest)) {
                Remove-Item -LiteralPath $dest -Force
            }
        }
        throw
    }
    Write-Host '[OK] UI v1.4.1 installed. No database or trading engine was modified.' -ForegroundColor Green
    Write-Host ('Backup: ' + $backup)
    Write-Host 'Launch start_windows.bat, then press Ctrl+F5 in the browser.'
    Write-Host 'To erase PAPER results later: Statistics -> Clear -> type CLEAR.'
}

try { Main } catch { Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }

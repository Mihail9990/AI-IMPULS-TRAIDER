"""Safety tests for user-triggered deletion of PAPER statistics (v1.4.1)."""
from __future__ import annotations
import json
import pytest
from fastapi.testclient import TestClient
from analyzer.server import app
from analyzer.engine import Pending
import analyzer.server as server


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD','a-random-test-password-1234')
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(app) as cli:
        yield cli

AUTH=('admin','a-random-test-password-1234')

def test_reset_endpoint_requires_auth_exact_confirmation_and_same_origin(client):
    url='/api/statistics/reset'
    assert client.post(url,json={'confirmation':'CLEAR'}).status_code==401
    assert client.post(url,json={'confirmation':'yes'},auth=AUTH).status_code==422
    assert client.post(url,json={},auth=AUTH).status_code==422
    assert client.post(url,json={'confirmation':'CLEAR'},auth=AUTH,
                       headers={'Origin':'https://evil.test'}).status_code==403


def test_reset_clears_live_and_historical_results_but_preserves_settings(client):
    svc=server.service
    assert svc is not None
    store=svc.store
    with svc.engine_lock:
        original_settings=svc.engine.settings
        svc.engine.mode='running'
        svc.engine.pending=Pending('BUY',999999.0,0,0,0,0,'BUY')
        svc.engine.realized_cycle_points=12.34
        svc.engine.trades=[dict(id=7,side='BUY',result='TP',pnl_points=12.34)]
        svc.engine.new_trades=[]
        svc.engine.events=[dict(type='sl',t_ms=0)]
        old_quote=svc.engine.latest
        svc.persist()
    store.save_live(svc.engine.to_snapshot(),[dict(id=7,side='BUY',result='TP')])
    store.set_state('custom_saved_setting',{'keep':42})
    run_id=store.make_job(0,60000,{'a':1},1,'demo')
    with store.lock,store.db:
        vid=store.db.execute('INSERT INTO variants(backtest_id,config,summary) VALUES(?,?,?)',
                             (run_id,'{}','{}')).lastrowid
        store.db.execute('''INSERT INTO backtest_trades(variant_id,backtest_id,opened_ms,result,payload)
                            VALUES(?,?,?,?,?)''',(vid,run_id,0,'SL','{}'))
    result=client.post('/api/statistics/reset',json={'confirmation':'CLEAR'},auth=AUTH)
    assert result.status_code==200,result.text
    data=result.json()
    assert data['stats_cleared'] and data['active_virtual_cycle_reset']
    with svc.engine_lock:
        assert svc.engine.mode=='stopped'
        assert svc.engine.pending is None and svc.engine.position is None and svc.engine.recovery is None
        assert svc.engine.realized_cycle_points==0
        assert svc.engine.trades==[] and svc.engine.events==[]
        assert svc.engine.settings==original_settings
        assert svc.engine.latest is not None
        assert svc.engine.latest.t_ms>=old_quote.t_ms if old_quote else True
    assert store.get_state('custom_saved_setting')=={'keep':42}
    with store.lock:
        for table in ('live_trades','backtests','variants','backtest_trades'):
            assert store.db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]==0
    assert client.get('/api/backtests',auth=AUTH).json()==[]
    assert client.get('/api/status',auth=AUTH).json()['summary']['trades']==0
    saved=store.get_state('live_snapshot')
    assert saved['mode']=='stopped'
    assert saved['settings']==json.loads(json.dumps(original_settings.__dict__))
    # A repeated user request may clear new results again (not a one-time migration).
    assert client.post('/api/statistics/reset',json={'confirmation':'CLEAR'},auth=AUTH).status_code==200


def test_reset_refused_during_backtest_and_keeps_data(client):
    svc=server.service
    assert svc is not None
    db=svc.store
    run_id=db.make_job(0,60000,{'a':1},1,'demo')
    assert svc.backtester.lock.acquire(blocking=False)
    try:
        response=client.post('/api/statistics/reset',json={'confirmation':'CLEAR'},auth=AUTH)
        assert response.status_code==409
        assert db.job(run_id) is not None
    finally:
        svc.backtester.lock.release()


def test_interface_has_clear_button_and_no_verbose_demo_warning(client):
    response=client.get('/',auth=AUTH)
    assert response.status_code==200
    text=response.text
    assert 'id="btnClearStatistics"' in text
    assert 'id="clearStatsDialog"' in text
    assert 'DEMO / СИНТЕТИКА' not in text
    assert 'НЕ РЫНОК' not in text
    assert '/assets/app.js?v=1.4.1' in text

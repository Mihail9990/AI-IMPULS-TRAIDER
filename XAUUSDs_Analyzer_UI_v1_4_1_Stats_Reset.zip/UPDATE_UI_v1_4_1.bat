@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_UI_v1_4_1.ps1"
set "EXITCODE=%ERRORLEVEL%"
echo.
if not "%EXITCODE%"=="0" (
  echo UPDATE FAILED. No data was intentionally deleted.
) else (
  echo UPDATE COMPLETED. You can start the analyzer.
)
pause
exit /b %EXITCODE%

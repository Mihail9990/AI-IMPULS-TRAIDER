@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_RECOVERY_V4_v1_9_0.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo UPDATE FAILED. See diagnostic above.
pause
exit /b %RC%

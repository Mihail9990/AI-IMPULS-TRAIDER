"""READ-ONLY analyzer preflight + an optional consistent SQLite BACKUP.

Never modifies the broker, settings, tick cache, live DB or trading positions.
"""
from __future__ import annotations
from pathlib import Path
import argparse, sqlite3, json


def env_vars(path:Path)->dict[str,str]:
    result={}
    for raw in path.read_text(encoding='utf-8-sig').splitlines():
        raw=raw.strip()
        if raw.startswith('#') or '=' not in raw:continue
        k,v=raw.split('=',1)
        result[k.strip()]=v.strip().strip('"').strip("'")
    return result


def database_path(root:Path)->Path:
    env=env_vars(root/'.env')
    source=(env.get('DATA_SOURCE','mt5') or 'mt5').lower()
    symbol=(env.get('MT5_SYMBOL','XAUUSD.s') if source=='mt5' else 'SYNTHETIC-DEMO')
    name=''.join(c for c in symbol if c.isalnum() or c in '._-')
    base=Path(env.get('DATA_DIR') or str(root/'data'))
    if not base.is_absolute():base=root/base
    return base/f'{source}_{name}'/'analyzer.sqlite3'


def check_and_backup(root:Path, backup_dir:Path)->None:
    root=root.resolve()
    for rel in ('start_windows.bat','.env','analyzer/engine.py','analyzer/live.py',
                'analyzer/server.py','web/app.js'):
        if not (root/rel).is_file():raise ValueError('Wrong installed folder: '+rel)
    db=database_path(root)
    if not db.exists():
        print('No existing SQLite database at configured path (no backup needed).')
        return
    db_file=db.resolve()
    conn=sqlite3.connect(db_file.as_uri()+'?mode=ro',uri=True,timeout=7)
    try:
        row=conn.execute("SELECT value FROM state WHERE key='live_snapshot'").fetchone()
        if row:
            state=json.loads(row[0])
            if any((state.get('pending'),state.get('position'),state.get('recovery'),
                    state.get('manual_positions'),state.get('manual_stops'))):
                raise ValueError('An ACTIVE virtual cycle is saved. Finish or manually abort it '
                                 'in OLD version, close the analyzer, then retry. Nothing changed.')
        backup_dir.mkdir(parents=True,exist_ok=True)
        destination=backup_dir/'analyzer.sqlite3'
        with sqlite3.connect(destination) as copy:
            conn.backup(copy)
        print('OK: consistent database backup saved (the original DB was not modified).')
    finally:
        conn.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--target',required=True,type=Path)
    parser.add_argument('--backup',required=True,type=Path)
    a=parser.parse_args()
    try:check_and_backup(a.target,a.backup)
    except Exception as exc:
        print('INSTALL BLOCKED:',exc)
        raise SystemExit(2)

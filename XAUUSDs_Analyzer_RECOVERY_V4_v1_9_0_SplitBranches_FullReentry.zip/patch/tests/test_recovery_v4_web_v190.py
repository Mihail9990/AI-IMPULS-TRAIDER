"""Authenticated API and backtesting support for independent split RECOVERY."""
from fastapi.testclient import TestClient
import pytest,time
import analyzer.server as server
AUTH=('admin','unique-v4-password-0123456789')

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD',AUTH[1]);monkeypatch.setenv('WEB_USERNAME',AUTH[0])
    monkeypatch.setenv('DATA_SOURCE','demo');monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as c:yield c

def test_v4_web_settings_and_saved_fields(client):
    html=client.get('/',auth=AUTH).text
    assert 'data-recovery-mode="split"' in html
    for name in ('recovery_v4_work_lots','recovery_v4_initial_lots',
                 'recovery_v4_second_entry_distance','recovery_v4_partial_lots',
                 'recovery_v4_stop_gap'):
        assert f'name="{name}"' in html
    values=dict(trigger_distance=1,tp_distance=.25,sl_distance=4,volume_lots=.03,
                recovery_enabled=True,recovery_variant='split',
                recovery_v4_initial_lots=.03,recovery_v4_work_lots=.06,
                recovery_v4_stop_gap=1.5,recovery_v4_second_entry_distance=.75,
                recovery_v4_partial_lots=.01,recovery_v4_range_mode='once')
    assert client.post('/api/settings',json=values).status_code==401
    result=client.post('/api/settings',auth=AUTH,json=values)
    assert result.status_code==200,result.text
    settings=client.get('/api/status',auth=AUTH).json()['settings']
    for k,v in values.items():assert settings[k]==v,(k,settings[k],v)

def test_v4_backtest_uses_full_volume_and_separate_parameters(client):
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1.0],
                 tps=[.25],sls=[4.0],volume_lots=.03,
                 recovery_enabled=True,recovery_variant='split',
                 recovery_v4_work_lots=.06,recovery_v4_stop_gap=1.5,
                 recovery_v4_second_entry_distance=.75,
                 recovery_v4_partial_lots=.01,recovery_v4_range_mode='once',
                 recovery_v4_expansion=1.0)
    result=client.post('/api/backtests',auth=AUTH,json=payload)
    assert result.status_code==200,result.text
    jid=result.json()['id']
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        job=client.get('/api/backtests/'+jid,auth=AUTH).json()
        if job['status'] in ('completed','failed'):break
        time.sleep(.05)
    assert job['status']=='completed',job.get('error')
    variants=client.get('/api/backtests/'+jid+'/variants',auth=AUTH).json()
    assert len(variants)==1
    config=variants[0]['config']
    assert config['recovery_variant']=='split'
    assert config['recovery_v4_work_lots']==.06
    assert config['recovery_v4_second_entry_distance']==.75

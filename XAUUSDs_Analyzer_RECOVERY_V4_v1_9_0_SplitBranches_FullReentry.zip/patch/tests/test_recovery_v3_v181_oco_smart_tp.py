"""RECOVERY V3 1.8.1: TWO STOPs during flat wait; opt-in SMART partial TP.

All tests are deterministic PAPER execution, no MT5 terminal orders.
"""
from dataclasses import asdict
import math
import pytest
from analyzer.engine import PaperEngine, Settings, Tick, Position, RecoveryLeg, RecoveryState


def tick(s, bid, spread=0.23):
    return Tick(int(s*1000),float(bid),float(bid+spread))


def config(**kwargs):
    cfg=dict(recovery_enabled=True,recovery_variant='fixed_flip',volume_lots=.03,
             recovery_v3_initial_lots=.03,recovery_v3_work_lots=.06,
             recovery_v3_initial_sl_distance=4.,recovery_v3_stop_gap=1.5,
             recovery_v3_partial_lots=.01)
    cfg.update(kwargs)
    return Settings(**cfg)


def waiting_after_buy_sl():
    e=PaperEngine(config(recovery_v3_range_mode='once'))
    e.mode='running'
    r=RecoveryState(0,Position('BUY',3918.83,3919.08,3914.83,0,3918.83,0,0,0,'BUY',0,lots=.03),
        3914.83,3914.83,3912.33,
        RecoveryLeg('BUY',3914.77,.06,1000,'fixed_flip',3913.27,v3_nominal_entry=3914.83),
        realized_weighted_points=-.18,variant='fixed_flip',v3_flip_count=2,v3_next_nominal=3912.33,
        pending_stops=[dict(side='SELL',level=3912.33,lots=.06,armed=True,created_ms=1000)])
    e.recovery=r
    e.latest=tick(3,3913.40)
    e.on_tick(tick(4,3913.27))
    assert e.recovery is r and r.active is None
    return e


def test_buy_sl_creates_both_oco_stops_instead_of_only_sell():
    e=waiting_after_buy_sl()
    pending={x['side']:x for x in e.recovery.pending_stops}
    assert set(pending)=={'BUY','SELL'}
    assert pending['BUY']['level']==pytest.approx(3914.83)
    assert pending['SELL']['level']==pytest.approx(3912.33)
    assert e.public_state()['recovery']['pending_stops'] and len(e.public_state()['recovery']['pending_stops'])==2
    assert e.recovery.v3_flip_count==3


def test_oco_buy_reentry_cancels_sell():
    e=waiting_after_buy_sl()
    e.on_tick(tick(5,3914.60)) # Ask 3914.83
    r=e.recovery
    assert r.active and r.active.side=='BUY'
    assert r.active.v3_nominal_entry==pytest.approx(3914.83)
    assert r.active.entry==pytest.approx(3914.83)
    assert [x for x in r.actions if x['type']=='v3_oco_cancel' and x['side']=='SELL']
    assert len(r.pending_stops)==1  # next stop PLANNED for any later BUY SL, not a live OCO
    assert r.pending_stops[0]['side']=='SELL'


def test_oco_sell_reentry_cancels_buy():
    e=waiting_after_buy_sl()
    e.on_tick(tick(5,3912.33))
    r=e.recovery
    assert r.active and r.active.side=='SELL'
    assert r.active.v3_nominal_entry==pytest.approx(3912.33)
    assert [x for x in r.actions if x['type']=='v3_oco_cancel' and x['side']=='BUY']


def test_waiting_between_sl_and_distant_stop_does_not_open():
    e=waiting_after_buy_sl()
    e.on_tick(tick(5,3913.20))
    e.on_tick(tick(6,3913.70))
    assert e.recovery.active is None
    assert len(e.recovery.pending_stops)==2


def test_sell_sl_reverses_same_and_opposite_levels():
    e=PaperEngine(config())
    r=RecoveryState(0,Position('SELL',4000,3999.75,4004,0,4000,0,0,0,'SELL',.23,lots=.03),
         4004.,4002.50,4000,
         RecoveryLeg('SELL',4000.02,.06,1000,'fixed_flip',4001.52,v3_nominal_entry=4000),
         realized_weighted_points=-.18,variant='fixed_flip',v3_flip_count=1,v3_next_nominal=4002.50,
         pending_stops=[dict(side='BUY',level=4002.50,lots=.06,armed=True,created_ms=1000)])
    e.mode='running';e.recovery=r
    e.on_tick(tick(2,4001.29))  # Ask 4001.52
    assert r.active is None
    levels={x['side']:x['level'] for x in r.pending_stops}
    assert levels=={'BUY':4002.50,'SELL':4000.0}


def test_manual_move_of_one_oco_order_preserves_other():
    e=waiting_after_buy_sl()
    e.move_trigger('recovery',3911.50,side='SELL')
    levels={x['side']:x['level'] for x in e.recovery.pending_stops}
    assert levels=={'BUY':3914.83,'SELL':3911.50}
    e.on_tick(tick(6,3914.60))
    assert e.recovery.active and e.recovery.active.side=='BUY'


def test_oco_snapshot_restores_both_pending_and_mode():
    e=waiting_after_buy_sl()
    e2=PaperEngine.from_snapshot(e.to_snapshot())
    assert len(e2.recovery.pending_stops)==2
    assert {x['side'] for x in e2.recovery.pending_stops}=={'SELL','BUY'}
    e2.on_tick(tick(5,3912.33))
    assert e2.recovery.active.side=='SELL'


def test_ambiguous_spread_overlap_does_not_choose_a_winner():
    e=waiting_after_buy_sl()
    # SELL STOP at 3912.33, BUY at 3914.83; bid/ask overlap both levels.
    e.on_tick(tick(5,3912.30,spread=2.60))
    assert e.recovery.active is None
    assert len(e.recovery.pending_stops)==2
    assert any(a['type']=='v3_spread_overlap' for a in e.recovery.actions)


def injected_trend(e,direction=1):
    e.candles=[]
    for minute in range(120):
        op=4000+direction*minute*.1
        cl=op+direction*.07
        e.candles.append(dict(time=minute*60,open=op,high=max(op,cl)+.03,
                              low=min(op,cl)-.03,close=cl,ticks=1))
    return Tick(120*60000,4012,4012.23)


def test_smart_tp_toggle_explicitly_disabled_by_default_and_validated():
    assert config().recovery_v3_smart_tp_enabled is False
    with pytest.raises(ValueError,match='SMART TP toggle'):
        config(recovery_v3_smart_tp_enabled='yes')


def test_trend_classifier_is_side_aware_and_uses_closed_bars():
    e=PaperEngine(config(recovery_v3_smart_tp_enabled=True))
    tick_now=injected_trend(e,1)
    assert e._v3_smart_tp_regime('BUY',tick_now)=='late'
    assert e._v3_smart_tp_regime('SELL',tick_now)=='early'
    e.candles=e.candles[:20]
    assert e._v3_smart_tp_regime('BUY',tick_now)=='equal'


def test_smart_grid_preserves_weighted_debt_and_changes_first_target():
    e=PaperEngine(config(recovery_v3_smart_tp_enabled=True))
    t=injected_trend(e)
    origin=Position('BUY',4000,4000.25,3996,0,4000,0,0,0,'BUY',0,lots=.03)
    r=RecoveryState(0,origin,3996,4000,3996,
        RecoveryLeg('BUY',4000,.06,t.t_ms,'fixed_flip',3998.5,v3_nominal_entry=4000),
        realized_weighted_points=-.18,variant='fixed_flip')
    e.recovery=r;e.mode='running'
    # For a clear comparison set spread to zero and current Bid = entry.
    t=Tick(t.t_ms,4000,4000)
    e._v3_grid_rebuild(t)
    late=list(r.active.v3_tp_targets)
    assert r.active.v3_tp_regime=='late'
    assert sum((x['price']-4000)*x['lots'] for x in late)>=.18-1e-8
    e.settings=config(recovery_v3_smart_tp_enabled=False)
    e._v3_grid_rebuild(t)
    equal=list(r.active.v3_tp_targets)
    assert equal[0]['price']<late[0]['price']
    assert math.isclose(equal[0]['price'],4000.86,abs_tol=.011)
    e.settings=config(recovery_v3_smart_tp_enabled=True)
    injected_trend(e,direction=-1)
    e._v3_grid_rebuild(t)
    assert r.active.v3_tp_regime=='early'
    assert r.active.v3_tp_targets[0]['price']<equal[0]['price']


def test_smart_setting_and_oco_targets_survive_snapshot():
    e=waiting_after_buy_sl()
    e.settings=config(recovery_v3_smart_tp_enabled=True)
    restored=PaperEngine.from_snapshot(e.to_snapshot())
    assert restored.settings.recovery_v3_smart_tp_enabled is True
    assert len(restored.recovery.pending_stops)==2

@pytest.fixture
def client(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    import analyzer.server as server
    monkeypatch.setenv('WEB_PASSWORD','safe-v3-oco-smart-tp-test-password')
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as x:yield x


def test_smart_tp_ui_and_settings_api(client):
    auth=('admin','safe-v3-oco-smart-tp-test-password')
    html=client.get('/',auth=auth).text
    assert 'name="recovery_v3_smart_tp_enabled"' in html
    payload=dict(trigger_distance=1,tp_distance=.25,sl_distance=3,volume_lots=.03,
                 recovery_enabled=True,recovery_variant='fixed_flip',
                 recovery_v3_initial_lots=.03,recovery_v3_work_lots=.06,
                 recovery_v3_partial_lots=.01,recovery_v3_smart_tp_enabled=True)
    result=client.post('/api/settings',auth=auth,json=payload)
    assert result.status_code==200,result.text
    setting=client.get('/api/status',auth=auth).json()['settings']
    assert setting['recovery_v3_smart_tp_enabled'] is True

def test_v3_smart_tp_backtest_api_serializes_its_setting(client):
    import time
    auth=('admin','safe-v3-oco-smart-tp-test-password')
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',distances=[1.0],tps=[.25],
        sls=[4.0],volume_lots=.03,recovery_enabled=True,recovery_variant='fixed_flip',
        recovery_v3_work_lots=.06,recovery_v3_stop_gap=1.5,
        recovery_v3_partial_lots=.01,recovery_v3_smart_tp_enabled=True,
        recovery_v3_range_mode='once',recovery_v3_expansion=1.0)
    r=client.post('/api/backtests',json=payload,auth=auth)
    assert r.status_code==200,r.text
    job_id=r.json()['id']
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        job=client.get('/api/backtests/'+job_id,auth=auth).json()
        if job['status'] in ('completed','failed'):break
        time.sleep(.05)
    assert job['status']=='completed',job.get('error')
    rows=client.get('/api/backtests/'+job_id+'/variants',auth=auth).json()
    assert len(rows)==1
    assert rows[0]['config']['recovery_v3_smart_tp_enabled'] is True

"""V4 split entry/TP tests; no real broker transactions."""
import pytest
from dataclasses import asdict
from analyzer.engine import Settings,PaperEngine,RecoveryState,Position,RecoveryLeg,Tick


def cfg(**extra):
    d=dict(recovery_enabled=True,recovery_variant='split',volume_lots=.03,
           recovery_v4_initial_lots=.03,recovery_v4_work_lots=.06,
           recovery_v4_initial_sl_distance=4,recovery_v4_stop_gap=1.5,
           recovery_v4_partial_lots=.01,recovery_v4_second_entry_distance=1.0,
           tick_size=.01,tick_value_per_lot=1)
    d.update(extra)
    return Settings(**d)


def t(i,bid,spread=.23):return Tick(i*1000,float(bid),round(bid+spread,10))


def start_sell(**extra):
    e=PaperEngine(cfg(**extra));e.mode='running'
    origin=Position('BUY',4000,4000.25,3996,0,4000,0,0,0,'BUY',.23,lots=.03)
    r=RecoveryState(1000,origin,3996,4000,3996,None,
        realized_weighted_points=-.12,variant='split',v3_last_nominal=4000,
        v3_next_nominal=3996,pending_stops=[dict(side='SELL',level=3996,
        lots=.06,armed=True,created_ms=1000)])
    e.recovery=r
    e.on_tick(t(2,3996))
    assert r.active and r.active.v4_branch=='A'
    return e,r


def test_v4_initial_split_only_half_enters_until_plus_one():
    e,r=start_sell()
    assert r.active.lots==pytest.approx(.03)
    assert r.v4_second is None and r.v4_wait_second
    assert r.v4_second_trigger==pytest.approx(3995.00)
    assert r.active.stop==pytest.approx(3997.50)
    e.on_tick(t(3,3995.20)) # Ask=3995.43, not at +1 yet
    assert r.v4_second is None
    e.on_tick(t(4,3994.77)) # Ask=3995.00 triggers B at observed Bid
    assert r.v4_second and r.v4_second.lots==pytest.approx(.03)
    assert r.v4_second.entry==pytest.approx(3994.77)
    assert r.v4_second.stop==pytest.approx(3996.27)


def test_v4_sl_before_second_branch_limits_losing_volume():
    e,r=start_sell()
    e.on_tick(t(3,3997.27)) # Ask=3997.50, 1.5 adverse
    assert r.active is None and r.v4_second is None
    assert any(x['type']=='v4_branch_sl' and x['lots']==pytest.approx(.03) for x in r.actions)
    assert r.realized_weighted_points==pytest.approx(-.12-.045)
    assert {p['side'] for p in r.pending_stops}=={'SELL','BUY'}
    assert all(p['lots']==pytest.approx(.06) for p in r.pending_stops)


def test_v4_reenter_after_sl_uses_full_volume_not_remainder():
    e,r=start_sell()
    e.on_tick(t(3,3994.77)) # branch B opens
    assert r.v4_second
    e._v4_close_lots(t(4,3994.30),'A',.01,'v4_partial_tp')
    r.partial_tps+=1
    assert r.active.lots==pytest.approx(.02) and r.v4_second.lots==pytest.approx(.03)
    e.on_tick(t(5,3996.04)) # Ask=3996.27 -> B SL, A still alive
    assert r.v4_second is None and r.active is not None
    e.on_tick(t(6,3997.27)) # Ask=3997.50 -> A SL
    assert r.active is None and len(r.pending_stops)==2
    assert all(p['lots']==pytest.approx(.06) for p in r.pending_stops)
    # First new recovery entry uses FULL .06 configured capacity, staged A/B.
    e.on_tick(t(7,3997.27)) # armed BUY might hit 3997.5 via ask
    if not r.active:e.on_tick(t(8,3997.50))
    assert r.active and r.active.lots==pytest.approx(.03)
    assert r.v4_wait_second and r.v4_second is None


def test_v4_tp_ladder_alternates_and_preserves_net_target():
    e,r=start_sell()
    e.on_tick(t(3,3994.77))
    targets=r.v4_tp_targets
    assert len(targets)==6
    assert [x['branch'] for x in targets]==['A','B','A','B','A','B']
    assert all(targets[i]['price']>targets[i+1]['price'] for i in range(5))
    # First target executable on SELL's Ask
    q=targets[0]['price']
    e.on_tick(t(4,round(q-.23,2)))
    assert r.partial_tps==1
    assert r.active.lots==pytest.approx(.02)
    assert r.v4_second.lots==pytest.approx(.03)
    assert r.v4_tp_targets[0]['branch']=='B'


def test_v4_both_positions_count_toward_ledger_and_snapshot():
    e,r=start_sell()
    e.on_tick(t(3,3994.77))
    quote=t(4,3994.90)
    weighted,_=e._recovery_net(quote)
    assert weighted==pytest.approx(r.realized_weighted_points+
        (r.active.entry-quote.ask)*r.active.lots+
        (r.v4_second.entry-quote.ask)*r.v4_second.lots)
    clone=PaperEngine.from_snapshot(e.to_snapshot())
    assert clone.recovery.v4_second.entry==pytest.approx(3994.77)
    assert clone.recovery.v4_wait_second==False
    assert clone.recovery.v4_tp_targets==r.v4_tp_targets
    assert clone.settings.recovery_variant=='split'


def test_v4_requires_equal_valid_branch_volumes():
    with pytest.raises(ValueError,match='two equal'):
        cfg(recovery_v4_work_lots=.05)
    with pytest.raises(ValueError,match='part'):
        cfg(recovery_v4_partial_lots=.04)


def test_v3_reentry_after_partial_tp_uses_full_configured_lots():
    cfg3=Settings(recovery_enabled=True,recovery_variant='fixed_flip',volume_lots=.03,
                  recovery_v3_initial_lots=.03,recovery_v3_work_lots=.06,
                  recovery_v3_partial_lots=.01,tick_value_per_lot=1)
    e=PaperEngine(cfg3);e.mode='running'
    pos=Position('BUY',4000,4000.25,3996,0,4000,0,0,0,'BUY',.23,lots=.03)
    r=RecoveryState(1000,pos,3996,4000,3996,
        RecoveryLeg('SELL',3996,.06,2000,'fixed_flip',3997.5,
                    v3_nominal_entry=3996),variant='fixed_flip',realized_weighted_points=-.20,
                    v3_next_nominal=3997.5,pending_stops=[dict(side='BUY',level=3997.5,lots=.06,armed=True)])
    e.recovery=r
    e._recovery_close_lots(t(3,3995.5),.02,'v3_partial_tp')
    assert r.active.lots==pytest.approx(.04)
    e.on_tick(t(4,3997.27))
    # Opposite stop is already hit on this tick, so the engine may immediately
    # re-enter. The important invariant is that it re-enters FULL .06, not .04.
    assert r.active is not None and r.active.lots==pytest.approx(.06)
    assert r.active.side=='BUY'


def test_v4_buy_branch_b_after_bid_moves_plus_one():
    e=PaperEngine(cfg());e.mode='running'
    origin=Position('SELL',4000,3999.75,4004,0,4000,0,0,0,'SELL',.23,lots=.03)
    r=RecoveryState(1000,origin,4004,4004,4000,None,realized_weighted_points=-.12,
          variant='split',v3_next_nominal=4004,pending_stops=[dict(side='BUY',level=4004,lots=.06,armed=True)])
    e.recovery=r
    e.on_tick(t(2,4003.77)) # ask=4004.00 executes A
    assert r.active.side=='BUY' and r.active.entry==pytest.approx(4004)
    e.on_tick(t(3,4004.90)) # Bid only +.90
    assert r.v4_second is None
    e.on_tick(t(4,4005.00)) # Bid +1; B buys at Ask 4005.23
    assert r.v4_second and r.v4_second.entry==pytest.approx(4005.23)
    assert r.v4_second.stop==pytest.approx(4003.73)


def test_v4_no_smart_tp_and_independent_settings():
    e=PaperEngine(cfg(recovery_v3_smart_tp_enabled=True,
                      recovery_v4_second_entry_distance=.75))
    assert e.settings.recovery_v3_smart_tp_enabled is True
    assert e.settings.recovery_v4_second_entry_distance==pytest.approx(.75)
    assert e.settings.recovery_v4_work_lots==pytest.approx(.06)


def test_v4_manual_close_can_close_both_branches_and_replans():
    e,r=start_sell()
    e.on_tick(t(3,3994.77))
    assert r.v4_second
    e.manual_close('recovery',.04)
    assert r.active is None
    assert r.v4_second and r.v4_second.lots==pytest.approx(.02)
    assert len(r.v4_tp_targets)==2

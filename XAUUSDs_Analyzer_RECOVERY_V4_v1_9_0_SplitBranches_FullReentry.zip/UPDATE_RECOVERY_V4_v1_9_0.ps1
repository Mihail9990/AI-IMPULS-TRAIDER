﻿param([string]$TargetDirectory='')
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$files=@(
  'analyzer\\engine.py',
  'analyzer\\backtest.py',
  'analyzer\\live.py',
  'analyzer\\server.py',
  'web\\index.html',
  'web\\app.js',
  'web\\terminal.css',
  'tests\\test_recovery_v3_v181_oco_smart_tp.py',
  'tests\\test_recovery_v4_split_v190.py',
  'tests\\test_recovery_v4_web_v190.py',
  'tests\\test_recovery_v2_api_v160.py',
  'tests\\test_recovery_v2_separate_sl_v161.py',
  'tests\\test_reset_statistics_v141.py',
  'tools\\precheck_v190.py'
)
function Main {
 Write-Host 'XAUUSD.s Analyzer: RECOVERY V4 v1.9.0 (two branches + FULL reentry volume)' -ForegroundColor Cyan
 Write-Host 'Supports installed v1.8.0 OR v1.8.1. Includes v1.8.1 OCO/SMART-TP fixes.'
 Write-Host 'No order_send or real broker transactions; never changes MT5/Caddy/HTTPS.'
 $manifest=Join-Path $here 'SHA256SUMS.txt'
 if(-not(Test-Path -LiteralPath $manifest -PathType Leaf)){throw 'SHA256SUMS.txt missing'}
 $hashes=@{}
 foreach($line in (Get-Content -LiteralPath $manifest)) {
  if($line -match '^([0-9a-fA-F]{64})\s{2}(.+)$') {$hashes[$matches[2]]=$matches[1].ToLowerInvariant()}
 }
 foreach($rel in $files) {
  $key='patch/'+($rel.Replace('\','/'))
  $src=Join-Path (Join-Path $here 'patch') $rel
  if(-not(Test-Path -LiteralPath $src -PathType Leaf)){throw ('Missing '+$key)}
  if(-not $hashes.ContainsKey($key)){throw ('Missing checksum '+$key)}
  if((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hashes[$key]){
   throw ('SHA-256 mismatch: '+$key)
  }
 }
 Write-Host '[OK] All package checksums verified.' -ForegroundColor Green
 if(-not $TargetDirectory) {
  Add-Type -AssemblyName System.Windows.Forms
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description='Select INSTALLED analyzer folder (start_windows.bat and .env)'
  $dialog.ShowNewFolderButton=$false
  if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){Write-Host 'Canceled';return}
  $TargetDirectory=$dialog.SelectedPath
 }
 $target=[System.IO.Path]::GetFullPath($TargetDirectory)
 foreach($rel in @('start_windows.bat','.env','analyzer\engine.py','analyzer\server.py','web\app.js','web\index.html')) {
  if(-not(Test-Path -LiteralPath (Join-Path $target $rel) -PathType Leaf)){
   throw ('Wrong folder: missing '+$rel)
  }
 }
 $existing=[System.IO.File]::ReadAllText((Join-Path $target 'analyzer\engine.py'))
 if(-not ($existing.Contains('recovery_v3_range_mode') -and $existing.Contains('_v3_grid_rebuild') -and
          $existing.Contains('recovery_v3_partial_lots'))){
  throw 'Existing analyzer must be v1.8.0 or v1.8.1. No changes made.'
 }
 $envFile=[System.IO.File]::ReadAllText((Join-Path $target '.env'))
 $port=8765
 $match=[regex]::Match($envFile,'(?m)^\s*WEB_PORT\s*=\s*(\d+)')
 if($match.Success){$port=[int]$match.Groups[1].Value}
 if(Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
  if(@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue).Count -gt 0){
   throw ('Analyzer still listening on '+$port+'. Close start_windows.bat first.')
  }
 }
 $python=Join-Path $target '.venv\Scripts\python.exe'
 $useLauncher=$false
 if(-not(Test-Path -LiteralPath $python -PathType Leaf)){
  $candidate=Get-Command py -ErrorAction SilentlyContinue
  if(-not $candidate){throw 'Python not found for state snapshot validation'}
  $python=$candidate.Source;$useLauncher=$true
 }
 $backup=Join-Path $target ('backup_RECOVERY_V4_v1_9_0_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
 New-Item -ItemType Directory -Path $backup -Force|Out-Null
 $precheck=Join-Path (Join-Path $here 'patch') 'tools\precheck_v190.py'
 if($useLauncher){& $python -3.13 $precheck --target $target --backup (Join-Path $backup 'database')}
 else{& $python $precheck --target $target --backup (Join-Path $backup 'database')}
 if($LASTEXITCODE -ne 0){throw 'ACTIVE cycle or SQLite precheck error; old files unchanged.'}
 $existed=@{}
 try {
  foreach($rel in $files) {
   $dest=Join-Path $target $rel;$existed[$rel]=Test-Path -LiteralPath $dest -PathType Leaf
   if($existed[$rel]){
    $bk=Join-Path $backup $rel
    New-Item -ItemType Directory -Path (Split-Path -Parent $bk) -Force|Out-Null
    Copy-Item -LiteralPath $dest -Destination $bk -Force
   }
  }
  foreach($rel in $files) {
   $src=Join-Path (Join-Path $here 'patch') $rel
   $dest=Join-Path $target $rel
   New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
   Copy-Item -LiteralPath $src -Destination $dest -Force
   Write-Host ('Updated '+$rel)
  }
 }catch {
  Write-Host 'File copy failed, restoring previous sources...' -ForegroundColor Yellow
  foreach($rel in $files){
   $dest=Join-Path $target $rel;$bk=Join-Path $backup $rel
   if(Test-Path -LiteralPath $bk -PathType Leaf){Copy-Item -LiteralPath $bk -Destination $dest -Force}
   elseif($existed.ContainsKey($rel) -and -not $existed[$rel] -and (Test-Path -LiteralPath $dest -PathType Leaf)){
    Remove-Item -LiteralPath $dest -Force
   }
  }
  throw
 }
 Write-Host '[OK] RECOVERY V4 v1.9.0 installed. All existing settings, trades, MT5, Caddy and HTTPS are unchanged.' -ForegroundColor Green
 Write-Host ('Source/database backup: '+$backup)
 Write-Host 'Restart start_windows.bat, Ctrl+F5 / clear Android browser cache, select V4 in Settings.'
}
try {Main}catch {Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}

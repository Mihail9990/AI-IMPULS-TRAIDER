"""Run with: python run.py"""
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent/'.env')

if len(os.getenv('WEB_PASSWORD','')) < 16 or os.getenv('WEB_PASSWORD','').startswith('REPLACE_'):
    sys.exit('ERROR: Copy .env.example to .env and set your OWN password, 16+ characters.')

import uvicorn

if __name__=='__main__':
    uvicorn.run('analyzer.server:app',host=os.getenv('WEB_HOST','127.0.0.1'),
                port=int(os.getenv('WEB_PORT','8765')),
                log_level=os.getenv('LOG_LEVEL','info'),reload=False,workers=1)

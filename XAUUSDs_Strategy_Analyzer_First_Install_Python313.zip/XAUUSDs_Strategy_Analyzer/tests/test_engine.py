import pytest
from analyzer.engine import PaperEngine, Settings, Tick


def tick(minute,sec,bid,ask=None):
    return Tick((minute*60+sec)*1000,bid,ask if ask is not None else bid+0.23)


def eng(distance=1,tp=.25,sl=3):
    e=PaperEngine(Settings(trigger_distance=distance,tp_distance=tp,sl_distance=sl))
    e.start();return e


def test_wait_closed_candle_and_keep_on_same_color():
    e=eng()
    e.on_tick(tick(0,0,4000))
    e.on_tick(tick(0,58,4000.50))
    assert e.pending is None
    e.on_tick(tick(1,0,4000.55))
    assert e.pending.side=='BUY' and e.pending.level==4001.5
    e.on_tick(tick(1,56,4000.7))
    e.on_tick(tick(2,0,4000.74))
    assert e.pending.level==4001.5 and e.canceled_orders==0
    assert e.placed_orders==1


def test_opposite_candle_cancels_and_doji_keeps():
    e=eng()
    e.on_tick(tick(0,0,4000))
    e.on_tick(tick(0,50,4000.4))
    e.on_tick(tick(1,0,4000.41))
    assert e.pending.side=='BUY'
    e.on_tick(tick(1,59,3999.9))
    e.on_tick(tick(2,0,3999.85))
    assert e.pending.side=='SELL' and e.pending.level==3998.9
    assert e.canceled_orders==1
    # Minute 2 opens 3999.85, closes unchanged -> doji does not cancel.
    e.on_tick(tick(3,0,3999.8))
    assert e.pending.side=='SELL' and e.placed_orders==2


def test_ask_triggers_buy_and_bid_closes_tp():
    e=eng()
    e.on_tick(tick(0,0,4000))
    e.on_tick(tick(0,50,4000.5))
    e.on_tick(tick(1,0,4000.6))
    assert e.pending.level==4001.5
    e.on_tick(tick(1,1,4001.24,4001.48))
    assert e.position is None  # ASK did not cross threshold
    e.on_tick(tick(1,2,4001.30,4001.53))
    assert e.position is not None and e.position.entry==4001.53
    assert e.position.tp==4001.78
    e.on_tick(tick(1,3,4001.77,4002.00))
    assert e.position is not None  # BID below TP despite ASK crossing
    e.on_tick(tick(1,4,4001.78,4002.01))
    assert e.position is None
    assert e.summary()['tp']==1
    assert e.trades[0]['pnl_points']==pytest.approx(.25)


def test_sell_stopped_on_ask_not_bid():
    e=eng()
    e.on_tick(tick(0,0,4000))
    e.on_tick(tick(0,50,3999.5))
    e.on_tick(tick(1,0,3999.4,3999.63))
    assert e.pending.side=='SELL' and e.pending.level==3998.5
    e.on_tick(tick(1,1,3998.45,3998.68))
    assert e.position and e.position.sl==4001.45
    e.on_tick(tick(1,2,4001.19,4001.42))
    assert e.position
    e.on_tick(tick(1,3,4001.23,4001.47))
    assert e.summary()['sl']==1
    assert e.trades[0]['exit']==4001.47  # worse than SL due to gap


def test_almost_tp_then_sl_and_color_does_not_cancel_filled_position():
    e=eng()
    e.on_tick(tick(0,0,4000))
    e.on_tick(tick(0,50,4000.5))
    e.on_tick(tick(1,0,4000.6))
    e.on_tick(tick(1,1,4001.30,4001.50)) # BUY entry=4001.50, target 4001.75
    e.on_tick(tick(1,10,4001.73,4001.96))
    e.on_tick(tick(1,50,4000.4,4000.63))
    e.on_tick(tick(2,0,4000.2,4000.43)) # opposite closed candle, but position retained
    assert e.position and e.pending is None
    e.on_tick(tick(2,10,3998.50,3998.73))
    assert e.trades[0]['result']=='SL'
    assert e.trades[0]['gap_to_tp']==pytest.approx(.02)
    assert e.summary()['near_tp_then_sl']['0.02']==1
    assert e.summary()['near_tp_then_sl']['0.01']==0


def test_stop_deferred_and_force_stop_do_not_invent_sl():
    e=eng();e.on_tick(tick(0,0,4000));e.on_tick(tick(0,50,4000.5));e.on_tick(tick(1,0,4000.6))
    e.request_stop()
    assert e.mode=='stopping' and e.pending
    e.force_stop()
    assert e.mode=='stopped' and e.summary()['sl']==0 and e.summary()['tp']==0


def test_snapshot_restore_preserves_working_levels():
    e=eng();e.on_tick(tick(0,0,4000));e.on_tick(tick(0,50,4000.5));e.on_tick(tick(1,0,4000.6))
    clone=PaperEngine.from_snapshot(e.to_snapshot())
    assert clone.pending.level==4001.5
    clone.on_tick(tick(1,1,4001.3,4001.55))
    assert clone.position and clone.position.entry==4001.55


def test_backtest_and_live_same_tick_sequence():
    seq=[tick(0,0,4000),tick(0,51,4000.5),tick(1,0,4000.6),tick(1,1,4001.30,4001.53),tick(1,2,4001.78,4002)]
    a=eng();b=eng()
    for t in seq:a.on_tick(t)
    for t in seq[:3]:b.on_tick(t)
    clone=PaperEngine.from_snapshot(b.to_snapshot())
    for t in seq[3:]:clone.on_tick(t)
    assert a.summary()==clone.summary()


def test_reject_invalid_quotes():
    with pytest.raises(ValueError):Tick(0,4001,4000)
    with pytest.raises(ValueError):Settings(tp_distance=0)


def test_old_pending_may_fill_on_first_tick_of_opposite_new_candle():
    e=eng()
    e.on_tick(tick(0,0,4000))
    e.on_tick(tick(0,50,4000.5))
    e.on_tick(tick(1,0,4000.6))
    assert e.pending.side=='BUY'
    e.on_tick(tick(1,40,4000.1,4000.33))  # red candle
    # At the boundary, ASK crosses the OLD BUY STOP before cancellation can happen.
    e.on_tick(tick(2,0,4001.3,4001.6))
    assert e.position and e.position.side=='BUY'
    assert e.canceled_orders==0

'use strict';
// No third-party chart library, account keys, exchange permissions or trading APIs.
const $ = (id) => document.getElementById(id);
const app = {tab:'live', status:null, marketCandles:[], replay:null, replayTimer:null,
  currentRun:null, selectedVariant:null, variants:[], settingsTouched:false, firstStatus:true,
  visibleBars:76, rightOffset:0, pointerMap:new Map(), drag:null, hover:null, mouseX:0, rendering:false};
const currency=(n,d=2)=>Number.isFinite(Number(n))?Number(n).toFixed(d):'—';
const sign=(n)=>Number(n)>0?'+':'';
const htmlesc=(str)=>String(str).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const ts=(ms,full=false)=>ms?new Date(ms).toLocaleString('ru-RU', full?{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}:{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';
const safe=(x)=>htmlesc(x??'—');
let toastTimer;
function toast(message){const el=$('toast');el.textContent=message;el.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),6500);}
async function api(path,options={}){
  const opts={credentials:'same-origin',...options,headers:{...(options.body?{'Content-Type':'application/json'}:{}),...options.headers}};
  const res=await fetch(path,opts);let data;
  try {data=await res.json();}catch {data=null;}
  if(!res.ok)throw Error(typeof data?.detail==='string'?data.detail:`HTTP ${res.status}`);
  return data;
}
function bodyForm(form){return Object.fromEntries(new FormData(form));}
function toggleTab(tab){
  app.tab=tab;
  document.querySelectorAll('[data-tab]').forEach(e=>e.classList.toggle('active',e.dataset.tab===tab));
  document.querySelectorAll('.page').forEach(e=>e.classList.toggle('active',e.id===`tab-${tab}`));
  $('activeBreadcrumb').textContent={live:'Онлайн',backtest:'Массовые тесты',insights:'Закономерности',history:'История'}[tab]||tab;
  if(tab==='history')refreshJobs();
  if(tab==='backtest')refreshVariants();
  if(tab==='insights')refreshRegimes();
  if(tab==='live')requestAnimationFrame(drawChart);
  window.scrollTo({top:0,behavior:'instant'});
}
function floatField(form,name){const v=Number(form.elements[name].value);if(!Number.isFinite(v))throw Error(`Неверное значение: ${name}`);return v;}
function setSettings(settings){
  if(app.settingsTouched)return;
  const form=$('settingsForm');
  for(const key of ['trigger_distance','tp_distance','sl_distance','volume_lots','commission_per_lot_roundtrip']){
    if(settings[key]!==undefined)form.elements[key].value=settings[key];
  }
}
function presentStatus(s){
  app.status=s;
  if(app.firstStatus){setSettings(s.settings);app.firstStatus=false;}
  const isDemo=s.source==='demo';
  $('sourceName').textContent=`${isDemo?'SYNTHETIC / DEMO':s.symbol}`;
  $('sourcePill').textContent=isDemo?'DEMO / НЕ РЫНОК':'MT5 CFD';
  $('sourcePill').style.color=isDemo?'#f0c878':'';
  $('demoBanner').classList.toggle('hidden',!isDemo);
  $('connectionBanner').classList.toggle('hidden',s.connection==='connected');
  $('connectionError').textContent=s.error||'Ожидание данных котировок';
  const conn=$('sidebarConnection');conn.className='connection '+s.connection;conn.innerHTML=`<i class="status-led"></i> ${s.connection==='connected'?'Котировки доступны':s.connection==='catching_up'?'Синхронизация истории':'Соединение отсутствует'}`;
  const mode=s.mode;
  const badge=$('liveModeBadge');badge.textContent={stopped:'Остановлен',running:'● Анализ активен',stopping:'Завершаем цикл'}[mode]||mode;
  badge.className='tag '+(mode==='running'?'active':mode==='stopping'?'stopping':'neutral');
  $('btnStart').disabled=mode!=='stopped'; $('btnStop').disabled=mode==='stopped';
  $('bidPrice').textContent=currency(s.tick?.bid); $('askPrice').textContent=currency(s.tick?.ask);
  $('spreadPrice').textContent=s.tick?currency(s.tick.ask-s.tick.bid):'—';
  const sum=s.summary;
  $('tpCount').textContent=sum.tp; $('slCount').textContent=sum.sl;
  $('tradeCount').textContent=sum.trades;
  $('winRate').textContent=currency(sum.win_rate,1)+'%';
  $('netPoints').textContent=sign(sum.pnl_points)+currency(sum.pnl_points);
  $('netPoints').className=sum.pnl_points>0?'positive':sum.pnl_points<0?'negative':'';
  $('maxDrawdown').textContent=currency(sum.max_drawdown_points);
  $('nearTPStats').innerHTML=Object.entries(sum.near_tp_then_sl).map(([v,n])=>`<div class="near-item">≤ ${safe(v)}<strong>${n} SL</strong></div>`).join('');
  updateCycle(s);
  updateEvents(s.events||[]);
  updateLiveTrades(s.trades||[]);
  if(!app.replay && s.tick && app.marketCandles.length){
    const minute=Math.floor(s.tick.t_ms/60000)*60;
    const idx=app.marketCandles.findIndex(c=>c.time===minute);
    if(idx>=0){const c=app.marketCandles[idx];c.close=s.tick.bid;c.high=Math.max(c.high,s.tick.bid);c.low=Math.min(c.low,s.tick.bid);}
  }
  requestDraw();
}
function updateCycle(s){
  const p=s.position, pend=s.pending, has=p||pend;
  $('cycleDot').classList.toggle('active',!!has);
  $('cycleStatus').textContent=p?'Позиция открыта':pend?'Триггер ожидает исполнения':s.mode==='running'?'Ожидание закрытой свечи':'Нет активного цикла';
  if(!has){$('currentCycle').innerHTML=`<div class="state-placeholder">${s.mode==='running'?'После закрытия M1 будет установлен новый виртуальный STOP.':'Запусти симуляцию для отслеживания триггеров.'}</div>`;return;}
  const side=p?.side??pend.side;
  const rows=p?[['Цена входа',currency(p.entry)],['Take Profit',currency(p.tp)],['Stop Loss',currency(p.sl)],['Спред при входе',currency(p.entry_spread)],['MFE / MAE',`${currency(p.mfe)} / ${currency(p.mae)}`]]:
    [['Триггер STOP',currency(pend.level)],['Закрытая свеча',new Date(pend.signal_time*1000).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})],['TP (ориентир)',currency(side==='BUY'?pend.level+s.settings.tp_distance:pend.level-s.settings.tp_distance)],['SL (ориентир)',currency(side==='BUY'?pend.level-s.settings.sl_distance:pend.level+s.settings.sl_distance)]];
  $('currentCycle').innerHTML=`<div class="cycle-type"><span class="type ${side.toLowerCase()}">${side} ${p?'POSITION':'STOP'}</span><span>${p?'ОТКРЫТО':'PENDING'}</span></div>`+rows.map(([name,value])=>`<div class="price-row"><span>${name}</span><b>${safe(value)}</b></div>`).join('');
}
const eventText={start:'Запуск анализа',stop_requested:'Остановка после цикла',forced_stop:'Принудительная остановка',forced_cancel:'Отмена триггера',forced_abandon:'Отказ от виртуальной позиции',place:'Выставлен STOP',cancel:'Триггер переставлен',fill:'Триггер исполнен',tp:'Take Profit',sl:'Stop Loss'};
function updateEvents(events){
  if(!events.length)return;
  $('eventFeed').innerHTML=events.slice(-14).reverse().map(e=>`<div class="event"><i class="event-led ${(e.side||'').toLowerCase()}"></i><div><strong>${safe(eventText[e.type]||e.type)} ${e.side||''} ${e.price!==undefined?currency(e.price):''}</strong><small>${e.reason==='opposite_closed_candle'?'Смена цвета M1':e.pnl_points!==undefined?`Результат ${sign(e.pnl_points)}${currency(e.pnl_points)} пункта`:''} <span class="event-time">${ts(e.t_ms)}</span></small></div></div>`).join('');
}
function updateLiveTrades(trades){
  const body=$('liveTradesBody');
  if(!trades.length){body.innerHTML='<tr><td colspan="7" class="empty-table">Пока нет сделок</td></tr>';return;}
  body.innerHTML=trades.slice().reverse().slice(0,20).map(t=>`<tr><td>${ts(t.opened_ms)}</td><td><span class="type ${t.side.toLowerCase()}">${t.side}</span></td><td>${currency(t.entry)}</td><td>${currency(t.exit)}</td><td><span class="result-pill ${t.result.toLowerCase()}">${t.result}</span></td><td class="${t.pnl_points>=0?'positive':'negative'}">${sign(t.pnl_points)}${currency(t.pnl_points)}</td><td>${t.result==='SL'?currency(t.gap_to_tp):'—'}</td></tr>`).join('');
}
function levels(){
  if(app.replay){const tr=app.replay.trade;const tick=app.replay.ticks[app.replay.index];if(!tick)return [];
    const out=[{price:tick.bid,label:'BID',color:'#6ba9f5',dash:[3,2]},{price:tick.ask,label:'ASK',color:'#c7a0e9',dash:[2,2]}];
    if(tick.t_ms<tr.opened_ms){out.push({price:tr.trigger_level,label:'STOP',color:'#e8b756',dash:[6,3]});}
    else if(tick.t_ms<=tr.closed_ms){out.push({price:tr.entry,label:'ENTRY',color:'#e8b756'}, {price:tr.tp,label:'TP',color:'#26c995',dash:[5,3]}, {price:tr.sl,label:'SL',color:'#ed7182',dash:[5,3]});}
    return out;
  }
  const s=app.status;if(!s)return [];
  const o=[];
  if(s.pending){const p=s.pending;const buy=p.side==='BUY';o.push({price:p.level,label:p.side+' STOP',color:'#e8b756',dash:[7,4]},{price:p.level+(buy?1:-1)*s.settings.tp_distance,label:'TP*',color:'#27b98b',dash:[4,6]},{price:p.level+(buy?-1:1)*s.settings.sl_distance,label:'SL*',color:'#dc6f7d',dash:[4,6]});}
  if(s.position){const p=s.position;o.push({price:p.entry,label:'ENTRY',color:'#e8b756'},{price:p.tp,label:'TP',color:'#26c995',dash:[6,3]},{price:p.sl,label:'SL',color:'#ed7182',dash:[6,3]});}
  if(s.tick){o.push({price:s.tick.bid,label:'BID',color:'#6ba9f5',dash:[2,3]},{price:s.tick.ask,label:'ASK',color:'#c7a0e9',dash:[2,3]});}
  return o;
}
function chartData(){
  if(!app.replay)return app.marketCandles;
  const ticks=app.replay.ticks;let idx=app.replay.index;
  const bars=[];let last=null;
  for(let i=0;i<=idx&&i<ticks.length;i++){
    const tk=ticks[i],time=Math.floor(tk.t_ms/60000)*60;
    if(!last||last.time!==time){last={time,open:tk.bid,high:tk.bid,low:tk.bid,close:tk.bid};bars.push(last);}
    else{last.high=Math.max(last.high,tk.bid);last.low=Math.min(last.low,tk.bid);last.close=tk.bid;}
  }
  return bars;
}
function requestDraw(){if(app.rendering)return;app.rendering=true;requestAnimationFrame(()=>{app.rendering=false;drawChart();});}
function drawChart(){
  const cv=$('priceCanvas');const bounds=cv.getBoundingClientRect();if(!bounds.width||!bounds.height)return;
  const ratio=Math.min(3,window.devicePixelRatio||1),width=bounds.width,height=bounds.height;
  cv.width=Math.round(width*ratio);cv.height=Math.round(height*ratio);
  const ctx=cv.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);
  ctx.clearRect(0,0,width,height);ctx.fillStyle='#0d1722';ctx.fillRect(0,0,width,height);
  const cs=chartData();$('chartEmpty').classList.toggle('hidden',cs.length>1);
  if(cs.length<2)return;
  const L=13,R=78,T=14,B=30;const w=width-L-R,h=height-T-B;
  if(w<100)return;
  app.visibleBars=Math.max(12,Math.min(260,app.visibleBars));
  const visible=app.visibleBars;
  app.rightOffset=Math.max(0,Math.min(cs.length-2,app.rightOffset));
  const end=Math.max(2,Math.min(cs.length,Math.ceil(cs.length-app.rightOffset)));
  const start=Math.max(0,Math.floor(end-visible));
  const sliced=cs.slice(start,end);
  const maxVal=Math.max(...sliced.map(c=>c.high)),minVal=Math.min(...sliced.map(c=>c.low));
  const overlay=levels();
  // Include nearby working prices in autoscale, but don't allow remote stale targets to flatten the chart.
  const span=Math.max(1,maxVal-minVal);
  const targets=overlay.filter(x=>x.price>=minVal-span*2&&x.price<=maxVal+span*2).map(x=>x.price);
  const maxP=Math.max(maxVal,...targets)+span*.14;
  const minP=Math.min(minVal,...targets)-span*.14;
  const priceY=p=>T+(maxP-p)/(maxP-minP)*h;
  // Background grids / value labels.
  ctx.textBaseline='middle';ctx.font='10px system-ui, Arial';
  for(let i=0;i<6;i++){
    const y=T+i*h/5;ctx.beginPath();ctx.strokeStyle='#223142';ctx.lineWidth=.7;ctx.setLineDash([3,4]);ctx.moveTo(L,y);ctx.lineTo(width-R,y);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle='#8c9cb0';ctx.textAlign='right';ctx.fillText(currency(maxP-(maxP-minP)*i/5),width-4,y);
  }
  const stepX=w/visible;
  for(let j=0;j<7;j++){
    const xp=L+j*w/6;ctx.strokeStyle='#1c2b3a';ctx.beginPath();ctx.moveTo(xp,T);ctx.lineTo(xp,T+h);ctx.stroke();
  }
  sliced.forEach((c,j)=>{
    const x=L+(j+.5)*stepX;
    const col=c.close>=c.open?'#26c696':'#e56b7e';
    ctx.strokeStyle=col;ctx.fillStyle=col;
    const hy=priceY(c.high),ly=priceY(c.low),oy=priceY(c.open),cy=priceY(c.close);
    ctx.beginPath();ctx.moveTo(x,hy);ctx.lineTo(x,ly);ctx.lineWidth=1.2;ctx.stroke();
    const bw=Math.max(1.2,Math.min(13,stepX*.65));ctx.fillRect(x-bw/2,Math.min(oy,cy),bw,Math.max(1.3,Math.abs(oy-cy)));
  });
  // bottom timeline
  ctx.textAlign='center';ctx.fillStyle='#8294a7';ctx.font='10px system-ui, Arial';
  const labels= Math.max(2,Math.floor(w/100));
  for(let i=0;i<=labels;i++){
    const j=Math.min(sliced.length-1,Math.floor(i*(sliced.length-1)/labels));
    const d=new Date(sliced[j].time*1000);
    ctx.fillText(d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}),L+(j+.5)*stepX,height-12);
  }
  const tagY=[];
  overlay.forEach(o=>{
    if(!Number.isFinite(o.price))return;
    const y=priceY(o.price);if(y<T-9||y>T+h+9)return;
    ctx.strokeStyle=o.color;ctx.lineWidth=1;ctx.setLineDash(o.dash||[]);ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(width-R,y);ctx.stroke();ctx.setLineDash([]);
    let ty=y;for(const prev of tagY){if(Math.abs(ty-prev)<18)ty=prev+18;}
    tagY.push(ty);ty=Math.max(T+10,Math.min(height-B-9,ty));
    ctx.fillStyle='#172536';ctx.fillRect(width-R+2,ty-9,R-4,17);
    ctx.fillStyle=o.color;ctx.textAlign='left';ctx.font='bold 10px system-ui, Arial';
    ctx.fillText(`${o.label} ${currency(o.price)}`,width-R+5,ty);
  });
  if(app.hover&&app.hover.x>=L&&app.hover.x<=width-R){
    const j=Math.floor((app.hover.x-L)/stepX);const data=sliced[j];
    if(data){const x=L+(j+.5)*stepX;
      ctx.strokeStyle='#64788a';ctx.lineWidth=.7;ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(x,T);ctx.lineTo(x,T+h);ctx.stroke();ctx.setLineDash([]);
      const desc=`O ${currency(data.open)}  H ${currency(data.high)}  L ${currency(data.low)}  C ${currency(data.close)}`;
      ctx.font='10px system-ui';const tw=ctx.measureText(desc).width;
      ctx.fillStyle='#1e3246';ctx.fillRect(L+5,T+5,tw+12,22);ctx.fillStyle='#ccd8e6';ctx.textAlign='left';ctx.fillText(desc,L+11,T+16);
    }
  }
}
function setupChartInteraction(){
  const cv=$('priceCanvas');
  cv.addEventListener('wheel',e=>{e.preventDefault();app.visibleBars=Math.max(12,Math.min(260,app.visibleBars*(e.deltaY>0?1.16:.86)));requestDraw();},{passive:false});
  cv.addEventListener('pointerdown',e=>{
    cv.setPointerCapture(e.pointerId);app.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});
    app.drag={x:e.clientX,right:app.rightOffset};app.hover=null;
    if(app.pointerMap.size===2){const p=[...app.pointerMap.values()];app.pinch={dist:Math.abs(p[0].x-p[1].x),startVisible:app.visibleBars};}
  });
  cv.addEventListener('pointermove',e=>{
    if(app.pointerMap.has(e.pointerId))app.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(app.pointerMap.size===2){const p=[...app.pointerMap.values()];const dist=Math.abs(p[0].x-p[1].x);if(app.pinch&&dist>5){app.visibleBars=Math.max(12,Math.min(260,app.pinch.startVisible*app.pinch.dist/dist));requestDraw();}}
    else if(app.pointerMap.size===1&&app.drag){const rect=cv.getBoundingClientRect(),step=(rect.width-91)/app.visibleBars;app.rightOffset=Math.max(0,app.drag.right+(app.drag.x-e.clientX)/Math.max(step,1));requestDraw();}
    else if(e.pointerType==='mouse'){app.hover={x:e.clientX-cv.getBoundingClientRect().left,y:e.clientY};requestDraw();}
  });
  const release=e=>{app.pointerMap.delete(e.pointerId);app.drag=null;app.pinch=null;};
  cv.addEventListener('pointerup',release);cv.addEventListener('pointercancel',release);
  cv.addEventListener('pointerleave',()=>{if(!app.pointerMap.size){app.hover=null;requestDraw();}});
  $('zoomIn').onclick=()=>{app.visibleBars=Math.max(12,app.visibleBars*.76);requestDraw();};
  $('zoomOut').onclick=()=>{app.visibleBars=Math.min(260,app.visibleBars*1.3);requestDraw();};
  $('zoomReset').onclick=()=>{app.visibleBars=76;app.rightOffset=0;requestDraw();};
  new ResizeObserver(requestDraw).observe(cv);
}
async function fetchStatus(){try{presentStatus(await api('/api/status'));}catch(e){$('connectionBanner').classList.remove('hidden');$('connectionError').textContent=e.message;}}
async function fetchChart(){if(app.replay)return;try{const rows=await api('/api/chart');if(rows.length){app.marketCandles=rows.map(c=>({time:+c.time,open:+c.open,high:+c.high,low:+c.low,close:+c.close})).sort((a,b)=>a.time-b.time);requestDraw();}}catch(e){/* service may be temporarily offline */}}
async function control(action){try{presentStatus(await api('/api/control/'+action,{method:'POST'}));toast(action==='start'?'Симуляция запущена: ожидаем закрытие свечи':action==='stop'?'Остановка после завершения цикла':'Виртуальный цикл прерван');}catch(e){toast('Ошибка: '+e.message);}}
function parseList(str){const values=str.split(/[;,\s]+/).filter(Boolean).map(v=>Number(v));if(!values.length||values.some(v=>!Number.isFinite(v)||v<=0||v>100))throw Error('Значения должны быть положительными числами, разделёнными запятыми');return [...new Set(values)];}
function updateCount(){try{const f=$('backtestForm').elements;const n=parseList(f.distances.value).length*parseList(f.tps.value).length*parseList(f.sls.value).length;$('comboCount').textContent=`${n} комбинаций${n>2000?' (максимум 2000)':''}`;}catch{$('comboCount').textContent='Проверь список параметров';}}
async function submitBacktest(e){e.preventDefault();try{const f=$('backtestForm').elements;const p={start_date:f.start_date.value,end_date:f.end_date.value,distances:parseList(f.distances.value),tps:parseList(f.tps.value),sls:parseList(f.sls.value),volume_lots:Number(f.volume_lots.value)};
  if(p.distances.length*p.tps.length*p.sls.length>2000)throw Error('Не более 2000 комбинаций');
  const job=await api('/api/backtests',{method:'POST',body:JSON.stringify(p)});app.currentRun=job.id;app.selectedVariant=null;
  $('variantDetails').classList.add('hidden');$('jobProgressPanel').classList.remove('hidden');$('variantsBody').innerHTML='<tr><td colspan="10" class="empty-table">Прогон запущен…</td></tr>';
  toast('Исследование '+job.id+' запущено. Можно закрыть браузер — расчёт продолжится на VPS.');
  await updateJob();
}catch(err){toast('Не удалось начать тест: '+err.message);}}
async function updateJob(){if(!app.currentRun)return;try{const j=await api('/api/backtests/'+app.currentRun);$('jobProgressPanel').classList.remove('hidden');$('jobTitle').textContent='Исследование '+j.id;$('jobStatus').textContent={queued:'В очереди',running:'Выполняется',completed:'Готово',failed:'Ошибка',interrupted:'Прерван рестартом'}[j.status]||j.status;
  $('progressFill').style.width=`${j.total?100*j.done/j.total:0}%`;
  $('jobProgressText').textContent=`${j.done} из ${j.total} комбинаций · ${j.day_progress||''}${j.error?' · '+j.error:''}`;
  if(j.status==='completed'&&!app.loadedRun?.includes(j.id)){app.loadedRun=(app.loadedRun||[]).concat([j.id]);await refreshVariants();}
  if(j.status==='failed')toast('Ошибка исследования: '+j.error);
}catch(e){console.warn(e);}}
async function refreshVariants(){if(!app.currentRun)return;try{const rows=await api('/api/backtests/'+app.currentRun+'/variants');app.variants=rows;
  if(!rows.length){$('variantsBody').innerHTML='<tr><td colspan="10" class="empty-table">Результаты ещё рассчитываются</td></tr>';return;}
  $('variantsBody').innerHTML=rows.map((r,i)=>{
    const c=r.config,s=r.summary;
    return `<tr><td>${i+1}</td><td><b>${currency(c.trigger_distance)}</b></td><td>${currency(c.tp_distance)} / ${currency(c.sl_distance)}</td><td>${s.trades}</td><td class="positive">${s.tp}</td><td class="negative">${s.sl}</td><td>${currency(s.win_rate,1)}%</td><td class="${(s.train?.pnl_points??0)>=0?'positive':'negative'}">${s.train?sign(s.train.pnl_points)+currency(s.train.pnl_points):'—'}</td><td class="${(s.holdout?.pnl_points??0)>=0?'positive':'negative'}">${s.holdout?sign(s.holdout.pnl_points)+currency(s.holdout.pnl_points):'—'}</td><td class="${s.pnl_points>=0?'positive':'negative'}"><b>${sign(s.pnl_points)}${currency(s.pnl_points)}</b></td><td>${currency(s.max_drawdown_points)}</td><td><button class="table-action" data-variant="${r.id}">Детали</button></td></tr>`;
  }).join('');
}catch(e){toast('Не удалось загрузить рейтинг: '+e.message);}}
async function selectVariant(id){try{const variant=app.variants.find(x=>x.id===id);if(!variant)throw Error('Вариант не найден');app.selectedVariant=id;
  const c=variant.config,s=variant.summary;
  $('variantTitle').textContent=`Триггер ${currency(c.trigger_distance)} · TP ${currency(c.tp_distance)} / SL ${currency(c.sl_distance)}`;
  $('variantStats').innerHTML=[['Сделок',s.trades],['TP',s.tp],['SL',s.sl],['WIN',currency(s.win_rate,1)+'%'],['Итог',sign(s.pnl_points)+currency(s.pnl_points)],['Просадка',currency(s.max_drawdown_points)],['Контроль 30%',s.holdout?sign(s.holdout.pnl_points)+currency(s.holdout.pnl_points):'—'],['SL близко к TP ≤0.05',s.near_tp_then_sl['0.05']]].map(([k,v])=>`<div><small>${k}</small><b>${v}</b></div>`).join('');
  $('variantDetails').classList.remove('hidden');
  const trades=await api(`/api/variants/${id}/trades?limit=300`);
  $('variantTradesBody').innerHTML=trades.map(t=>`<tr><td>${ts(t.opened_ms,true)}</td><td><span class="type ${t.side.toLowerCase()}">${t.side}</span></td><td>${currency(t.entry)}</td><td>${currency(t.tp)}</td><td>${currency(t.sl)}</td><td><span class="result-pill ${t.result.toLowerCase()}">${t.result}</span></td><td>${t.result==='SL'?currency(t.gap_to_tp):'—'}</td><td><button class="table-action" data-replay="${t.db_id}">▶ График</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty-table">Закрытых сделок нет</td></tr>';
  $('variantDetails').scrollIntoView({behavior:'smooth',block:'start'});
  await fetchInsights(id);
}catch(e){toast('Ошибка загрузки варианта: '+e.message);}}
async function refreshRegimes(){
  if(!app.currentRun)return;
  try{
    const rows=await api(`/api/backtests/${app.currentRun}/regimes`);
    $('regimesBody').innerHTML=rows.map(r=>`<tr><td>${safe(r.group)}</td><td>${safe(r.bucket)}</td><td>${currency(r.trigger_distance)}</td><td>${currency(r.tp_distance)} / ${currency(r.sl_distance)}</td><td>${r.trades}</td><td>${currency(r.win_rate,1)}%</td><td class="${r.pnl_points>=0?'positive':'negative'}">${sign(r.pnl_points)}${currency(r.pnl_points)}</td></tr>`).join('')||'<tr><td colspan="7" class="empty-table">Недостаточно сделок для сравнения (минимум 20 в каждой группе)</td></tr>';
  }catch(e){console.warn(e);}
}
async function fetchInsights(variantId){try{const rows=await api(`/api/variants/${variantId}/insights`);const variant=app.variants.find(v=>v.id===variantId);$('insightsLabel').textContent=variant?`Триггер ${currency(variant.config.trigger_distance)} / TP ${currency(variant.config.tp_distance)} / SL ${currency(variant.config.sl_distance)}`:'Выбранный вариант';
  const groups=Object.groupBy?Object.groupBy(rows,r=>r.type):rows.reduce((acc,r)=>((acc[r.type]??=[]).push(r),acc),{});
  $('insightsContent').innerHTML=Object.entries(groups).map(([type,items])=>`<div class="insight-section"><h3>${safe(type)}</h3>${items.map(g=>`<div class="insight-row"><span>${safe(g.bucket)}</span><div class="insight-track"><div class="insight-fill" style="width:${Math.max(0,Math.min(100,g.win_rate))}%"></div></div><small>${currency(g.win_rate,1)}% TP</small><small class="${g.pnl_points>=0?'positive':'negative'}">${sign(g.pnl_points)}${currency(g.pnl_points)} п.</small></div>`).join('')}</div>`).join('')||'<div class="empty-table">Нет данных</div>';
}catch(e){toast('Не удалось рассчитать закономерности: '+e.message);}}
async function refreshJobs(){try{const rows=await api('/api/backtests');$('jobsList').innerHTML=rows.map(j=>`<div class="history-item"><div><strong>${safe(j.id)} · ${j.config.distances.length*j.config.tps.length*j.config.sls.length} комбинаций</strong><small>${new Date(j.created_ms).toLocaleString('ru-RU')} · ${new Date(j.start_ms).toLocaleDateString('ru-RU')}—${new Date(j.end_ms).toLocaleDateString('ru-RU')} UTC · ${safe(j.source)}</small></div><div class="actions"><span class="history-status">${safe(j.status)} ${j.done}/${j.total}</span><button class="table-action" data-job="${safe(j.id)}">Открыть</button></div></div>`).join('')||'<div class="empty-table">Исследований ещё нет</div>';}catch(e){toast(e.message);}}
async function openRun(id){app.currentRun=id;toggleTab('backtest');await updateJob();await refreshVariants();}
async function loadReplay(tradeId){try{const obj=await api('/api/replay/'+tradeId);clearInterval(app.replayTimer);app.replay={...obj,index:0};app.visibleBars=75;app.rightOffset=0;toggleTab('live');
  $('replayBar').classList.remove('hidden');$('replaySlider').max=Math.max(0,obj.ticks.length-1);$('replaySlider').value=0;
  $('replayNote').textContent=`${obj.trade.side} ${currency(obj.trade.entry)} → ${obj.trade.result}${obj.truncated?' · фрагмент ограничен':''}${obj.source==='demo'?' · DEMO':''}`;
  refreshReplayLabel();requestDraw();$('priceCanvas').scrollIntoView({behavior:'smooth',block:'center'});
}catch(e){toast('Не удалось открыть повтор: '+e.message);}}
function refreshReplayLabel(){if(!app.replay)return;const tk=app.replay.ticks[app.replay.index];$('replayTime').textContent=ts(tk?.t_ms);$('replaySlider').value=app.replay.index;}
function stopReplay(){clearInterval(app.replayTimer);app.replayTimer=null;$('replayPlay').textContent='▶';}
function closeReplay(){stopReplay();app.replay=null;$('replayBar').classList.add('hidden');app.rightOffset=0;requestDraw();}
function replayPlay(){if(!app.replay)return;if(app.replayTimer){stopReplay();return;}if(app.replay.index>=app.replay.ticks.length-1)app.replay.index=0;$('replayPlay').textContent='❚❚';
  app.replayTimer=setInterval(()=>{app.replay.index=Math.min(app.replay.index+Math.max(1,Math.round(app.replay.ticks.length/300)),app.replay.ticks.length-1);refreshReplayLabel();requestDraw();if(app.replay.index>=app.replay.ticks.length-1)stopReplay();},75);
}
function setup(){
  document.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>toggleTab(btn.dataset.tab)));
  $('btnStart').addEventListener('click',()=>control('start'));
  $('btnStop').addEventListener('click',()=>control('stop'));
  $('btnForce').addEventListener('click',()=>{if(confirm('Прервать текущий виртуальный цикл без TP/SL?'))control('force_stop');});
  $('settingsForm').addEventListener('input',()=>{app.settingsTouched=true;});
  $('settingsForm').addEventListener('submit',async e=>{e.preventDefault();try{const f=$('settingsForm');const payload={};for(const key of ['trigger_distance','tp_distance','sl_distance','volume_lots','commission_per_lot_roundtrip'])payload[key]=floatField(f,key);
    await api('/api/settings',{method:'POST',body:JSON.stringify(payload)});app.settingsTouched=false;toast('Параметры виртуальной стратегии сохранены');
  }catch(err){toast('Ошибка: '+err.message);}});
  $('backtestForm').addEventListener('submit',submitBacktest);
  for(const name of ['distances','tps','sls'])$('backtestForm').elements[name].addEventListener('input',updateCount);
  $('variantsBody').addEventListener('click',e=>{const btn=e.target.closest('[data-variant]');if(btn)selectVariant(Number(btn.dataset.variant));});
  $('variantTradesBody').addEventListener('click',e=>{const btn=e.target.closest('[data-replay]');if(btn)loadReplay(Number(btn.dataset.replay));});
  $('jobsList').addEventListener('click',e=>{const btn=e.target.closest('[data-job]');if(btn)openRun(btn.dataset.job);});
  $('btnRefreshVariants').addEventListener('click',refreshVariants);$('btnJobsRefresh').addEventListener('click',refreshJobs);
  $('btnExportVariants').addEventListener('click',()=>{if(app.currentRun)window.location.href=`/api/backtests/${app.currentRun}/export.csv`;else toast('Сначала выбери исследование');});
  $('btnExportTrades').addEventListener('click',()=>{if(app.selectedVariant)window.location.href=`/api/variants/${app.selectedVariant}/export.csv`;});
  $('closeReplay').addEventListener('click',closeReplay);$('replayPlay').addEventListener('click',replayPlay);
  $('replaySlider').addEventListener('input',e=>{if(!app.replay)return;app.replay.index=Number(e.target.value);refreshReplayLabel();requestDraw();});
  setupChartInteraction();
  const today=new Date();const utcDay=today.toISOString().slice(0,10);const start=new Date(today.getTime()-7*86400000).toISOString().slice(0,10);
  $('backtestForm').elements.start_date.value=start;$('backtestForm').elements.end_date.value=utcDay;
  updateCount();fetchStatus();fetchChart();
  setInterval(()=>{$('utcClock').textContent='UTC '+new Date().toISOString().slice(11,19);},1000);
  setInterval(fetchStatus,1400);setInterval(fetchChart,12000);
  setInterval(()=>{if(app.currentRun)updateJob();},2500);
}
document.addEventListener('DOMContentLoaded',setup);

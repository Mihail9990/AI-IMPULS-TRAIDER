"""Disk tick archive and UTC day iterator. The cache always knows if data is DEMO."""
from __future__ import annotations

import csv
import gzip
import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Iterator

from .engine import Tick
from .sources import MT5Quotes, DemoQuotes, demo_historical_ticks, SourceError

UTC=timezone.utc
DAY_MS=86_400_000
HOUR_MS=3_600_000


class TickArchive:
    def __init__(self,root: Path,source,source_kind: str):
        self.root=Path(root)
        self.source=source
        self.source_kind=source_kind
        safe = ''.join(c for c in source.symbol if c.isalnum() or c in ('-','_','.'))
        self.path=self.root / source_kind / safe
        self.path.mkdir(parents=True,exist_ok=True)

    @staticmethod
    def midnight(ms:int)->int:
        return ms-(ms%DAY_MS)

    def file_for(self,day_ms:int)->Path:
        return self.path / (datetime.fromtimestamp(day_ms/1000,UTC).strftime('%Y%m%d')+'.csv.gz')

    def _partial_file(self,day_ms:int,required_end:int):
        base=self.file_for(day_ms)
        prefix=base.name.replace('.csv.gz','.')
        candidates=[]
        for candidate in self.path.glob(prefix+'*.partial.csv.gz'):
            try:
                last_ms=int(candidate.name[len(prefix):].split('.')[0])
            except (ValueError, IndexError):
                continue
            if last_ms>=required_end:
                candidates.append((last_ms,candidate))
        return min(candidates)[1] if candidates else None

    def _download_day(self,day_ms:int,cutoff_ms:int):
        target=self.file_for(day_ms)
        upper=min(day_ms+DAY_MS-1,cutoff_ms)
        if upper<day_ms+DAY_MS-1:
            target=self.path/(target.name.replace('.csv.gz',f'.{upper}.partial.csv.gz'))
            if target.exists():
                return target,0,True
        temporary=target.with_suffix('.download')
        count=0
        previous=None
        try:
            with gzip.open(temporary,'wt',newline='',encoding='utf-8') as f:
                w=csv.writer(f)
                w.writerow(['timestamp_ms','bid','ask'])
                if self.source_kind=='demo':
                    seq=demo_historical_ticks(day_ms,upper+1)
                    for tk in seq:
                        w.writerow([tk.t_ms,tk.bid,tk.ask]); count+=1
                else:
                    # Short requests keep one MT5 call from blocking live polling for a whole day.
                    for h_start in range(day_ms,upper+1,HOUR_MS):
                        h_end=min(h_start+HOUR_MS-1,upper)
                        for tk in self.source.range(h_start,h_end):
                            sig=(tk.t_ms,tk.bid,tk.ask)
                            if sig==previous:
                                continue
                            previous=sig
                            w.writerow([tk.t_ms,tk.bid,tk.ask]);count+=1
            # Incomplete days are cached WITH their exact upper UTC bound.
            # Never reuse them for a later cutoff; never mark them as complete.
            os.replace(temporary,target)
            return target,count,True
        except Exception:
            temporary.unlink(missing_ok=True)
            raise

    def iter_range(self, start_ms:int, end_ms:int,
                   progress:Callable[[int,int],None]|None=None) -> Iterator[Tick]:
        """Inclusive UTC boundaries. Archives complete days, streams partial-day temporary files."""
        if end_ms<=start_ms:
            return
        day=self.midnight(start_ms)
        day_max=self.midnight(end_ms)
        total_days=(day_max-day)//DAY_MS+1
        day_idx=0
        last_sig=None
        while day <= day_max:
            path=self.file_for(day)
            completed=True
            if not path.exists():
                required_end=min(day+DAY_MS-1,end_ms)
                path=self._partial_file(day,required_end) or path
            if not path.exists():
                path,n,completed=self._download_day(day,end_ms)
            try:
                with gzip.open(path,'rt',newline='',encoding='utf-8') as f:
                    reader=csv.DictReader(f)
                    for row in reader:
                        t_ms=int(row['timestamp_ms'])
                        if t_ms < start_ms or t_ms > end_ms:
                            continue
                        tk=Tick(t_ms,float(row['bid']),float(row['ask']))
                        sig=(tk.t_ms,tk.bid,tk.ask)
                        if sig!=last_sig:
                            last_sig=sig
                            yield tk
            finally:
                if not completed:
                    path.unlink(missing_ok=True)
            day_idx+=1
            if progress:
                progress(day_idx,total_days)
            day += DAY_MS

"""Batched grid search over real, cached historical Bid/Ask ticks."""
from __future__ import annotations
from dataclasses import asdict
from itertools import product
import threading

from .engine import PaperEngine,Settings
from .storage import Store
from .tickcache import TickArchive


def period_metrics(trades:list[dict])->dict:
    """Closed deals only; used for 70% training / 30% chronological holdout."""
    tp=sum(t['result']=='TP' for t in trades)
    sl=sum(t['result']=='SL' for t in trades)
    net=sum(t['pnl_points'] for t in trades)
    balance=peak=max_dd=0.0
    for tr in trades:
        balance += tr['pnl_points']
        peak=max(peak,balance)
        max_dd=max(max_dd,peak-balance)
    return dict(trades=len(trades),tp=tp,sl=sl,pnl_points=round(net,5),
                win_rate=round(100*tp/len(trades),2) if trades else 0,
                max_drawdown_points=round(max_dd,5))


class Backtester:
    def __init__(self,archive:TickArchive,store:Store, details:dict):
        self.archive=archive
        self.store=store
        self.details=details
        self.running_job=None
        self.lock=threading.Lock()

    def submit(self,start_ms:int,end_ms:int,distances:list[float],tps:list[float],sls:list[float],
               volume_lots:float=0.1, commission_roundtrip:float=0.0):
        combos=list(product(distances,tps,sls))
        if not combos:raise ValueError('At least one configuration required')
        if len(combos)>2000:raise ValueError('Maximum 2000 configurations per run')
        if not self.lock.acquire(blocking=False):
            raise ValueError(f'Backtest already running: {self.running_job}')
        try:
            configs=[]
            for d,tp,sl in combos:
                config=Settings(trigger_distance=d,tp_distance=tp,sl_distance=sl,
                                tick_size=self.details['tick_size'],volume_lots=volume_lots,
                                tick_value_per_lot=self.details['tick_value_per_lot'],
                                commission_per_lot_roundtrip=commission_roundtrip)
                configs.append(config)
            split_ms=start_ms+int((end_ms-start_ms)*0.70)
            meta=dict(distances=distances,tps=tps,sls=sls,volume_lots=volume_lots,
                      commission_roundtrip=commission_roundtrip,train_until_ms=split_ms,
                      symbol=self.details['symbol'])
            run_id=self.store.make_job(start_ms,end_ms,meta,len(configs),self.archive.source_kind)
            self.running_job=run_id
            t=threading.Thread(target=self._worker,args=(run_id,start_ms,end_ms,configs),
                               name='BacktestWorker',daemon=True)
            t.start()
            return run_id
        except Exception:
            self.running_job=None
            self.lock.release()
            raise

    def _worker(self,run_id,start_ms,end_ms,configs):
        try:
            self.store.update_job(run_id,status='running')
            done=0
            # Batches bound the RAM cost, and reuse tick archives rather than re-download.
            for i in range(0,len(configs),16):
                batch=configs[i:i+16]
                engines=[PaperEngine(cfg) for cfg in batch]
                for engine in engines:
                    engine.start()
                def progress(x,total):
                    self.store.update_job(run_id,progress=f'Группа {i//16+1}: день {x}/{total}')
                count=0
                for tk in self.archive.iter_range(start_ms,end_ms,progress=progress):
                    for e in engines:
                        e.on_tick(tk)
                    count+=1
                    if count%100000==0:
                        for e in engines:
                            e.new_trades.clear();e.new_events.clear()
                if count==0:
                    raise RuntimeError('No ticks for requested period; check trading days, MT5 history and symbol')
                for config,engine in zip(batch,engines):
                    # Never use later holdout deals for selecting the ranking.
                    # A trade that crosses the split is excluded from BOTH subperiods.
                    split_ms=start_ms+int((end_ms-start_ms)*0.70)
                    train=[t for t in engine.trades if t['closed_ms']<split_ms]
                    holdout=[t for t in engine.trades if t['opened_ms']>=split_ms]
                    full=engine.summary()
                    full['train']=period_metrics(train)
                    full['holdout']=period_metrics(holdout)
                    full['cross_boundary_excluded']=len(engine.trades)-len(train)-len(holdout)
                    self.store.save_variant(run_id,asdict(config),full,engine.trades)
                    done+=1
                    self.store.update_job(run_id,done=done)
            self.store.update_job(run_id,status='completed',progress='Готово')
        except Exception as exc:
            self.store.update_job(run_id,status='failed',error=str(exc))
        finally:
            self.running_job=None
            self.lock.release()

"""Quote-only MT5 adapter and clearly labelled synthetic DEMO source."""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from pathlib import Path
import math
import os
import random
import threading
import time
from typing import Iterator

from .engine import Tick

UTC = timezone.utc


class SourceError(RuntimeError):
    pass


class MT5Quotes:
    """Never calls order_send(), positions_*, orders_* or any trade API."""
    def __init__(self, symbol='XAUUSD.s', terminal_path='', expected_login=''):
        self.symbol = symbol
        self.terminal_path = terminal_path
        self.expected_login = str(expected_login or '')
        self.lock = threading.RLock()
        self.mt5 = None
        self.last_error = None
        self.connected = False

    def connect(self):
        with self.lock:
            if self.connected:
                return
            try:
                import MetaTrader5 as mt5
            except ImportError as exc:
                raise SourceError('MetaTrader5 requires 64-bit Windows Python and pip install MetaTrader5') from exc
            self.mt5 = mt5
            ok = mt5.initialize(self.terminal_path) if self.terminal_path else mt5.initialize()
            if not ok:
                raise SourceError(f'MT5 initialize failed: {mt5.last_error()}')
            account = mt5.account_info()
            if not account:
                raise SourceError('No active MT5 account. Log into Bybit CFD in the terminal.')
            if self.expected_login and str(account.login) != self.expected_login:
                raise SourceError(f'Unexpected MT5 account {account.login}; expected {self.expected_login}')
            if not mt5.symbol_select(self.symbol, True):
                raise SourceError(f'Symbol {self.symbol!r} not available: {mt5.last_error()}')
            self.connected = True

    def symbol_details(self) -> dict:
        with self.lock:
            self.connect()
            info = self.mt5.symbol_info(self.symbol)
            if info is None:
                raise SourceError(f'No symbol info: {self.symbol}')
            size = float(info.trade_tick_size or info.point or 0.01)
            return dict(symbol=self.symbol, tick_size=size,
                        digits=int(info.digits), tick_value_per_lot=float(info.trade_tick_value or 0.0),
                        volume_min=float(info.volume_min), volume_step=float(info.volume_step),
                        stops_level=int(info.trade_stops_level),
                        account_login=str(self.mt5.account_info().login))

    def range(self, start_ms: int, end_ms: int) -> list[Tick]:
        if end_ms < start_ms:
            return []
        with self.lock:
            self.connect()
            # All datetimes are timezone-aware UTC (critical for MT5 API).
            st = datetime.fromtimestamp(start_ms/1000, UTC)
            en = datetime.fromtimestamp(end_ms/1000, UTC)
            values = self.mt5.copy_ticks_range(self.symbol, st, en, self.mt5.COPY_TICKS_INFO)
            if values is None:
                self.last_error = str(self.mt5.last_error())
                raise SourceError(f'copy_ticks_range failed: {self.last_error}')
            out = []
            for row in values:
                t = int(row['time_msc'])
                b, a = float(row['bid']), float(row['ask'])
                if start_ms <= t <= end_ms and b > 0 and a >= b and math.isfinite(a):
                    out.append(Tick(t,b,a))
            return out

    def chart(self, count=450) -> list[dict]:
        with self.lock:
            self.connect()
            rates = self.mt5.copy_rates_from_pos(self.symbol, self.mt5.TIMEFRAME_M1, 0, count)
            if rates is None:
                raise SourceError(f'copy_rates_from_pos failed: {self.mt5.last_error()}')
            return [dict(time=int(r['time']),open=float(r['open']),high=float(r['high']),
                         low=float(r['low']),close=float(r['close'])) for r in rates]


class DemoQuotes:
    """Synthetic random walk. STRICTLY demo; never label the values as real broker ticks."""
    def __init__(self, symbol='SYNTHETIC-DEMO'):
        self.symbol = symbol
        self.value = 4000.0
        self.rng = random.Random(20261025)
        self.last_ms = 0
        self.lock = threading.RLock()
        # Seed display-only candles so the DEMO UI has a useful chart immediately.
        self.history = []
        fake = random.Random(8242)
        minute = (int(time.time()) // 60)*60
        for i in range(240, 0, -1):
            start = self.value
            finish = round(max(100,start+fake.gauss(0,0.38)),2)
            high = round(max(start,finish)+abs(fake.gauss(0,0.12)),2)
            low = round(min(start,finish)-abs(fake.gauss(0,0.12)),2)
            self.history.append(dict(time=minute-i*60,open=round(start,2),high=high,low=low,close=finish))
            self.value = finish

    def symbol_details(self):
        return dict(symbol=self.symbol,tick_size=0.01,digits=2,
                    tick_value_per_lot=0.0,volume_min=0.01,volume_step=0.01,
                    stops_level=0,account_login='DEMO / NO BROKER')

    def range(self, start_ms: int, end_ms: int) -> list[Tick]:
        # Called only for live demo poll. Synthetic stream at current time.
        with self.lock:
            now = int(time.time()*1000)
            if self.last_ms >= now:
                return []
            steps = min(50,max(1,(now-self.last_ms)//400)) if self.last_ms else 1
            out=[]
            for i in range(steps):
                self.value = max(1,self.value+self.rng.gauss(0,0.09))
                spread = max(0.10,0.22+self.rng.uniform(-0.04,0.04))
                t = now-(steps-i-1)*30
                out.append(Tick(t,round(self.value,2),round(self.value+spread,2)))
            self.last_ms = now
            return out

    def chart(self,count=450):
        return self.history[-count:]


def demo_historical_ticks(start_ms: int,end_ms: int) -> Iterator[Tick]:
    """Deterministic synthetic tick set for testing the web/app, NOT market data."""
    rng = random.Random(1985+(start_ms//86400000))
    price = 4000.0
    for t in range(start_ms, end_ms, 1500):
        price = max(10,price+rng.gauss(0,0.09))
        bid = round(price,2)
        ask = round(bid+0.23+rng.uniform(-0.04,0.04),2)
        yield Tick(t,bid,max(bid,ask))

"""Long-running, read-only quote ingestion. The phone is only a remote web client."""
from __future__ import annotations

from dataclasses import asdict,replace
import os
from pathlib import Path
import threading
import time
from datetime import datetime,timezone

from .engine import PaperEngine,Settings
from .sources import MT5Quotes,DemoQuotes,SourceError
from .storage import Store
from .tickcache import TickArchive
from .backtest import Backtester


class AnalyzerService:
    def __init__(self,root:Path):
        self.data_source=os.getenv('DATA_SOURCE','mt5').lower()
        if self.data_source not in ('mt5','demo'):
            raise ValueError('DATA_SOURCE must be mt5 or demo')
        self.symbol=os.getenv('MT5_SYMBOL','XAUUSD.s') if self.data_source=='mt5' else 'SYNTHETIC-DEMO'
        self.source=(MT5Quotes(symbol=self.symbol, terminal_path=os.getenv('MT5_TERMINAL_PATH',''),
                               expected_login=os.getenv('MT5_EXPECTED_LOGIN',''))
                     if self.data_source=='mt5' else DemoQuotes())
        safe_name=''.join(x for x in self.symbol if x.isalnum() or x in '._-')
        self.data_path=Path(root)/f'{self.data_source}_{safe_name}'
        self.data_path.mkdir(parents=True,exist_ok=True)
        self.store=Store(self.data_path/'analyzer.sqlite3')
        saved=self.store.get_state('live_snapshot')
        self.engine=PaperEngine.from_snapshot(saved) if saved else PaperEngine()
        self.archive=TickArchive(Path(root)/'cache',self.source,self.data_source)
        self.details=dict(symbol=self.symbol,tick_size=0.01,tick_value_per_lot=0.0,
                          account_login='DISCONNECTED')
        self.backtester=Backtester(self.archive,self.store,self.details)
        self.engine_lock=threading.RLock()
        self.stop_flag=threading.Event()
        self.worker=None
        self.connection_status='connecting'
        self.error=''
        self.last_connected_ms=0
        self.last_persist=0.0
        self.last_chart_read=0
        self.cached_chart=[]
        # Poll watermark may be ahead of the last tick during a quiet market.
        self.cursor_ms=self.engine.latest.t_ms if self.engine.latest else None

    def start_worker(self):
        if self.worker and self.worker.is_alive():
            return
        self.worker=threading.Thread(target=self._run,name='LiveQuoteCollector',daemon=True)
        self.worker.start()

    def _run(self):
        while not self.stop_flag.is_set():
            try:
                details=self.source.symbol_details()
                with self.engine_lock:
                    self.details=details
                    self.backtester.details=details
                    if self.engine.settings.tick_size!=details['tick_size'] or (
                        self.engine.settings.tick_value_per_lot!=details['tick_value_per_lot']):
                        if self.engine.pending or self.engine.position:
                            # Do not move levels of an active virtual cycle on reconnect.
                            pass
                        else:
                            self.engine.settings=replace(self.engine.settings,
                                tick_size=details['tick_size'],
                                tick_value_per_lot=details['tick_value_per_lot'])
                    self.connection_status='catching_up' if self.data_source=='mt5' else 'connected'
                    self.error=''
                break
            except Exception as exc:
                self.connection_status='disconnected'
                self.error=str(exc)
                self.stop_flag.wait(7)
        while not self.stop_flag.is_set():
            try:
                # Read a little behind wall-clock and replay a brief overlap:
                # historical tick publication may lag the visible terminal quote.
                now_ms=int(time.time()*1000)-1000
                if self.cursor_ms is None:
                    self.cursor_ms=now_ms-90_000
                # Work through outages in bounded time chunks; preserve tick order.
                lower=max(0,self.cursor_ms-3000)
                upper=min(now_ms,self.cursor_ms+45_000)
                if upper>lower:
                    ticks=self.source.range(lower,upper)
                    with self.engine_lock:
                        for tick in ticks:
                            self.engine.on_tick(tick)
                        self.last_connected_ms=int(time.time()*1000)
                    self.cursor_ms=upper
                    lag_ms=max(0,int(time.time()*1000)-self.cursor_ms)
                    self.connection_status='catching_up' if lag_ms>5000 and self.data_source=='mt5' else 'connected'
                    self.error=f'Восстановление тиков: отставание {round(lag_ms/1000)} сек.' if self.connection_status=='catching_up' else ''
                now=time.monotonic()
                if now-self.last_persist>3:
                    self.persist()
                    self.last_persist=now
                if self.cursor_ms >= now_ms-1000:
                    self.stop_flag.wait(0.7)
            except Exception as exc:
                self.connection_status='disconnected'
                self.error=str(exc)
                self.stop_flag.wait(5)
                try:
                    self.source.connected=False  # reconnect after terminal restart
                except Exception:
                    pass
                try:
                    self.source.connect()
                except Exception:
                    pass
        self.persist()

    def persist(self):
        with self.engine_lock:
            # Keep DB writes under the engine lock so two thread snapshots cannot
            # be written in reverse order, losing a recently opened position.
            self.store.save_live(self.engine.to_snapshot(),self.engine.new_trades[:])
            self.engine.new_trades.clear()
            self.engine.new_events.clear()

    def status(self):
        with self.engine_lock:
            result=self.engine.public_state()
            result.update(source=self.data_source, symbol=self.symbol, details=self.details,
                          connection=self.connection_status,error=self.error,
                          last_contact_ms=self.last_connected_ms)
            return result

    def chart(self):
        # Cache MT5 broker bars ~15sec, update the current bar from the tick stream.
        now=time.monotonic()
        if self.data_source=='mt5' and now-self.last_chart_read>15:
            try:
                self.cached_chart=self.source.chart(520)
                self.last_chart_read=now
            except Exception:
                pass
        with self.engine_lock:
            local=self.engine.chart_candles(520)
            if self.data_source=='demo':
                merged={int(c['time']):c for c in self.source.chart(520)}
                for c in local:
                    merged[c['time']]=c
                return [merged[k] for k in sorted(merged)[-520:]]
            if not self.cached_chart:
                return local[-520:]
            # Broker candles supply the full existing chart (Bid OHLC).
            merged={int(c['time']):c for c in self.cached_chart}
            for c in local:
                if c['time']>=max(merged,default=0):
                    old=merged.get(int(c['time']))
                    if old is None:
                        merged[int(c['time'])]=c
                    else:
                        # Keep the broker bar OPEN; locally observed partial ticks
                        # must never replace the broker's actual candle open.
                        merged[int(c['time'])]={**old,'high':max(old['high'],c['high']),
                                                'low':min(old['low'],c['low']),
                                                'close':c['close']}
            return [merged[k] for k in sorted(merged)[-520:]]

    def update_settings(self,setting:Settings):
        with self.engine_lock:
            if self.engine.pending or self.engine.position:
                raise ValueError('Finish or force-stop current virtual cycle before changing settings')
            self.engine.settings=setting
        self.persist()

    def control(self,action:str):
        with self.engine_lock:
            if action=='start':
                if self.data_source=='mt5' and self.connection_status!='connected':
                    raise ValueError('MT5 is not ready or restoring tick history; start after quotes synchronize')
                self.engine.start()
                # If market was closed for hours/days, do not use Friday's last
                # incomplete bar as the first signal when pressing /start on Sunday.
                if self.data_source=='mt5':
                    utc_minute=(int(time.time())//60)*60
                    if self.engine.arm_minute is None or self.engine.arm_minute<utc_minute:
                        self.engine.arm_minute=utc_minute
            elif action=='stop':
                self.engine.request_stop()
            elif action=='force_stop':
                self.engine.force_stop()
            else:
                raise ValueError('Unknown action')
        self.persist()
        return self.status()

    def shutdown(self):
        self.stop_flag.set()
        if self.worker:
            self.worker.join(timeout=3)
        self.persist()

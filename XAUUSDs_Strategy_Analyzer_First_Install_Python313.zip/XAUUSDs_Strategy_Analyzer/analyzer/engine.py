"""Deterministic, tick-driven paper trading engine. Contains ZERO broker trade calls.

All input timestamps are Unix milliseconds UTC; candles use BID; executions use ASK
for buys and BID for sells, exits in the opposite quote. Historical and live modes
both drive this exact same engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from math import ceil, floor, isfinite
from typing import Any, Optional


@dataclass(frozen=True)
class Settings:
    trigger_distance: float = 1.0
    tp_distance: float = 0.25
    sl_distance: float = 3.0
    tick_size: float = 0.01
    volume_lots: float = 0.10
    tick_value_per_lot: float = 0.0  # currency value of 1 tick for ONE lot; 0 = unknown
    commission_per_lot_roundtrip: float = 0.0

    def __post_init__(self):
        for name in ('trigger_distance', 'tp_distance', 'sl_distance', 'tick_size', 'volume_lots'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n <= 0:
                raise ValueError(f'{name} must be finite and > 0')
        for name in ('tick_value_per_lot', 'commission_per_lot_roundtrip'):
            n = getattr(self, name)
            if not isinstance(n, (int, float)) or not isfinite(n) or n < 0:
                raise ValueError(f'{name} must be finite and >= 0')


@dataclass(frozen=True)
class Tick:
    t_ms: int
    bid: float
    ask: float

    def __post_init__(self):
        if not isinstance(self.t_ms, int) or self.t_ms < 0:
            raise ValueError('Invalid timestamp')
        if not all(isfinite(x) and x > 0 for x in (self.bid, self.ask)) or self.ask < self.bid:
            raise ValueError('Invalid Bid/Ask quote')


@dataclass
class Candle:
    time: int  # minute start in UNIX seconds UTC
    open: float
    high: float
    low: float
    close: float
    ticks: int = 1

    @property
    def color(self) -> str:
        return 'BUY' if self.close > self.open else ('SELL' if self.close < self.open else 'DOJI')

    def on_tick(self, bid: float):
        self.high = max(self.high, bid)
        self.low = min(self.low, bid)
        self.close = bid
        self.ticks += 1


@dataclass
class Pending:
    side: str
    level: float
    created_ms: int
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str


@dataclass
class Position:
    side: str
    entry: float
    tp: float
    sl: float
    opened_ms: int
    trigger_level: float
    signal_time: int
    signal_body: float
    signal_range: float
    signal_color: str
    entry_spread: float
    mfe: float = 0.0
    mae: float = 0.0


class PaperEngine:
    def __init__(self, settings: Settings = Settings()):
        self.settings = settings
        self.mode = 'stopped'  # stopped | running | stopping
        self.arm_minute: Optional[int] = None
        self.candle: Optional[Candle] = None
        self.candles: list[dict] = []
        self.pending: Optional[Pending] = None
        self.position: Optional[Position] = None
        self.latest: Optional[Tick] = None
        self.last_tick_signature: Optional[tuple] = None
        self.trade_seq = 0
        self.order_seq = 0
        self.trades: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.new_trades: list[dict[str, Any]] = []
        self.new_events: list[dict[str, Any]] = []
        self.canceled_orders = 0
        self.placed_orders = 0
        self.triggered_orders = 0
        self.skipped_invalid = 0
        self.tick_count = 0
        self.first_tick_ms: Optional[int] = None
        self.max_tick_gap_ms = 0

    def _level(self, p: float, higher: bool) -> float:
        """Snap protective/entry target outward to the symbol's tick grid."""
        tick = self.settings.tick_size
        scale = p / tick
        snapped = (ceil(scale - 1e-8) if higher else floor(scale + 1e-8)) * tick
        return round(snapped, 10)

    def _event(self, t_ms: int, typ: str, **extra):
        row = dict(t_ms=t_ms, type=typ, **extra)
        self.events.append(row)
        self.new_events.append(row)
        if len(self.events) > 250:
            self.events = self.events[-250:]

    def start(self) -> None:
        if self.mode != 'stopped':
            raise ValueError('Session is already running')
        self.mode = 'running'
        self.arm_minute = self.candle.time if self.candle else None
        self.pending = None
        self.position = None
        self._event(self.latest.t_ms if self.latest else 0, 'start')

    def request_stop(self) -> None:
        """Finish the existing cycle (including waiting for a pending trigger)."""
        if self.mode == 'running':
            if self.pending is None and self.position is None:
                self.mode = 'stopped'
            else:
                self.mode = 'stopping'
            self._event(self.latest.t_ms if self.latest else 0, 'stop_requested')

    def force_stop(self) -> None:
        """Abandon virtual pending/position (not an SL/TP)."""
        if self.pending:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_cancel', side=self.pending.side, price=self.pending.level)
        if self.position:
            self._event(self.latest.t_ms if self.latest else 0, 'forced_abandon', side=self.position.side, price=self.position.entry)
        self.mode = 'stopped'
        self.pending = None
        self.position = None
        self._event(self.latest.t_ms if self.latest else 0, 'forced_stop')

    def _create_pending(self, bar: Candle, t_ms: int):
        side = bar.color
        if side == 'DOJI':
            return
        delta = self.settings.trigger_distance
        level = self._level(bar.close + delta if side == 'BUY' else bar.close - delta, side == 'BUY')
        if self.pending and self.pending.side == side:
            return
        if self.pending:
            self.canceled_orders += 1
            self._event(t_ms, 'cancel', side=self.pending.side, price=self.pending.level,
                        reason='opposite_closed_candle')
        self.pending = Pending(side, level, t_ms, bar.time, abs(bar.close-bar.open),
                               bar.high-bar.low, side)
        self.placed_orders += 1
        self.order_seq += 1
        self._event(t_ms, 'place', side=side, price=level, signal_time=bar.time)

    def _finish_bar(self, bar: Candle, t_ms: int):
        self.candles.append(asdict(bar))
        if len(self.candles) > 750:
            self.candles = self.candles[-750:]
        if self.mode in ('running', 'stopping') and self.position is None:
            if self.arm_minute is not None and bar.time < self.arm_minute:
                return
            self._create_pending(bar, t_ms)

    def _fill(self, tick: Tick):
        p = self.pending
        if p is None:
            return
        if p.side == 'BUY':
            if tick.ask < p.level:
                return
            fill = max(p.level, tick.ask)  # adverse gap/trigger slippage
            tp = self._level(fill + self.settings.tp_distance, True)
            sl = self._level(fill - self.settings.sl_distance, False)
        else:
            if tick.bid > p.level:
                return
            fill = min(p.level, tick.bid)
            tp = self._level(fill - self.settings.tp_distance, False)
            sl = self._level(fill + self.settings.sl_distance, True)
        self.position = Position(p.side, fill, tp, sl, tick.t_ms, p.level, p.signal_time,
                                 p.signal_body, p.signal_range, p.signal_color,
                                 tick.ask - tick.bid)
        self.pending = None
        self.triggered_orders += 1
        self._event(tick.t_ms, 'fill', side=p.side, price=fill, trigger_level=p.level,
                    tp=tp, sl=sl, spread=tick.ask-tick.bid)

    def _position_tick(self, tick: Tick):
        pos = self.position
        if pos is None:
            return
        # Mark to market on the quote that actually CLOSES the position.
        exit_quote = tick.bid if pos.side == 'BUY' else tick.ask
        move = exit_quote - pos.entry if pos.side == 'BUY' else pos.entry - exit_quote
        pos.mfe = max(pos.mfe, move)
        pos.mae = max(pos.mae, -move)
        if pos.side == 'BUY':
            result = 'SL' if tick.bid <= pos.sl else ('TP' if tick.bid >= pos.tp else None)
            exit_price = min(pos.sl, tick.bid) if result == 'SL' else pos.tp
        else:
            result = 'SL' if tick.ask >= pos.sl else ('TP' if tick.ask <= pos.tp else None)
            exit_price = max(pos.sl, tick.ask) if result == 'SL' else pos.tp
        if result is None:
            return
        points = exit_price - pos.entry if pos.side == 'BUY' else pos.entry - exit_price
        gap_to_tp = max(0.0, abs(pos.tp-pos.entry)-pos.mfe)
        money = None
        if self.settings.tick_value_per_lot > 0:
            money = (points/self.settings.tick_size*self.settings.tick_value_per_lot
                     - self.settings.commission_per_lot_roundtrip) * self.settings.volume_lots
        self.trade_seq += 1
        trade = dict(
            id=self.trade_seq, side=pos.side, result=result, opened_ms=pos.opened_ms,
            closed_ms=tick.t_ms, entry=pos.entry, exit=round(exit_price, 10),
            tp=pos.tp, sl=pos.sl, trigger_level=pos.trigger_level,
            pnl_points=round(points, 10), pnl_money_est=round(money, 5) if money is not None else None,
            mfe_points=round(pos.mfe, 10), mae_points=round(pos.mae, 10),
            gap_to_tp=round(gap_to_tp, 10), duration_seconds=round((tick.t_ms-pos.opened_ms)/1000,3),
            signal_time=pos.signal_time, signal_body=round(pos.signal_body, 6),
            signal_range=round(pos.signal_range, 6), signal_color=pos.signal_color,
            spread_at_entry=round(pos.entry_spread, 10),
            entry_utc_hour=datetime.fromtimestamp(pos.opened_ms/1000, timezone.utc).hour,
        )
        self.trades.append(trade)
        self.new_trades.append(trade)
        self._event(tick.t_ms, result.lower(), side=pos.side, price=exit_price, trade_id=self.trade_seq,
                    pnl_points=trade['pnl_points'], gap_to_tp=trade['gap_to_tp'])
        self.position = None
        if self.mode == 'stopping':
            self.mode = 'stopped'
            self.arm_minute = None
        else:
            # Next full candle close may launch next cycle, not the current tick.
            self.arm_minute = (tick.t_ms // 60000) * 60

    def on_tick(self, tick: Tick):
        if self.last_tick_signature == (tick.t_ms,tick.bid,tick.ask):
            return
        if self.latest and tick.t_ms < self.latest.t_ms:
            self.skipped_invalid += 1
            return
        if self.latest:
            self.max_tick_gap_ms = max(self.max_tick_gap_ms, tick.t_ms-self.latest.t_ms)
        else:
            self.first_tick_ms = tick.t_ms
        self.last_tick_signature = (tick.t_ms,tick.bid,tick.ask)
        self.latest = tick
        self.tick_count += 1
        minute = (tick.t_ms // 60000) * 60
        if self.candle is None:
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            if self.mode == 'running' and self.arm_minute is None:
                self.arm_minute = minute
        elif minute != self.candle.time:
            # The old STOP still exists at the *first tick* of a new minute.
            # Broker may execute it before our simulated cancel/replace request.
            if self.mode in ('running', 'stopping') and self.pending is not None and self.position is None:
                self._fill(tick)
                filled_on_boundary = self.position is not None
            else:
                filled_on_boundary = False
            old = self.candle
            self.candle = Candle(minute,tick.bid,tick.bid,tick.bid,tick.bid)
            self._finish_bar(old,tick.t_ms)
            if filled_on_boundary:
                self._position_tick(tick)
                return
        else:
            self.candle.on_tick(tick.bid)
        if self.mode in ('running', 'stopping'):
            if self.position:
                self._position_tick(tick)
            elif self.pending:
                self._fill(tick)
                # No same-tick exit for freshly filled position.

    def summary(self) -> dict:
        trades = self.trades
        tp = sum(t['result']=='TP' for t in trades)
        sl = sum(t['result']=='SL' for t in trades)
        gross_win = sum(max(0,t['pnl_points']) for t in trades)
        gross_loss = -sum(min(0,t['pnl_points']) for t in trades)
        balance = peak = max_dd = 0.0
        for t in trades:
            balance += t['pnl_points']
            peak = max(peak,balance)
            max_dd = max(max_dd,peak-balance)
        near = {f'{v:.2f}':sum(t['result']=='SL' and t['gap_to_tp']<=v+1e-9 for t in trades)
                for v in (0.01,0.02,0.05,0.10,0.15,0.20)}
        return dict(trades=len(trades),tp=tp,sl=sl,win_rate=round(100*tp/len(trades),2) if trades else 0,
                    pnl_points=round(balance,5),max_drawdown_points=round(max_dd,5),
                    profit_factor=round(gross_win/gross_loss,3) if gross_loss else None,
                    pnl_money_est=(round(sum(t['pnl_money_est'] for t in trades),4)
                                   if trades and all(t['pnl_money_est'] is not None for t in trades) else None),
                    near_tp_then_sl=near,placed=self.placed_orders,canceled=self.canceled_orders,
                    triggered=self.triggered_orders, tick_count=self.tick_count,
                    max_tick_gap_seconds=round(self.max_tick_gap_ms/1000,3))

    def public_state(self) -> dict:
        return dict(mode=self.mode,settings=asdict(self.settings),
                    tick=asdict(self.latest) if self.latest else None,
                    candle=asdict(self.candle) if self.candle else None,
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    summary=self.summary(),events=self.events[-30:],trades=self.trades[-35:])

    def chart_candles(self, max_rows=450) -> list[dict]:
        data = self.candles[-max_rows:]
        if self.candle:
            data = data + [asdict(self.candle)]
        return data

    def to_snapshot(self) -> dict:
        # No transient output buffers, they are already stored separately.
        return dict(settings=asdict(self.settings),mode=self.mode,arm_minute=self.arm_minute,
                    candle=asdict(self.candle) if self.candle else None,candles=self.candles[-750:],
                    pending=asdict(self.pending) if self.pending else None,
                    position=asdict(self.position) if self.position else None,
                    latest=asdict(self.latest) if self.latest else None,
                    trade_seq=self.trade_seq,order_seq=self.order_seq,
                    trades=self.trades,events=self.events[-250:],canceled_orders=self.canceled_orders,
                    placed_orders=self.placed_orders, triggered_orders=self.triggered_orders,
                    tick_count=self.tick_count,skipped_invalid=self.skipped_invalid,
                    first_tick_ms=self.first_tick_ms,max_tick_gap_ms=self.max_tick_gap_ms)

    @classmethod
    def from_snapshot(cls, data: dict) -> 'PaperEngine':
        e = cls(Settings(**data['settings']))
        for attr, typ in [('candle',Candle),('pending',Pending),('position',Position),('latest',Tick)]:
            if data.get(attr):
                setattr(e,attr,typ(**data[attr]))
        for attr in ('mode','arm_minute','trade_seq','order_seq','canceled_orders','placed_orders',
                     'triggered_orders','skipped_invalid','tick_count','first_tick_ms','max_tick_gap_ms'):
            if attr in data:
                setattr(e,attr,data[attr])
        e.candles = data.get('candles',[])
        e.trades = data.get('trades',[])
        e.events = data.get('events',[])
        e.last_tick_signature = (e.latest.t_ms,e.latest.bid,e.latest.ask) if e.latest else None
        return e

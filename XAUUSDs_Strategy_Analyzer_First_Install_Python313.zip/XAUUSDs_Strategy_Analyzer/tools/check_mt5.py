"""Run from project root to verify MT5 account and read-only XAUUSD.s prices."""
import os
import sys
import time
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dotenv import load_dotenv
from analyzer.sources import MT5Quotes
load_dotenv(Path(__file__).resolve().parents[1]/'.env')

symbol=os.getenv('MT5_SYMBOL','XAUUSD.s')
src=MT5Quotes(symbol,os.getenv('MT5_TERMINAL_PATH',''),os.getenv('MT5_EXPECTED_LOGIN',''))
try:
    details=src.symbol_details()
    print('Read-only MT5 connected. Instrument diagnostics:')
    for k,v in details.items():print(f'  {k}: {v}')
    now=int(time.time()*1000)
    ticks=src.range(now-90_000,now)
    print('Quote updates in past 90 seconds:',len(ticks))
    if ticks:
        tk=ticks[-1]
        print('Last UTC:',datetime.fromtimestamp(tk.t_ms/1000,timezone.utc).isoformat())
        print('Bid:',tk.bid,'Ask:',tk.ask,'Spread:',round(tk.ask-tk.bid,5))
    else:
        print('No recent ticks. The market may be closed; check MT5 Market Watch.')
    print('No trading or broker order operations were executed.')
except Exception as exc:
    print('DIAGNOSTICS FAILED:',exc)
    sys.exit(1)

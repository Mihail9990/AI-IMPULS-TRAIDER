# Removes ONLY the HTTPS proxy service and 3 named firewall rules. Keeps certificates, config and all data.
$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host 'Run PowerShell as Administrator.' -ForegroundColor Red
    exit 1
}
$serviceName='XAUAnalyzerHTTPS'
$service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($service) {
    if ($service.Status -ne 'Stopped') { Stop-Service -Name $serviceName -Force }
    & sc.exe delete $serviceName | Out-Host
}
foreach ($rule in @('XAU Analyzer HTTPS 443', 'XAU Analyzer ACME HTTP 80','XAU Analyzer DENY backend 8765')) {
    Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue | Remove-NetFirewallRule
}
Write-Host 'XAU HTTPS service and rules removed. Original MT5, analyzer, Caddy files/certs/data are untouched.'

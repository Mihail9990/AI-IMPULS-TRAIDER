@echo off
setlocal
cd /d "%~dp0"
echo CAUTION: this removes only the XAUAnalyzerHTTPS proxy service and dedicated firewall rules.
set /p ANSWER=Type YES to uninstall HTTPS proxy: 
if /I not "%ANSWER%"=="YES" exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall_https_ip.ps1"
pause

# Diagnostic only: reads status; does not change Windows configuration.
$ErrorActionPreference = 'Continue'
$service = Get-Service -Name 'XAUAnalyzerHTTPS' -ErrorAction SilentlyContinue
Write-Host '=== XAU Analyzer HTTPS / IP diagnostic ==='
if ($service) { Write-Host ('HTTPS service: ' + $service.Status) }
else { Write-Host 'HTTPS service: NOT INSTALLED' }
$cfg = Join-Path $env:ProgramData 'XAUAnalyzer\CaddyData\Caddyfile'
$ip = $null
if (Test-Path -LiteralPath $cfg) {
    $text = Get-Content -LiteralPath $cfg -Raw -Encoding ASCII
    if ($text -match '(?m)^\s*default_sni\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$') { $ip = $Matches[1] }
    Write-Host ('Configured VPS IPv4: ' + $ip)
} else { Write-Host 'Caddyfile is missing.' }
$listeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
    Where-Object { $_.LocalPort -in @(80,443,8765) })
foreach ($item in ($listeners | Sort-Object LocalPort,LocalAddress -Unique)) {
    Write-Host ("LISTEN TCP $($item.LocalAddress):$($item.LocalPort) PID=$($item.OwningProcess)")
}
if ($listeners | Where-Object { $_.LocalPort -eq 8765 -and $_.LocalAddress -notin @('127.0.0.1','::1') }) {
    Write-Host 'WARNING: port 8765 is not loopback-only. Set WEB_HOST=127.0.0.1 and restart Python.' -ForegroundColor Red
}
try {
    $resp = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/' -TimeoutSec 5
    Write-Host ('Local analyzer HTTP: ' + [int]$resp.StatusCode)
} catch {
    if ($_.Exception.Response) {
        Write-Host ('Local analyzer HTTP: ' + [int]$_.Exception.Response.StatusCode + ' (401 means auth works)')
    } else { Write-Host ('Local analyzer: OFFLINE (' + $_.Exception.Message + ')') }
}
if ($ip) {
    try {
        $resp = Invoke-WebRequest -UseBasicParsing -Uri "https://$ip/" -TimeoutSec 10
        Write-Host ('Public HTTPS: ' + [int]$resp.StatusCode)
    } catch {
        if ($_.Exception.Response) {
            Write-Host ('Public HTTPS: ' + [int]$_.Exception.Response.StatusCode + ' (401 is normal without password)')
        } else { Write-Host ('Public HTTPS not verified: ' + $_.Exception.Message) }
    }
    $tcp = $null
    $tls = $null
    try {
        $tcp = New-Object Net.Sockets.TcpClient
        $tcp.ReceiveTimeout = 7000
        $tcp.SendTimeout = 7000
        $tcp.Connect($ip,443)
        $tls = New-Object Net.Security.SslStream($tcp.GetStream(),$false,({
            param($sender,$certificate,$chain,$errors)
            return ($errors -eq [Net.Security.SslPolicyErrors]::None)
        }))
        $tls.AuthenticateAsClient($ip)
        $cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($tls.RemoteCertificate)
        Write-Host ('Certificate subject: ' + $cert.Subject)
        Write-Host ('Certificate expires: ' + $cert.NotAfter.ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss') + ' UTC')
    } catch { Write-Host ('TLS handshake not verified: ' + $_.Exception.Message) }
    finally {
        if ($tls) { $tls.Dispose() }
        if ($tcp) { $tcp.Dispose() }
    }
}
Write-Host 'Check provider firewall for inbound TCP 80/443. Phone test must be from a DIFFERENT network.'

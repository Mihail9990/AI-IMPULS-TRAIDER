@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo  XAU Analyzer - public IP HTTPS setup
 echo ==============================================
echo Run this file AS ADMINISTRATOR on your Windows VPS.
echo Your .env must have WEB_HOST=127.0.0.1, WEB_PORT=8765.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_https_ip.ps1"
if errorlevel 1 (
  echo.
  echo SETUP FAILED. See the reason above. No existing bots were stopped.
) else (
  echo.
  echo HTTPS proxy service has been installed. See HTTPS_IP_README.md.
)
pause

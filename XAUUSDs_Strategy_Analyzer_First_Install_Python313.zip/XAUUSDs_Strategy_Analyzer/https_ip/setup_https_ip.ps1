# Public-IP HTTPS installer for XAUUSD.s Strategy Analyzer on Windows Server.
# Run elevated. Only the dedicated XAUAnalyzerHTTPS service and XAU-specific firewall rules are changed.
# No changes are made to MT5 or to any existing trading bots.
[CmdletBinding()]
param([string]$PublicIP = '')
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$serviceName = 'XAUAnalyzerHTTPS'
$version = '2.11.7'
$archiveHash = '0A1EDC0B799512051C57071CE0E798D3F2CF67DC98171366F1D2B326072E3B06'
$downloadURL = "https://github.com/caddyserver/caddy/releases/download/v$version/caddy_${version}_windows_amd64.zip"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$envFile = Join-Path $projectRoot '.env'
$binDir = Join-Path $env:ProgramData 'XAUAnalyzer\CaddyBin'
$exePath = Join-Path $binDir 'caddy.exe'
$configPath = Join-Path $env:ProgramData 'XAUAnalyzer\CaddyData\Caddyfile'
$archivePath = Join-Path $binDir "caddy_$version.zip"
$storagePath = Join-Path $env:ProgramData 'XAUAnalyzer\CaddyData'

function Assert-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Please right-click install_https_ip.bat and choose Run as administrator.'
    }
}
function Get-EnvValue([string]$name) {
    $lines = @(Get-Content -LiteralPath $envFile -Encoding UTF8)
    foreach ($line in $lines) {
        if ($line -match ('^\s*' + [regex]::Escape($name) + '\s*=\s*(.*?)\s*$')) {
            return $Matches[1].Trim('"', "'", ' ')
        }
    }
    return $null
}
function Assert-ReadyEnvironment {
    if (-not (Test-Path -LiteralPath $envFile)) {
        throw ('Cannot find ' + $envFile + '. First run install_windows.bat and edit .env.')
    }
    $pw = Get-EnvValue 'WEB_PASSWORD'
    if (-not $pw -or $pw.Length -lt 16 -or $pw.StartsWith('REPLACE_')) {
        throw 'WEB_PASSWORD in .env must be a UNIQUE password with 16+ characters. Keep it private.'
    }
    $bind = Get-EnvValue 'WEB_HOST'
    if ($bind -ne '127.0.0.1') {
        throw ('WEB_HOST must be 127.0.0.1, but it is ' + $bind + '. Do not publicly bind port 8765.')
    }
    $port = Get-EnvValue 'WEB_PORT'
    if ($port -ne '8765') {
        throw ('WEB_PORT must be 8765, but it is ' + $port + '. This installer proxies to localhost:8765.')
    }
    if (-not (Test-Path -LiteralPath (Join-Path $projectRoot '.venv\Scripts\python.exe'))) {
        throw 'Python environment missing. Run install_windows.bat first.'
    }
}
function Assert-PublicIPv4([string]$value) {
    $addr = $null
    if (-not [Net.IPAddress]::TryParse($value, [ref]$addr) -or
        $addr.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or
        $addr.ToString() -ne $value) {
        throw 'Enter a valid public IPv4 address such as 12.34.56.78 (no port).'
    }
    $b = $addr.GetAddressBytes()
    $a = [int]$b[0]; $c = [int]$b[1]; $d = [int]$b[2]
    if ($a -eq 0 -or $a -eq 10 -or $a -eq 127 -or $a -ge 224 -or
        ($a -eq 169 -and $c -eq 254) -or
        ($a -eq 172 -and $c -ge 16 -and $c -le 31) -or
        ($a -eq 192 -and $c -eq 168) -or
        ($a -eq 100 -and $c -ge 64 -and $c -le 127) -or
        ($a -eq 198 -and $c -ge 18 -and $c -le 19) -or
        ($a -eq 192 -and $c -eq 0 -and $d -eq 2) -or
        ($a -eq 198 -and $c -eq 51 -and $d -eq 100) -or
        ($a -eq 203 -and $c -eq 0 -and $d -eq 113)) {
        throw 'The address is private, reserved, or an example address; a publicly reachable VPS IPv4 is required.'
    }
}
function Assert-PortsFree {
    # Never disrupt MT5, IIS or existing proxy services that could use these ports.
    $listeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
        Where-Object { $_.LocalPort -eq 80 -or $_.LocalPort -eq 443 })
    if ($listeners.Count -gt 0) {
        $owners = ($listeners | ForEach-Object {
            "port=$($_.LocalPort) PID=$($_.OwningProcess) address=$($_.LocalAddress)"
        } | Sort-Object -Unique) -join '; '
        throw ('TCP 80/443 is already in use: ' + $owners + '. Resolve the conflict manually; nothing will be stopped.')
    }
}
function Install-VerifiedCaddy {
    New-Item -ItemType Directory -Path $binDir -Force | Out-Null
    & icacls.exe $binDir /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /T | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not protect the executable directory ACL.' }
    if (Test-Path -LiteralPath $exePath) {
        $verText = (& $exePath version 2>&1 | Out-String)
        if ($LASTEXITCODE -eq 0 -and $verText -match '^v2\.11\.7') {
            Write-Host 'Caddy v2.11.7 already present.'
            return
        }
    }
    if (-not (Test-Path -LiteralPath $archivePath)) {
        Write-Host ('Downloading official Caddy ' + $version + ' from GitHub...')
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $downloadURL -OutFile $archivePath
    }
    $actualHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actualHash -ne $archiveHash) {
        Remove-Item -LiteralPath $archivePath -Force -ErrorAction SilentlyContinue
        throw 'Caddy SHA256 mismatch! Download discarded; no executable was installed.'
    }
    $extractDir = Join-Path $binDir 'extracted'
    if (Test-Path -LiteralPath $extractDir) { Remove-Item $extractDir -Recurse -Force }
    Expand-Archive -LiteralPath $archivePath -DestinationPath $extractDir -Force
    $foundExe = Get-ChildItem -LiteralPath $extractDir -Recurse -File -Filter 'caddy.exe' | Select-Object -First 1
    if ($null -eq $foundExe) { throw 'Official Caddy zip does not contain caddy.exe.' }
    Copy-Item -LiteralPath $foundExe.FullName -Destination $exePath -Force
    Remove-Item $extractDir -Recurse -Force
    $newVersion = (& $exePath version | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $newVersion -notmatch '^v2\.11\.7') {
        throw ('Unexpected Caddy binary version: ' + $newVersion)
    }
    Write-Host ('Caddy verified: ' + $newVersion)
}
function Write-CaddyConfig([string]$ip) {
    New-Item -ItemType Directory -Path $storagePath -Force | Out-Null
    # TLS private keys should be readable only by SYSTEM and local Administrators.
    & icacls.exe $storagePath /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /T | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not protect the certificate directory ACL.' }
    $forwardPath = $storagePath.Replace('\','/')
    $template = @'
{
    default_sni __PUBLIC_IPV4__
    admin 127.0.0.1:2019
    storage file_system __STORAGE_PATH__
    log {
        output file __STORAGE_PATH__/caddy.log {
            roll_size 10MiB
            roll_keep 5
            roll_keep_for 168h
        }
        level INFO
    }
}

__PUBLIC_IPV4__ {
    tls {
        issuer acme https://acme-v02.api.letsencrypt.org/directory {
            profile shortlived
            disable_tlsalpn_challenge
        }
    }
    encode gzip
    header {
        X-Content-Type-Options nosniff
        X-Frame-Options DENY
        Referrer-Policy no-referrer
    }
    reverse_proxy 127.0.0.1:8765
}
'@
    $config = $template.Replace('__PUBLIC_IPV4__', $ip).Replace('__STORAGE_PATH__', $forwardPath)
    $config | Set-Content -LiteralPath $configPath -Encoding ASCII
    & $exePath validate --config $configPath --adapter caddyfile
    if ($LASTEXITCODE -ne 0) { throw 'Caddy configuration validation failed. Service was not created.' }
}
function Add-FirewallRules {
    $rules = @(
        @{ Name='XAU Analyzer HTTPS 443'; Protocol='TCP'; Port=443; Action='Allow' },
        @{ Name='XAU Analyzer ACME HTTP 80'; Protocol='TCP'; Port=80; Action='Allow' },
        @{ Name='XAU Analyzer DENY backend 8765'; Protocol='TCP'; Port=8765; Action='Block' }
    )
    foreach ($r in $rules) {
        if (-not (Get-NetFirewallRule -DisplayName $r.Name -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName $r.Name -Direction Inbound -Action $r.Action `
                -Protocol $r.Protocol -LocalPort $r.Port -Profile Any | Out-Null
        }
    }
}

try {
    Write-Host '=== XAU Strategy Analyzer HTTPS / IP setup ==='
    Assert-Administrator
    Assert-ReadyEnvironment
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        throw ("Service $serviceName already exists. Do not create duplicates; see HTTPS_IP_README.md.")
    }
    if (-not $PublicIP) { $PublicIP = Read-Host 'Enter public IPv4 of your Windows VPS' }
    Assert-PublicIPv4 $PublicIP
    Assert-PortsFree
    Install-VerifiedCaddy
    Write-CaddyConfig $PublicIP
    Add-FirewallRules
    $binaryPath = ('"{0}" run --config "{1}" --adapter caddyfile' -f $exePath, $configPath)
    New-Service -Name $serviceName -BinaryPathName $binaryPath -DisplayName 'XAU Strategy Analyzer HTTPS (Caddy)' -StartupType Automatic | Out-Null
    Start-Service -Name $serviceName -ErrorAction Stop
    Start-Sleep -Seconds 2
    $state = (Get-Service -Name $serviceName).Status
    Write-Host ('Service status: ' + $state)
    if ($state -ne 'Running') { throw 'Caddy service failed to stay running. Check Caddy log.' }
    Write-Host ''
    Write-Host ('Secure address: https://' + $PublicIP)
    Write-Host 'Open TCP 80 and 443 in your VPS provider firewall too (not only Windows Firewall).'
    Write-Host 'Start the Python analyzer separately. Do NOT expose TCP 8765 to the internet.'
    Write-Host ('Caddy log: ' + (Join-Path $storagePath 'caddy.log'))
    Write-Host "Wait until the Let's Encrypt certificate is obtained before testing the phone browser."
    Write-Host 'Run check_https_ip.bat to verify the service and TLS.'
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}

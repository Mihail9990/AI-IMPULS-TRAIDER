@echo off
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set LOG_LEVEL=warning
"%~dp0.venv\Scripts\python.exe" "%~dp0run.py" >> "%~dp0logs\analyzer-task.log" 2>&1

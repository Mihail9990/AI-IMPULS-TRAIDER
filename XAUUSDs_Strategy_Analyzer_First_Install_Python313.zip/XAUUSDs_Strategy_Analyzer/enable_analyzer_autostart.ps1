# Optional: start the Python analyzer when THIS Windows user logs in.
# MT5 GUI/account must also be accessible in the same interactive user session.
$ErrorActionPreference='Stop'
$root=(Resolve-Path $PSScriptRoot).Path
if (-not (Test-Path (Join-Path $root '.venv\Scripts\python.exe'))) { throw 'Run install_windows.bat first.' }
if (-not (Test-Path (Join-Path $root '.env'))) { throw 'Configure .env first.' }
$launcher=Join-Path $root 'run_analyzer_task.cmd'
$user=[Security.Principal.WindowsIdentity]::GetCurrent().Name
$taskName='XAU Strategy Analyzer (user logon)'
$trigger=New-ScheduledTaskTrigger -AtLogOn -User $user
$action=New-ScheduledTaskAction -Execute 'cmd.exe' -Argument ('/d /s /c ""{0}""' -f $launcher) -WorkingDirectory $root
$principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([timespan]::Zero) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Write-Host ('Registered autostart for ' + $user + '. Task: ' + $taskName)
Write-Host 'It starts at user logon, NOT before login. MT5 must be available to that user.'
Write-Host 'Stop any already-running run.py before manually starting the scheduled task.'

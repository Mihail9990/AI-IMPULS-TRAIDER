@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Python environment not found. Run install_windows.bat first.
  pause
  exit /b 1
)
if not exist .env (
  echo Missing .env. Run install_windows.bat, then set WEB_PASSWORD.
  pause
  exit /b 1
)
.venv\Scripts\python.exe run.py
 echo Server stopped.
pause

@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_RECOVERY_V4_UI_v1_9_1.ps1"
if errorlevel 1 (
  echo.
  echo UPDATE FAILED. Previous analyzer files should remain unchanged.
) else (
  echo.
  echo Installer finished. Read the output above for confirmation.
)
pause

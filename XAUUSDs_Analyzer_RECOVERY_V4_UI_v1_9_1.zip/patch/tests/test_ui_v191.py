"""UI v1.9.1 smoke checks — no changes to order logic or historical stored records."""
from pathlib import Path
from fastapi.testclient import TestClient
import pytest
import analyzer.server as server


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('WEB_PASSWORD','local-only-unique-pass-for-ui-v191')
    monkeypatch.setenv('DATA_SOURCE','demo')
    monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as c:
        yield c


def test_new_navigation_without_mass_test_interface(client):
    response=client.get('/',auth=('admin','local-only-unique-pass-for-ui-v191'))
    assert response.status_code==200
    text=response.text
    for tab in ('live','settings','insights','history'):
        assert f'data-tab="{tab}"' in text
        assert f'id="tab-{tab}"' in text
    assert 'id="tab-backtest"' not in text
    assert 'id="backtestForm"' not in text
    assert 'id="tradeCount"' not in text
    assert 'id="nearTPStats"' not in text
    assert text.count('id="btnClearStatistics"')==1
    assert 'id="clearStatsDialog"' in text
    assert 'id="smartTpTargets"' in text
    assert 'id="smartM5"' in text and 'id="smartM15"' in text
    assert '/assets/app.js?v=1.9.1' in text


def test_smart_tp_display_uses_existing_engine_state_and_closed_candles():
    text=(Path(__file__).resolve().parent.parent/'web'/'app.js').read_text(encoding='utf-8')
    assert 'c.time+60<=nowSeconds' in text
    assert "leg.v3_tp_regime" in text
    assert "leg.v3_tp_targets" in text
    assert "settings.recovery_v3_smart_tp_enabled" in text
    assert "refreshVariants" not in text
    assert "submitBacktest" not in text


def test_reversed_pan_isolated_from_pending_stop_drag():
    text=(Path(__file__).resolve().parent.parent/'web'/'app.js').read_text(encoding='utf-8')
    assert 'app.rightOffset=Math.max(0,g.right+(e.clientX-g.x)/Math.max(step,1))' in text
    assert "g.line?.kind==='move'" in text
    assert 'app.previewLevel=chartPriceFromClient(e.clientY)' in text


def test_server_keeps_auth_and_reset_endpoint(client):
    assert client.get('/').status_code==401
    assert client.post('/api/statistics/reset',json={'confirmation':'CLEAR'}).status_code==401
    creds=('admin','local-only-unique-pass-for-ui-v191')
    assert client.get('/api/status',auth=creds).status_code==200
    assert client.get('/api/chart',auth=creds).status_code==200

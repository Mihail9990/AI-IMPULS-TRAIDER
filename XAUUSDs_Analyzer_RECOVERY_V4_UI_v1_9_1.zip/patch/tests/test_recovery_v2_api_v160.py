import time
import pytest
from fastapi.testclient import TestClient
import analyzer.server as server

AUTH=('admin','test-pass-for-rec-v2-long')

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('WEB_PASSWORD',AUTH[1]);monkeypatch.setenv('WEB_USERNAME','admin')
    monkeypatch.setenv('DATA_SOURCE','demo');monkeypatch.setenv('DATA_DIR',str(tmp_path))
    with TestClient(server.app) as c:yield c


def test_v2_api_settings_persist_and_old_mode_still_selectable(client):
    payload=dict(trigger_distance=1.0,tp_distance=.25,sl_distance=3.0,
                 recovery_enabled=True,recovery_variant='extreme',
                 volume_lots=.03,recovery_v2_initial_lots=.03,recovery_v2_work_lots=.05,
                 recovery_v2_trigger_distance=1.5,recovery_v2_initial_tp_distance=.33,
                 recovery_v2_initial_sl_distance=.80,recovery_v2_support_sl_distance=1.30,
                 recovery_v2_trail_step=.15,recovery_v2_reentry_offset=.75,
                 recovery_v2_opposite_max_range=0)
    assert client.post('/api/settings',json=payload).status_code==401
    r=client.post('/api/settings',json=payload,auth=AUTH)
    assert r.status_code==200,r.text
    d=client.get('/api/status',auth=AUTH).json()['settings']
    for field,val in payload.items():
        assert d[field]==val,(field,d[field],val)
    html=client.get('/',auth=AUTH).text
    for field in ['recovery_variant','recovery_v2_reentry_offset',
                  'recovery_v2_trail_step','recovery_v2_initial_sl_distance']:
        assert f'name="{field}"' in html
    assert '/assets/app.js?v=1.9.1' in html
    wrong=dict(payload,volume_lots=.01)
    assert client.post('/api/settings',json=wrong,auth=AUTH).status_code==409
    old=dict(payload,recovery_variant='classic',volume_lots=.01)
    assert client.post('/api/settings',json=old,auth=AUTH).status_code==200
    assert client.get('/api/status',auth=AUTH).json()['settings']['recovery_variant']=='classic'


def test_v2_backtest_full_pipeline_and_distances(client):
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',
       distances=[.8],tps=[.25],sls=[1.0],volume_lots=.03,recovery_enabled=True,
       recovery_variant='extreme',recovery_trail_offsets=[.8,1.0],
       recovery_v2_reentry_offsets=[.5,.75],recovery_v2_trail_steps=[.1],
       recovery_v2_work_lots=.03,recovery_v2_opposite_max_range=0)
    res=client.post('/api/backtests',json=payload,auth=AUTH)
    assert res.status_code==200,res.text
    job_id=res.json()['id']
    deadline=time.monotonic()+24
    while time.monotonic()<deadline:
        job=client.get('/api/backtests/'+job_id,auth=AUTH).json()
        if job['status'] in ('completed','failed'):break
        time.sleep(.07)
    assert job['status']=='completed',job['error']
    variants=client.get(f'/api/backtests/{job_id}/variants',auth=AUTH).json()
    assert len(variants)==4
    assert {v['config']['recovery_v2_reentry_offset'] for v in variants}=={.5,.75}
    assert {v['config']['recovery_v2_support_sl_distance'] for v in variants}=={.8,1.0}
    assert all(v['config']['recovery_variant']=='extreme' for v in variants)
    assert all('unresolved_recovery' in v['summary'] for v in variants)


def test_v2_backtest_max_combinations_blocked(client):
    payload=dict(start_date='2026-10-22',end_date='2026-10-22',
       distances=[.8],tps=[.25],sls=[1.0],volume_lots=.03,recovery_enabled=True,
       recovery_variant='extreme',recovery_trail_offsets=[1.0],
       recovery_v2_reentry_offsets=[.5,.75],recovery_v2_trail_steps=[.1],
       recovery_v2_work_lots=.03,recovery_v2_opposite_max_range=-1)
    assert client.post('/api/backtests',json=payload,auth=AUTH).status_code==422
